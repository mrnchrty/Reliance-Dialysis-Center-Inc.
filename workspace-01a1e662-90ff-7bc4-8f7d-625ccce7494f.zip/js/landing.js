/**
 * Reliance Dialysis Center Inc. — Public Landing Page Script
 * Navigation scroll-spy, mobile drawer, session-aware Login/Portal link, and Reliance Assistant chatbot.
 */

import { resolveAuthenticatedContext, getPanelUrlForRole } from './authGuard.js';
import { mountRelianceChatbot } from './components/chatbot.js';

async function initLandingPage() {
  mountRelianceChatbot();

  // Mobile Menu Toggle
  const toggleBtn = document.getElementById('mobile-menu-toggle');
  const navLinks = document.getElementById('public-nav-links');
  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => navLinks.classList.remove('open'));
    });
  }

  // Highlight active section in red on scroll / click
  const spyLinks = Array.from(document.querySelectorAll('.nav-spy-link'));
  const sections = ['home', 'about', 'services']
    .map(id => document.getElementById(id))
    .filter(Boolean);

  function updateActiveNav() {
    const scrollPos = window.scrollY + 180;
    let currentId = 'home';
    for (const sec of sections) {
      if (sec.offsetTop <= scrollPos) {
        currentId = sec.id;
      }
    }
    spyLinks.forEach(a => {
      a.classList.toggle('active', a.dataset.section === currentId);
    });
  }

  window.addEventListener('scroll', updateActiveNav, { passive: true });
  updateActiveNav();

  // If visitor is already authenticated, update Login & Booking buttons to take them directly to their panel
  try {
    const ctx = await resolveAuthenticatedContext();
    if (ctx) {
      const targetUrl = getPanelUrlForRole(ctx.role);
      const navAuth = document.getElementById('nav-auth-link');
      if (navAuth) {
        navAuth.textContent = ctx.role === 'patient' ? 'My Portal' : ctx.role === 'staff' ? 'Staff Panel' : 'Admin Panel';
        navAuth.href = targetUrl;
      }
      document.querySelectorAll('.booking-cta-btn').forEach(btn => {
        btn.href = ctx.role === 'patient' ? '/patient.html#book' : targetUrl;
      });
    }
  } catch {
    // Visitor remains unauthenticated
  }
}

initLandingPage();
