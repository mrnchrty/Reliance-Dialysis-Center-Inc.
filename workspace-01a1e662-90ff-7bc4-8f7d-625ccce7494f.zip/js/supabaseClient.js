/**
 * Reliance Dialysis Center Inc. — Centralized Supabase Client Module
 * Connects all four panels (Public, Patient, Staff, Super Admin) to one Supabase project.
 * Never exposes service-role keys in frontend code.
 */

import { createClient } from '../assets/vendor/supabase.esm.js';

export const SUPABASE_URL = 'https://aoeexkzhdottbepqfmfv.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFvZWV4a3poZG90dGJlcHFmbWZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQzNzY1MTUsImV4cCI6MjEwOTk1MjUxNX0.Mq9qoI-Qa7_Mo9M5vf1GhF8HKT-SSkgtxGZDZ3YMQxc';
export const STORAGE_BUCKET = 'patient-documents';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'rdc_mabini_auth_session'
  }
});

export const REQUIRED_DOCUMENT_TYPES = [
  "Nephrologist's Endorsement",
  'Medical Abstract',
  'Latest Laboratory Results',
  'Valid Identification'
];

export const APPOINTMENT_STATUSES = [
  'Pending',
  'Under Review',
  'Confirmed',
  'Rejected'
];

export const DEFAULT_CLINIC_CONFIG = {
  operating_days: [1, 2, 3, 4, 5, 6], // Monday - Saturday (Closed Sunday = 0)
  operating_hours: { open: '08:00', close: '17:00' },
  max_advance_days: 60,
  allow_recurring_generation: true,
  time_slots: [
    { id: 'Morning', label: 'Morning', display: '8:00 AM–11:00 AM', start_time: '08:00', end_time: '11:00' },
    { id: 'Midday', label: 'Midday', display: '11:00 AM–2:00 PM', start_time: '11:00', end_time: '14:00' },
    { id: 'Afternoon', label: 'Afternoon', display: '2:00 PM–5:00 PM', start_time: '14:00', end_time: '17:00' }
  ]
};

/**
 * Retrieve clinic schedule configuration from Supabase RPC (with graceful fallback)
 */
export async function fetchClinicConfig() {
  try {
    const { data, error } = await supabase.rpc('get_clinic_schedule_config');
    if (error || !data) return structuredClone(DEFAULT_CLINIC_CONFIG);
    return {
      ...DEFAULT_CLINIC_CONFIG,
      ...data,
      time_slots: Array.isArray(data.time_slots) && data.time_slots.length > 0
        ? data.time_slots
        : DEFAULT_CLINIC_CONFIG.time_slots
    };
  } catch {
    return structuredClone(DEFAULT_CLINIC_CONFIG);
  }
}

/**
 * Record an audit log event via secure SECURITY DEFINER RPC
 */
export async function recordAudit(activity, affectedModule, affectedRecordId = null, details = {}) {
  try {
    await supabase.rpc('log_audit_event', {
      p_activity: activity,
      p_module: affectedModule,
      p_record_id: affectedRecordId ? String(affectedRecordId) : null,
      p_details: details || {}
    });
  } catch (err) {
    console.warn('Audit log skipped:', err?.message || err);
  }
}

/**
 * Notify all active clinic staff via secure RPC
 */
export async function notifyStaff(title, message, type = 'Appointment', appointmentId = null) {
  try {
    await supabase.rpc('notify_all_staff', {
      p_title: title,
      p_message: message,
      p_type: type,
      p_appointment_id: appointmentId
    });
  } catch (err) {
    console.warn('Staff notification warning:', err?.message || err);
  }
}

/**
 * Send a notification to a specific user_id in public.notifications
 */
export async function sendUserNotification(recipientUserId, title, message, type = 'System', relatedAppointmentId = null) {
  if (!recipientUserId) return;
  const { error } = await supabase.from('notifications').insert({
    recipient_user_id: recipientUserId,
    title,
    message,
    notification_type: type,
    related_appointment_id: relatedAppointmentId
  });
  if (error) console.warn('Notification insert error:', error.message);
}
