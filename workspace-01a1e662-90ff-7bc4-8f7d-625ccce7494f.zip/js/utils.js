/**
 * Reliance Dialysis Center Inc. — Shared Utilities & Formatters
 */

export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function formatDate(dateStr, opts = { month: 'short', day: 'numeric', year: 'numeric' }) {
  if (!dateStr) return '—';
  const clean = String(dateStr).length === 10 ? `${dateStr}T00:00:00` : dateStr;
  const d = new Date(clean);
  if (Number.isNaN(d.getTime())) return String(dateStr);
  return d.toLocaleDateString('en-PH', opts);
}

export function formatDateTime(isoStr) {
  if (!isoStr) return '—';
  const d = new Date(isoStr);
  if (Number.isNaN(d.getTime())) return String(isoStr);
  return d.toLocaleString('en-PH', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

export function formatTime12h(timeStr) {
  if (!timeStr) return '—';
  const parts = String(timeStr).split(':');
  if (parts.length < 2) return timeStr;
  let h = parseInt(parts[0], 10);
  const m = parts[1];
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${m} ${ampm}`;
}

export function formatTimeRange(startTime, endTime) {
  if (!startTime || !endTime) return '—';
  return `${formatTime12h(startTime)}–${formatTime12h(endTime)}`;
}

export function getTodayISO() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function toISODate(dateObj) {
  const y = dateObj.getFullYear();
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  const d = String(dateObj.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function formatFileSize(bytes) {
  if (!bytes || Number.isNaN(Number(bytes))) return '—';
  const n = Number(bytes);
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

export function statusBadgeHtml(status, isCancelled = false) {
  if (isCancelled) {
    return `<span class="badge badge-status-${slugify(status)}">${escapeHtml(status)}</span> <span class="badge badge-cancelled" title="Recorded cancellation action">Cancelled</span>`;
  }
  return `<span class="badge badge-status-${slugify(status)}">${escapeHtml(status)}</span>`;
}

export function docBadgeHtml(status) {
  return `<span class="badge badge-doc-${slugify(status)}">${escapeHtml(status || 'Not Uploaded')}</span>`;
}

export function machineBadgeHtml(status) {
  return `<span class="badge badge-machine-${slugify(status)}">${escapeHtml(status)}</span>`;
}

export function slugify(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

/**
 * Evaluate profile completeness percentage & missing fields for a patient
 */
export function evaluateProfileCompletion(patient, medicalProfile) {
  const requiredPersonal = [
    { key: 'full_name', label: 'Full Name', val: patient?.full_name },
    { key: 'date_of_birth', label: 'Date of Birth', val: patient?.date_of_birth },
    { key: 'sex', label: 'Sex', val: patient?.sex },
    { key: 'address', label: 'Complete Address', val: patient?.address },
    { key: 'contact_number', label: 'Contact Number', val: patient?.contact_number },
    { key: 'emergency_contact_name', label: 'Emergency Contact Name', val: patient?.emergency_contact_name },
    { key: 'emergency_contact_number', label: 'Emergency Contact Number', val: patient?.emergency_contact_number }
  ];

  const requiredMedical = [
    { key: 'height', label: 'Height', val: medicalProfile?.height },
    { key: 'weight', label: 'Weight', val: medicalProfile?.weight },
    { key: 'blood_type', label: 'Blood Type', val: medicalProfile?.blood_type },
    { key: 'allergies', label: 'Known Allergies', val: medicalProfile?.allergies },
    { key: 'diagnosis', label: 'Medical Diagnosis / Kidney Condition', val: medicalProfile?.diagnosis },
    { key: 'existing_medical_conditions', label: 'Existing Medical Conditions', val: medicalProfile?.existing_medical_conditions },
    { key: 'current_medications', label: 'Current Medications', val: medicalProfile?.current_medications },
    { key: 'attending_nephrologist', label: 'Attending Nephrologist', val: medicalProfile?.attending_nephrologist },
    { key: 'prescribed_dialysis_frequency', label: 'Prescribed Dialysis Frequency', val: medicalProfile?.prescribed_dialysis_frequency }
  ];

  const all = [...requiredPersonal, ...requiredMedical];
  const filled = all.filter(item => item.val !== null && item.val !== undefined && String(item.val).trim() !== '');
  const missing = all.filter(item => item.val === null || item.val === undefined || String(item.val).trim() === '');
  const percentage = Math.round((filled.length / all.length) * 100);

  return {
    isComplete: missing.length === 0,
    percentage,
    missingFields: missing.map(m => m.label),
    personalComplete: requiredPersonal.every(i => i.val && String(i.val).trim() !== ''),
    medicalComplete: requiredMedical.every(i => i.val !== null && i.val !== undefined && String(i.val).trim() !== '')
  };
}
