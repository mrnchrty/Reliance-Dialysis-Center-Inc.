/**
 * Reliance Dialysis Center Inc. — Centralized Authentication & Role Resolution
 */

import { supabase, recordAudit } from './supabaseClient.js';

/**
 * Determine the authenticated user's role & profile record from Staff / Patients tables
 */
export async function resolveAuthenticatedContext() {
  const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
  if (sessionErr || !sessionData?.session?.user) {
    return null;
  }

  const user = sessionData.session.user;

  // 1. Check Staff table first (staff or super_admin)
  const { data: staffRow } = await supabase
    .from('staff')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle();

  if (staffRow && staffRow.account_status === 'Active') {
    return {
      user,
      role: staffRow.role === 'super_admin' ? 'super_admin' : 'staff',
      staff: staffRow,
      patient: null,
      displayName: staffRow.full_name || user.email
    };
  }

  if (staffRow && staffRow.account_status === 'Inactive') {
    // Check if user also has an active patient profile; otherwise account is deactivated
    const { data: patCheck } = await supabase
      .from('patients')
      .select('*')
      .eq('user_id', user.id)
      .eq('account_status', 'Active')
      .maybeSingle();

    if (!patCheck) {
      await supabase.auth.signOut();
      throw new Error('Your account has been deactivated by an administrator. Please contact Reliance Dialysis Center Inc.');
    }
  }

  // 2. Check Patients table
  let { data: patientRow } = await supabase
    .from('patients')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle();

  // Ensure patient row exists if signed up as patient
  if (!patientRow) {
    const fallbackName = user.user_metadata?.full_name || user.email?.split('@')[0] || 'Patient';
    const { data: inserted, error: insertErr } = await supabase
      .from('patients')
      .insert({
        user_id: user.id,
        email: user.email,
        full_name: fallbackName
      })
      .select('*')
      .single();

    if (!insertErr && inserted) {
      patientRow = inserted;
    }
  }

  if (patientRow && patientRow.account_status === 'Inactive') {
    await supabase.auth.signOut();
    throw new Error('Your patient account is currently inactive. Please contact the clinic front desk.');
  }

  return {
    user,
    role: 'patient',
    staff: null,
    patient: patientRow,
    displayName: patientRow?.full_name || user.user_metadata?.full_name || user.email
  };
}

/**
 * Redirect URL for each role
 */
export function getPanelUrlForRole(role) {
  if (role === 'super_admin') return '/admin.html';
  if (role === 'staff') return '/staff.html';
  return '/patient.html';
}

/**
 * Guard a protected panel page so users can only access their authorized role panel
 */
export async function requireRoleGuard(allowedRoles = ['patient']) {
  try {
    const ctx = await resolveAuthenticatedContext();
    if (!ctx) {
      window.location.replace('/auth.html');
      return null;
    }
    if (!allowedRoles.includes(ctx.role)) {
      window.location.replace(getPanelUrlForRole(ctx.role));
      return null;
    }
    return ctx;
  } catch (err) {
    sessionStorage.setItem('rdc_auth_flash', err.message || 'Authentication check failed.');
    window.location.replace('/auth.html');
    return null;
  }
}

/**
 * Sign out user cleanly and redirect to landing or auth page
 */
export async function signOutAndRedirect(target = '/auth.html') {
  try {
    await recordAudit('User Logged Out', 'Authentication');
  } catch {
    // ignore
  }
  await supabase.auth.signOut();
  window.location.replace(target);
}
