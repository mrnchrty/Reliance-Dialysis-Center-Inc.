/**
 * Reliance Dialysis Center Inc. — Staff Panel Modules 5–9:
 *   5. Recurring Appointment Management (Patient Medical Profiles + Appointments ONLY)
 *   6. Dialysis Machine Management (10 machines, status, schedules, maintenance, overlap protection)
 *   7. Dialysis Session Management (Record post-treatment session into dialysis_sessions)
 *   8. Medical Record Management (Profiles, Documents, Sessions, Authorized File Upload, Release Toggle — NO extra table)
 *   9. Staff Notifications
 */

import {
  supabase,
  STORAGE_BUCKET,
  recordAudit,
  sendUserNotification
} from '../supabaseClient.js';
import {
  escapeHtml,
  formatDate,
  formatDateTime,
  formatTimeRange,
  getTodayISO,
  toISODate,
  machineBadgeHtml,
  docBadgeHtml
} from '../utils.js';
import { showToast, openModal, closeModal } from '../components/toast.js';
import { previewStaffDocument } from './staffClinicalViews.js';

const WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DAY_INDEX = { Monday: 1, Tuesday: 2, Wednesday: 3, Thursday: 4, Friday: 5, Saturday: 6 };

/* 5. RECURRING APPOINTMENT MANAGEMENT */
export function renderStaffRecurring({ container, state, onRefresh }) {
  const slots = state.clinicConfig?.time_slots || [];

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Recurring Appointment Management</h1>
        <p class="page-subtitle">Configure approved recurring days &amp; preferred session times in Patient Medical Profiles and generate succeeding appointment requests for review.</p>
      </div>
    </div>

    <div class="card">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Patient</th>
              <th>Prescribed Frequency</th>
              <th>Approved Recurring Days</th>
              <th>Preferred Time</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${state.patients.map(p => {
              const med = state.medicalMap.get(p.patient_id) || {};
              const rDays = Array.isArray(med.recurring_days) ? med.recurring_days : [];
              return `
                <tr>
                  <td><strong>${escapeHtml(p.full_name)}</strong></td>
                  <td>${escapeHtml(med.prescribed_dialysis_frequency || 'Not set')}</td>
                  <td>${rDays.length ? escapeHtml(rDays.join(', ')) : '<span class="text-muted">Not configured</span>'}</td>
                  <td>${escapeHtml(med.preferred_time || '—')}</td>
                  <td>
                    <div style="display:flex; gap:0.4rem; flex-wrap:wrap;">
                      <button type="button" class="btn btn-outline-blue btn-xs cfg-rec-btn" data-pid="${escapeHtml(p.patient_id)}">
                        Configure Pattern
                      </button>
                      ${rDays.length > 0 ? `
                        <button type="button" class="btn btn-primary btn-xs gen-rec-btn" data-pid="${escapeHtml(p.patient_id)}">
                          Generate 2-Wk Requests
                        </button>
                      ` : ''}
                    </div>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.querySelectorAll('.cfg-rec-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const p = state.patients.find(x => x.patient_id === btn.dataset.pid);
      const med = state.medicalMap.get(p.patient_id) || {};
      const currentDays = Array.isArray(med.recurring_days) ? med.recurring_days : [];

      openModal({
        title: `Configure Recurring Schedule — ${p.full_name}`,
        bodyHtml: `
          <p class="text-muted" style="margin-top:0; font-size:0.86rem;">
            Prescribed Frequency: <strong>${escapeHtml(med.prescribed_dialysis_frequency || 'Not specified')}</strong> (kept distinct from approved recurring days).
          </p>
          <form id="staff-rec-cfg-form">
            <div class="form-group" style="margin-bottom:1rem;">
              <label class="form-label">Approved Operating Days (Mon–Sat) <span class="req">*</span></label>
              <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:0.5rem; margin-top:0.3rem;">
                ${WEEKDAYS.map(day => `
                  <label style="display:flex; align-items:center; gap:0.45rem; font-size:0.88rem;">
                    <input type="checkbox" name="rec_day" value="${day}" ${currentDays.includes(day) ? 'checked' : ''} />
                    <span>${day}</span>
                  </label>
                `).join('')}
              </div>
            </div>

            <div class="form-group" style="margin-bottom:1.1rem;">
              <label class="form-label">Approved Preferred Session Time <span class="req">*</span></label>
              <select id="rec-pref-time" class="form-control" required>
                ${slots.map(s => `
                  <option value="${escapeHtml(s.id)}" ${med.preferred_time === s.id ? 'selected' : ''}>${escapeHtml(s.label)} (${escapeHtml(s.display)})</option>
                `).join('')}
              </select>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;">Save Approved Recurring Pattern</button>
          </form>
        `,
        onMount: (mEl) => {
          mEl.querySelector('#staff-rec-cfg-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const chosenDays = Array.from(mEl.querySelectorAll('input[name="rec_day"]:checked')).map(c => c.value);
            const prefTime = mEl.querySelector('#rec-pref-time').value;

            const { error } = await supabase
              .from('patient_medical_profiles')
              .upsert({
                patient_id: p.patient_id,
                recurring_days: chosenDays,
                preferred_time: prefTime
              }, { onConflict: 'patient_id' });

            if (error) {
              showToast(error.message, 'error');
              return;
            }

            if (p.user_id) {
              await sendUserNotification(
                p.user_id,
                'Recurring Dialysis Pattern Configured',
                `Clinic staff configured your recurring schedule preference: ${chosenDays.join(', ') || 'Cleared'} (${prefTime}).`,
                'Recurring'
              );
            }
            await recordAudit('Configured Patient Recurring Schedule', 'Patient Medical Profiles', p.patient_id, {
              recurring_days: chosenDays,
              preferred_time: prefTime
            });

            closeModal();
            showToast('Recurring pattern saved.', 'success');
            await onRefresh();
            renderStaffRecurring({ container, state, onRefresh });
          });
        }
      });
    });
  });

  container.querySelectorAll('.gen-rec-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const p = state.patients.find(x => x.patient_id === btn.dataset.pid);
      const med = state.medicalMap.get(p.patient_id) || {};
      const rDays = Array.isArray(med.recurring_days) ? med.recurring_days : [];
      const prefTime = med.preferred_time || 'Morning';
      const targetNums = rDays.map(d => DAY_INDEX[d]).filter(Boolean);

      const existingDates = new Set(
        state.appointments
          .filter(a => a.patient_id === p.patient_id && !a.is_cancelled)
          .map(a => a.confirmed_date || a.requested_date)
      );

      const dates = [];
      const now = new Date();
      for (let i = 1; i <= 14; i++) {
        const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
        if (targetNums.includes(d.getDay())) {
          const iso = toISODate(d);
          if (!existingDates.has(iso)) dates.push(iso);
        }
      }

      if (dates.length === 0) {
        showToast('All matching dates in the next 14 days already have requests.', 'info');
        return;
      }

      const grp = crypto.randomUUID();
      const rows = dates.map(dt => ({
        patient_id: p.patient_id,
        requested_date: dt,
        requested_time: prefTime,
        appointment_status: 'Pending',
        is_recurring: true,
        recurrence_group_id: grp,
        status_history: [{
          status: 'Pending',
          timestamp: new Date().toISOString(),
          remarks: `Generated by clinical staff from recurring pattern (${rDays.join(', ')} • ${prefTime}). Ready for machine assignment in Appointment Management.`
        }]
      }));

      const { error } = await supabase.from('appointments').insert(rows);
      if (error) {
        showToast(error.message, 'error');
        return;
      }

      if (p.user_id) {
        await sendUserNotification(
          p.user_id,
          'Upcoming Recurring Requests Generated',
          `${rows.length} succeeding appointment request(s) (${dates.join(', ')}) were generated and are pending machine assignment.`,
          'Recurring'
        );
      }
      await recordAudit('Staff Generated Succeeding Recurring Requests', 'Appointments', grp, {
        patient_id: p.patient_id,
        dates
      });

      showToast(`Generated ${rows.length} Pending request(s). Review & assign machines in Appointment Management.`, 'success');
      await onRefresh();
      renderStaffRecurring({ container, state, onRefresh });
    });
  });
}

/* 6. DIALYSIS MACHINE MANAGEMENT */
export function renderStaffMachines({ container, state, onRefresh }) {
  let selectedScheduleDate = getTodayISO();

  function draw() {
    const daySlots = state.machineSlots.filter(s => s.schedule_date === selectedScheduleDate);

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Dialysis Machine Management</h1>
          <p class="page-subtitle">Monitor the 10 hemodialysis stations, view machine slot schedules, and mark stations for preventive maintenance.</p>
        </div>
        <div style="display:flex; align-items:center; gap:0.6rem;">
          <label class="form-label" style="margin:0;">Schedule Date:</label>
          <input type="date" id="mach-sched-date" class="form-control" style="width:auto;" value="${escapeHtml(selectedScheduleDate)}" />
        </div>
      </div>

      <div class="machines-grid">
        ${state.machines.map(m => {
          const mSlots = daySlots.filter(s => s.machine_id === m.machine_id && s.slot_status !== 'Cancelled');
          const cls = m.machine_status === 'Maintenance' ? 'maintenance' : m.machine_status === 'Offline' ? 'offline' : '';
          return `
            <div class="machine-station-card ${cls}">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.45rem;">
                <strong style="font-size:1.05rem; color:var(--reliance-blue);">${escapeHtml(m.machine_code)}</strong>
                ${machineBadgeHtml(m.machine_status)}
              </div>
              <div style="font-size:0.86rem; font-weight:600;">${escapeHtml(m.machine_name)}</div>
              <div class="text-muted" style="font-size:0.78rem; margin-bottom:0.65rem;">${escapeHtml(m.description || '')}</div>

              ${m.maintenance_remarks ? `
                <div style="font-size:0.78rem; background:#fff8e6; padding:0.4rem 0.55rem; border-radius:4px; margin-bottom:0.65rem;">
                  <strong>Maintenance:</strong> ${escapeHtml(m.maintenance_remarks)}
                </div>
              ` : ''}

              <div style="font-size:0.8rem; margin-bottom:0.75rem;">
                <strong>Slots on ${escapeHtml(formatDate(selectedScheduleDate))}:</strong>
                ${mSlots.length === 0 ? `<div class="text-muted">No booked slots</div>` : mSlots.map(sl => `
                  <div style="padding:0.2rem 0; border-bottom:1px dashed var(--border-subtle);">
                    ${escapeHtml(formatTimeRange(sl.start_time, sl.end_time))} • <strong>${escapeHtml(sl.slot_status)}</strong>
                  </div>
                `).join('')}
              </div>

              <button type="button" class="btn btn-outline-blue btn-xs upd-machine-btn" data-mid="${escapeHtml(m.machine_id)}" style="width:100%;">
                Update Operational Status
              </button>
            </div>
          `;
        }).join('')}
      </div>
    `;

    container.querySelector('#mach-sched-date')?.addEventListener('change', (e) => {
      selectedScheduleDate = e.target.value;
      draw();
    });

    container.querySelectorAll('.upd-machine-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const m = state.machines.find(x => x.machine_id === btn.dataset.mid);
        if (!m) return;
        openModal({
          title: `Update Station — ${m.machine_code}`,
          size: 'sm',
          bodyHtml: `
            <form id="upd-mach-form">
              <div class="form-group" style="margin-bottom:0.9rem;">
                <label class="form-label">Operational Status <span class="req">*</span></label>
                <select id="um-status" class="form-control" required>
                  ${['Available', 'Occupied', 'Maintenance', 'Offline'].map(st => `
                    <option value="${st}" ${m.machine_status === st ? 'selected' : ''}>${st}</option>
                  `).join('')}
                </select>
              </div>
              <div class="form-group" style="margin-bottom:1rem;">
                <label class="form-label">Maintenance / Operational Remarks</label>
                <textarea id="um-remarks" class="form-control">${escapeHtml(m.maintenance_remarks || '')}</textarea>
              </div>
              <button type="submit" class="btn btn-primary" style="width:100%;">Save Machine Status</button>
            </form>
          `,
          onMount: (mEl) => {
            mEl.querySelector('#upd-mach-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const st = mEl.querySelector('#um-status').value;
              const rem = mEl.querySelector('#um-remarks').value.trim();

              const { error } = await supabase
                .from('dialysis_machines')
                .update({ machine_status: st, maintenance_remarks: rem || null })
                .eq('machine_id', m.machine_id);

              if (error) {
                showToast(error.message, 'error');
                return;
              }
              await recordAudit(`Updated Machine ${m.machine_code} Status to ${st}`, 'Dialysis Machines', m.machine_id, { status: st, remarks: rem });
              closeModal();
              showToast(`${m.machine_code} updated to ${st}.`, 'success');
              await onRefresh();
              draw();
            });
          }
        });
      });
    });
  }

  draw();
}

/* 7. DIALYSIS SESSION MANAGEMENT */
export function renderStaffSessions({ container, state, onRefresh }) {
  const confirmedEligible = state.appointments.filter(a =>
    a.appointment_status === 'Confirmed' &&
    !a.is_cancelled &&
    !state.sessions.some(s => s.appointment_id === a.appointment_id)
  );

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Dialysis Session Management</h1>
        <p class="page-subtitle">Record actual post-dialysis treatment times, pre/post weights, blood pressures, ultrafiltration, and clinical notes.</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="new-session-btn">+ Record Treatment Session</button>
    </div>

    <div class="card">
      <div class="card-header">
        <h2 class="card-title">Recorded Dialysis Sessions (${state.sessions.length})</h2>
      </div>
      ${state.sessions.length === 0 ? `<div class="empty-state">No dialysis sessions recorded yet.</div>` : `
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Patient</th>
                <th>Machine</th>
                <th>Actual Time</th>
                <th>Pre / Post Weight</th>
                <th>BP &amp; UF</th>
                <th>Released</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              ${state.sessions.map(s => `
                <tr>
                  <td><strong>${escapeHtml(formatDate(s.treatment_date))}</strong></td>
                  <td>${escapeHtml(s.patient_name)}</td>
                  <td>${escapeHtml(s.machine_code)}</td>
                  <td>${escapeHtml(formatTimeRange(s.actual_start_time, s.actual_end_time))}</td>
                  <td>${escapeHtml(s.pre_dialysis_weight ?? '—')} kg → ${escapeHtml(s.post_dialysis_weight ?? '—')} kg</td>
                  <td style="font-size:0.8rem;">
                    ${escapeHtml(s.blood_pressure_pre || '—')} → ${escapeHtml(s.blood_pressure_post || '—')}<br>
                    UF: ${escapeHtml(s.ultrafiltration_volume ?? '—')} mL
                  </td>
                  <td><span class="badge ${s.is_released_to_patient ? 'badge-status-confirmed' : 'badge-status-pending'}">${s.is_released_to_patient ? 'Released' : 'Internal'}</span></td>
                  <td style="max-width:220px; font-size:0.81rem;">${escapeHtml(s.treatment_notes || '—')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;

  container.querySelector('#new-session-btn')?.addEventListener('click', () => {
    openModal({
      title: 'Record Dialysis Treatment Session',
      size: 'lg',
      bodyHtml: `
        <form id="record-session-form">
          <div class="form-grid" style="margin-bottom:1rem;">
            <div class="form-group full-width">
              <label class="form-label">Link to Confirmed Appointment (Optional — auto-fills Patient &amp; Machine)</label>
              <select id="rs-appt-select" class="form-control">
                <option value="">-- Walk-in / Select Confirmed Appointment --</option>
                ${confirmedEligible.map(a => `
                  <option value="${escapeHtml(a.appointment_id)}"
                    data-pid="${escapeHtml(a.patient_id)}"
                    data-mid="${escapeHtml(a.machine_id || '')}"
                    data-date="${escapeHtml(a.confirmed_date || a.requested_date)}">
                    ${escapeHtml(a.patient_name)} — ${escapeHtml(formatDate(a.confirmed_date || a.requested_date))} (${escapeHtml(a.machine_code || 'Station')})
                  </option>
                `).join('')}
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Patient <span class="req">*</span></label>
              <select id="rs-patient" class="form-control" required>
                <option value="">Select Patient</option>
                ${state.patients.map(p => `<option value="${escapeHtml(p.patient_id)}">${escapeHtml(p.full_name)}</option>`).join('')}
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Assigned Machine <span class="req">*</span></label>
              <select id="rs-machine" class="form-control" required>
                <option value="">Select Machine</option>
                ${state.machines.map(m => `<option value="${escapeHtml(m.machine_id)}">${escapeHtml(m.machine_code)} — ${escapeHtml(m.machine_name)}</option>`).join('')}
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Treatment Date <span class="req">*</span></label>
              <input type="date" id="rs-date" class="form-control" value="${getTodayISO()}" required />
            </div>

            <div class="form-group">
              <label class="form-label">Session Status <span class="req">*</span></label>
              <select id="rs-status" class="form-control" required>
                <option value="Completed">Completed</option>
                <option value="In Progress">In Progress</option>
                <option value="Terminated Early">Terminated Early</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Actual Start Time <span class="req">*</span></label>
              <input type="time" id="rs-start" class="form-control" value="08:00" required />
            </div>

            <div class="form-group">
              <label class="form-label">Actual End Time <span class="req">*</span></label>
              <input type="time" id="rs-end" class="form-control" value="11:00" required />
            </div>

            <div class="form-group">
              <label class="form-label">Pre-Dialysis Weight (kg) <span class="req">*</span></label>
              <input type="number" step="0.01" id="rs-pre-wt" class="form-control" placeholder="e.g., 58.2" required />
            </div>

            <div class="form-group">
              <label class="form-label">Post-Dialysis Weight (kg) <span class="req">*</span></label>
              <input type="number" step="0.01" id="rs-post-wt" class="form-control" placeholder="e.g., 56.4" required />
            </div>

            <div class="form-group">
              <label class="form-label">Pre-Dialysis BP</label>
              <input type="text" id="rs-bp-pre" class="form-control" placeholder="140/90 mmHg" />
            </div>

            <div class="form-group">
              <label class="form-label">Post-Dialysis BP</label>
              <input type="text" id="rs-bp-post" class="form-control" placeholder="125/80 mmHg" />
            </div>

            <div class="form-group">
              <label class="form-label">Ultrafiltration Volume (mL)</label>
              <input type="number" step="10" id="rs-uf" class="form-control" placeholder="1800" />
            </div>

            <div class="form-group">
              <label class="form-label">Release Record to Patient Portal?</label>
              <select id="rs-release" class="form-control">
                <option value="true" selected>Yes — Release immediately to My Records</option>
                <option value="false">Hold for internal review first</option>
              </select>
            </div>

            <div class="form-group full-width">
              <label class="form-label">Treatment Notes <span class="req">*</span></label>
              <textarea id="rs-notes" class="form-control" required placeholder="Clinical summary, vascular access condition, patient tolerance..."></textarea>
            </div>
          </div>

          <button type="submit" class="btn btn-primary" style="width:100%;">Save Dialysis Session Record</button>
        </form>
      `,
      onMount: (mEl) => {
        const apptSel = mEl.querySelector('#rs-appt-select');
        apptSel.addEventListener('change', () => {
          const opt = apptSel.selectedOptions[0];
          if (opt && opt.value) {
            if (opt.dataset.pid) mEl.querySelector('#rs-patient').value = opt.dataset.pid;
            if (opt.dataset.mid) mEl.querySelector('#rs-machine').value = opt.dataset.mid;
            if (opt.dataset.date) mEl.querySelector('#rs-date').value = opt.dataset.date;
          }
        });

        mEl.querySelector('#record-session-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const apptId = apptSel.value || null;
          const patientId = mEl.querySelector('#rs-patient').value;
          const machineId = mEl.querySelector('#rs-machine').value;
          const isReleased = mEl.querySelector('#rs-release').value === 'true';

          const payload = {
            appointment_id: apptId,
            patient_id: patientId,
            machine_id: machineId,
            recorded_by: state.staff.staff_id,
            treatment_date: mEl.querySelector('#rs-date').value,
            actual_start_time: mEl.querySelector('#rs-start').value,
            actual_end_time: mEl.querySelector('#rs-end').value,
            pre_dialysis_weight: parseFloat(mEl.querySelector('#rs-pre-wt').value),
            post_dialysis_weight: parseFloat(mEl.querySelector('#rs-post-wt').value),
            blood_pressure_pre: mEl.querySelector('#rs-bp-pre').value.trim() || null,
            blood_pressure_post: mEl.querySelector('#rs-bp-post').value.trim() || null,
            ultrafiltration_volume: mEl.querySelector('#rs-uf').value ? parseFloat(mEl.querySelector('#rs-uf').value) : null,
            session_status: mEl.querySelector('#rs-status').value,
            is_released_to_patient: isReleased,
            treatment_notes: mEl.querySelector('#rs-notes').value.trim()
          };

          const { data: created, error } = await supabase
            .from('dialysis_sessions')
            .insert(payload)
            .select('*')
            .single();

          if (error) {
            showToast(error.message, 'error');
            return;
          }

          if (apptId) {
            await supabase.from('appointments').update({ attendance_flag: 'Attended' }).eq('appointment_id', apptId);
          }

          const pt = state.patients.find(p => p.patient_id === patientId);
          if (pt?.user_id && isReleased) {
            await sendUserNotification(
              pt.user_id,
              'Newly Released Dialysis Record',
              `Your hemodialysis treatment record for ${formatDate(payload.treatment_date)} is now available in My Records.`,
              'Medical Record',
              apptId
            );
          }

          await recordAudit('Recorded Dialysis Treatment Session', 'Dialysis Sessions', created.session_id, {
            patient_id: patientId,
            treatment_date: payload.treatment_date
          });

          closeModal();
          showToast('Dialysis session saved!', 'success');
          await onRefresh();
          renderStaffSessions({ container, state, onRefresh });
        });
      }
    });
  });
}

/* 8. MEDICAL RECORD MANAGEMENT (Uses existing Patient Medical Profiles, Patient Documents, Dialysis Sessions ONLY) */
export function renderStaffMedicalRecords({ container, state, onRefresh }) {
  let selectedPatientId = state.patients[0]?.patient_id || '';

  function draw() {
    const pt = state.patients.find(p => p.patient_id === selectedPatientId);
    const med = pt ? (state.medicalMap.get(pt.patient_id) || {}) : {};
    const pDocs = state.documents.filter(d => d.patient_id === selectedPatientId);
    const pSess = state.sessions.filter(s => s.patient_id === selectedPatientId);

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Medical Record Management</h1>
          <p class="page-subtitle">Manage patient medical profiles, upload authorized clinical files, and control which records are released to patients.</p>
        </div>
        <div style="display:flex; gap:0.6rem; align-items:center;">
          <select id="mr-patient-select" class="form-control" style="min-width:240px;">
            ${state.patients.map(p => `<option value="${escapeHtml(p.patient_id)}" ${p.patient_id === selectedPatientId ? 'selected' : ''}>${escapeHtml(p.full_name)}</option>`).join('')}
          </select>
          ${pt ? `<button type="button" class="btn btn-primary btn-sm" id="upload-auth-med-file">+ Upload Authorized File</button>` : ''}
        </div>
      </div>

      ${!pt ? `<div class="empty-state">No registered patients yet.</div>` : `
        ${med.correction_request_notes ? `
          <div class="alert alert-red">
            <strong>Patient Correction Request:</strong> "${escapeHtml(med.correction_request_notes)}"
          </div>
        ` : ''}

        <div class="card" style="margin-bottom:1.25rem;">
          <div class="card-header">
            <h2 class="card-title">Clinical Profile — ${escapeHtml(pt.full_name)}</h2>
          </div>
          <div class="kv-grid">
            <div class="kv-item"><div class="kv-label">Diagnosis</div><div class="kv-value">${escapeHtml(med.diagnosis || '—')}</div></div>
            <div class="kv-item"><div class="kv-label">Nephrologist</div><div class="kv-value">${escapeHtml(med.attending_nephrologist || '—')}</div></div>
            <div class="kv-item"><div class="kv-label">Blood Type / Weight</div><div class="kv-value">${escapeHtml(med.blood_type || '—')} • ${escapeHtml(med.weight ?? '—')} kg</div></div>
            <div class="kv-item"><div class="kv-label">Allergies &amp; Medications</div><div class="kv-value">${escapeHtml(med.allergies || '—')} | ${escapeHtml(med.current_medications || '—')}</div></div>
          </div>
        </div>

        <div class="dashboard-grid-2">
          <!-- Dialysis Sessions Release Control -->
          <div class="card">
            <div class="card-header">
              <h2 class="card-title">Dialysis Session Release Control (${pSess.length})</h2>
            </div>
            ${pSess.length === 0 ? `<div class="empty-state">No treatment sessions recorded for this patient.</div>` : `
              <div class="table-responsive">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Machine</th>
                      <th>Portal Visibility</th>
                      <th>Toggle</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${pSess.map(s => `
                      <tr>
                        <td>${escapeHtml(formatDate(s.treatment_date))}</td>
                        <td>${escapeHtml(s.machine_code)}</td>
                        <td><span class="badge ${s.is_released_to_patient ? 'badge-status-confirmed' : 'badge-status-pending'}">${s.is_released_to_patient ? 'Released' : 'Held'}</span></td>
                        <td>
                          <button type="button" class="btn btn-outline-blue btn-xs toggle-sess-release" data-sid="${escapeHtml(s.session_id)}" data-cur="${s.is_released_to_patient}">
                            ${s.is_released_to_patient ? 'Hold' : 'Release'}
                          </button>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            `}
          </div>

          <!-- Patient Documents & Authorized Files -->
          <div class="card">
            <div class="card-header">
              <h2 class="card-title">Documents &amp; Authorized Files (${pDocs.length})</h2>
            </div>
            ${pDocs.length === 0 ? `<div class="empty-state">No documents on file.</div>` : `
              <div class="table-responsive">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Category</th>
                      <th>Status</th>
                      <th>Released</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${pDocs.map(d => `
                      <tr>
                        <td>
                          <strong>${escapeHtml(d.document_type)}</strong>
                          <div class="text-muted" style="font-size:0.76rem;">${escapeHtml(d.file_name)}</div>
                        </td>
                        <td>${docBadgeHtml(d.verification_status)}</td>
                        <td>${d.is_released_to_patient ? 'Yes' : 'Held'}</td>
                        <td>
                          <button type="button" class="btn btn-outline btn-xs mr-preview-doc" data-did="${escapeHtml(d.document_id)}">View</button>
                          <button type="button" class="btn btn-outline-blue btn-xs toggle-doc-release" data-did="${escapeHtml(d.document_id)}" data-cur="${d.is_released_to_patient}">
                            ${d.is_released_to_patient ? 'Hide' : 'Release'}
                          </button>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            `}
          </div>
        </div>
      `}
    `;

    container.querySelector('#mr-patient-select')?.addEventListener('change', (e) => {
      selectedPatientId = e.target.value;
      draw();
    });

    container.querySelectorAll('.mr-preview-doc').forEach(b => {
      b.addEventListener('click', () => {
        const doc = state.documents.find(x => x.document_id === b.dataset.did);
        if (doc) previewStaffDocument(doc);
      });
    });

    container.querySelectorAll('.toggle-sess-release').forEach(btn => {
      btn.addEventListener('click', async () => {
        const nextVal = btn.dataset.cur !== 'true';
        const { error } = await supabase
          .from('dialysis_sessions')
          .update({ is_released_to_patient: nextVal })
          .eq('session_id', btn.dataset.sid);
        if (error) { showToast(error.message, 'error'); return; }

        if (nextVal && pt?.user_id) {
          await sendUserNotification(pt.user_id, 'Medical Record Released', 'A dialysis session record has been released to your portal.', 'Medical Record');
        }
        await recordAudit(`${nextVal ? 'Released' : 'Held'} Dialysis Session Record`, 'Medical Record Management', btn.dataset.sid);
        showToast('Session visibility updated.', 'success');
        await onRefresh();
        draw();
      });
    });

    container.querySelectorAll('.toggle-doc-release').forEach(btn => {
      btn.addEventListener('click', async () => {
        const nextVal = btn.dataset.cur !== 'true';
        const { error } = await supabase
          .from('patient_documents')
          .update({ is_released_to_patient: nextVal })
          .eq('document_id', btn.dataset.did);
        if (error) { showToast(error.message, 'error'); return; }
        await recordAudit(`${nextVal ? 'Released' : 'Held'} Patient Document`, 'Medical Record Management', btn.dataset.did);
        showToast('Document visibility updated.', 'success');
        await onRefresh();
        draw();
      });
    });

    container.querySelector('#upload-auth-med-file')?.addEventListener('click', () => {
      openModal({
        title: `Upload Authorized Medical File — ${pt.full_name}`,
        size: 'sm',
        bodyHtml: `
          <form id="staff-upload-med-form">
            <div class="form-group" style="margin-bottom:0.9rem;">
              <label class="form-label">Select PDF or Image (Max 10 MB) <span class="req">*</span></label>
              <input type="file" id="staff-med-file" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.webp" required />
            </div>
            <div class="form-group" style="margin-bottom:0.9rem;">
              <label class="form-label">Clinical Description / Remarks <span class="req">*</span></label>
              <textarea id="staff-med-remarks" class="form-control" required placeholder="e.g., Monthly Dialysis Adequacy (Kt/V) Summary..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">Upload &amp; Release to Patient</button>
          </form>
        `,
        onMount: (mEl) => {
          mEl.querySelector('#staff-upload-med-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const file = mEl.querySelector('#staff-med-file').files?.[0];
            const rem = mEl.querySelector('#staff-med-remarks').value.trim();
            if (!file) return;

            const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
            const path = `${pt.user_id}/${Date.now()}_staff_${safe}`;
            const { error: upErr } = await supabase.storage.from(STORAGE_BUCKET).upload(path, file, { contentType: file.type });
            if (upErr) { showToast(upErr.message, 'error'); return; }

            const { error: insErr } = await supabase.from('patient_documents').insert({
              patient_id: pt.patient_id,
              document_type: 'Authorized Medical Record',
              file_path: path,
              file_name: file.name,
              file_size: file.size,
              mime_type: file.type,
              verification_status: 'Verified',
              reviewed_by: state.staff.staff_id,
              reviewed_at: new Date().toISOString(),
              remarks: rem,
              is_released_to_patient: true
            });
            if (insErr) { showToast(insErr.message, 'error'); return; }

            if (pt.user_id) {
              await sendUserNotification(pt.user_id, 'New Released Medical Document', `Clinic staff uploaded "${file.name}" (${rem}) to My Records.`, 'Medical Record');
            }
            await recordAudit('Uploaded Authorized Medical File', 'Medical Record Management', pt.patient_id, { file_name: file.name });
            closeModal();
            showToast('Authorized medical file uploaded and released.', 'success');
            await onRefresh();
            draw();
          });
        }
      });
    });
  }

  draw();
}

/* 9. STAFF NOTIFICATIONS */
export function renderStaffNotificationsView({ container, state, notifBell, onRefresh }) {
  const list = state.notifications || [];
  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Staff Operational Notifications</h1>
        <p class="page-subtitle">New appointment requests, document submissions, reschedule alerts, cancellations, and system events.</p>
      </div>
      <button type="button" class="btn btn-outline-blue btn-sm" id="staff-mark-all-read">Mark All Read</button>
    </div>

    <div class="card">
      ${list.length === 0 ? `<div class="empty-state">No notifications yet.</div>` : `
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          ${list.map(n => `
            <div style="padding:0.9rem 1rem; border:1px solid var(--border-subtle); border-left:4px solid ${n.is_read ? 'var(--reliance-blue)' : 'var(--reliance-red)'}; border-radius:8px; background:#fff;">
              <div style="display:flex; justify-content:space-between; font-size:0.78rem; color:var(--text-muted);">
                <strong>${escapeHtml(n.notification_type)}</strong>
                <span>${escapeHtml(formatDateTime(n.created_at))}</span>
              </div>
              <div style="font-weight:700; margin-top:0.2rem;">${escapeHtml(n.title)}</div>
              <div style="font-size:0.86rem; color:var(--text-secondary);">${escapeHtml(n.message)}</div>
            </div>
          `).join('')}
        </div>
      `}
    </div>
  `;

  container.querySelector('#staff-mark-all-read')?.addEventListener('click', async () => {
    await notifBell.markAllRead();
    await onRefresh();
    renderStaffNotificationsView({ container, state, notifBell, onRefresh });
  });
}
