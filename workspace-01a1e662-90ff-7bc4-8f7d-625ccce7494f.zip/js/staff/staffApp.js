/**
 * Reliance Dialysis Center Inc. — Staff Panel Master Controller
 */

import { supabase, fetchClinicConfig } from '../supabaseClient.js';
import { requireRoleGuard, signOutAndRedirect } from '../authGuard.js';
import { NotificationBell } from '../components/notifications.js';

import {
  renderStaffDashboard,
  renderStaffPatients,
  renderStaffDocumentVerification,
  renderStaffAppointments
} from './staffClinicalViews.js';

import {
  renderStaffRecurring,
  renderStaffMachines,
  renderStaffSessions,
  renderStaffMedicalRecords,
  renderStaffNotificationsView
} from './staffOperationsViews.js';

const mainView = document.getElementById('staff-main-view');
const sidebar = document.getElementById('portal-sidebar');

const state = {
  user: null,
  staff: null,
  patients: [],
  medicalMap: new Map(),
  documents: [],
  appointments: [],
  machines: [],
  machineSlots: [],
  sessions: [],
  notifications: [],
  auditLogs: [],
  clinicConfig: null
};

let notifBell = null;

async function refreshStaffData() {
  const [ptRes, medRes, docRes, apptRes, machRes, slotRes, sessRes, notifRes, auditRes, cfg] = await Promise.all([
    supabase.from('patients').select('*').order('full_name', { ascending: true }),
    supabase.from('patient_medical_profiles').select('*'),
    supabase.from('patient_documents').select('*, patients(full_name)').order('uploaded_at', { ascending: false }),
    supabase
      .from('appointments')
      .select('*, patients(full_name), machine_slots(machine_id, dialysis_machines(machine_code, machine_name))')
      .order('requested_date', { ascending: false }),
    supabase.from('dialysis_machines').select('*').order('machine_code', { ascending: true }),
    supabase.from('machine_slots').select('*').order('schedule_date', { ascending: false }),
    supabase
      .from('dialysis_sessions')
      .select('*, patients(full_name), dialysis_machines(machine_code, machine_name)')
      .order('treatment_date', { ascending: false }),
    supabase.from('notifications').select('*').eq('recipient_user_id', state.user.id).order('created_at', { ascending: false }),
    supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(30),
    fetchClinicConfig()
  ]);

  state.patients = ptRes.data || [];
  state.medicalMap = new Map((medRes.data || []).map(m => [m.patient_id, m]));
  state.documents = (docRes.data || []).map(d => ({
    ...d,
    patient_name: d.patients?.full_name || 'Patient'
  }));
  state.appointments = (apptRes.data || []).map(a => ({
    ...a,
    patient_name: a.patients?.full_name || 'Patient',
    machine_id: a.machine_slots?.machine_id || null,
    machine_code: a.machine_slots?.dialysis_machines?.machine_code || null
  }));
  state.machines = machRes.data || [];
  state.machineSlots = slotRes.data || [];
  state.sessions = (sessRes.data || []).map(s => ({
    ...s,
    patient_name: s.patients?.full_name || 'Patient',
    machine_code: s.dialysis_machines?.machine_code || 'Station'
  }));
  state.notifications = notifRes.data || [];
  state.auditLogs = auditRes.data || [];
  state.clinicConfig = cfg;

  if (notifBell) await notifBell.refresh();
}

function navigateTo(view) {
  sidebar.classList.remove('open');
  document.querySelectorAll('.sidebar-nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });

  if (view === 'dashboard') {
    renderStaffDashboard({ container: mainView, state, onNavigate: navigateTo });
  } else if (view === 'patients') {
    renderStaffPatients({ container: mainView, state });
  } else if (view === 'documents') {
    renderStaffDocumentVerification({ container: mainView, state, onRefresh: refreshStaffData });
  } else if (view === 'appointments') {
    renderStaffAppointments({ container: mainView, state, onRefresh: refreshStaffData });
  } else if (view === 'recurring') {
    renderStaffRecurring({ container: mainView, state, onRefresh: refreshStaffData });
  } else if (view === 'machines') {
    renderStaffMachines({ container: mainView, state, onRefresh: refreshStaffData });
  } else if (view === 'sessions') {
    renderStaffSessions({ container: mainView, state, onRefresh: refreshStaffData });
  } else if (view === 'records') {
    renderStaffMedicalRecords({ container: mainView, state, onRefresh: refreshStaffData });
  } else if (view === 'notifications') {
    renderStaffNotificationsView({ container: mainView, state, notifBell, onRefresh: refreshStaffData });
  }
}

async function initStaffPanel() {
  const ctx = await requireRoleGuard(['staff', 'super_admin']);
  if (!ctx) return;

  state.user = ctx.user;
  state.staff = ctx.staff;

  document.getElementById('header-staff-name').textContent = state.staff.full_name;
  document.getElementById('dropdown-staff-name').textContent = state.staff.full_name;
  document.getElementById('dropdown-staff-pos').textContent = state.staff.position;

  if (ctx.role === 'super_admin') {
    const swBtn = document.getElementById('switch-admin-btn');
    swBtn.hidden = false;
    swBtn.addEventListener('click', () => { window.location.href = '/admin.html'; });
  }

  notifBell = new NotificationBell({
    userId: state.user.id,
    bellButton: document.getElementById('notif-bell-btn'),
    badgeElement: document.getElementById('notif-badge'),
    dropdownElement: document.getElementById('notif-dropdown'),
    onViewAll: () => navigateTo('notifications')
  });
  await notifBell.init();

  const trigger = document.getElementById('profile-trigger-btn');
  const dropdown = document.getElementById('profile-dropdown');
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    dropdown.hidden = !dropdown.hidden;
  });
  document.addEventListener('click', (e) => {
    if (!dropdown.hidden && !document.getElementById('profile-menu-wrapper').contains(e.target)) {
      dropdown.hidden = true;
    }
  });

  document.getElementById('staff-logout-btn').addEventListener('click', () => signOutAndRedirect('/auth.html'));
  document.getElementById('sidebar-toggle-btn').addEventListener('click', () => sidebar.classList.toggle('open'));

  document.querySelectorAll('.sidebar-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.view));
  });

  await refreshStaffData();
  navigateTo('dashboard');
}

initStaffPanel();
