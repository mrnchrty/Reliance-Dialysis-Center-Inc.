/**
 * Reliance Dialysis Center Inc. — Staff Panel Modules 1–4:
 *   1. Staff Dashboard
 *   2. Patient Management (Search, Profile, Documents, Appointment & Dialysis History)
 *   3. Document Verification (Review 4 required documents, Verify/Needs Correction/Reject, Notify Patient)
 *   4. Appointment Management (Review requests, check doc verification, atomic machine assignment & 4 statuses)
 */

import {
  supabase,
  STORAGE_BUCKET,
  APPOINTMENT_STATUSES,
  recordAudit,
  sendUserNotification
} from '../supabaseClient.js';
import {
  escapeHtml,
  formatDate,
  formatDateTime,
  formatTimeRange,
  formatFileSize,
  getTodayISO,
  statusBadgeHtml,
  docBadgeHtml,
  machineBadgeHtml
} from '../utils.js';
import { showToast, openModal, closeModal } from '../components/toast.js';

export async function previewStaffDocument(doc) {
  try {
    const { data, error } = await supabase.storage.from(STORAGE_BUCKET).createSignedUrl(doc.file_path, 300);
    if (error) throw error;
    const isImg = (doc.mime_type || '').startsWith('image/');
    openModal({
      title: `${doc.document_type} — ${doc.file_name}`,
      size: 'lg',
      bodyHtml: isImg
        ? `<div style="text-align:center;"><img src="${escapeHtml(data.signedUrl)}" alt="${escapeHtml(doc.file_name)}" style="max-height:65vh; margin:0 auto;" /></div>`
        : `<iframe src="${escapeHtml(data.signedUrl)}" title="Document Preview" style="width:100%; height:65vh; border:1px solid var(--border-subtle);"></iframe>`,
      footerHtml: `<a href="${escapeHtml(data.signedUrl)}" target="_blank" rel="noopener" class="btn btn-primary btn-sm">Open Original File</a>`
    });
  } catch (err) {
    showToast(err.message || 'Unable to preview document.', 'error');
  }
}

/* 1. STAFF DASHBOARD */
export function renderStaffDashboard({ container, state, onNavigate }) {
  const today = getTodayISO();
  const todaysAppts = state.appointments.filter(a =>
    !a.is_cancelled && (a.confirmed_date === today || (!a.confirmed_date && a.requested_date === today))
  );
  const pendingRequests = state.appointments.filter(a =>
    !a.is_cancelled && (a.appointment_status === 'Pending' || a.appointment_status === 'Under Review')
  );
  const docsAwaiting = state.documents.filter(d => d.verification_status === 'Pending');
  const availMachines = state.machines.filter(m => m.machine_status === 'Available').length;
  const occMachines = state.machines.filter(m => m.machine_status === 'Occupied').length;
  const completedSessions = state.sessions.filter(s => s.session_status === 'Completed').length;

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Clinical Staff Dashboard</h1>
        <p class="page-subtitle">Daily hemodialysis schedule, pending requests, document verification queue, and station readiness.</p>
      </div>
      <div style="font-weight:600; color:var(--reliance-blue);">${escapeHtml(formatDate(today, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }))}</div>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Today's Appointments</div>
        <div class="stat-value">${todaysAppts.length}</div>
        <div class="stat-meta">Scheduled for ${escapeHtml(formatDate(today))}</div>
      </div>

      <div class="stat-card accent-red">
        <div class="stat-label">Pending Requests</div>
        <div class="stat-value">${pendingRequests.length}</div>
        <div class="stat-meta">${docsAwaiting.length} doc(s) awaiting verification</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Machines (Avail / Occupied)</div>
        <div class="stat-value">${availMachines} / ${occMachines}</div>
        <div class="stat-meta">Out of ${state.machines.length} total stations</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Completed Dialysis Sessions</div>
        <div class="stat-value">${completedSessions}</div>
        <div class="stat-meta">Total recorded treatments</div>
      </div>
    </div>

    <div class="dashboard-grid-2">
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Pending &amp; Under Review Requests</h2>
          <button type="button" class="btn-link-sm" data-snav="appointments">Manage All →</button>
        </div>
        ${pendingRequests.length === 0 ? `<div class="empty-state">All appointment requests are processed!</div>` : `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Requested Date</th>
                  <th>Time</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${pendingRequests.slice(0, 6).map(a => `
                  <tr>
                    <td><strong>${escapeHtml(a.patient_name)}</strong></td>
                    <td>${escapeHtml(formatDate(a.requested_date))}</td>
                    <td>${escapeHtml(a.requested_time)}</td>
                    <td>${statusBadgeHtml(a.appointment_status)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Documents Awaiting Verification (${docsAwaiting.length})</h2>
          <button type="button" class="btn-link-sm" data-snav="documents">Verify Documents →</button>
        </div>
        ${docsAwaiting.length === 0 ? `<div class="empty-state">No pending documents in queue.</div>` : `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Document Type</th>
                  <th>Uploaded</th>
                </tr>
              </thead>
              <tbody>
                ${docsAwaiting.slice(0, 6).map(d => `
                  <tr>
                    <td><strong>${escapeHtml(d.patient_name)}</strong></td>
                    <td>${escapeHtml(d.document_type)}</td>
                    <td>${escapeHtml(formatDate(d.uploaded_at))}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2 class="card-title">Recent Clinical System Activities</h2>
      </div>
      ${state.auditLogs.length === 0 ? `<div class="empty-state">No recent activities logged.</div>` : `
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Module</th>
                <th>Activity</th>
              </tr>
            </thead>
            <tbody>
              ${state.auditLogs.slice(0, 8).map(log => `
                <tr>
                  <td>${escapeHtml(formatDateTime(log.created_at))}</td>
                  <td><span class="badge badge-status-under-review">${escapeHtml(log.affected_module)}</span></td>
                  <td>${escapeHtml(log.activity)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;

  container.querySelectorAll('[data-snav]').forEach(b => {
    b.addEventListener('click', () => onNavigate(b.dataset.snav));
  });
}

/* 2. PATIENT MANAGEMENT */
export function renderStaffPatients({ container, state }) {
  let searchQuery = '';

  function draw() {
    const q = searchQuery.toLowerCase();
    const list = state.patients.filter(p =>
      !q ||
      (p.full_name || '').toLowerCase().includes(q) ||
      (p.email || '').toLowerCase().includes(q) ||
      (p.contact_number || '').toLowerCase().includes(q)
    );

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Patient Management</h1>
          <p class="page-subtitle">Search registered patients and inspect personal profiles, medical backgrounds, documents, and treatment histories.</p>
        </div>
      </div>

      <div class="card">
        <div class="filter-bar">
          <input type="search" id="staff-pt-search" class="form-control" style="min-width:280px;" placeholder="Search by patient name, email, or phone..." value="${escapeHtml(searchQuery)}" />
          <span class="text-muted" style="font-size:0.85rem;">Showing ${list.length} of ${state.patients.length} patient(s)</span>
        </div>

        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Sex / DOB</th>
                <th>Contact</th>
                <th>Diagnosis &amp; Frequency</th>
                <th>Attending Nephrologist</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${list.map(p => {
                const med = state.medicalMap.get(p.patient_id);
                return `
                  <tr>
                    <td>
                      <strong>${escapeHtml(p.full_name)}</strong>
                      <div class="text-muted" style="font-size:0.78rem;">${escapeHtml(p.email || '')}</div>
                    </td>
                    <td>${escapeHtml(p.sex || '—')} • ${escapeHtml(formatDate(p.date_of_birth))}</td>
                    <td>${escapeHtml(p.contact_number || '—')}</td>
                    <td>
                      <div>${escapeHtml(med?.diagnosis || 'Profile incomplete')}</div>
                      <div class="text-muted" style="font-size:0.78rem;">${escapeHtml(med?.prescribed_dialysis_frequency || '')}</div>
                    </td>
                    <td>${escapeHtml(med?.attending_nephrologist || '—')}</td>
                    <td>
                      <button type="button" class="btn btn-outline-blue btn-xs inspect-pt-btn" data-pid="${escapeHtml(p.patient_id)}">
                        Full Chart
                      </button>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    const sInput = container.querySelector('#staff-pt-search');
    sInput.addEventListener('input', (e) => {
      searchQuery = e.target.value;
      const pos = sInput.selectionStart;
      draw();
      const nextInput = container.querySelector('#staff-pt-search');
      nextInput.focus();
      nextInput.setSelectionRange(pos, pos);
    });

    container.querySelectorAll('.inspect-pt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const p = state.patients.find(x => x.patient_id === btn.dataset.pid);
        if (!p) return;
        const med = state.medicalMap.get(p.patient_id) || {};
        const pDocs = state.documents.filter(d => d.patient_id === p.patient_id);
        const pAppts = state.appointments.filter(a => a.patient_id === p.patient_id);
        const pSess = state.sessions.filter(s => s.patient_id === p.patient_id);

        openModal({
          title: `Patient Chart — ${p.full_name}`,
          size: 'lg',
          bodyHtml: `
            <h4 style="margin:0 0 0.6rem; color:var(--reliance-blue);">Personal &amp; Emergency Details</h4>
            <div class="kv-grid" style="margin-bottom:1.2rem;">
              <div class="kv-item"><div class="kv-label">Address</div><div class="kv-value">${escapeHtml(p.address || '—')}</div></div>
              <div class="kv-item"><div class="kv-label">Contact</div><div class="kv-value">${escapeHtml(p.contact_number || '—')}</div></div>
              <div class="kv-item"><div class="kv-label">Emergency Contact</div><div class="kv-value">${escapeHtml(p.emergency_contact_name || '—')} (${escapeHtml(p.emergency_contact_number || '—')})</div></div>
              <div class="kv-item"><div class="kv-label">Blood Type / Weight / Height</div><div class="kv-value">${escapeHtml(med.blood_type || '—')} • ${escapeHtml(med.weight ?? '—')} kg • ${escapeHtml(med.height ?? '—')} cm</div></div>
            </div>

            <h4 style="margin:0 0 0.6rem; color:var(--reliance-blue);">Medical &amp; Dialysis Profile</h4>
            <div class="kv-grid" style="margin-bottom:1.2rem;">
              <div class="kv-item"><div class="kv-label">Diagnosis</div><div class="kv-value">${escapeHtml(med.diagnosis || '—')}</div></div>
              <div class="kv-item"><div class="kv-label">Allergies</div><div class="kv-value">${escapeHtml(med.allergies || '—')}</div></div>
              <div class="kv-item"><div class="kv-label">Medications</div><div class="kv-value">${escapeHtml(med.current_medications || '—')}</div></div>
              <div class="kv-item"><div class="kv-label">Nephrologist / Frequency</div><div class="kv-value">${escapeHtml(med.attending_nephrologist || '—')} (${escapeHtml(med.prescribed_dialysis_frequency || '—')})</div></div>
            </div>

            <h4 style="margin:0 0 0.5rem; color:var(--reliance-blue);">Submitted Documents (${pDocs.length})</h4>
            <div style="margin-bottom:1.2rem; font-size:0.84rem;">
              ${pDocs.length === 0 ? '<span class="text-muted">None uploaded</span>' : pDocs.map(d => `
                <div style="display:flex; justify-content:space-between; padding:0.35rem 0; border-bottom:1px solid var(--border-subtle);">
                  <span>${escapeHtml(d.document_type)} — ${escapeHtml(d.file_name)}</span>
                  ${docBadgeHtml(d.verification_status)}
                </div>
              `).join('')}
            </div>

            <h4 style="margin:0 0 0.5rem; color:var(--reliance-blue);">Appointment History (${pAppts.length}) &amp; Dialysis Sessions (${pSess.length})</h4>
            <div style="font-size:0.84rem;">
              ${pAppts.slice(0, 5).map(a => `
                <div style="display:flex; justify-content:space-between; padding:0.35rem 0; border-bottom:1px solid var(--border-subtle);">
                  <span>${escapeHtml(formatDate(a.confirmed_date || a.requested_date))} (${escapeHtml(a.requested_time)}) — Machine: ${escapeHtml(a.machine_code || 'Unassigned')}</span>
                  ${statusBadgeHtml(a.appointment_status, a.is_cancelled)}
                </div>
              `).join('')}
            </div>
          `
        });
      });
    });
  }

  draw();
}

/* 3. DOCUMENT VERIFICATION */
export function renderStaffDocumentVerification({ container, state, onRefresh }) {
  let filterStatus = 'ALL';

  function draw() {
    const docs = state.documents.filter(d =>
      filterStatus === 'ALL' ? true : d.verification_status === filterStatus
    );

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Document Verification</h1>
          <p class="page-subtitle">Review patient endorsement, medical abstract, laboratory results, and ID uploads stored in Supabase Storage.</p>
        </div>
      </div>

      <div class="card">
        <div class="filter-bar">
          <select id="doc-verif-filter" class="form-control">
            <option value="ALL" ${filterStatus === 'ALL' ? 'selected' : ''}>All Verification Statuses</option>
            ${['Pending', 'Verified', 'Needs Correction', 'Rejected'].map(st => `
              <option value="${st}" ${filterStatus === st ? 'selected' : ''}>${st}</option>
            `).join('')}
          </select>
        </div>

        ${docs.length === 0 ? `<div class="empty-state">No patient documents match this filter.</div>` : `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Document Type</th>
                  <th>File</th>
                  <th>Uploaded</th>
                  <th>Status</th>
                  <th>Remarks</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${docs.map(d => `
                  <tr>
                    <td><strong>${escapeHtml(d.patient_name)}</strong></td>
                    <td>${escapeHtml(d.document_type)}</td>
                    <td>${escapeHtml(d.file_name)} <span class="text-muted">(${escapeHtml(formatFileSize(d.file_size))})</span></td>
                    <td>${escapeHtml(formatDateTime(d.uploaded_at))}</td>
                    <td>${docBadgeHtml(d.verification_status)}</td>
                    <td style="max-width:200px; font-size:0.82rem;">${escapeHtml(d.remarks || '—')}</td>
                    <td>
                      <div style="display:flex; gap:0.35rem; flex-wrap:wrap;">
                        <button type="button" class="btn btn-outline btn-xs staff-doc-preview" data-id="${escapeHtml(d.document_id)}">Preview</button>
                        <button type="button" class="btn btn-primary btn-xs staff-doc-review" data-id="${escapeHtml(d.document_id)}">Verify / Update</button>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>
    `;

    container.querySelector('#doc-verif-filter')?.addEventListener('change', (e) => {
      filterStatus = e.target.value;
      draw();
    });

    container.querySelectorAll('.staff-doc-preview').forEach(b => {
      b.addEventListener('click', () => {
        const doc = state.documents.find(x => x.document_id === b.dataset.id);
        if (doc) previewStaffDocument(doc);
      });
    });

    container.querySelectorAll('.staff-doc-review').forEach(b => {
      b.addEventListener('click', () => {
        const doc = state.documents.find(x => x.document_id === b.dataset.id);
        if (!doc) return;
        openModal({
          title: `Review Document — ${doc.document_type}`,
          bodyHtml: `
            <p style="margin-top:0; font-size:0.88rem;">
              Patient: <strong>${escapeHtml(doc.patient_name)}</strong> • File: <strong>${escapeHtml(doc.file_name)}</strong>
            </p>
            <form id="doc-review-modal-form">
              <div class="form-group" style="margin-bottom:0.9rem;">
                <label class="form-label">Verification Decision <span class="req">*</span></label>
                <select id="dr-status" class="form-control" required>
                  ${['Verified', 'Needs Correction', 'Rejected', 'Pending'].map(s => `
                    <option value="${s}" ${doc.verification_status === s ? 'selected' : ''}>${s}</option>
                  `).join('')}
                </select>
              </div>
              <div class="form-group" style="margin-bottom:1rem;">
                <label class="form-label">Staff Remarks / Correction Instructions</label>
                <textarea id="dr-remarks" class="form-control" placeholder="Provide clear instructions if corrections or updated labs are needed...">${escapeHtml(doc.remarks || '')}</textarea>
              </div>
              <button type="submit" class="btn btn-primary" style="width:100%;">Save Verification Decision &amp; Notify Patient</button>
            </form>
          `,
          onMount: (mEl) => {
            mEl.querySelector('#doc-review-modal-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const newStatus = mEl.querySelector('#dr-status').value;
              const remarks = mEl.querySelector('#dr-remarks').value.trim();

              const { error } = await supabase
                .from('patient_documents')
                .update({
                  verification_status: newStatus,
                  reviewed_by: state.staff.staff_id,
                  reviewed_at: new Date().toISOString(),
                  remarks: remarks || null
                })
                .eq('document_id', doc.document_id);

              if (error) {
                showToast(error.message, 'error');
                return;
              }

              // If Needs Correction, set any Pending appointment for this patient to Under Review per spec IV.E
              if (newStatus === 'Needs Correction') {
                await supabase
                  .from('appointments')
                  .update({
                    appointment_status: 'Under Review',
                    staff_remarks: `Document correction needed (${doc.document_type}): ${remarks}`
                  })
                  .eq('patient_id', doc.patient_id)
                  .eq('appointment_status', 'Pending');
              }

              const pt = state.patients.find(p => p.patient_id === doc.patient_id);
              if (pt?.user_id) {
                await sendUserNotification(
                  pt.user_id,
                  `Document ${newStatus}: ${doc.document_type}`,
                  remarks
                    ? `Your ${doc.document_type} was marked "${newStatus}". Remarks: ${remarks}`
                    : `Your ${doc.document_type} has been reviewed and marked "${newStatus}".`,
                  'Document'
                );
              }

              await recordAudit(`Document ${newStatus}`, 'Patient Documents', doc.document_id, {
                document_type: doc.document_type,
                remarks
              });

              closeModal();
              showToast('Document verification saved and patient notified.', 'success');
              await onRefresh();
              draw();
            });
          }
        });
      });
    });
  }

  draw();
}

/* 4. APPOINTMENT MANAGEMENT */
export function renderStaffAppointments({ container, state, onRefresh }) {
  let statusFilter = 'ALL';

  function draw() {
    const list = state.appointments.filter(a =>
      statusFilter === 'ALL' ? true : a.appointment_status === statusFilter
    );

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Appointment Management</h1>
          <p class="page-subtitle">Process requests across the 4 official statuses (Pending, Under Review, Confirmed, Rejected) and assign dialysis machines.</p>
        </div>
      </div>

      <div class="card">
        <div class="filter-bar">
          <select id="staff-appt-filter" class="form-control">
            <option value="ALL" ${statusFilter === 'ALL' ? 'selected' : ''}>All 4 Statuses</option>
            ${APPOINTMENT_STATUSES.map(s => `<option value="${s}" ${statusFilter === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </div>

        ${list.length === 0 ? `<div class="empty-state">No appointments found.</div>` : `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Requested Schedule</th>
                  <th>Confirmed Schedule</th>
                  <th>Machine</th>
                  <th>Status</th>
                  <th>Docs Verified</th>
                  <th>Attendance</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${list.map(a => {
                  const ptDocs = state.documents.filter(d => d.patient_id === a.patient_id);
                  const verCount = ptDocs.filter(d => d.verification_status === 'Verified').length;
                  return `
                    <tr>
                      <td>
                        <strong>${escapeHtml(a.patient_name)}</strong>
                        ${a.reschedule_requested ? `<div class="text-red" style="font-size:0.76rem; font-weight:600;">Reschedule Note: ${escapeHtml(a.reschedule_notes || '')}</div>` : ''}
                      </td>
                      <td>${escapeHtml(formatDate(a.requested_date))} • ${escapeHtml(a.requested_time)}</td>
                      <td>
                        ${a.confirmed_date ? `${escapeHtml(formatDate(a.confirmed_date))} (${escapeHtml(formatTimeRange(a.confirmed_start_time, a.confirmed_end_time))})` : '—'}
                      </td>
                      <td><strong>${escapeHtml(a.machine_code || 'Unassigned')}</strong></td>
                      <td>${statusBadgeHtml(a.appointment_status, a.is_cancelled)}</td>
                      <td><span class="badge ${verCount >= 4 ? 'badge-doc-verified' : 'badge-doc-pending'}">${verCount}/4 Verified</span></td>
                      <td>${escapeHtml(a.attendance_flag || 'Scheduled')}</td>
                      <td>
                        <button type="button" class="btn btn-primary btn-xs process-appt-btn" data-id="${escapeHtml(a.appointment_id)}">
                          Process / Assign
                        </button>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>
    `;

    container.querySelector('#staff-appt-filter')?.addEventListener('change', (e) => {
      statusFilter = e.target.value;
      draw();
    });

    container.querySelectorAll('.process-appt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const appt = state.appointments.find(x => x.appointment_id === btn.dataset.id);
        if (!appt) return;
        const slots = state.clinicConfig?.time_slots || [];
        const matchedSlot = slots.find(s => s.id === appt.requested_time) || slots[0];
        const defDate = appt.confirmed_date || appt.requested_date;
        const defStart = appt.confirmed_start_time ? appt.confirmed_start_time.slice(0, 5) : (matchedSlot?.start_time || '08:00');
        const defEnd = appt.confirmed_end_time ? appt.confirmed_end_time.slice(0, 5) : (matchedSlot?.end_time || '11:00');

        const operationalMachines = state.machines.filter(m => m.machine_status !== 'Maintenance' && m.machine_status !== 'Offline');

        openModal({
          title: `Process Appointment — ${appt.patient_name}`,
          size: 'md',
          bodyHtml: `
            <form id="staff-process-appt-form">
              <div class="form-grid" style="margin-bottom:0.9rem;">
                <div class="form-group">
                  <label class="form-label">Target Status (Strictly 4 Main Statuses) <span class="req">*</span></label>
                  <select id="pa-status" class="form-control" required>
                    ${APPOINTMENT_STATUSES.map(st => `
                      <option value="${st}" ${appt.appointment_status === st ? 'selected' : ''}>${st}</option>
                    `).join('')}
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label">Attendance Tracking</label>
                  <select id="pa-attendance" class="form-control">
                    ${['Scheduled', 'Attended', 'No-Show'].map(af => `
                      <option value="${af}" ${appt.attendance_flag === af ? 'selected' : ''}>${af}</option>
                    `).join('')}
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label">Schedule Date <span class="req">*</span></label>
                  <input type="date" id="pa-date" class="form-control" value="${escapeHtml(defDate)}" required />
                </div>

                <div class="form-group">
                  <label class="form-label">Assign Dialysis Machine (Required for Confirmed)</label>
                  <select id="pa-machine" class="form-control">
                    <option value="">-- Select Available Station --</option>
                    ${operationalMachines.map(m => `
                      <option value="${escapeHtml(m.machine_id)}" ${appt.machine_id === m.machine_id ? 'selected' : ''}>
                        ${escapeHtml(m.machine_code)} — ${escapeHtml(m.machine_name)} (${escapeHtml(m.machine_status)})
                      </option>
                    `).join('')}
                  </select>
                </div>

                <div class="form-group">
                  <label class="form-label">Start Time</label>
                  <input type="time" id="pa-start" class="form-control" value="${escapeHtml(defStart)}" required />
                </div>

                <div class="form-group">
                  <label class="form-label">End Time</label>
                  <input type="time" id="pa-end" class="form-control" value="${escapeHtml(defEnd)}" required />
                </div>

                <div class="form-group full-width">
                  <label class="form-label">Staff Remarks (Visible to Patient)</label>
                  <textarea id="pa-remarks" class="form-control" placeholder="Remarks, machine instructions, or rejection/correction explanation...">${escapeHtml(appt.staff_remarks || '')}</textarea>
                </div>
              </div>
              <button type="submit" class="btn btn-primary" style="width:100%;">Save Appointment Decision</button>
            </form>
          `,
          onMount: (mEl) => {
            mEl.querySelector('#staff-process-appt-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const newStatus = mEl.querySelector('#pa-status').value;
              const attendance = mEl.querySelector('#pa-attendance').value;
              const cDate = mEl.querySelector('#pa-date').value;
              const machineId = mEl.querySelector('#pa-machine').value;
              const sTime = mEl.querySelector('#pa-start').value;
              const eTime = mEl.querySelector('#pa-end').value;
              const remarks = mEl.querySelector('#pa-remarks').value.trim();

              try {
                if (newStatus === 'Confirmed') {
                  if (!machineId) {
                    throw new Error('Please assign an operational dialysis machine before confirming the appointment.');
                  }
                  const { error: rpcErr } = await supabase.rpc('assign_machine_and_confirm_appointment', {
                    p_appointment_id: appt.appointment_id,
                    p_machine_id: machineId,
                    p_confirmed_date: cDate,
                    p_start_time: sTime,
                    p_end_time: eTime,
                    p_remarks: remarks || null
                  });
                  if (rpcErr) {
                    if (rpcErr.message.includes('excl_machine_slot_no_overlap')) {
                      throw new Error('Double-booking prevented: That machine already has an overlapping slot on the selected date and time.');
                    }
                    throw rpcErr;
                  }

                  if (attendance !== appt.attendance_flag) {
                    await supabase.from('appointments').update({ attendance_flag: attendance }).eq('appointment_id', appt.appointment_id);
                  }
                } else {
                  if (newStatus === 'Rejected' && !remarks) {
                    throw new Error('Please provide a reason in Staff Remarks when rejecting an appointment.');
                  }

                  const nextHist = [...(appt.status_history || []), {
                    status: newStatus,
                    timestamp: new Date().toISOString(),
                    remarks: remarks || `Status updated to ${newStatus} by clinical staff.`
                  }];

                  const { error: updErr } = await supabase
                    .from('appointments')
                    .update({
                      appointment_status: newStatus,
                      processed_by: state.staff.staff_id,
                      staff_remarks: remarks || null,
                      attendance_flag: attendance,
                      reschedule_requested: false,
                      status_history: nextHist
                    })
                    .eq('appointment_id', appt.appointment_id);
                  if (updErr) throw updErr;

                  const pt = state.patients.find(p => p.patient_id === appt.patient_id);
                  if (pt?.user_id) {
                    await sendUserNotification(
                      pt.user_id,
                      `Appointment Status: ${newStatus}`,
                      `Your appointment request for ${formatDate(cDate)} is now "${newStatus}".${remarks ? ` Remarks: ${remarks}` : ''}`,
                      'Appointment',
                      appt.appointment_id
                    );
                  }

                  await recordAudit(`Updated Appointment Status to ${newStatus}`, 'Appointments', appt.appointment_id, {
                    status: newStatus,
                    attendance,
                    remarks
                  });
                }

                closeModal();
                showToast(`Appointment updated (${newStatus}).`, 'success');
                await onRefresh();
                draw();
              } catch (err) {
                showToast(err.message || 'Failed to update appointment.', 'error');
              }
            });
          }
        });
      });
    });
  }

  draw();
}
