/**
 * Reliance Dialysis Center Inc. — Authentication Module
 * Handles Supabase Auth Registration, Login, Forgot Password, Password Recovery,
 * and automatic Role-based Panel Redirection.
 */

import { supabase, recordAudit } from './supabaseClient.js';
import { resolveAuthenticatedContext, getPanelUrlForRole } from './authGuard.js';
import { mountRelianceChatbot } from './components/chatbot.js';
import { escapeHtml } from './utils.js';

const alertBox = document.getElementById('auth-alert-box');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const forgotForm = document.getElementById('forgot-form');
const recoveryForm = document.getElementById('recovery-update-form');

const tabButtons = Array.from(document.querySelectorAll('.auth-tab-btn'));

function showAlert(msg, type = 'info') {
  alertBox.hidden = false;
  const cls = type === 'error' ? 'alert alert-red' : type === 'success' ? 'alert alert-success' : 'alert';
  alertBox.className = cls;
  alertBox.innerHTML = escapeHtml(msg);
}

function clearAlert() {
  alertBox.hidden = true;
  alertBox.innerHTML = '';
}

function switchTab(tabName) {
  clearAlert();
  tabButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tabName));
  loginForm.hidden = tabName !== 'login';
  registerForm.hidden = tabName !== 'register';
  forgotForm.hidden = tabName !== 'forgot';
  recoveryForm.hidden = tabName !== 'recovery';
}

async function redirectAuthenticatedUser() {
  const ctx = await resolveAuthenticatedContext();
  if (ctx) {
    window.location.replace(getPanelUrlForRole(ctx.role));
    return true;
  }
  return false;
}

async function initAuthPage() {
  mountRelianceChatbot();

  // Check flash message from guard
  const flash = sessionStorage.getItem('rdc_auth_flash');
  if (flash) {
    sessionStorage.removeItem('rdc_auth_flash');
    showAlert(flash, 'error');
  }

  // Listen for PASSWORD_RECOVERY event from Supabase Auth link
  supabase.auth.onAuthStateChange((event) => {
    if (event === 'PASSWORD_RECOVERY') {
      switchTab('recovery');
    }
  });

  // Query param ?mode=register
  const params = new URLSearchParams(window.location.search);
  if (params.get('mode') === 'register') {
    switchTab('register');
  }

  // If already logged in (and not in password recovery hash), redirect to panel
  if (!window.location.hash.includes('type=recovery')) {
    try {
      const redirected = await redirectAuthenticatedUser();
      if (redirected) return;
    } catch (err) {
      showAlert(err.message, 'error');
    }
  }

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  document.getElementById('goto-forgot-link')?.addEventListener('click', () => switchTab('forgot'));
  document.getElementById('goto-register-link')?.addEventListener('click', () => switchTab('register'));

  // Login Handler
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert();

    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    if (!email || !password) {
      showAlert('Please enter both your email address and password.', 'error');
      return;
    }

    const submitBtn = document.getElementById('login-submit-btn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Signing in...';

    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      const ctx = await resolveAuthenticatedContext();
      if (!ctx) throw new Error('Unable to resolve user profile.');

      await recordAudit('User Signed In', 'Authentication', ctx.user.id, { role: ctx.role });
      window.location.replace(getPanelUrlForRole(ctx.role));
    } catch (err) {
      showAlert(err.message || 'Invalid login credentials.', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Sign In to Portal';
    }
  });

  // Quick verified role login buttons
  document.querySelectorAll('.quick-login-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('login-email').value = btn.dataset.email;
      document.getElementById('login-password').value = btn.dataset.pass;
      loginForm.requestSubmit();
    });
  });

  // Patient Registration Handler
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert();

    const fullName = document.getElementById('reg-fullname').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const confirm = document.getElementById('reg-confirm').value;

    if (!fullName || !email || !password || !confirm) {
      showAlert('Please complete all required registration fields.', 'error');
      return;
    }
    if (password.length < 6) {
      showAlert('Password must be at least 6 characters long.', 'error');
      return;
    }
    if (password !== confirm) {
      showAlert('Password and Confirm Password do not match.', 'error');
      return;
    }

    const regBtn = document.getElementById('reg-submit-btn');
    regBtn.disabled = true;
    regBtn.textContent = 'Creating Patient Account...';

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            intended_role: 'patient'
          }
        }
      });
      if (error) throw error;

      if (data?.session) {
        window.location.replace('/patient.html#onboarding');
      } else {
        showAlert('Account registered! Please sign in below with your credentials.', 'success');
        switchTab('login');
        document.getElementById('login-email').value = email;
      }
    } catch (err) {
      showAlert(err.message || 'Registration failed.', 'error');
    } finally {
      regBtn.disabled = false;
      regBtn.textContent = 'Create Patient Account';
    }
  });

  // Forgot Password Handler
  forgotForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAlert();
    const email = document.getElementById('forgot-email').value.trim();
    if (!email) {
      showAlert('Please enter your registered email address.', 'error');
      return;
    }

    const forgotBtn = document.getElementById('forgot-submit-btn');
    forgotBtn.disabled = true;
    forgotBtn.textContent = 'Sending Recovery Link...';

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth.html`
      });
      if (error) throw error;
      showAlert('Password reset instructions have been sent to your email address.', 'success');
    } catch (err) {
      showAlert(err.message || 'Could not send reset email.', 'error');
    } finally {
      forgotBtn.disabled = false;
      forgotBtn.textContent = 'Send Password Reset Link';
    }
  });

  // Password Recovery Update Handler
  recoveryForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const newPassword = document.getElementById('new-rec-password').value;
    if (!newPassword || newPassword.length < 6) {
      showAlert('Password must be at least 6 characters.', 'error');
      return;
    }
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      showAlert('Password updated! Redirecting to your portal...', 'success');
      setTimeout(() => redirectAuthenticatedUser(), 900);
    } catch (err) {
      showAlert(err.message || 'Failed to update password.', 'error');
    }
  });
}

initAuthPage();
