/**
 * Reliance Dialysis Center Inc. — Patient "My Records" Module (IV.G)
 * Contains three main sections:
 *   1. Medical Information (read-only official clinical view + link to profile correction)
 *   2. Submitted Documents (4 required documents + released authorized medical files with signed previews)
 *   3. Dialysis History (completed/released treatment sessions from dialysis_sessions; read-only for patients)
 */

import { supabase, STORAGE_BUCKET, REQUIRED_DOCUMENT_TYPES } from '../supabaseClient.js';
import {
  escapeHtml,
  formatDate,
  formatDateTime,
  formatTimeRange,
  formatFileSize,
  docBadgeHtml
} from '../utils.js';
import { showToast, openModal } from '../components/toast.js';

export function renderPatientRecordsModule({ container, state, onNavigateProfile }) {
  let activeTab = 'medical';

  async function previewFile(doc) {
    try {
      const { data, error } = await supabase.storage
        .from(STORAGE_BUCKET)
        .createSignedUrl(doc.file_path, 300);
      if (error) throw error;

      const isImage = (doc.mime_type || '').startsWith('image/');
      openModal({
        title: `${doc.document_type} — ${doc.file_name}`,
        size: 'lg',
        bodyHtml: isImage
          ? `<div style="text-align:center;"><img src="${escapeHtml(data.signedUrl)}" alt="${escapeHtml(doc.file_name)}" style="max-height:65vh; margin:0 auto;" /></div>`
          : `<iframe src="${escapeHtml(data.signedUrl)}" title="Document Preview" style="width:100%; height:65vh; border:1px solid var(--border-subtle);"></iframe>`,
        footerHtml: `<a href="${escapeHtml(data.signedUrl)}" target="_blank" rel="noopener" class="btn btn-primary btn-sm">Open / Download</a>`
      });
    } catch (err) {
      showToast(err.message || 'File preview unavailable.', 'error');
    }
  }

  function render() {
    const m = state.medicalProfile || {};
    const docs = state.documents || [];
    const sessions = state.sessions || [];

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">My Medical &amp; Dialysis Records</h1>
          <p class="page-subtitle">View your clinical profile, submitted verification documents, and official released hemodialysis treatment records.</p>
        </div>
      </div>

      <div class="sub-tabs">
        <button type="button" class="sub-tab-btn ${activeTab === 'medical' ? 'active' : ''}" data-rtab="medical">
          1. Medical Information
        </button>
        <button type="button" class="sub-tab-btn ${activeTab === 'documents' ? 'active' : ''}" data-rtab="documents">
          2. Submitted Documents (${docs.length})
        </button>
        <button type="button" class="sub-tab-btn ${activeTab === 'history' ? 'active' : ''}" data-rtab="history">
          3. Dialysis History (${sessions.length})
        </button>
      </div>

      <div id="records-tab-body"></div>
    `;

    container.querySelectorAll('[data-rtab]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.rtab;
        render();
      });
    });

    const body = container.querySelector('#records-tab-body');

    if (activeTab === 'medical') {
      body.innerHTML = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Patient Medical Profile</h2>
            <button type="button" class="btn btn-outline-blue btn-sm" id="rec-request-update-btn">
              Update / Request Correction
            </button>
          </div>

          <div class="kv-grid">
            <div class="kv-item">
              <div class="kv-label">Height</div>
              <div class="kv-value">${m.height ? `${escapeHtml(m.height)} cm` : '—'}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Weight Profile (Baseline)</div>
              <div class="kv-value">${m.weight ? `${escapeHtml(m.weight)} kg` : '—'}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Blood Type</div>
              <div class="kv-value">${escapeHtml(m.blood_type || '—')}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Known Allergies</div>
              <div class="kv-value">${escapeHtml(m.allergies || '—')}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Medical Diagnosis / Kidney Condition</div>
              <div class="kv-value"><strong>${escapeHtml(m.diagnosis || '—')}</strong></div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Existing Medical Conditions</div>
              <div class="kv-value">${escapeHtml(m.existing_medical_conditions || '—')}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Previous Surgeries</div>
              <div class="kv-value">${escapeHtml(m.previous_surgeries || 'None reported')}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Current Medications</div>
              <div class="kv-value">${escapeHtml(m.current_medications || '—')}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Attending Nephrologist</div>
              <div class="kv-value"><strong>${escapeHtml(m.attending_nephrologist || '—')}</strong></div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Prescribed Dialysis Frequency</div>
              <div class="kv-value"><strong>${escapeHtml(m.prescribed_dialysis_frequency || '—')}</strong></div>
            </div>
          </div>
        </div>
      `;

      body.querySelector('#rec-request-update-btn')?.addEventListener('click', () => onNavigateProfile());
    }

    if (activeTab === 'documents') {
      const additionalDocs = docs.filter(d => !REQUIRED_DOCUMENT_TYPES.includes(d.document_type));
      body.innerHTML = `
        <div class="card" style="margin-bottom:1.35rem;">
          <div class="card-header">
            <h2 class="card-title">Required Appointment Documents</h2>
          </div>

          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Document Category</th>
                  <th>File Information</th>
                  <th>Uploaded Date</th>
                  <th>Verification Status</th>
                  <th>Verification Remarks</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${REQUIRED_DOCUMENT_TYPES.map(dt => {
                  const doc = docs
                    .filter(x => x.document_type === dt)
                    .sort((a, b) => new Date(b.uploaded_at) - new Date(a.uploaded_at))[0];
                  return `
                    <tr>
                      <td><strong>${escapeHtml(dt)}</strong></td>
                      <td>${doc ? `${escapeHtml(doc.file_name)} <span class="text-muted">(${escapeHtml(formatFileSize(doc.file_size))})</span>` : '<span class="text-muted">Not uploaded yet</span>'}</td>
                      <td>${doc ? escapeHtml(formatDateTime(doc.uploaded_at)) : '—'}</td>
                      <td>${docBadgeHtml(doc?.verification_status || 'Missing')}</td>
                      <td>${escapeHtml(doc?.remarks || (doc?.reviewed_at ? `Reviewed ${formatDate(doc.reviewed_at)}` : '—'))}</td>
                      <td>
                        ${doc ? `<button type="button" class="btn btn-outline-blue btn-xs rec-doc-view-btn" data-id="${escapeHtml(doc.document_id)}">View File</button>` : '—'}
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>

        ${additionalDocs.length > 0 ? `
          <div class="card">
            <div class="card-header">
              <h2 class="card-title">Additional Released Medical Files</h2>
            </div>
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>File Name</th>
                    <th>Released Date</th>
                    <th>Notes</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  ${additionalDocs.map(doc => `
                    <tr>
                      <td><strong>${escapeHtml(doc.document_type)}</strong></td>
                      <td>${escapeHtml(doc.file_name)}</td>
                      <td>${escapeHtml(formatDateTime(doc.uploaded_at))}</td>
                      <td>${escapeHtml(doc.remarks || '—')}</td>
                      <td><button type="button" class="btn btn-outline-blue btn-xs rec-doc-view-btn" data-id="${escapeHtml(doc.document_id)}">View File</button></td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        ` : ''}
      `;

      body.querySelectorAll('.rec-doc-view-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const doc = docs.find(d => d.document_id === btn.dataset.id);
          if (doc) previewFile(doc);
        });
      });
    }

    if (activeTab === 'history') {
      body.innerHTML = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Official Dialysis Treatment History</h2>
            <span class="text-muted" style="font-size:0.82rem;">Read-only official treatment records released by clinic staff</span>
          </div>

          ${sessions.length === 0 ? `
            <div class="empty-state">No completed dialysis treatment records have been released yet.</div>
          ` : `
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Treatment Date</th>
                    <th>Assigned Machine</th>
                    <th>Actual Treatment Time</th>
                    <th>Pre-Dialysis Weight</th>
                    <th>Post-Dialysis Weight</th>
                    <th>Vitals / UF</th>
                    <th>Released Treatment Notes</th>
                  </tr>
                </thead>
                <tbody>
                  ${sessions.map(s => `
                    <tr>
                      <td><strong>${escapeHtml(formatDate(s.treatment_date))}</strong></td>
                      <td><span class="badge badge-machine-occupied">${escapeHtml(s.machine_code || 'Station')}</span></td>
                      <td>${escapeHtml(formatTimeRange(s.actual_start_time, s.actual_end_time))}</td>
                      <td>${s.pre_dialysis_weight !== null && s.pre_dialysis_weight !== undefined ? `${escapeHtml(s.pre_dialysis_weight)} kg` : '—'}</td>
                      <td>${s.post_dialysis_weight !== null && s.post_dialysis_weight !== undefined ? `${escapeHtml(s.post_dialysis_weight)} kg` : '—'}</td>
                      <td style="font-size:0.81rem;">
                        ${s.blood_pressure_pre ? `BP: ${escapeHtml(s.blood_pressure_pre)} → ${escapeHtml(s.blood_pressure_post || '—')}<br>` : ''}
                        ${s.ultrafiltration_volume ? `UF: ${escapeHtml(s.ultrafiltration_volume)} mL` : ''}
                      </td>
                      <td style="max-width:280px; font-size:0.83rem;">${escapeHtml(s.treatment_notes || '—')}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `}
        </div>
      `;
    }
  }

  render();
}
