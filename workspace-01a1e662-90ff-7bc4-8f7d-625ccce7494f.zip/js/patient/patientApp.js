/**
 * Reliance Dialysis Center Inc. — Patient Portal Master Controller
 * Orchestrates Auth Guard, Initial Profile Setup enforcement, Page 6 Header/Sidebar,
 * Notification Bell, Reliance Assistant Chatbot, and all Patient Panel views.
 */

import { supabase, fetchClinicConfig } from '../supabaseClient.js';
import { requireRoleGuard, signOutAndRedirect } from '../authGuard.js';
import { NotificationBell } from '../components/notifications.js';
import { mountRelianceChatbot } from '../components/chatbot.js';
import { evaluateProfileCompletion, escapeHtml, formatDateTime } from '../utils.js';

import { renderPatientDashboard } from './dashboard.js';
import { renderPatientBookingModule } from './booking.js';
import { renderPatientRecordsModule } from './records.js';
import { renderPatientProfileForm } from './profile.js';

const mainView = document.getElementById('patient-main-view');
const sidebar = document.getElementById('portal-sidebar');

const state = {
  user: null,
  patient: null,
  medicalProfile: null,
  documents: [],
  appointments: [],
  sessions: [],
  notifications: [],
  clinicConfig: null
};

let currentView = 'dashboard';
let currentSubTab = null;
let notifBell = null;

async function refreshPatientData() {
  const [patRes, medRes, docRes, apptRes, sessRes, notifRes, cfg] = await Promise.all([
    supabase.from('patients').select('*').eq('user_id', state.user.id).single(),
    supabase.from('patient_medical_profiles').select('*').eq('patient_id', state.patient.patient_id).maybeSingle(),
    supabase.from('patient_documents').select('*').eq('patient_id', state.patient.patient_id).order('uploaded_at', { ascending: false }),
    supabase
      .from('appointments')
      .select('*, machine_slots(machine_id, dialysis_machines(machine_code, machine_name))')
      .eq('patient_id', state.patient.patient_id)
      .order('requested_date', { ascending: false }),
    supabase
      .from('dialysis_sessions')
      .select('*, dialysis_machines(machine_code, machine_name)')
      .eq('patient_id', state.patient.patient_id)
      .eq('is_released_to_patient', true)
      .order('treatment_date', { ascending: false }),
    supabase
      .from('notifications')
      .select('*')
      .eq('recipient_user_id', state.user.id)
      .order('created_at', { ascending: false }),
    fetchClinicConfig()
  ]);

  if (patRes.data) state.patient = patRes.data;
  state.medicalProfile = medRes.data || null;
  state.documents = docRes.data || [];
  state.appointments = (apptRes.data || []).map(a => ({
    ...a,
    machine_code: a.machine_slots?.dialysis_machines?.machine_code || null
  }));
  state.sessions = (sessRes.data || []).map(s => ({
    ...s,
    machine_code: s.dialysis_machines?.machine_code || null
  }));
  state.notifications = notifRes.data || [];
  state.clinicConfig = cfg;

  document.getElementById('header-patient-name').textContent = state.patient?.full_name || 'Patient';
  document.getElementById('dropdown-patient-name').textContent = state.patient?.full_name || 'Patient';
  document.getElementById('dropdown-patient-email').textContent = state.user?.email || '';

  if (notifBell) await notifBell.refresh();
}

function renderAllNotificationsView() {
  const list = state.notifications || [];
  mainView.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Notifications</h1>
        <p class="page-subtitle">All appointment updates, document correction requests, confirmations, and released record alerts.</p>
      </div>
      <button type="button" class="btn btn-outline-blue btn-sm" id="page-mark-all-read">Mark All as Read</button>
    </div>

    <div class="card">
      ${list.length === 0 ? `<div class="empty-state">You have no notifications yet.</div>` : `
        <div style="display:flex; flex-direction:column; gap:0.75rem;">
          ${list.map(n => `
            <div style="padding:0.9rem 1rem; border:1px solid var(--border-subtle); border-left:4px solid ${n.is_read ? 'var(--reliance-blue)' : 'var(--reliance-red)'}; border-radius:8px; background:${n.is_read ? '#fff' : '#f7faff'};">
              <div style="display:flex; justify-content:space-between; font-size:0.78rem; color:var(--text-muted);">
                <strong>${escapeHtml(n.notification_type)}</strong>
                <span>${escapeHtml(formatDateTime(n.created_at))}</span>
              </div>
              <div style="font-weight:700; margin-top:0.2rem;">${escapeHtml(n.title)}</div>
              <div style="font-size:0.88rem; color:var(--text-secondary); margin-top:0.15rem;">${escapeHtml(n.message)}</div>
            </div>
          `).join('')}
        </div>
      `}
    </div>
  `;

  mainView.querySelector('#page-mark-all-read')?.addEventListener('click', async () => {
    await notifBell.markAllRead();
    await refreshPatientData();
    renderAllNotificationsView();
  });
}

async function navigateTo(view, subTab = null) {
  const completion = evaluateProfileCompletion(state.patient, state.medicalProfile);

  // Enforce Initial Patient Profile Setup right after registration
  if (!completion.isComplete && view !== 'profile') {
    currentView = 'onboarding';
    document.querySelectorAll('.sidebar-nav-btn').forEach(b => b.classList.remove('active'));
    renderPatientProfileForm({
      container: mainView,
      state,
      isOnboarding: true,
      onSaved: async () => {
        await refreshPatientData();
        await navigateTo('dashboard');
      }
    });
    return;
  }

  currentView = view;
  currentSubTab = subTab;
  sidebar.classList.remove('open');

  document.querySelectorAll('.sidebar-nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });

  if (view === 'dashboard') {
    renderPatientDashboard({
      container: mainView,
      state,
      onNavigate: (v, s) => navigateTo(v, s)
    });
  } else if (view === 'book') {
    await renderPatientBookingModule({
      container: mainView,
      state,
      initialSubTab: currentSubTab || 'wizard',
      onRefreshState: refreshPatientData,
      onGoToProfile: () => navigateTo('profile')
    });
  } else if (view === 'records') {
    renderPatientRecordsModule({
      container: mainView,
      state,
      onNavigateProfile: () => navigateTo('profile')
    });
  } else if (view === 'profile' || view === 'onboarding') {
    renderPatientProfileForm({
      container: mainView,
      state,
      isOnboarding: !completion.isComplete,
      onSaved: async () => {
        await refreshPatientData();
        await navigateTo('dashboard');
      }
    });
  } else if (view === 'notifications') {
    renderAllNotificationsView();
  }
}

async function initPatientPortal() {
  const ctx = await requireRoleGuard(['patient']);
  if (!ctx) return;

  state.user = ctx.user;
  state.patient = ctx.patient;

  mountRelianceChatbot();

  // Notification Bell
  notifBell = new NotificationBell({
    userId: state.user.id,
    bellButton: document.getElementById('notif-bell-btn'),
    badgeElement: document.getElementById('notif-badge'),
    dropdownElement: document.getElementById('notif-dropdown'),
    onViewAll: () => navigateTo('notifications')
  });
  await notifBell.init();

  // Profile Dropdown
  const profileTrigger = document.getElementById('profile-trigger-btn');
  const profileDropdown = document.getElementById('profile-dropdown');
  profileTrigger.addEventListener('click', (e) => {
    e.stopPropagation();
    profileDropdown.hidden = !profileDropdown.hidden;
  });
  document.addEventListener('click', (e) => {
    if (!profileDropdown.hidden && !document.getElementById('profile-menu-wrapper').contains(e.target)) {
      profileDropdown.hidden = true;
    }
  });

  document.getElementById('menu-my-profile-btn').addEventListener('click', () => {
    profileDropdown.hidden = true;
    navigateTo('profile');
  });
  document.getElementById('menu-notifications-btn').addEventListener('click', () => {
    profileDropdown.hidden = true;
    navigateTo('notifications');
  });
  document.getElementById('menu-logout-btn').addEventListener('click', () => {
    signOutAndRedirect('/auth.html');
  });

  // Mobile Sidebar Toggle
  document.getElementById('sidebar-toggle-btn').addEventListener('click', () => {
    sidebar.classList.toggle('open');
  });

  // Left Sidebar Navigation
  document.querySelectorAll('.sidebar-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.view));
  });

  await refreshPatientData();

  const hash = window.location.hash.replace('#', '');
  if (['book', 'records', 'profile', 'notifications'].includes(hash)) {
    await navigateTo(hash);
  } else {
    await navigateTo('dashboard');
  }
}

initPatientPortal();
