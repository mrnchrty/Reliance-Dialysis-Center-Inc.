/**
 * Reliance Dialysis Center Inc. — Patient Appointment Booking, Tracking & Recurring Schedule Module
 * Implements:
 *   - IV.D: 5-Step Appointment Booking Wizard (Profile Check -> 4 Documents in Supabase Storage -> Interactive Calendar -> Preferred Time -> Review & Submit)
 *   - Strict Machine Assignment Rule: Patients select ONLY date & time; NEVER machine.
 *   - IV.E: Appointment Tracking with ONLY 4 main statuses (Pending, Under Review, Confirmed, Rejected) + separate Cancellation & Reschedule actions + Status History modal.
 *   - IV.F: Recurring Appointments view & patient succeeding request generator using existing patient_medical_profiles + appointments tables.
 */

import {
  supabase,
  STORAGE_BUCKET,
  REQUIRED_DOCUMENT_TYPES,
  APPOINTMENT_STATUSES,
  recordAudit,
  notifyStaff,
  sendUserNotification
} from '../supabaseClient.js';
import {
  escapeHtml,
  formatDate,
  formatDateTime,
  formatTimeRange,
  formatFileSize,
  getTodayISO,
  toISODate,
  statusBadgeHtml,
  docBadgeHtml,
  evaluateProfileCompletion
} from '../utils.js';
import { showToast, openModal, closeModal } from '../components/toast.js';

const ALLOWED_MIMES = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10 MB

const DAY_NAME_TO_INDEX = {
  Sunday: 0,
  Monday: 1,
  Tuesday: 2,
  Wednesday: 3,
  Thursday: 4,
  Friday: 5,
  Saturday: 6
};

export async function renderPatientBookingModule({ container, state, initialSubTab = 'wizard', onRefreshState, onGoToProfile }) {
  let activeSubTab = initialSubTab || 'wizard';
  let currentStep = 1;
  let selectedDate = '';
  let selectedTimeId = '';
  let calYear = new Date().getFullYear();
  let calMonth = new Date().getMonth();
  let availabilityData = { active_machine_capacity: 9, booked_slots: [], pending_requests: [] };
  let statusFilter = 'ALL';

  async function loadCalendarAvailability() {
    const start = new Date(calYear, calMonth, 1);
    const end = new Date(calYear, calMonth + 2, 0);
    const { data, error } = await supabase.rpc('get_schedule_availability', {
      p_start_date: toISODate(start),
      p_end_date: toISODate(end)
    });
    if (!error && data) {
      availabilityData = data;
    }
  }

  function getLatestDocByType(docType) {
    const matches = (state.documents || [])
      .filter(d => d.document_type === docType)
      .sort((a, b) => new Date(b.uploaded_at) - new Date(a.uploaded_at));
    return matches[0] || null;
  }

  function allFourDocumentsReady() {
    return REQUIRED_DOCUMENT_TYPES.every(dt => {
      const doc = getLatestDocByType(dt);
      return doc && (doc.verification_status === 'Verified' || doc.verification_status === 'Pending');
    });
  }

  function getSlotCapacityForDate(dateIso, slotObj) {
    const maxCap = Number(availabilityData.active_machine_capacity ?? 9);
    if (maxCap <= 0) return 0;

    const booked = (availabilityData.booked_slots || [])
      .filter(s => s.schedule_date === dateIso && s.start_time.slice(0, 5) === slotObj.start_time.slice(0, 5))
      .reduce((acc, r) => acc + Number(r.booked_count || 0), 0);

    return Math.max(0, maxCap - booked);
  }

  function getTotalRemainingCapacityForDate(dateIso) {
    const slots = state.clinicConfig?.time_slots || [];
    return slots.reduce((sum, sl) => sum + getSlotCapacityForDate(dateIso, sl), 0);
  }

  function isOperatingDate(dateObj) {
    const opDays = state.clinicConfig?.operating_days || [1, 2, 3, 4, 5, 6];
    return opDays.includes(dateObj.getDay());
  }

  async function openDocumentPreview(doc) {
    try {
      const { data, error } = await supabase.storage
        .from(STORAGE_BUCKET)
        .createSignedUrl(doc.file_path, 300);
      if (error) throw error;

      const isImage = (doc.mime_type || '').startsWith('image/');
      openModal({
        title: `${doc.document_type} — ${doc.file_name}`,
        size: 'lg',
        bodyHtml: isImage
          ? `<div style="text-align:center;"><img src="${escapeHtml(data.signedUrl)}" alt="${escapeHtml(doc.file_name)}" style="max-height:65vh; margin:0 auto; border-radius:6px;" /></div>`
          : `<iframe src="${escapeHtml(data.signedUrl)}" title="Document Preview" style="width:100%; height:65vh; border:1px solid var(--border-subtle); border-radius:6px;"></iframe>`,
        footerHtml: `<a href="${escapeHtml(data.signedUrl)}" target="_blank" rel="noopener" class="btn btn-primary btn-sm">Open / Download File</a>`
      });
    } catch (err) {
      showToast(err.message || 'Could not generate preview link.', 'error');
    }
  }

  async function uploadPatientDocument(docType, file, progressFillEl) {
    if (!ALLOWED_MIMES.includes(file.type)) {
      throw new Error('Invalid file format. Please upload PDF, JPG, PNG, or WEBP only.');
    }
    if (file.size > MAX_FILE_BYTES) {
      throw new Error('File exceeds the 10 MB maximum size limit.');
    }

    if (progressFillEl) progressFillEl.style.width = '35%';

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const storagePath = `${state.user.id}/${Date.now()}_${safeName}`;

    const { error: upErr } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(storagePath, file, { upsert: true, contentType: file.type });

    if (upErr) throw upErr;
    if (progressFillEl) progressFillEl.style.width = '75%';

    const existing = getLatestDocByType(docType);
    if (existing && existing.verification_status !== 'Verified') {
      const { error: updErr } = await supabase
        .from('patient_documents')
        .update({
          file_path: storagePath,
          file_name: file.name,
          file_size: file.size,
          mime_type: file.type,
          uploaded_at: new Date().toISOString(),
          verification_status: 'Pending',
          remarks: null
        })
        .eq('document_id', existing.document_id);
      if (updErr) throw updErr;
    } else {
      const { error: insErr } = await supabase
        .from('patient_documents')
        .insert({
          patient_id: state.patient.patient_id,
          document_type: docType,
          file_path: storagePath,
          file_name: file.name,
          file_size: file.size,
          mime_type: file.type,
          verification_status: 'Pending'
        });
      if (insErr) throw insErr;
    }

    if (progressFillEl) progressFillEl.style.width = '100%';

    await notifyStaff(
      'Document Uploaded for Verification',
      `${state.patient.full_name} uploaded "${docType}" (${file.name}).`,
      'Document'
    );
    await recordAudit('Uploaded Required Medical Document', 'Patient Documents', docType, {
      file_name: file.name,
      size: file.size
    });
  }

  async function render() {
    const completion = evaluateProfileCompletion(state.patient, state.medicalProfile);
    const slots = state.clinicConfig?.time_slots || [];

    // Auto-advance step 1 if profile is already complete and user hasn't picked a step yet
    if (currentStep === 1 && completion.isComplete && allFourDocumentsReady() && !selectedDate) {
      // keep step 1 visible so user sees the 5-step flow clearly, with instant Continue button
    }

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Appointments &amp; Scheduling</h1>
          <p class="page-subtitle">Submit online hemodialysis schedule requests, track approval status, and manage recurring sessions.</p>
        </div>
      </div>

      <div class="sub-tabs">
        <button type="button" class="sub-tab-btn ${activeSubTab === 'wizard' ? 'active' : ''}" data-subtab="wizard">
          Book New Appointment
        </button>
        <button type="button" class="sub-tab-btn ${activeSubTab === 'tracking' ? 'active' : ''}" data-subtab="tracking">
          Appointment Tracking (${(state.appointments || []).length})
        </button>
        <button type="button" class="sub-tab-btn ${activeSubTab === 'recurring' ? 'active' : ''}" data-subtab="recurring">
          Recurring Schedule
        </button>
      </div>

      <div id="booking-subview-body"></div>
    `;

    container.querySelectorAll('.sub-tab-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        activeSubTab = btn.dataset.subtab;
        await render();
      });
    });

    const subBody = container.querySelector('#booking-subview-body');

    if (activeSubTab === 'wizard') {
      await renderWizard(subBody, completion, slots);
    } else if (activeSubTab === 'tracking') {
      renderTracking(subBody);
    } else {
      await renderRecurring(subBody, slots);
    }
  }

  async function renderWizard(target, completion, slots) {
    if (currentStep === 3 || currentStep === 4) {
      await loadCalendarAvailability();
    }

    const stepLabels = [
      'Profile Check',
      'Upload 4 Documents',
      'Select Date',
      'Preferred Time',
      'Review & Submit'
    ];

    const stepperHtml = `
      <div class="wizard-stepper">
        ${stepLabels.map((lbl, idx) => {
          const sNum = idx + 1;
          const cls = sNum === currentStep ? 'active' : sNum < currentStep ? 'done' : '';
          return `
            <div class="wizard-step-pill ${cls}">
              <span class="step-num">${sNum < currentStep ? '✓' : sNum}</span>
              <span>${escapeHtml(lbl)}</span>
            </div>
          `;
        }).join('')}
      </div>
    `;

    let stepContentHtml = '';

    // STEP 1: Profile Completion Check
    if (currentStep === 1) {
      stepContentHtml = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Step 1 — Profile Completion Verification</h2>
            <span class="badge ${completion.isComplete ? 'badge-status-confirmed' : 'badge-status-rejected'}">
              ${completion.percentage}% Complete
            </span>
          </div>

          ${completion.isComplete ? `
            <div class="alert alert-success">
              <strong>Personal &amp; Medical Profile Verified Complete:</strong> Your information for <strong>${escapeHtml(state.patient.full_name)}</strong> (Attending Nephrologist: ${escapeHtml(state.medicalProfile.attending_nephrologist)}, Prescribed Frequency: ${escapeHtml(state.medicalProfile.prescribed_dialysis_frequency)}) is ready. You do not need to fill out your profile again.
            </div>
            <div class="kv-grid" style="margin-bottom:1.25rem;">
              <div class="kv-item"><div class="kv-label">Full Name</div><div class="kv-value">${escapeHtml(state.patient.full_name)}</div></div>
              <div class="kv-item"><div class="kv-label">Contact Number</div><div class="kv-value">${escapeHtml(state.patient.contact_number)}</div></div>
              <div class="kv-item"><div class="kv-label">Diagnosis</div><div class="kv-value">${escapeHtml(state.medicalProfile.diagnosis)}</div></div>
              <div class="kv-item"><div class="kv-label">Prescribed Frequency</div><div class="kv-value">${escapeHtml(state.medicalProfile.prescribed_dialysis_frequency)}</div></div>
            </div>
            <div style="display:flex; justify-content:flex-end;">
              <button type="button" class="btn btn-primary" id="step1-next-btn">Proceed to Step 2: Required Documents →</button>
            </div>
          ` : `
            <div class="alert alert-red">
              <strong>Profile Setup Required:</strong> Before submitting an appointment request, please complete the following missing fields:
              <ul style="margin:0.5rem 0 0 1.2rem;">
                ${completion.missingFields.map(f => `<li>${escapeHtml(f)}</li>`).join('')}
              </ul>
            </div>
            <button type="button" class="btn btn-red" id="goto-profile-from-step1">Complete Personal &amp; Medical Profile Now</button>
          `}
        </div>
      `;
    }

    // STEP 2: Upload Required 4 Documents (Supabase Storage)
    if (currentStep === 2) {
      const docsReady = allFourDocumentsReady();
      stepContentHtml = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Step 2 — Upload Required Medical Documents (4 Categories)</h2>
            <span class="badge ${docsReady ? 'badge-status-confirmed' : 'badge-status-pending'}">
              ${docsReady ? 'All 4 Ready' : 'Action Required'}
            </span>
          </div>

          <p class="text-muted" style="font-size:0.88rem; margin-top:0;">
            Accepted formats: <strong>PDF, JPG, PNG, WEBP</strong> (Max 10 MB per file). Previously verified documents remain saved and reusable for succeeding appointments unless clinic staff request an update.
          </p>

          <div class="doc-upload-grid" style="margin-bottom:1.35rem;">
            ${REQUIRED_DOCUMENT_TYPES.map((docType, idx) => {
              const existing = getLatestDocByType(docType);
              return `
                <div class="doc-slot-card" data-doc-card="${idx}">
                  <div>
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:0.5rem; margin-bottom:0.45rem;">
                      <strong style="color:var(--reliance-blue); font-size:0.94rem;">${idx + 1}. ${escapeHtml(docType)}</strong>
                      ${docBadgeHtml(existing?.verification_status || 'Missing')}
                    </div>

                    ${existing ? `
                      <div style="font-size:0.82rem; color:var(--text-secondary); margin-bottom:0.4rem;">
                        <div><strong>File:</strong> ${escapeHtml(existing.file_name)} (${escapeHtml(formatFileSize(existing.file_size))})</div>
                        <div><strong>Uploaded:</strong> ${escapeHtml(formatDateTime(existing.uploaded_at))}</div>
                        ${existing.remarks ? `<div class="text-red" style="margin-top:0.25rem;"><strong>Staff Remarks:</strong> ${escapeHtml(existing.remarks)}</div>` : ''}
                      </div>
                    ` : `
                      <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:0.4rem;">
                        No document uploaded yet. Required before booking submission.
                      </div>
                    `}
                  </div>

                  <div>
                    <div class="upload-progress-bar" style="margin-bottom:0.55rem;" hidden>
                      <div class="upload-progress-fill" style="width:0%"></div>
                    </div>

                    <div style="display:flex; flex-wrap:wrap; gap:0.5rem; align-items:center;">
                      <label class="btn btn-outline-blue btn-xs" style="cursor:pointer;">
                        <span>${existing ? 'Replace Document' : 'Select & Upload File'}</span>
                        <input type="file" class="doc-file-input" data-doctype="${escapeHtml(docType)}" accept=".pdf,.jpg,.jpeg,.png,.webp" hidden />
                      </label>
                      ${existing ? `
                        <button type="button" class="btn btn-outline btn-xs preview-doc-btn" data-docid="${escapeHtml(existing.document_id)}">
                          Preview File
                        </button>
                      ` : ''}
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          <div style="display:flex; justify-content:space-between;">
            <button type="button" class="btn btn-outline" id="step2-back-btn">← Back</button>
            <button type="button" class="btn btn-primary" id="step2-next-btn" ${docsReady ? '' : 'disabled'}>
              Proceed to Step 3: Select Date →
            </button>
          </div>
        </div>
      `;
    }

    // STEP 3: Interactive Appointment Calendar (Mon–Sat, 8AM–5PM, Closed Sundays)
    if (currentStep === 3) {
      const monthStart = new Date(calYear, calMonth, 1);
      const monthName = monthStart.toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });
      const startWeekday = monthStart.getDay();
      const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
      const todayIso = getTodayISO();

      const dayCells = [];
      for (let b = 0; b < startWeekday; b++) {
        dayCells.push(`<div></div>`);
      }
      for (let day = 1; day <= daysInMonth; day++) {
        const dObj = new Date(calYear, calMonth, day);
        const iso = toISODate(dObj);
        const isPast = iso < todayIso;
        const isOpenDay = isOperatingDate(dObj);
        const remCap = isOpenDay ? getTotalRemainingCapacityForDate(iso) : 0;
        const isDisabled = isPast || !isOpenDay || remCap <= 0;
        const isSelected = selectedDate === iso;

        let capLabel = '';
        if (!isOpenDay) capLabel = 'Closed';
        else if (isPast) capLabel = 'Past';
        else if (remCap <= 0) capLabel = 'Full';
        else capLabel = `${remCap} slots`;

        dayCells.push(`
          <button
            type="button"
            class="cal-day ${!isOpenDay ? 'closed' : ''} ${remCap <= 0 && isOpenDay && !isPast ? 'full' : ''} ${isSelected ? 'selected' : ''}"
            data-date="${iso}"
            ${isDisabled ? 'disabled' : ''}>
            <strong>${day}</strong>
            <span class="cal-cap-tag">${escapeHtml(capLabel)}</span>
          </button>
        `);
      }

      stepContentHtml = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Step 3 — Select Preferred Appointment Date</h2>
            <span class="text-muted" style="font-size:0.84rem;">Mon–Sat • 8:00 AM–5:00 PM (Closed Sundays)</span>
          </div>

          <div class="calendar-shell" style="margin-bottom:1.25rem;">
            <div class="calendar-header">
              <button type="button" class="btn btn-outline btn-sm" id="cal-prev-month">← Previous</button>
              <strong style="font-size:1.05rem; color:var(--reliance-blue);">${escapeHtml(monthName)}</strong>
              <button type="button" class="btn btn-outline btn-sm" id="cal-next-month">Next →</button>
            </div>

            <div class="calendar-weekdays">
              <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
            </div>

            <div class="calendar-days-grid">
              ${dayCells.join('')}
            </div>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center;">
            <button type="button" class="btn btn-outline" id="step3-back-btn">← Back</button>
            <div>
              ${selectedDate ? `<span style="margin-right:0.85rem; font-weight:600; color:var(--reliance-blue);">Selected: ${escapeHtml(formatDate(selectedDate))}</span>` : ''}
              <button type="button" class="btn btn-primary" id="step3-next-btn" ${selectedDate ? '' : 'disabled'}>
                Proceed to Step 4: Select Time →
              </button>
            </div>
          </div>
        </div>
      `;
    }

    // STEP 4: Select Preferred Time (Configurable 3-session schedule; NO machine selection!)
    if (currentStep === 4) {
      stepContentHtml = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Step 4 — Select Preferred Session Time (${escapeHtml(formatDate(selectedDate))})</h2>
          </div>

          <div class="alert">
            <strong>Dialysis Machine Assignment Policy:</strong> Patients select only their preferred appointment date and session time. Specific dialysis machines are assigned by authorized clinic staff after reviewing your documents and schedule request.
          </div>

          <div class="time-slots-grid" style="margin-bottom:1.35rem;">
            ${slots.map(slot => {
              const cap = getSlotCapacityForDate(selectedDate, slot);
              const isSelected = selectedTimeId === slot.id;
              return `
                <button
                  type="button"
                  class="time-slot-card ${isSelected ? 'selected' : ''}"
                  data-slot-id="${escapeHtml(slot.id)}"
                  ${cap <= 0 ? 'disabled' : ''}>
                  <div style="font-weight:700; font-size:1.05rem; color:var(--reliance-blue); margin-bottom:0.25rem;">
                    ${escapeHtml(slot.label)}
                  </div>
                  <div style="font-size:0.92rem; color:var(--text-main); margin-bottom:0.5rem;">
                    ${escapeHtml(slot.display)}
                  </div>
                  <div class="badge ${cap > 0 ? 'badge-status-confirmed' : 'badge-status-rejected'}">
                    ${cap > 0 ? `${cap} station(s) open` : 'No capacity'}
                  </div>
                </button>
              `;
            }).join('')}
          </div>

          <div style="display:flex; justify-content:space-between;">
            <button type="button" class="btn btn-outline" id="step4-back-btn">← Back</button>
            <button type="button" class="btn btn-primary" id="step4-next-btn" ${selectedTimeId ? '' : 'disabled'}>
              Proceed to Step 5: Review &amp; Submit →
            </button>
          </div>
        </div>
      `;
    }

    // STEP 5: Review and Submit
    if (currentStep === 5) {
      const chosenSlot = slots.find(s => s.id === selectedTimeId);
      stepContentHtml = `
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Step 5 — Review &amp; Submit Appointment Request</h2>
            <span class="badge badge-status-pending">Initial Status: Pending</span>
          </div>

          <div class="kv-grid" style="margin-bottom:1.35rem;">
            <div class="kv-item">
              <div class="kv-label">Patient Name</div>
              <div class="kv-value">${escapeHtml(state.patient.full_name)}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Selected Appointment Date</div>
              <div class="kv-value"><strong>${escapeHtml(formatDate(selectedDate, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }))}</strong></div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Preferred Session Time</div>
              <div class="kv-value"><strong>${escapeHtml(chosenSlot ? `${chosenSlot.label} (${chosenSlot.display})` : selectedTimeId)}</strong></div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Dialysis Machine</div>
              <div class="kv-value text-muted">Assigned by Staff upon Approval</div>
            </div>
          </div>

          <h3 style="font-size:0.95rem; color:var(--reliance-blue); margin:0 0 0.65rem;">Submitted Required Documents</h3>
          <div class="table-responsive" style="margin-bottom:1.35rem;">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Document Category</th>
                  <th>File Name</th>
                  <th>Verification Status</th>
                </tr>
              </thead>
              <tbody>
                ${REQUIRED_DOCUMENT_TYPES.map(dt => {
                  const doc = getLatestDocByType(dt);
                  return `
                    <tr>
                      <td><strong>${escapeHtml(dt)}</strong></td>
                      <td>${escapeHtml(doc?.file_name || '—')}</td>
                      <td>${docBadgeHtml(doc?.verification_status)}</td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>

          <div style="display:flex; justify-content:space-between;">
            <button type="button" class="btn btn-outline" id="step5-back-btn">← Back</button>
            <button type="button" class="btn btn-red" id="submit-appointment-request-btn">
              Submit Appointment Request
            </button>
          </div>
        </div>
      `;
    }

    target.innerHTML = stepperHtml + stepContentHtml;

    // Bind Step 1 actions
    target.querySelector('#goto-profile-from-step1')?.addEventListener('click', () => onGoToProfile());
    target.querySelector('#step1-next-btn')?.addEventListener('click', () => {
      currentStep = 2;
      render();
    });

    // Bind Step 2 actions (Uploads & Preview)
    target.querySelectorAll('.doc-file-input').forEach(input => {
      input.addEventListener('change', async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const docType = input.dataset.doctype;
        const card = input.closest('.doc-slot-card');
        const bar = card.querySelector('.upload-progress-bar');
        const fill = card.querySelector('.upload-progress-fill');
        bar.hidden = false;
        fill.style.width = '15%';

        try {
          await uploadPatientDocument(docType, file, fill);
          showToast(`${docType} uploaded successfully.`, 'success');
          await onRefreshState();
          await render();
        } catch (err) {
          bar.hidden = true;
          showToast(err.message || 'Document upload failed.', 'error');
        }
      });
    });

    target.querySelectorAll('.preview-doc-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const doc = (state.documents || []).find(d => d.document_id === btn.dataset.docid);
        if (doc) openDocumentPreview(doc);
      });
    });

    target.querySelector('#step2-back-btn')?.addEventListener('click', () => { currentStep = 1; render(); });
    target.querySelector('#step2-next-btn')?.addEventListener('click', () => { currentStep = 3; render(); });

    // Bind Step 3 Calendar actions
    target.querySelector('#cal-prev-month')?.addEventListener('click', () => {
      calMonth--;
      if (calMonth < 0) { calMonth = 11; calYear--; }
      render();
    });
    target.querySelector('#cal-next-month')?.addEventListener('click', () => {
      calMonth++;
      if (calMonth > 11) { calMonth = 0; calYear++; }
      render();
    });
    target.querySelectorAll('.cal-day:not([disabled])').forEach(dayBtn => {
      dayBtn.addEventListener('click', () => {
        selectedDate = dayBtn.dataset.date;
        selectedTimeId = '';
        render();
      });
    });
    target.querySelector('#step3-back-btn')?.addEventListener('click', () => { currentStep = 2; render(); });
    target.querySelector('#step3-next-btn')?.addEventListener('click', () => { currentStep = 4; render(); });

    // Bind Step 4 Time Slot selection
    target.querySelectorAll('.time-slot-card:not([disabled])').forEach(card => {
      card.addEventListener('click', () => {
        selectedTimeId = card.dataset.slotId;
        render();
      });
    });
    target.querySelector('#step4-back-btn')?.addEventListener('click', () => { currentStep = 3; render(); });
    target.querySelector('#step4-next-btn')?.addEventListener('click', () => { currentStep = 5; render(); });

    // Bind Step 5 Submit Appointment Request
    target.querySelector('#step5-back-btn')?.addEventListener('click', () => { currentStep = 4; render(); });
    target.querySelector('#submit-appointment-request-btn')?.addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      btn.textContent = 'Submitting Request...';

      try {
        const initialHistory = [{
          status: 'Pending',
          timestamp: new Date().toISOString(),
          remarks: 'Submitted online appointment request via Patient Portal.'
        }];

        const { data: inserted, error } = await supabase
          .from('appointments')
          .insert({
            patient_id: state.patient.patient_id,
            requested_date: selectedDate,
            requested_time: selectedTimeId,
            appointment_status: 'Pending',
            is_recurring: false,
            status_history: initialHistory
          })
          .select('*')
          .single();

        if (error) throw error;

        await sendUserNotification(
          state.user.id,
          'Appointment Request Received',
          `Your request for ${formatDate(selectedDate)} (${selectedTimeId}) has been received with status Pending.`,
          'Appointment',
          inserted.appointment_id
        );

        await notifyStaff(
          'New Patient Appointment Request',
          `${state.patient.full_name} requested ${selectedTimeId} session on ${formatDate(selectedDate)}.`,
          'Appointment',
          inserted.appointment_id
        );

        await recordAudit('Submitted Appointment Request', 'Appointments', inserted.appointment_id, {
          requested_date: selectedDate,
          requested_time: selectedTimeId
        });

        showToast('Appointment request submitted! Status set to Pending.', 'success');
        selectedDate = '';
        selectedTimeId = '';
        currentStep = 1;
        activeSubTab = 'tracking';
        await onRefreshState();
        await render();
      } catch (err) {
        showToast(err.message || 'Failed to submit appointment request.', 'error');
        btn.disabled = false;
        btn.textContent = 'Submit Appointment Request';
      }
    });
  }

  // IV.E: Appointment Tracking (Strictly 4 statuses: Pending, Under Review, Confirmed, Rejected)
  function renderTracking(target) {
    const list = (state.appointments || []).filter(a =>
      statusFilter === 'ALL' ? true : a.appointment_status === statusFilter
    );

    target.innerHTML = `
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">My Appointment Requests &amp; Status Tracking</h2>
          <div class="filter-bar" style="margin-bottom:0;">
            <select id="pt-status-filter" class="form-control">
              <option value="ALL" ${statusFilter === 'ALL' ? 'selected' : ''}>All 4 Statuses</option>
              ${APPOINTMENT_STATUSES.map(st => `
                <option value="${st}" ${statusFilter === st ? 'selected' : ''}>${st}</option>
              `).join('')}
            </select>
          </div>
        </div>

        ${list.length === 0 ? `
          <div class="empty-state">No appointment requests match the selected filter.</div>
        ` : `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Requested Schedule</th>
                  <th>Confirmed Schedule</th>
                  <th>Assigned Machine</th>
                  <th>Status</th>
                  <th>Submitted</th>
                  <th>Staff Remarks</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${list.map(a => `
                  <tr>
                    <td>
                      <strong>${escapeHtml(formatDate(a.requested_date))}</strong>
                      <div class="text-muted" style="font-size:0.79rem;">${escapeHtml(a.requested_time)}${a.is_recurring ? ' • Recurring' : ''}</div>
                    </td>
                    <td>
                      ${a.confirmed_date ? `
                        <strong>${escapeHtml(formatDate(a.confirmed_date))}</strong>
                        <div class="text-muted" style="font-size:0.79rem;">${escapeHtml(formatTimeRange(a.confirmed_start_time, a.confirmed_end_time))}</div>
                      ` : '—'}
                    </td>
                    <td>${escapeHtml(a.machine_code || 'Pending Staff Assignment')}</td>
                    <td>
                      ${statusBadgeHtml(a.appointment_status, a.is_cancelled)}
                      ${a.reschedule_requested ? `<div style="margin-top:3px;"><span class="badge badge-doc-needs-correction">Reschedule Requested</span></div>` : ''}
                    </td>
                    <td>${escapeHtml(formatDate(a.created_at))}</td>
                    <td style="max-width:230px; font-size:0.82rem;">
                      ${escapeHtml(a.staff_remarks || (a.is_cancelled ? `Cancelled: ${a.cancellation_reason || ''}` : '—'))}
                    </td>
                    <td>
                      <div style="display:flex; flex-wrap:wrap; gap:0.35rem;">
                        <button type="button" class="btn btn-outline btn-xs view-history-btn" data-id="${escapeHtml(a.appointment_id)}">
                          History
                        </button>
                        ${!a.is_cancelled && a.appointment_status !== 'Rejected' && (a.confirmed_date || a.requested_date) >= getTodayISO() ? `
                          <button type="button" class="btn btn-outline-blue btn-xs req-resched-btn" data-id="${escapeHtml(a.appointment_id)}">
                            Reschedule
                          </button>
                          <button type="button" class="btn btn-danger btn-xs cancel-appt-btn" data-id="${escapeHtml(a.appointment_id)}">
                            Cancel
                          </button>
                        ` : ''}
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>
    `;

    target.querySelector('#pt-status-filter')?.addEventListener('change', (e) => {
      statusFilter = e.target.value;
      renderTracking(target);
    });

    // Status Update History Modal
    target.querySelectorAll('.view-history-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const appt = (state.appointments || []).find(x => x.appointment_id === btn.dataset.id);
        if (!appt) return;
        const hist = Array.isArray(appt.status_history) ? appt.status_history : [];
        openModal({
          title: `Status History — ${formatDate(appt.requested_date)} (${appt.requested_time})`,
          bodyHtml: `
            <div style="margin-bottom:0.85rem;">
              Current Main Status: ${statusBadgeHtml(appt.appointment_status, appt.is_cancelled)}
            </div>
            ${hist.length === 0 ? `<div class="text-muted">Submitted on ${escapeHtml(formatDateTime(appt.created_at))}</div>` : `
              <div style="display:flex; flex-direction:column; gap:0.65rem;">
                ${hist.map(h => `
                  <div style="padding:0.65rem 0.85rem; border:1px solid var(--border-subtle); border-left:3px solid var(--reliance-blue); border-radius:6px;">
                    <div style="display:flex; justify-content:space-between; font-size:0.78rem; color:var(--text-muted);">
                      <strong>${escapeHtml(h.status || 'Action')}</strong>
                      <span>${escapeHtml(formatDateTime(h.timestamp))}</span>
                    </div>
                    <div style="font-size:0.85rem; margin-top:0.2rem;">${escapeHtml(h.remarks || '')}</div>
                  </div>
                `).join('')}
              </div>
            `}
          `
        });
      });
    });

    // Request Reschedule Action (keeps 4 main statuses intact)
    target.querySelectorAll('.req-resched-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const appt = (state.appointments || []).find(x => x.appointment_id === btn.dataset.id);
        if (!appt) return;
        openModal({
          title: 'Request Schedule Change',
          bodyHtml: `
            <form id="pt-resched-modal-form">
              <div class="form-group" style="margin-bottom:0.9rem;">
                <label class="form-label">Preferred New Date <span class="req">*</span></label>
                <input type="date" id="rs-new-date" class="form-control" min="${getTodayISO()}" value="${escapeHtml(appt.requested_date)}" required />
              </div>
              <div class="form-group" style="margin-bottom:0.9rem;">
                <label class="form-label">Preferred Session Time <span class="req">*</span></label>
                <select id="rs-new-time" class="form-control" required>
                  ${(state.clinicConfig?.time_slots || []).map(s => `
                    <option value="${escapeHtml(s.id)}" ${appt.requested_time === s.id ? 'selected' : ''}>${escapeHtml(s.label)} (${escapeHtml(s.display)})</option>
                  `).join('')}
                </select>
              </div>
              <div class="form-group" style="margin-bottom:1rem;">
                <label class="form-label">Reason for Schedule Change <span class="req">*</span></label>
                <textarea id="rs-reason" class="form-control" required placeholder="State your requested adjustment for clinic staff review..."></textarea>
              </div>
              <button type="submit" class="btn btn-primary" style="width:100%;">Submit Reschedule Request</button>
            </form>
          `,
          onMount: (modalEl) => {
            modalEl.querySelector('#pt-resched-modal-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const newDate = modalEl.querySelector('#rs-new-date').value;
              const newTime = modalEl.querySelector('#rs-new-time').value;
              const reason = modalEl.querySelector('#rs-reason').value.trim();
              const dCheck = new Date(`${newDate}T00:00:00`);
              if (dCheck.getDay() === 0) {
                showToast('Reliance Dialysis Center is closed on Sundays. Please pick Monday–Saturday.', 'error');
                return;
              }
              const nextHist = [...(appt.status_history || []), {
                status: appt.appointment_status,
                timestamp: new Date().toISOString(),
                remarks: `Patient requested reschedule to ${newDate} (${newTime}): ${reason}`
              }];

              const { error } = await supabase
                .from('appointments')
                .update({
                  reschedule_requested: true,
                  reschedule_notes: `Requested ${newDate} (${newTime}) — ${reason}`,
                  status_history: nextHist
                })
                .eq('appointment_id', appt.appointment_id);

              if (error) {
                showToast(error.message, 'error');
                return;
              }

              await notifyStaff(
                'Patient Reschedule Request',
                `${state.patient.full_name} requested to reschedule appointment to ${formatDate(newDate)} (${newTime}).`,
                'Reschedule',
                appt.appointment_id
              );
              await recordAudit('Requested Appointment Reschedule', 'Appointments', appt.appointment_id, { newDate, newTime, reason });
              closeModal();
              showToast('Reschedule request forwarded to staff.', 'success');
              await onRefreshState();
              await render();
            });
          }
        });
      });
    });

    // Separate Cancellation Action (Recorded without creating a 5th appointment_status)
    target.querySelectorAll('.cancel-appt-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const appt = (state.appointments || []).find(x => x.appointment_id === btn.dataset.id);
        if (!appt) return;
        openModal({
          title: 'Cancel Appointment Request',
          size: 'sm',
          bodyHtml: `
            <p style="font-size:0.88rem; margin-top:0;">
              Cancelling records a cancellation action on your ${escapeHtml(formatDate(appt.confirmed_date || appt.requested_date))} appointment and notifies clinic staff.
            </p>
            <form id="pt-cancel-modal-form">
              <div class="form-group" style="margin-bottom:1rem;">
                <label class="form-label">Cancellation Reason <span class="req">*</span></label>
                <textarea id="cancel-reason-input" class="form-control" required placeholder="Please provide your reason..."></textarea>
              </div>
              <button type="submit" class="btn btn-danger" style="width:100%;">Confirm Cancellation</button>
            </form>
          `,
          onMount: (modalEl) => {
            modalEl.querySelector('#pt-cancel-modal-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const reason = modalEl.querySelector('#cancel-reason-input').value.trim();
              const nextHist = [...(appt.status_history || []), {
                status: 'Cancellation Recorded',
                timestamp: new Date().toISOString(),
                remarks: `Cancelled by patient: ${reason}`
              }];

              const { error } = await supabase
                .from('appointments')
                .update({
                  is_cancelled: true,
                  cancelled_at: new Date().toISOString(),
                  cancellation_reason: reason,
                  cancelled_by_role: 'patient',
                  status_history: nextHist
                })
                .eq('appointment_id', appt.appointment_id);

              if (error) {
                showToast(error.message, 'error');
                return;
              }

              await notifyStaff(
                'Appointment Cancelled by Patient',
                `${state.patient.full_name} cancelled their ${formatDate(appt.confirmed_date || appt.requested_date)} appointment. Reason: ${reason}`,
                'Cancellation',
                appt.appointment_id
              );
              await sendUserNotification(
                state.user.id,
                'Cancellation Recorded',
                `Your cancellation for ${formatDate(appt.confirmed_date || appt.requested_date)} has been recorded.`,
                'Cancellation',
                appt.appointment_id
              );
              await recordAudit('Patient Cancelled Appointment', 'Appointments', appt.appointment_id, { reason });
              closeModal();
              showToast('Appointment cancellation recorded.', 'success');
              await onRefreshState();
              await render();
            });
          }
        });
      });
    });
  }

  // IV.F: Recurring Appointments (Uses Patient Medical Profiles + Appointments tables ONLY)
  async function renderRecurring(target, slots) {
    await loadCalendarAvailability();
    const m = state.medicalProfile || {};
    const approvedDays = Array.isArray(m.recurring_days) ? m.recurring_days : [];
    const prefTime = m.preferred_time || 'Morning';
    const hasApprovedPattern = approvedDays.length > 0;

    target.innerHTML = `
      <div class="card" style="margin-bottom:1.35rem;">
        <div class="card-header">
          <h2 class="card-title">Prescribed Frequency &amp; Approved Recurring Schedule</h2>
          <span class="badge ${hasApprovedPattern ? 'badge-status-confirmed' : 'badge-status-pending'}">
            ${hasApprovedPattern ? 'Staff-Configured Pattern Active' : 'Pending Staff Pattern Setup'}
          </span>
        </div>

        <div class="kv-grid" style="margin-bottom:1.2rem;">
          <div class="kv-item">
            <div class="kv-label">Prescribed Dialysis Frequency</div>
            <div class="kv-value"><strong>${escapeHtml(m.prescribed_dialysis_frequency || 'Not specified')}</strong></div>
          </div>
          <div class="kv-item">
            <div class="kv-label">Staff-Approved Recurring Days</div>
            <div class="kv-value">${hasApprovedPattern ? escapeHtml(approvedDays.join(', ')) : 'Awaiting clinic staff configuration'}</div>
          </div>
          <div class="kv-item">
            <div class="kv-label">Approved Preferred Time Slot</div>
            <div class="kv-value">${escapeHtml(prefTime)}</div>
          </div>
          <div class="kv-item">
            <div class="kv-label">Confirmation Policy</div>
            <div class="kv-value">Generated sessions start as <strong>Pending</strong> for staff machine assignment</div>
          </div>
        </div>

        ${hasApprovedPattern ? `
          <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:1rem; padding-top:0.5rem;">
            <div class="text-muted" style="font-size:0.86rem;">
              Generate succeeding appointment requests for the next 2 weeks based on your approved <strong>${escapeHtml(approvedDays.join(', '))} (${escapeHtml(prefTime)})</strong> pattern. Staff will review capacity, assign a dialysis machine, and confirm each session.
            </div>
            <button type="button" class="btn btn-primary btn-sm" id="pt-generate-recurring-btn">
              Generate Next 2 Weeks of Requests
            </button>
          </div>
        ` : `
          <div class="alert" style="margin-bottom:0;">
            Once clinic staff configure your recurring days (for example, Monday, Wednesday, and Friday) in Recurring Appointment Management, you can generate succeeding appointment batches right here.
          </div>
        `}
      </div>
    `;

    target.querySelector('#pt-generate-recurring-btn')?.addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      btn.textContent = 'Checking Availability & Generating...';

      try {
        if (!allFourDocumentsReady()) {
          throw new Error('Please upload all 4 required documents in Book New Appointment before generating succeeding sessions.');
        }

        const slotObj = slots.find(s => s.id === prefTime) || slots[0];
        const targetDayNums = approvedDays.map(d => DAY_NAME_TO_INDEX[d]).filter(n => n !== undefined);
        const existingDates = new Set(
          (state.appointments || [])
            .filter(a => !a.is_cancelled)
            .map(a => a.confirmed_date || a.requested_date)
        );

        const candidates = [];
        const base = new Date();
        for (let offset = 1; offset <= 14; offset++) {
          const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + offset);
          const iso = toISODate(d);
          if (!targetDayNums.includes(d.getDay())) continue;
          if (!isOperatingDate(d)) continue;
          if (existingDates.has(iso)) continue;
          if (getSlotCapacityForDate(iso, slotObj) <= 0) continue;
          candidates.push(iso);
        }

        if (candidates.length === 0) {
          throw new Error('All matching recurring dates in the next 14 days are either already requested or at full capacity.');
        }

        const groupId = crypto.randomUUID();
        const rows = candidates.map(dateIso => ({
          patient_id: state.patient.patient_id,
          requested_date: dateIso,
          requested_time: slotObj.id,
          appointment_status: 'Pending',
          is_recurring: true,
          recurrence_group_id: groupId,
          status_history: [{
            status: 'Pending',
            timestamp: new Date().toISOString(),
            remarks: `Generated from approved recurring schedule (${approvedDays.join(', ')} • ${slotObj.id}). Awaiting staff review and machine assignment.`
          }]
        }));

        const { error } = await supabase.from('appointments').insert(rows);
        if (error) throw error;

        await notifyStaff(
          'Recurring Appointment Batch Generated',
          `${state.patient.full_name} generated ${rows.length} succeeding recurring appointment request(s) awaiting review & machine assignment.`,
          'Recurring'
        );
        await sendUserNotification(
          state.user.id,
          'Recurring Requests Submitted',
          `${rows.length} succeeding appointment request(s) (${candidates.join(', ')}) have been forwarded to staff for review and machine assignment.`,
          'Recurring'
        );
        await recordAudit('Generated Succeeding Recurring Appointments', 'Appointments', groupId, {
          dates: candidates,
          preferred_time: slotObj.id
        });

        showToast(`Generated ${rows.length} recurring request(s) for staff review!`, 'success');
        activeSubTab = 'tracking';
        await onRefreshState();
        await render();
      } catch (err) {
        showToast(err.message || 'Could not generate recurring appointments.', 'error');
        btn.disabled = false;
        btn.textContent = 'Generate Next 2 Weeks of Requests';
      }
    });
  }

  await render();
}
