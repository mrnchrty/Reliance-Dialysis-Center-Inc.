/**
 * Reliance Dialysis Center Inc. — Patient Onboarding & My Profile Module
 * Implements Initial Patient Profile Setup (Personal + Medical Information)
 * and My Profile (Update permitted fields, Request medical info corrections, Change Password, Logout).
 */

import { supabase, recordAudit, notifyStaff } from '../supabaseClient.js';
import { escapeHtml } from '../utils.js';
import { showToast } from '../components/toast.js';
import { signOutAndRedirect } from '../authGuard.js';

export function renderPatientProfileForm({ container, state, isOnboarding = false, onSaved }) {
  const p = state.patient || {};
  const m = state.medicalProfile || {};

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">${isOnboarding ? 'Complete Your Patient Profile' : 'My Profile & Account Settings'}</h1>
        <p class="page-subtitle">
          ${isOnboarding
            ? 'Please complete your Personal and Medical Information once before submitting hemodialysis appointment requests.'
            : 'Review and update your personal details, medical background, account password, or request clinical record updates.'}
        </p>
      </div>
      ${!isOnboarding ? `<button type="button" class="btn btn-danger btn-sm" id="profile-logout-btn">Logout</button>` : ''}
    </div>

    ${isOnboarding ? `
      <div class="alert">
        <strong>One-Time Setup:</strong> Your information is securely saved in Reliance Dialysis Center Inc.'s database so you will not need to re-enter these forms when booking succeeding appointments.
      </div>
    ` : ''}

    <form id="patient-profile-master-form">
      <!-- Section 1: Personal Information -->
      <div class="card" style="margin-bottom:1.35rem;">
        <div class="card-header">
          <h2 class="card-title">1. Personal &amp; Emergency Contact Information</h2>
          <span class="badge badge-status-under-review">Required</span>
        </div>

        <div class="form-grid">
          <div class="form-group">
            <label class="form-label" for="pf-fullname">Full Name <span class="req">*</span></label>
            <input type="text" id="pf-fullname" class="form-control" value="${escapeHtml(p.full_name || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="pf-dob">Date of Birth <span class="req">*</span></label>
            <input type="date" id="pf-dob" class="form-control" value="${escapeHtml(p.date_of_birth || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="pf-sex">Sex <span class="req">*</span></label>
            <select id="pf-sex" class="form-control" required>
              <option value="">Select sex</option>
              ${['Male', 'Female', 'Prefer not to say'].map(opt => `
                <option value="${opt}" ${p.sex === opt ? 'selected' : ''}>${opt}</option>
              `).join('')}
            </select>
          </div>

          <div class="form-group">
            <label class="form-label" for="pf-contact">Contact Number <span class="req">*</span></label>
            <input type="tel" id="pf-contact" class="form-control" placeholder="09XX XXX XXXX" value="${escapeHtml(p.contact_number || '')}" required />
          </div>

          <div class="form-group full-width">
            <label class="form-label" for="pf-address">Complete Address <span class="req">*</span></label>
            <input type="text" id="pf-address" class="form-control" placeholder="House/Sitio, Barangay, Municipality, Province" value="${escapeHtml(p.address || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="pf-em-name">Emergency Contact Name <span class="req">*</span></label>
            <input type="text" id="pf-em-name" class="form-control" value="${escapeHtml(p.emergency_contact_name || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="pf-em-phone">Emergency Contact Number <span class="req">*</span></label>
            <input type="tel" id="pf-em-phone" class="form-control" placeholder="09XX XXX XXXX" value="${escapeHtml(p.emergency_contact_number || '')}" required />
          </div>
        </div>
      </div>

      <!-- Section 2: Medical Information -->
      <div class="card" style="margin-bottom:1.35rem;">
        <div class="card-header">
          <h2 class="card-title">2. Medical &amp; Dialysis Information</h2>
          <span class="badge badge-status-under-review">Required</span>
        </div>

        <h3 style="font-size:0.94rem; color:var(--reliance-blue); margin:0 0 0.75rem;">Basic Health Information</h3>
        <div class="form-grid" style="margin-bottom:1.35rem;">
          <div class="form-group">
            <label class="form-label" for="mf-height">Height (cm) <span class="req">*</span></label>
            <input type="number" step="0.1" min="50" max="250" id="mf-height" class="form-control" placeholder="e.g., 162" value="${escapeHtml(m.height ?? '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-weight">Baseline / Dry Weight (kg) <span class="req">*</span></label>
            <input type="number" step="0.1" min="15" max="250" id="mf-weight" class="form-control" placeholder="e.g., 58.5" value="${escapeHtml(m.weight ?? '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-blood">Blood Type <span class="req">*</span></label>
            <select id="mf-blood" class="form-control" required>
              <option value="">Select blood type</option>
              ${['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'].map(bt => `
                <option value="${bt}" ${m.blood_type === bt ? 'selected' : ''}>${bt}</option>
              `).join('')}
            </select>
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-allergies">Known Allergies <span class="req">*</span></label>
            <input type="text" id="mf-allergies" class="form-control" placeholder="Enter 'None known' if none" value="${escapeHtml(m.allergies || '')}" required />
          </div>
        </div>

        <h3 style="font-size:0.94rem; color:var(--reliance-blue); margin:0 0 0.75rem;">Medical Background</h3>
        <div class="form-grid" style="margin-bottom:1.35rem;">
          <div class="form-group">
            <label class="form-label" for="mf-diagnosis">Medical Diagnosis or Kidney Condition <span class="req">*</span></label>
            <input type="text" id="mf-diagnosis" class="form-control" placeholder="e.g., Chronic Kidney Disease Stage 5" value="${escapeHtml(m.diagnosis || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-conditions">Existing Medical Conditions <span class="req">*</span></label>
            <input type="text" id="mf-conditions" class="form-control" placeholder="e.g., Hypertension, Diabetes (or None)" value="${escapeHtml(m.existing_medical_conditions || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-surgeries">Previous Surgeries (if applicable)</label>
            <input type="text" id="mf-surgeries" class="form-control" placeholder="e.g., AV Fistula Creation (Optional)" value="${escapeHtml(m.previous_surgeries || '')}" />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-meds">Current Medications <span class="req">*</span></label>
            <input type="text" id="mf-meds" class="form-control" placeholder="List maintenance medications" value="${escapeHtml(m.current_medications || '')}" required />
          </div>
        </div>

        <h3 style="font-size:0.94rem; color:var(--reliance-blue); margin:0 0 0.75rem;">Dialysis Information</h3>
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label" for="mf-nephro">Attending Nephrologist <span class="req">*</span></label>
            <input type="text" id="mf-nephro" class="form-control" placeholder="Dr. Full Name" value="${escapeHtml(m.attending_nephrologist || '')}" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-freq">Prescribed Dialysis Frequency <span class="req">*</span></label>
            <select id="mf-freq" class="form-control" required>
              <option value="">Select prescribed frequency</option>
              ${['1x a week', '2x a week', '3x a week', '4x a week', 'As prescribed / Acute'].map(fq => `
                <option value="${fq}" ${m.prescribed_dialysis_frequency === fq ? 'selected' : ''}>${fq}</option>
              `).join('')}
            </select>
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-start-date">Date Started Dialysis (if applicable)</label>
            <input type="date" id="mf-start-date" class="form-control" value="${escapeHtml(m.dialysis_start_date || '')}" />
          </div>

          <div class="form-group">
            <label class="form-label" for="mf-prev-center">Previous Dialysis Center (if applicable)</label>
            <input type="text" id="mf-prev-center" class="form-control" placeholder="Leave blank if first-time dialysis patient" value="${escapeHtml(m.previous_dialysis_center || '')}" />
          </div>
        </div>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:0.85rem; margin-bottom:1.5rem;">
        <button type="submit" class="btn btn-primary" id="save-profile-btn">
          ${isOnboarding ? 'Save Profile & Continue to Dashboard' : 'Save Profile Changes'}
        </button>
      </div>
    </form>

    ${!isOnboarding ? `
      <div class="dashboard-grid-2">
        <!-- Request Medical Record Correction -->
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Request Official Medical Profile Correction</h2>
          </div>
          <p class="text-muted" style="font-size:0.86rem; margin-top:0;">
            Need clinic staff to update verified clinical details or approved recurring dialysis days? Submit a correction request below.
          </p>
          <form id="medical-correction-form">
            <div class="form-group" style="margin-bottom:0.85rem;">
              <label class="form-label" for="corr-notes">Correction Details <span class="req">*</span></label>
              <textarea id="corr-notes" class="form-control" placeholder="Describe the medical profile or prescription change to be reviewed by clinic staff..." required>${escapeHtml(m.correction_request_notes || '')}</textarea>
            </div>
            <button type="submit" class="btn btn-outline-blue btn-sm">Submit Correction Request to Staff</button>
          </form>
        </div>

        <!-- Change Password -->
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">Change Account Password</h2>
          </div>
          <form id="change-password-form">
            <div class="form-group" style="margin-bottom:0.85rem;">
              <label class="form-label" for="cp-new">New Password <span class="req">*</span></label>
              <input type="password" id="cp-new" class="form-control" minlength="6" placeholder="Minimum 6 characters" required />
            </div>
            <div class="form-group" style="margin-bottom:0.85rem;">
              <label class="form-label" for="cp-confirm">Confirm New Password <span class="req">*</span></label>
              <input type="password" id="cp-confirm" class="form-control" minlength="6" placeholder="Re-enter new password" required />
            </div>
            <button type="submit" class="btn btn-primary btn-sm">Update Password</button>
          </form>
        </div>
      </div>
    ` : ''}
  `;

  // Bind Master Profile Save
  const form = container.querySelector('#patient-profile-master-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const saveBtn = container.querySelector('#save-profile-btn');
    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving...';

    try {
      const personalPayload = {
        full_name: container.querySelector('#pf-fullname').value.trim(),
        date_of_birth: container.querySelector('#pf-dob').value || null,
        sex: container.querySelector('#pf-sex').value || null,
        contact_number: container.querySelector('#pf-contact').value.trim(),
        address: container.querySelector('#pf-address').value.trim(),
        emergency_contact_name: container.querySelector('#pf-em-name').value.trim(),
        emergency_contact_number: container.querySelector('#pf-em-phone').value.trim()
      };

      const medicalPayload = {
        patient_id: state.patient.patient_id,
        height: parseFloat(container.querySelector('#mf-height').value),
        weight: parseFloat(container.querySelector('#mf-weight').value),
        blood_type: container.querySelector('#mf-blood').value,
        allergies: container.querySelector('#mf-allergies').value.trim(),
        diagnosis: container.querySelector('#mf-diagnosis').value.trim(),
        existing_medical_conditions: container.querySelector('#mf-conditions').value.trim(),
        previous_surgeries: container.querySelector('#mf-surgeries').value.trim() || null,
        current_medications: container.querySelector('#mf-meds').value.trim(),
        attending_nephrologist: container.querySelector('#mf-nephro').value.trim(),
        prescribed_dialysis_frequency: container.querySelector('#mf-freq').value,
        dialysis_start_date: container.querySelector('#mf-start-date').value || null,
        previous_dialysis_center: container.querySelector('#mf-prev-center').value.trim() || null
      };

      if (!personalPayload.full_name || !personalPayload.date_of_birth || !personalPayload.sex ||
          !personalPayload.contact_number || !personalPayload.address ||
          !personalPayload.emergency_contact_name || !personalPayload.emergency_contact_number) {
        throw new Error('Please fill in all required Personal Information fields.');
      }

      if (Number.isNaN(medicalPayload.height) || Number.isNaN(medicalPayload.weight) ||
          !medicalPayload.blood_type || !medicalPayload.diagnosis || !medicalPayload.attending_nephrologist ||
          !medicalPayload.prescribed_dialysis_frequency) {
        throw new Error('Please fill in all required Medical & Dialysis Information fields.');
      }

      const { error: patErr } = await supabase
        .from('patients')
        .update(personalPayload)
        .eq('patient_id', state.patient.patient_id);
      if (patErr) throw patErr;

      const { error: medErr } = await supabase
        .from('patient_medical_profiles')
        .upsert(medicalPayload, { onConflict: 'patient_id' });
      if (medErr) throw medErr;

      await recordAudit(
        isOnboarding ? 'Completed Initial Patient Profile Setup' : 'Updated Patient Profile',
        'Patients & Medical Profile',
        state.patient.patient_id
      );

      showToast('Profile saved successfully!', 'success');
      if (typeof onSaved === 'function') await onSaved();
    } catch (err) {
      showToast(err.message || 'Failed to save profile.', 'error');
    } finally {
      if (saveBtn.isConnected) {
        saveBtn.disabled = false;
        saveBtn.textContent = isOnboarding ? 'Save Profile & Continue to Dashboard' : 'Save Profile Changes';
      }
    }
  });

  // Logout button on My Profile
  container.querySelector('#profile-logout-btn')?.addEventListener('click', () => signOutAndRedirect('/auth.html'));

  // Medical Correction Request Form
  container.querySelector('#medical-correction-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const notes = container.querySelector('#corr-notes').value.trim();
    if (!notes) return;
    try {
      const { error } = await supabase
        .from('patient_medical_profiles')
        .update({ correction_request_notes: notes })
        .eq('patient_id', state.patient.patient_id);
      if (error) throw error;

      await notifyStaff(
        'Medical Profile Correction Request',
        `${state.patient.full_name} submitted a medical profile correction note: "${notes}"`,
        'Medical Record'
      );
      await recordAudit('Submitted Medical Profile Correction Request', 'Patient Medical Profiles', state.patient.patient_id, { notes });
      showToast('Correction request sent to clinic staff.', 'success');
    } catch (err) {
      showToast(err.message || 'Failed to submit request.', 'error');
    }
  });

  // Change Password Form
  container.querySelector('#change-password-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const p1 = container.querySelector('#cp-new').value;
    const p2 = container.querySelector('#cp-confirm').value;
    if (p1.length < 6) {
      showToast('Password must be at least 6 characters.', 'error');
      return;
    }
    if (p1 !== p2) {
      showToast('Passwords do not match.', 'error');
      return;
    }
    try {
      const { error } = await supabase.auth.updateUser({ password: p1 });
      if (error) throw error;
      await recordAudit('Changed Account Password', 'Authentication', state.user.id);
      showToast('Password updated successfully.', 'success');
      e.target.reset();
    } catch (err) {
      showToast(err.message || 'Could not update password.', 'error');
    }
  });
}
