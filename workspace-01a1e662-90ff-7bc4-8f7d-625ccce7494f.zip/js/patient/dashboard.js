/**
 * Reliance Dialysis Center Inc. — Patient Dashboard Module (IV.C)
 * Displays Welcome greeting + date, 4 Summary Cards, Next Appointment,
 * Recent Activities, Notifications Preview, and Quick Actions.
 * All data retrieved live from Supabase filtered to the authenticated patient.
 */

import {
  escapeHtml,
  formatDate,
  formatDateTime,
  formatTimeRange,
  getTodayISO,
  statusBadgeHtml,
  evaluateProfileCompletion
} from '../utils.js';

export function renderPatientDashboard({ container, state, onNavigate }) {
  const todayIso = getTodayISO();
  const todayReadable = formatDate(todayIso, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  const completion = evaluateProfileCompletion(state.patient, state.medicalProfile);

  const activeAppts = (state.appointments || []).filter(a => !a.is_cancelled);
  const upcomingConfirmed = activeAppts
    .filter(a => a.appointment_status === 'Confirmed' && (a.confirmed_date || a.requested_date) >= todayIso)
    .sort((a, b) => (a.confirmed_date || a.requested_date).localeCompare(b.confirmed_date || b.requested_date));

  const pendingOrReview = activeAppts.filter(a =>
    a.appointment_status === 'Pending' || a.appointment_status === 'Under Review'
  );

  const completedSessions = (state.sessions || []).filter(s => s.session_status === 'Completed');
  const nextAppt = upcomingConfirmed[0] || null;

  // Build Recent Activities timeline from real appointments, documents, and released sessions
  const activities = [];
  (state.appointments || []).slice(0, 6).forEach(a => {
    activities.push({
      ts: a.updated_at || a.created_at,
      label: `Appointment Request (${formatDate(a.confirmed_date || a.requested_date)})`,
      detail: a.is_cancelled
        ? `Cancelled — ${a.cancellation_reason || 'Patient/staff cancellation'}`
        : `Status: ${a.appointment_status}${a.staff_remarks ? ` • "${a.staff_remarks}"` : ''}`
    });
  });

  (state.documents || []).slice(0, 4).forEach(d => {
    activities.push({
      ts: d.reviewed_at || d.uploaded_at,
      label: `Document: ${d.document_type}`,
      detail: `${d.verification_status} (${d.file_name})`
    });
  });

  (state.sessions || []).slice(0, 4).forEach(s => {
    activities.push({
      ts: s.updated_at || s.created_at,
      label: `Released Dialysis Record (${formatDate(s.treatment_date)})`,
      detail: `Machine ${s.machine_code || 'Assigned'} • Pre ${s.pre_dialysis_weight ?? '—'} kg → Post ${s.post_dialysis_weight ?? '—'} kg`
    });
  });

  activities.sort((a, b) => new Date(b.ts) - new Date(a.ts));
  const recentTop = activities.slice(0, 6);
  const latestNotifs = (state.notifications || []).slice(0, 4);

  container.innerHTML = `
    <!-- Welcome Section -->
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Welcome, ${escapeHtml(state.patient?.full_name || 'Patient')}</h1>
        <p class="page-subtitle">
          Manage your hemodialysis appointments, documents, and released treatment records at Reliance Dialysis Center Inc.
        </p>
      </div>
      <div style="text-align:right; font-size:0.88rem; color:var(--text-secondary); font-weight:600;">
        ${escapeHtml(todayReadable)}
      </div>
    </div>

    ${!completion.isComplete ? `
      <div class="alert alert-red" style="display:flex; justify-content:space-between; align-items:center; gap:1rem; flex-wrap:wrap;">
        <div>
          <strong>Profile Incomplete (${completion.percentage}%):</strong>
          Complete your personal and medical profile (${escapeHtml(completion.missingFields.slice(0, 3).join(', '))}${completion.missingFields.length > 3 ? '...' : ''}) before booking appointments.
        </div>
        <button type="button" class="btn btn-red btn-sm" id="dash-complete-profile-btn">Complete Profile</button>
      </div>
    ` : ''}

    <!-- Summary Cards -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Upcoming Appointments</div>
        <div class="stat-value">${upcomingConfirmed.length}</div>
        <div class="stat-meta">Confirmed future sessions</div>
      </div>

      <div class="stat-card accent-red">
        <div class="stat-label">Pending Requests</div>
        <div class="stat-value">${pendingOrReview.length}</div>
        <div class="stat-meta">Pending or Under Review</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Completed Dialysis Sessions</div>
        <div class="stat-value">${completedSessions.length}</div>
        <div class="stat-meta">Released in Dialysis History</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Profile Completion</div>
        <div class="stat-value">${completion.percentage}%</div>
        <div class="stat-meta">${completion.isComplete ? 'Ready for booking' : `${completion.missingFields.length} field(s) remaining`}</div>
      </div>
    </div>

    <!-- Quick Actions Row -->
    <div class="card" style="margin-bottom:1.35rem; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:1rem;">
      <div>
        <strong style="color:var(--reliance-blue);">Quick Actions</strong>
        <div class="text-muted" style="font-size:0.84rem;">Jump directly to appointment scheduling, records, or account details.</div>
      </div>
      <div style="display:flex; flex-wrap:wrap; gap:0.65rem;">
        <button type="button" class="btn btn-primary btn-sm" data-nav="book">Book an Appointment</button>
        <button type="button" class="btn btn-outline-blue btn-sm" data-nav="records">View My Records</button>
        <button type="button" class="btn btn-outline btn-sm" data-nav="profile">View My Profile</button>
      </div>
    </div>

    <div class="dashboard-grid-2">
      <!-- Next Appointment Card -->
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Next Confirmed Appointment</h2>
          <button type="button" class="btn-link-sm" data-nav="book" data-sub="tracking">Track All Requests →</button>
        </div>

        ${nextAppt ? `
          <div class="kv-grid">
            <div class="kv-item">
              <div class="kv-label">Confirmed Date</div>
              <div class="kv-value">${escapeHtml(formatDate(nextAppt.confirmed_date || nextAppt.requested_date))}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Confirmed Time</div>
              <div class="kv-value">${escapeHtml(
                nextAppt.confirmed_start_time
                  ? formatTimeRange(nextAppt.confirmed_start_time, nextAppt.confirmed_end_time)
                  : nextAppt.requested_time
              )}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Appointment Status</div>
              <div class="kv-value">${statusBadgeHtml(nextAppt.appointment_status, nextAppt.is_cancelled)}</div>
            </div>
            <div class="kv-item">
              <div class="kv-label">Assigned Machine</div>
              <div class="kv-value"><strong>${escapeHtml(nextAppt.machine_code || 'Assigned at Check-in')}</strong></div>
            </div>
          </div>
          ${nextAppt.staff_remarks ? `
            <div class="alert" style="margin-top:1rem; margin-bottom:0;">
              <strong>Clinic Remarks:</strong> ${escapeHtml(nextAppt.staff_remarks)}
            </div>
          ` : ''}
        ` : `
          <div class="empty-state">
            No upcoming confirmed appointments yet.
            <div style="margin-top:0.75rem;">
              <button type="button" class="btn btn-primary btn-sm" data-nav="book">Request a Schedule</button>
            </div>
          </div>
        `}
      </div>

      <!-- Notifications Preview Card -->
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Latest Notifications</h2>
          <button type="button" class="btn-link-sm" data-nav="notifications">View All Notifications →</button>
        </div>

        ${latestNotifs.length === 0 ? `
          <div class="empty-state">No recent notifications.</div>
        ` : `
          <div style="display:flex; flex-direction:column; gap:0.65rem;">
            ${latestNotifs.map(n => `
              <div style="padding:0.65rem 0.8rem; border:1px solid var(--border-subtle); border-left:3px solid ${n.is_read ? 'var(--reliance-blue)' : 'var(--reliance-red)'}; border-radius:var(--radius-sm); background:#fff;">
                <div style="display:flex; justify-content:space-between; font-size:0.74rem; color:var(--text-muted);">
                  <span>${escapeHtml(n.notification_type)}</span>
                  <span>${escapeHtml(formatDateTime(n.created_at))}</span>
                </div>
                <div style="font-weight:600; font-size:0.88rem; margin-top:0.15rem;">${escapeHtml(n.title)}</div>
                <div style="font-size:0.81rem; color:var(--text-secondary);">${escapeHtml(n.message)}</div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>

    <!-- Recent Activities -->
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">Recent Activities</h2>
      </div>
      ${recentTop.length === 0 ? `
        <div class="empty-state">Your appointment updates, document submissions, and released dialysis records will appear here.</div>
      ` : `
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Date &amp; Time</th>
                <th>Activity</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              ${recentTop.map(act => `
                <tr>
                  <td>${escapeHtml(formatDateTime(act.ts))}</td>
                  <td><strong>${escapeHtml(act.label)}</strong></td>
                  <td>${escapeHtml(act.detail)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `}
    </div>
  `;

  container.querySelector('#dash-complete-profile-btn')?.addEventListener('click', () => onNavigate('profile'));
  container.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => onNavigate(btn.dataset.nav, btn.dataset.sub || null));
  });
}
