/**
 * Reliance Dialysis Center Inc. — Super Administrator Panel Views (VI.1 – VI.7)
 *   1. Dashboard
 *   2. User Management (Activate/Deactivate, Assign Authorized Roles)
 *   3. Staff Management & Roles (Create Staff Accounts in Supabase Auth, Assign Positions & Permissions)
 *   4. System Configuration (Operating Days, Hours, Time Slots, Scheduling Settings)
 *   5. Machine & Schedule Configuration (Add/Update Dialysis Machines, Availability, Slot Schedules)
 *   6. Analytics & Reports (Patient, Appointment, Sessions, Machine Utilization, Demand, No-Show Analysis + CSV Export)
 *   7. Audit Logs (Searchable & Filterable Accountability Trail)
 */

import { supabase, recordAudit } from '../supabaseClient.js';
import {
  escapeHtml,
  formatDate,
  formatDateTime,
  formatTimeRange,
  getTodayISO,
  machineBadgeHtml,
  statusBadgeHtml
} from '../utils.js';
import { showToast, openModal, closeModal } from '../components/toast.js';

const DAY_LABELS = [
  { num: 0, name: 'Sunday' },
  { num: 1, name: 'Monday' },
  { num: 2, name: 'Tuesday' },
  { num: 3, name: 'Wednesday' },
  { num: 4, name: 'Thursday' },
  { num: 5, name: 'Friday' },
  { num: 6, name: 'Saturday' }
];

/* 1. SUPER ADMIN DASHBOARD */
export function renderAdminDashboard({ container, state, onNavigate }) {
  const totalPatients = state.patients.length;
  const activeStaff = state.staffList.filter(s => s.account_status === 'Active').length;
  const confirmedAppts = state.appointments.filter(a => a.appointment_status === 'Confirmed' && !a.is_cancelled).length;
  const completedSessions = state.sessions.filter(s => s.session_status === 'Completed').length;

  const operationalMachines = state.machines.filter(m => m.machine_status !== 'Maintenance' && m.machine_status !== 'Offline').length;
  const bookedSlotsCount = state.machineSlots.filter(s => s.slot_status === 'Booked' || s.slot_status === 'Completed').length;

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Super Administrator Executive Dashboard</h1>
        <p class="page-subtitle">Facility-wide governance, staffing, appointment metrics, machine utilization, and security audit overview.</p>
      </div>
      <div style="display:flex; gap:0.5rem;">
        <button type="button" class="btn btn-outline-blue btn-sm" data-anav="analytics">View Analytics</button>
        <button type="button" class="btn btn-primary btn-sm" data-anav="staff">Manage Staff</button>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Total Registered Patients</div>
        <div class="stat-value">${totalPatients}</div>
        <div class="stat-meta">Centralized patient registry</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Active Staff &amp; Admins</div>
        <div class="stat-value">${activeStaff}</div>
        <div class="stat-meta">${state.staffList.length} total staff record(s)</div>
      </div>

      <div class="stat-card accent-red">
        <div class="stat-label">Appointment Statistics</div>
        <div class="stat-value">${state.appointments.length}</div>
        <div class="stat-meta">${confirmedAppts} confirmed • ${completedSessions} completed sessions</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Operational Machines</div>
        <div class="stat-value">${operationalMachines}/${state.machines.length}</div>
        <div class="stat-meta">${bookedSlotsCount} total scheduled machine slots</div>
      </div>
    </div>

    <div class="dashboard-grid-2">
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Appointment Status Distribution</h2>
        </div>
        <div class="analytics-bar-list">
          ${['Pending', 'Under Review', 'Confirmed', 'Rejected'].map(st => {
            const cnt = state.appointments.filter(a => a.appointment_status === st).length;
            const pct = state.appointments.length ? Math.round((cnt / state.appointments.length) * 100) : 0;
            return `
              <div class="analytics-bar-row">
                <strong>${st}</strong>
                <div class="analytics-bar-track">
                  <div class="analytics-bar-fill ${st === 'Rejected' ? 'red' : ''}" style="width:${pct}%"></div>
                </div>
                <span>${cnt} (${pct}%)</span>
              </div>
            `;
          }).join('')}
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Recent System Audit Logs</h2>
          <button type="button" class="btn-link-sm" data-anav="audit">Full Audit Trail →</button>
        </div>
        ${state.auditLogs.length === 0 ? `<div class="empty-state">No audit logs recorded.</div>` : `
          <div style="display:flex; flex-direction:column; gap:0.55rem; font-size:0.84rem;">
            ${state.auditLogs.slice(0, 5).map(l => `
              <div style="padding:0.45rem 0; border-bottom:1px solid var(--border-subtle); display:flex; justify-content:space-between; gap:0.75rem;">
                <span><strong>[${escapeHtml(l.affected_module)}]</strong> ${escapeHtml(l.activity)}</span>
                <span class="text-muted" style="white-space:nowrap;">${escapeHtml(formatDate(l.created_at))}</span>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>
  `;

  container.querySelectorAll('[data-anav]').forEach(b => {
    b.addEventListener('click', () => onNavigate(b.dataset.anav));
  });
}

/* 2. USER MANAGEMENT */
export function renderAdminUsers({ container, state, onRefresh }) {
  let search = '';

  function draw() {
    const unified = [];
    const seenUserIds = new Set();

    state.staffList.forEach(s => {
      seenUserIds.add(s.user_id);
      unified.push({
        user_id: s.user_id,
        record_id: s.staff_id,
        source: 'staff',
        full_name: s.full_name,
        email: s.email,
        role: s.role,
        status: s.account_status,
        created_at: s.created_at
      });
    });

    state.patients.forEach(p => {
      if (!seenUserIds.has(p.user_id)) {
        unified.push({
          user_id: p.user_id,
          record_id: p.patient_id,
          source: 'patient',
          full_name: p.full_name,
          email: p.email,
          role: 'patient',
          status: p.account_status,
          created_at: p.created_at
        });
      }
    });

    const q = search.toLowerCase();
    const filtered = unified.filter(u =>
      !q ||
      (u.full_name || '').toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q) ||
      (u.role || '').toLowerCase().includes(q)
    );

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">User Management</h1>
          <p class="page-subtitle">View all registered users across Patients and Staff, manage account access, and assign authorized roles.</p>
        </div>
      </div>

      <div class="card">
        <div class="filter-bar">
          <input type="search" id="admin-user-search" class="form-control" style="min-width:280px;" placeholder="Search name, email, or role..." value="${escapeHtml(search)}" />
        </div>

        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Authorized Role</th>
                <th>Account Status</th>
                <th>Registered</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${filtered.map(u => `
                <tr>
                  <td><strong>${escapeHtml(u.full_name)}</strong></td>
                  <td>${escapeHtml(u.email || '—')}</td>
                  <td><span class="badge ${u.role === 'super_admin' ? 'badge-status-rejected' : u.role === 'staff' ? 'badge-status-under-review' : 'badge-status-confirmed'}">${escapeHtml(u.role)}</span></td>
                  <td><span class="badge ${u.status === 'Active' ? 'badge-status-confirmed' : 'badge-cancelled'}">${escapeHtml(u.status)}</span></td>
                  <td>${escapeHtml(formatDate(u.created_at))}</td>
                  <td>
                    <div style="display:flex; gap:0.4rem; flex-wrap:wrap;">
                      <button type="button" class="btn btn-outline btn-xs toggle-acct-btn"
                        data-uid="${escapeHtml(u.user_id)}"
                        data-src="${escapeHtml(u.source)}"
                        data-rid="${escapeHtml(u.record_id)}"
                        data-st="${escapeHtml(u.status)}">
                        ${u.status === 'Active' ? 'Deactivate' : 'Activate'}
                      </button>
                      <button type="button" class="btn btn-outline-blue btn-xs assign-role-btn"
                        data-uid="${escapeHtml(u.user_id)}"
                        data-name="${escapeHtml(u.full_name)}"
                        data-role="${escapeHtml(u.role)}">
                        Assign Role
                      </button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    const sEl = container.querySelector('#admin-user-search');
    sEl.addEventListener('input', (e) => {
      search = e.target.value;
      const pos = sEl.selectionStart;
      draw();
      const next = container.querySelector('#admin-user-search');
      next.focus();
      next.setSelectionRange(pos, pos);
    });

    container.querySelectorAll('.toggle-acct-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (btn.dataset.uid === state.user.id) {
          showToast('You cannot deactivate your own active Super Administrator account.', 'error');
          return;
        }
        const nextStatus = btn.dataset.st === 'Active' ? 'Inactive' : 'Active';
        const tbl = btn.dataset.src === 'staff' ? 'staff' : 'patients';
        const pk = btn.dataset.src === 'staff' ? 'staff_id' : 'patient_id';

        const { error } = await supabase
          .from(tbl)
          .update({ account_status: nextStatus })
          .eq(pk, btn.dataset.rid);
        if (error) { showToast(error.message, 'error'); return; }

        await recordAudit(`Changed Account Status to ${nextStatus}`, 'User Management', btn.dataset.uid);
        showToast(`Account set to ${nextStatus}.`, 'success');
        await onRefresh();
        draw();
      });
    });

    container.querySelectorAll('.assign-role-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        openModal({
          title: `Assign Authorized Role — ${btn.dataset.name}`,
          size: 'sm',
          bodyHtml: `
            <form id="assign-role-modal-form">
              <div class="form-group" style="margin-bottom:0.9rem;">
                <label class="form-label">Select Role <span class="req">*</span></label>
                <select id="ar-role" class="form-control" required>
                  ${['patient', 'staff', 'super_admin'].map(r => `
                    <option value="${r}" ${btn.dataset.role === r ? 'selected' : ''}>${r}</option>
                  `).join('')}
                </select>
              </div>
              <div class="form-group" style="margin-bottom:1rem;">
                <label class="form-label">Staff Position Title (if Staff / Super Admin)</label>
                <input type="text" id="ar-pos" class="form-control" value="Dialysis Nurse" />
              </div>
              <button type="submit" class="btn btn-primary" style="width:100%;">Update Role Assignment</button>
            </form>
          `,
          onMount: (mEl) => {
            mEl.querySelector('#assign-role-modal-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const newRole = mEl.querySelector('#ar-role').value;
              const pos = mEl.querySelector('#ar-pos').value.trim() || 'Dialysis Nurse';
              const { error } = await supabase.rpc('admin_assign_user_role', {
                p_target_user_id: btn.dataset.uid,
                p_new_role: newRole,
                p_position: pos
              });
              if (error) { showToast(error.message, 'error'); return; }
              closeModal();
              showToast('Role assignment updated.', 'success');
              await onRefresh();
              draw();
            });
          }
        });
      });
    });
  }

  draw();
}

/* 3. STAFF MANAGEMENT & ROLES */
export function renderAdminStaff({ container, state, onRefresh }) {
  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Staff Management &amp; Roles</h1>
        <p class="page-subtitle">Create new clinical staff or administrator accounts in Supabase Auth and manage positions, permissions, and status.</p>
      </div>
      <button type="button" class="btn btn-primary btn-sm" id="create-staff-btn">+ Create Staff Account</button>
    </div>

    <div class="card">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Full Name</th>
              <th>Email</th>
              <th>Position</th>
              <th>Role</th>
              <th>Contact</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${state.staffList.map(s => `
              <tr>
                <td><strong>${escapeHtml(s.full_name)}</strong></td>
                <td>${escapeHtml(s.email || '—')}</td>
                <td>${escapeHtml(s.position)}</td>
                <td><span class="badge ${s.role === 'super_admin' ? 'badge-status-rejected' : 'badge-status-under-review'}">${escapeHtml(s.role)}</span></td>
                <td>${escapeHtml(s.contact_number || '—')}</td>
                <td><span class="badge ${s.account_status === 'Active' ? 'badge-status-confirmed' : 'badge-cancelled'}">${escapeHtml(s.account_status)}</span></td>
                <td>
                  <button type="button" class="btn btn-outline-blue btn-xs edit-staff-btn" data-sid="${escapeHtml(s.staff_id)}">
                    Edit / Permissions
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.querySelector('#create-staff-btn')?.addEventListener('click', () => {
    openModal({
      title: 'Create Clinical Staff / Administrator Account',
      bodyHtml: `
        <form id="new-staff-form">
          <div class="form-grid" style="margin-bottom:1rem;">
            <div class="form-group">
              <label class="form-label">Full Name <span class="req">*</span></label>
              <input type="text" id="ns-name" class="form-control" placeholder="RN Full Name" required />
            </div>
            <div class="form-group">
              <label class="form-label">Email Address <span class="req">*</span></label>
              <input type="email" id="ns-email" class="form-control" placeholder="staff@reliancedialysis.ph" required />
            </div>
            <div class="form-group">
              <label class="form-label">Initial Password <span class="req">*</span></label>
              <input type="password" id="ns-pass" class="form-control" minlength="6" placeholder="Min. 6 characters" required />
            </div>
            <div class="form-group">
              <label class="form-label">Position <span class="req">*</span></label>
              <input type="text" id="ns-pos" class="form-control" value="Dialysis Nurse" required />
            </div>
            <div class="form-group">
              <label class="form-label">Role <span class="req">*</span></label>
              <select id="ns-role" class="form-control" required>
                <option value="staff">Staff</option>
                <option value="super_admin">Super Administrator</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Contact Number</label>
              <input type="tel" id="ns-phone" class="form-control" placeholder="09XX XXX XXXX" />
            </div>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%;">Create Account</button>
        </form>
      `,
      onMount: (mEl) => {
        mEl.querySelector('#new-staff-form').addEventListener('submit', async (e) => {
          e.preventDefault();
          const { error } = await supabase.rpc('admin_create_staff_account', {
            p_email: mEl.querySelector('#ns-email').value.trim(),
            p_password: mEl.querySelector('#ns-pass').value,
            p_full_name: mEl.querySelector('#ns-name').value.trim(),
            p_position: mEl.querySelector('#ns-pos').value.trim(),
            p_role: mEl.querySelector('#ns-role').value,
            p_contact_number: mEl.querySelector('#ns-phone').value.trim() || null
          });
          if (error) { showToast(error.message, 'error'); return; }
          closeModal();
          showToast('Staff account created and activated!', 'success');
          await onRefresh();
          renderAdminStaff({ container, state, onRefresh });
        });
      }
    });
  });

  container.querySelectorAll('.edit-staff-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const s = state.staffList.find(x => x.staff_id === btn.dataset.sid);
      if (!s) return;
      const perms = s.permissions || {};

      openModal({
        title: `Edit Staff & Permissions — ${s.full_name}`,
        bodyHtml: `
          <form id="edit-staff-form">
            <div class="form-grid" style="margin-bottom:1rem;">
              <div class="form-group">
                <label class="form-label">Full Name <span class="req">*</span></label>
                <input type="text" id="es-name" class="form-control" value="${escapeHtml(s.full_name)}" required />
              </div>
              <div class="form-group">
                <label class="form-label">Position <span class="req">*</span></label>
                <input type="text" id="es-pos" class="form-control" value="${escapeHtml(s.position)}" required />
              </div>
              <div class="form-group">
                <label class="form-label">Role <span class="req">*</span></label>
                <select id="es-role" class="form-control">
                  <option value="staff" ${s.role === 'staff' ? 'selected' : ''}>Staff</option>
                  <option value="super_admin" ${s.role === 'super_admin' ? 'selected' : ''}>Super Administrator</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Contact Number</label>
                <input type="text" id="es-phone" class="form-control" value="${escapeHtml(s.contact_number || '')}" />
              </div>
              <div class="form-group full-width">
                <label class="form-label">Authorized Module Permissions</label>
                <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:0.45rem; margin-top:0.35rem; font-size:0.86rem;">
                  ${[
                    ['verify_documents', 'Document Verification'],
                    ['manage_appointments', 'Appointment Processing'],
                    ['manage_machines', 'Dialysis Machine Control'],
                    ['record_sessions', 'Record Dialysis Sessions'],
                    ['release_records', 'Medical Record Release']
                  ].map(([k, lbl]) => `
                    <label style="display:flex; align-items:center; gap:0.45rem;">
                      <input type="checkbox" name="perm_chk" value="${k}" ${perms[k] !== false ? 'checked' : ''} />
                      <span>${lbl}</span>
                    </label>
                  `).join('')}
                </div>
              </div>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">Save Staff Profile &amp; Permissions</button>
          </form>
        `,
        onMount: (mEl) => {
          mEl.querySelector('#edit-staff-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const newPerms = {};
            mEl.querySelectorAll('input[name="perm_chk"]').forEach(chk => {
              newPerms[chk.value] = chk.checked;
            });

            const { error } = await supabase
              .from('staff')
              .update({
                full_name: mEl.querySelector('#es-name').value.trim(),
                position: mEl.querySelector('#es-pos').value.trim(),
                role: mEl.querySelector('#es-role').value,
                contact_number: mEl.querySelector('#es-phone').value.trim() || null,
                permissions: newPerms
              })
              .eq('staff_id', s.staff_id);

            if (error) { showToast(error.message, 'error'); return; }
            await recordAudit('Updated Staff Profile & Permissions', 'Staff Management', s.staff_id, { role: mEl.querySelector('#es-role').value });
            closeModal();
            showToast('Staff record updated.', 'success');
            await onRefresh();
            renderAdminStaff({ container, state, onRefresh });
          });
        }
      });
    });
  });
}

/* 4. SYSTEM CONFIGURATION */
export function renderAdminSystemConfig({ container, state, onRefresh }) {
  const cfg = state.clinicConfig;
  const opDays = cfg.operating_days || [1, 2, 3, 4, 5, 6];
  const slots = cfg.time_slots || [];

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">System Configuration</h1>
        <p class="page-subtitle">Configure clinic operating days, operating hours, configurable appointment session time slots, and scheduling rules.</p>
      </div>
    </div>

    <form id="sys-config-form">
      <div class="card" style="margin-bottom:1.35rem;">
        <div class="card-header">
          <h2 class="card-title">Clinic Operating Schedule</h2>
        </div>

        <div class="form-group" style="margin-bottom:1.15rem;">
          <label class="form-label">Operating Days (Patients can only select active operating days)</label>
          <div style="display:flex; flex-wrap:wrap; gap:1rem; margin-top:0.35rem;">
            ${DAY_LABELS.map(d => `
              <label style="display:flex; align-items:center; gap:0.45rem; font-size:0.9rem;">
                <input type="checkbox" name="cfg_op_day" value="${d.num}" ${opDays.includes(d.num) ? 'checked' : ''} />
                <span>${d.name}</span>
              </label>
            `).join('')}
          </div>
        </div>

        <div class="form-grid-3">
          <div class="form-group">
            <label class="form-label">Opening Time</label>
            <input type="time" id="cfg-open" class="form-control" value="${escapeHtml(cfg.operating_hours?.open || '08:00')}" required />
          </div>
          <div class="form-group">
            <label class="form-label">Closing Time</label>
            <input type="time" id="cfg-close" class="form-control" value="${escapeHtml(cfg.operating_hours?.close || '17:00')}" required />
          </div>
          <div class="form-group">
            <label class="form-label">Max Advance Booking Days</label>
            <input type="number" min="7" max="180" id="cfg-adv-days" class="form-control" value="${escapeHtml(cfg.max_advance_days || 60)}" required />
          </div>
        </div>
      </div>

      <div class="card" style="margin-bottom:1.35rem;">
        <div class="card-header">
          <h2 class="card-title">Appointment Session Time Slots</h2>
        </div>
        <div style="display:flex; flex-direction:column; gap:0.85rem;">
          ${slots.map((sl, idx) => `
            <div class="form-grid-3" data-slot-row="${idx}" style="padding-bottom:0.75rem; border-bottom:1px solid var(--border-subtle);">
              <div class="form-group">
                <label class="form-label">Session Label</label>
                <input type="text" class="form-control sl-label" value="${escapeHtml(sl.label)}" required />
              </div>
              <div class="form-group">
                <label class="form-label">Start Time</label>
                <input type="time" class="form-control sl-start" value="${escapeHtml(sl.start_time.slice(0, 5))}" required />
              </div>
              <div class="form-group">
                <label class="form-label">End Time</label>
                <input type="time" class="form-control sl-end" value="${escapeHtml(sl.end_time.slice(0, 5))}" required />
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <button type="submit" class="btn btn-primary">Save Clinic System Configuration</button>
    </form>
  `;

  container.querySelector('#sys-config-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const chosenDays = Array.from(container.querySelectorAll('input[name="cfg_op_day"]:checked')).map(c => Number(c.value));
    const newSlots = Array.from(container.querySelectorAll('[data-slot-row]')).map(row => {
      const label = row.querySelector('.sl-label').value.trim();
      const start_time = row.querySelector('.sl-start').value;
      const end_time = row.querySelector('.sl-end').value;
      return {
        id: label,
        label,
        display: formatTimeRange(start_time, end_time),
        start_time,
        end_time
      };
    });

    const newConfig = {
      operating_days: chosenDays,
      operating_hours: {
        open: container.querySelector('#cfg-open').value,
        close: container.querySelector('#cfg-close').value
      },
      max_advance_days: Number(container.querySelector('#cfg-adv-days').value || 60),
      allow_recurring_generation: true,
      time_slots: newSlots
    };

    const { error } = await supabase.rpc('update_clinic_schedule_config', { p_config: newConfig });
    if (error) { showToast(error.message, 'error'); return; }

    showToast('System configuration saved across all panels!', 'success');
    await onRefresh();
    renderAdminSystemConfig({ container, state, onRefresh });
  });
}

/* 5. MACHINE & SCHEDULE CONFIGURATION */
export function renderAdminMachineConfig({ container, state, onRefresh }) {
  let inspectDate = getTodayISO();

  function draw() {
    const daySlots = state.machineSlots.filter(s => s.schedule_date === inspectDate);

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Machine &amp; Schedule Configuration</h1>
          <p class="page-subtitle">Manage dialysis stations, register additional machines, update maintenance blocks, and monitor machine slot settings.</p>
        </div>
        <div style="display:flex; gap:0.65rem; align-items:center;">
          <input type="date" id="adm-mach-date" class="form-control" style="width:auto;" value="${escapeHtml(inspectDate)}" />
          <button type="button" class="btn btn-primary btn-sm" id="adm-add-machine-btn">+ Register Machine</button>
        </div>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Machine Code</th>
                <th>Station Name</th>
                <th>Status</th>
                <th>Description / Maintenance Remarks</th>
                <th>Slots (${escapeHtml(formatDate(inspectDate))})</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${state.machines.map(m => {
                const ms = daySlots.filter(s => s.machine_id === m.machine_id);
                return `
                  <tr>
                    <td><strong>${escapeHtml(m.machine_code)}</strong></td>
                    <td>${escapeHtml(m.machine_name)}</td>
                    <td>${machineBadgeHtml(m.machine_status)}</td>
                    <td style="font-size:0.82rem;">
                      <div>${escapeHtml(m.description || '')}</div>
                      ${m.maintenance_remarks ? `<div class="text-red">Maint: ${escapeHtml(m.maintenance_remarks)}</div>` : ''}
                    </td>
                    <td style="font-size:0.81rem;">
                      ${ms.length === 0 ? '<span class="text-muted">Open</span>' : ms.map(sl => `${escapeHtml(formatTimeRange(sl.start_time, sl.end_time))} (${escapeHtml(sl.slot_status)})`).join('<br>')}
                    </td>
                    <td>
                      <button type="button" class="btn btn-outline-blue btn-xs adm-edit-mach" data-mid="${escapeHtml(m.machine_id)}">Edit Station</button>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    container.querySelector('#adm-mach-date')?.addEventListener('change', (e) => {
      inspectDate = e.target.value;
      draw();
    });

    container.querySelector('#adm-add-machine-btn')?.addEventListener('click', () => {
      openModal({
        title: 'Register New Dialysis Machine',
        size: 'sm',
        bodyHtml: `
          <form id="adm-new-mach-form">
            <div class="form-group" style="margin-bottom:0.85rem;">
              <label class="form-label">Machine Code <span class="req">*</span></label>
              <input type="text" id="nm-code" class="form-control" placeholder="e.g., RDC-M11" required />
            </div>
            <div class="form-group" style="margin-bottom:0.85rem;">
              <label class="form-label">Machine Name <span class="req">*</span></label>
              <input type="text" id="nm-name" class="form-control" placeholder="Hemodialysis Station 11" required />
            </div>
            <div class="form-group" style="margin-bottom:1rem;">
              <label class="form-label">Description</label>
              <input type="text" id="nm-desc" class="form-control" placeholder="Standard Hemodialysis Unit" />
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">Register Station</button>
          </form>
        `,
        onMount: (mEl) => {
          mEl.querySelector('#adm-new-mach-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const code = mEl.querySelector('#nm-code').value.trim().toUpperCase();
            const { data, error } = await supabase
              .from('dialysis_machines')
              .insert({
                machine_code: code,
                machine_name: mEl.querySelector('#nm-name').value.trim(),
                description: mEl.querySelector('#nm-desc').value.trim() || null,
                machine_status: 'Available'
              })
              .select('*')
              .single();
            if (error) { showToast(error.message, 'error'); return; }
            await recordAudit(`Registered Dialysis Machine ${code}`, 'Machine Configuration', data.machine_id);
            closeModal();
            showToast('Dialysis machine registered.', 'success');
            await onRefresh();
            draw();
          });
        }
      });
    });

    container.querySelectorAll('.adm-edit-mach').forEach(btn => {
      btn.addEventListener('click', () => {
        const m = state.machines.find(x => x.machine_id === btn.dataset.mid);
        if (!m) return;
        openModal({
          title: `Configure Machine — ${m.machine_code}`,
          size: 'sm',
          bodyHtml: `
            <form id="adm-edit-mach-form">
              <div class="form-group" style="margin-bottom:0.85rem;">
                <label class="form-label">Station Name <span class="req">*</span></label>
                <input type="text" id="em-name" class="form-control" value="${escapeHtml(m.machine_name)}" required />
              </div>
              <div class="form-group" style="margin-bottom:0.85rem;">
                <label class="form-label">Status <span class="req">*</span></label>
                <select id="em-status" class="form-control">
                  ${['Available', 'Occupied', 'Maintenance', 'Offline'].map(s => `<option value="${s}" ${m.machine_status === s ? 'selected' : ''}>${s}</option>`).join('')}
                </select>
              </div>
              <div class="form-group" style="margin-bottom:0.85rem;">
                <label class="form-label">Description</label>
                <input type="text" id="em-desc" class="form-control" value="${escapeHtml(m.description || '')}" />
              </div>
              <div class="form-group" style="margin-bottom:1rem;">
                <label class="form-label">Maintenance Remarks</label>
                <textarea id="em-rem" class="form-control">${escapeHtml(m.maintenance_remarks || '')}</textarea>
              </div>
              <button type="submit" class="btn btn-primary" style="width:100%;">Update Machine</button>
            </form>
          `,
          onMount: (mEl) => {
            mEl.querySelector('#adm-edit-mach-form').addEventListener('submit', async (e) => {
              e.preventDefault();
              const { error } = await supabase
                .from('dialysis_machines')
                .update({
                  machine_name: mEl.querySelector('#em-name').value.trim(),
                  machine_status: mEl.querySelector('#em-status').value,
                  description: mEl.querySelector('#em-desc').value.trim() || null,
                  maintenance_remarks: mEl.querySelector('#em-rem').value.trim() || null
                })
                .eq('machine_id', m.machine_id);
              if (error) { showToast(error.message, 'error'); return; }
              await recordAudit(`Updated Machine Configuration ${m.machine_code}`, 'Machine Configuration', m.machine_id);
              closeModal();
              showToast('Machine configuration saved.', 'success');
              await onRefresh();
              draw();
            });
          }
        });
      });
    });
  }

  draw();
}

/* 6. ANALYTICS AND REPORTS */
export function renderAdminAnalytics({ container, state }) {
  const totalPatients = state.patients.length;
  const freqCounts = {};
  state.medicalProfiles.forEach(m => {
    const f = m.prescribed_dialysis_frequency || 'Unspecified';
    freqCounts[f] = (freqCounts[f] || 0) + 1;
  });

  // Appointment Demand by Session Time
  const demandByTime = {};
  state.appointments.forEach(a => {
    const t = a.requested_time || 'Other';
    demandByTime[t] = (demandByTime[t] || 0) + 1;
  });

  // Machine Utilization by Machine Code
  const machineUsage = state.machines.map(m => {
    const sessCnt = state.sessions.filter(s => s.machine_id === m.machine_id).length;
    const slotCnt = state.machineSlots.filter(sl => sl.machine_id === m.machine_id && sl.slot_status !== 'Cancelled').length;
    return { code: m.machine_code, total: Math.max(sessCnt, slotCnt), status: m.machine_status };
  });
  const maxMachTotal = Math.max(1, ...machineUsage.map(x => x.total));

  // Attendance & No-Show Analysis
  const confirmedTotal = state.appointments.filter(a => a.appointment_status === 'Confirmed').length;
  const attendedCnt = state.appointments.filter(a => a.attendance_flag === 'Attended').length;
  const noShowCnt = state.appointments.filter(a => a.attendance_flag === 'No-Show').length;
  const cancelledCnt = state.appointments.filter(a => a.is_cancelled).length;
  const noShowRate = confirmedTotal > 0 ? ((noShowCnt / confirmedTotal) * 100).toFixed(1) : '0.0';

  container.innerHTML = `
    <div class="page-header-row">
      <div>
        <h1 class="page-title">Analytics &amp; Operational Reports</h1>
        <p class="page-subtitle">Live clinical analytics computed directly from PostgreSQL records: Patient demographics, demand, machine utilization, and no-show rates.</p>
      </div>
      <button type="button" class="btn btn-outline-blue btn-sm" id="export-analytics-csv">Export Summary CSV</button>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Registered Patients</div>
        <div class="stat-value">${totalPatients}</div>
        <div class="stat-meta">${state.medicalProfiles.length} completed medical profile(s)</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Completed Dialysis Sessions</div>
        <div class="stat-value">${state.sessions.length}</div>
        <div class="stat-meta">Attended appointments: ${attendedCnt}</div>
      </div>
      <div class="stat-card accent-red">
        <div class="stat-label">No-Show Rate</div>
        <div class="stat-value">${noShowRate}%</div>
        <div class="stat-meta">${noShowCnt} no-show(s) • ${cancelledCnt} cancellation(s)</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total Appointment Demand</div>
        <div class="stat-value">${state.appointments.length}</div>
        <div class="stat-meta">All requested schedules</div>
      </div>
    </div>

    <div class="dashboard-grid-2">
      <!-- Appointment Demand Analysis -->
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Appointment Demand by Session Slot</h2>
        </div>
        <div class="analytics-bar-list">
          ${Object.entries(demandByTime).length === 0 ? `<div class="text-muted">No appointment data yet.</div>` :
            Object.entries(demandByTime).map(([slot, cnt]) => {
              const pct = Math.round((cnt / Math.max(1, state.appointments.length)) * 100);
              return `
                <div class="analytics-bar-row">
                  <strong>${escapeHtml(slot)}</strong>
                  <div class="analytics-bar-track"><div class="analytics-bar-fill" style="width:${pct}%"></div></div>
                  <span>${cnt} (${pct}%)</span>
                </div>
              `;
            }).join('')}
        </div>

        <hr style="border:0; border-top:1px solid var(--border-subtle); margin:1.25rem 0;" />
        <h3 style="font-size:0.95rem; color:var(--reliance-blue); margin:0 0 0.75rem;">Patient Prescribed Frequency Breakdown</h3>
        <div class="analytics-bar-list">
          ${Object.entries(freqCounts).length === 0 ? `<div class="text-muted">No medical profiles yet.</div>` :
            Object.entries(freqCounts).map(([fq, cnt]) => {
              const pct = Math.round((cnt / Math.max(1, state.medicalProfiles.length)) * 100);
              return `
                <div class="analytics-bar-row">
                  <strong>${escapeHtml(fq)}</strong>
                  <div class="analytics-bar-track"><div class="analytics-bar-fill red" style="width:${pct}%"></div></div>
                  <span>${cnt}</span>
                </div>
              `;
            }).join('')}
        </div>
      </div>

      <!-- Machine Utilization Analysis -->
      <div class="card">
        <div class="card-header">
          <h2 class="card-title">Dialysis Machine Utilization (10 Stations)</h2>
        </div>
        <div class="analytics-bar-list">
          ${machineUsage.map(m => {
            const pct = Math.round((m.total / maxMachTotal) * 100);
            return `
              <div class="analytics-bar-row">
                <span><strong>${escapeHtml(m.code)}</strong> <small class="text-muted">(${escapeHtml(m.status)})</small></span>
                <div class="analytics-bar-track"><div class="analytics-bar-fill" style="width:${m.total > 0 ? pct : 0}%"></div></div>
                <span>${m.total} slot(s)</span>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    </div>
  `;

  container.querySelector('#export-analytics-csv')?.addEventListener('click', () => {
    const rows = [
      ['Metric', 'Value'],
      ['Total Registered Patients', totalPatients],
      ['Total Appointments', state.appointments.length],
      ['Confirmed Appointments', confirmedTotal],
      ['Completed Dialysis Sessions', state.sessions.length],
      ['No-Show Count', noShowCnt],
      ['No-Show Rate (%)', noShowRate],
      ['Recorded Cancellations', cancelledCnt]
    ];
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reliance_mabini_analytics_${getTodayISO()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  });
}

/* 7. AUDIT LOGS */
export function renderAdminAuditLogs({ container, state }) {
  let modFilter = 'ALL';
  let search = '';

  const modules = Array.from(new Set(state.auditLogs.map(l => l.affected_module))).sort();

  function draw() {
    const q = search.toLowerCase();
    const list = state.auditLogs.filter(l => {
      if (modFilter !== 'ALL' && l.affected_module !== modFilter) return false;
      if (q && !(l.activity || '').toLowerCase().includes(q) && !JSON.stringify(l.details || {}).toLowerCase().includes(q)) return false;
      return true;
    });

    container.innerHTML = `
      <div class="page-header-row">
        <div>
          <h1 class="page-title">Immutable Security &amp; Operational Audit Logs</h1>
          <p class="page-subtitle">Read-only accountability log tracking authentication, profile updates, document verifications, machine assignments, and configuration changes.</p>
        </div>
      </div>

      <div class="card">
        <div class="filter-bar">
          <select id="audit-mod-filter" class="form-control">
            <option value="ALL">All Modules</option>
            ${modules.map(m => `<option value="${escapeHtml(m)}" ${modFilter === m ? 'selected' : ''}>${escapeHtml(m)}</option>`).join('')}
          </select>
          <input type="search" id="audit-search-input" class="form-control" style="min-width:260px;" placeholder="Filter activity or record details..." value="${escapeHtml(search)}" />
        </div>

        ${list.length === 0 ? `<div class="empty-state">No audit log entries match your filter.</div>` : `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Module</th>
                  <th>Activity</th>
                  <th>Record ID</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                ${list.map(l => `
                  <tr>
                    <td style="white-space:nowrap;">${escapeHtml(formatDateTime(l.created_at))}</td>
                    <td><span class="badge badge-status-under-review">${escapeHtml(l.affected_module)}</span></td>
                    <td><strong>${escapeHtml(l.activity)}</strong></td>
                    <td style="font-size:0.78rem; color:var(--text-muted);">${escapeHtml(l.affected_record_id || '—')}</td>
                    <td style="font-size:0.78rem; max-width:280px; word-break:break-word;">${escapeHtml(JSON.stringify(l.details || {}))}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `}
      </div>
    `;

    container.querySelector('#audit-mod-filter')?.addEventListener('change', (e) => {
      modFilter = e.target.value;
      draw();
    });

    const sIn = container.querySelector('#audit-search-input');
    sIn.addEventListener('input', (e) => {
      search = e.target.value;
      const p = sIn.selectionStart;
      draw();
      const nx = container.querySelector('#audit-search-input');
      nx.focus();
      nx.setSelectionRange(p, p);
    });
  }

  draw();
}
