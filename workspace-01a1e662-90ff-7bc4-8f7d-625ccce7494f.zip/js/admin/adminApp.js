/**
 * Reliance Dialysis Center Inc. — Super Administrator Panel Master Controller
 */

import { supabase, fetchClinicConfig } from '../supabaseClient.js';
import { requireRoleGuard, signOutAndRedirect } from '../authGuard.js';
import { NotificationBell } from '../components/notifications.js';

import {
  renderAdminDashboard,
  renderAdminUsers,
  renderAdminStaff,
  renderAdminSystemConfig,
  renderAdminMachineConfig,
  renderAdminAnalytics,
  renderAdminAuditLogs
} from './adminViews.js';

const mainView = document.getElementById('admin-main-view');
const sidebar = document.getElementById('portal-sidebar');

const state = {
  user: null,
  staff: null,
  patients: [],
  staffList: [],
  medicalProfiles: [],
  appointments: [],
  machines: [],
  machineSlots: [],
  sessions: [],
  auditLogs: [],
  clinicConfig: null
};

let notifBell = null;

async function refreshAdminData() {
  const [ptRes, stRes, medRes, apptRes, machRes, slotRes, sessRes, auditRes, cfg] = await Promise.all([
    supabase.from('patients').select('*').order('created_at', { ascending: false }),
    supabase.from('staff').select('*').order('created_at', { ascending: false }),
    supabase.from('patient_medical_profiles').select('*'),
    supabase.from('appointments').select('*').order('created_at', { ascending: false }),
    supabase.from('dialysis_machines').select('*').order('machine_code', { ascending: true }),
    supabase.from('machine_slots').select('*').order('schedule_date', { ascending: false }),
    supabase.from('dialysis_sessions').select('*').order('treatment_date', { ascending: false }),
    supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(200),
    fetchClinicConfig()
  ]);

  state.patients = ptRes.data || [];
  state.staffList = stRes.data || [];
  state.medicalProfiles = medRes.data || [];
  state.appointments = apptRes.data || [];
  state.machines = machRes.data || [];
  state.machineSlots = slotRes.data || [];
  state.sessions = sessRes.data || [];
  state.auditLogs = auditRes.data || [];
  state.clinicConfig = cfg;

  if (notifBell) await notifBell.refresh();
}

function navigateTo(view) {
  sidebar.classList.remove('open');
  document.querySelectorAll('.sidebar-nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });

  if (view === 'dashboard') {
    renderAdminDashboard({ container: mainView, state, onNavigate: navigateTo });
  } else if (view === 'users') {
    renderAdminUsers({ container: mainView, state, onRefresh: refreshAdminData });
  } else if (view === 'staff') {
    renderAdminStaff({ container: mainView, state, onRefresh: refreshAdminData });
  } else if (view === 'config') {
    renderAdminSystemConfig({ container: mainView, state, onRefresh: refreshAdminData });
  } else if (view === 'machines') {
    renderAdminMachineConfig({ container: mainView, state, onRefresh: refreshAdminData });
  } else if (view === 'analytics') {
    renderAdminAnalytics({ container: mainView, state });
  } else if (view === 'audit') {
    renderAdminAuditLogs({ container: mainView, state });
  }
}

async function initAdminPanel() {
  const ctx = await requireRoleGuard(['super_admin']);
  if (!ctx) return;

  state.user = ctx.user;
  state.staff = ctx.staff;

  document.getElementById('header-admin-name').textContent = state.staff.full_name;
  document.getElementById('dropdown-admin-name').textContent = state.staff.full_name;
  document.getElementById('dropdown-admin-pos').textContent = state.staff.position;

  notifBell = new NotificationBell({
    userId: state.user.id,
    bellButton: document.getElementById('notif-bell-btn'),
    badgeElement: document.getElementById('notif-badge'),
    dropdownElement: document.getElementById('notif-dropdown'),
    onViewAll: () => navigateTo('audit')
  });
  await notifBell.init();

  const trigger = document.getElementById('profile-trigger-btn');
  const dropdown = document.getElementById('profile-dropdown');
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    dropdown.hidden = !dropdown.hidden;
  });
  document.addEventListener('click', (e) => {
    if (!dropdown.hidden && !document.getElementById('profile-menu-wrapper').contains(e.target)) {
      dropdown.hidden = true;
    }
  });

  document.getElementById('goto-staff-panel-btn').addEventListener('click', () => {
    window.location.href = '/staff.html';
  });
  document.getElementById('admin-logout-btn').addEventListener('click', () => signOutAndRedirect('/auth.html'));
  document.getElementById('sidebar-toggle-btn').addEventListener('click', () => sidebar.classList.toggle('open'));

  document.querySelectorAll('.sidebar-nav-btn').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.view));
  });

  await refreshAdminData();
  navigateTo('dashboard');
}

initAdminPanel();
