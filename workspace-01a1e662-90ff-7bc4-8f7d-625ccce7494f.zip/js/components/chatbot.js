/**
 * Reliance Dialysis Center Inc. — Floating "Reliance Assistant" Chatbot
 * Matches Page 1 reference pill button and answers ONLY general system questions:
 *  - Registration
 *  - Required documents
 *  - Booking procedures
 *  - Operating schedule
 *  - Accessing medical records
 * Strictly refuses medical diagnoses or treatment recommendations.
 */

import { escapeHtml } from '../utils.js';

const QUICK_TOPICS = [
  { id: 'register', label: 'How do I register?' },
  { id: 'documents', label: 'Required documents' },
  { id: 'booking', label: 'Booking procedure' },
  { id: 'schedule', label: 'Operating schedule' },
  { id: 'records', label: 'Accessing medical records' }
];

function generateAssistantReply(rawQuery) {
  const q = String(rawQuery || '').toLowerCase();

  // Safety boundary: Never give medical diagnoses or treatment advice
  const clinicalKeywords = [
    'diagnos', 'symptom', 'medicine', 'medication', 'dosage', 'dose', 'pain',
    'fever', 'dizzy', 'cramps', 'swelling', 'creatinine', 'potassium', 'diet',
    'prescribe', 'cure', 'infection', 'bleeding', 'blood pressure high', 'fistula hurt',
    'emergency', 'chest pain', 'shortness of breath'
  ];
  if (clinicalKeywords.some(k => q.includes(k))) {
    return `I am the Reliance Assistant for system and scheduling guidance only, so I cannot provide medical diagnoses, lab interpretations, or treatment recommendations. Please consult your attending nephrologist directly, or call Reliance Dialysis Center Inc. at 0969 161 3662 (Mabini Community Hospital compound) for immediate clinical assistance.`;
  }

  if (q.includes('register') || q.includes('sign up') || q.includes('account') || q.includes('profile')) {
    return `To register as a patient:\n1. Click "Login" or "Book your appointment now" and choose Create Account.\n2. Enter your Full Name, Email Address, and Password.\n3. After logging in, complete your one-time Personal Information and Medical Profile forms so you won't need to re-enter them for future appointments.`;
  }

  if (q.includes('document') || q.includes('upload') || q.includes('requirement') || q.includes('endorsement') || q.includes('abstract') || q.includes('lab') || q.includes('id')) {
    return `You need to upload four (4) required documents in PDF, JPG, PNG, or WEBP format (up to 10 MB each):\n1. Nephrologist's Endorsement\n2. Medical Abstract\n3. Latest Laboratory Results\n4. Valid Identification (ID)\n\nOnce verified by our staff, your documents remain saved for succeeding appointments unless updated labs are requested.`;
  }

  if (q.includes('book') || q.includes('appointment') || q.includes('machine') || q.includes('status') || q.includes('confirm') || q.includes('recurring')) {
    return `How to book an appointment online:\n1. Complete your Personal & Medical Profile.\n2. Upload the 4 required documents.\n3. Select an available operating date (Monday–Saturday) and preferred session time (Morning, Midday, or Afternoon).\n4. Submit your request.\n\nNote: Patients choose only their preferred date and time—authorized clinic staff assign the dialysis machine and update your status (Pending → Under Review → Confirmed or Rejected).`;
  }

  if (q.includes('schedule') || q.includes('hour') || q.includes('open') || q.includes('close') || q.includes('sunday') || q.includes('time') || q.includes('location') || q.includes('where') || q.includes('contact')) {
    return `Clinic Operating Schedule & Location:\n• Days: Monday to Saturday (Closed on Sundays)\n• Hours: 8:00 AM to 5:00 PM\n• Treatment Sessions:\n  – Morning: 8:00 AM–11:00 AM\n  – Midday: 11:00 AM–2:00 PM\n  – Afternoon: 2:00 PM–5:00 PM\n• Location: Mabini Community Hospital, Sitio Mailayin, Pulong Niogan, Mabini, Batangas\n• Contact: 0969 161 3662 | redci.mabini@thebestrenalcare.com`;
  }

  if (q.includes('record') || q.includes('history') || q.includes('session') || q.includes('weight')) {
    return `To view your medical and dialysis records:\n1. Log in to the Patient Panel and open "My Records" in the left blue sidebar.\n2. You can view three organized tabs: Medical Information, Submitted Documents (with verification status), and Dialysis History (treatment dates, assigned machine, pre/post weights, and released notes).`;
  }

  return `Hello! I'm the Reliance Assistant for Reliance Dialysis Center Inc. in Mabini, Batangas. I can help you with:\n• Account registration & profile setup\n• The 4 required medical documents\n• Online appointment booking procedures\n• Clinic operating days & session times\n• Accessing your medical & dialysis records\n\n(Note: I do not provide medical diagnoses or treatment advice.)`;
}

export function mountRelianceChatbot() {
  if (document.getElementById('reliance-chatbot-root')) return;

  const root = document.createElement('div');
  root.id = 'reliance-chatbot-root';
  root.className = 'chatbot-root';
  root.innerHTML = `
    <div class="chatbot-window" id="chatbot-window" hidden>
      <div class="chatbot-header">
        <div>
          <div class="chatbot-title">Reliance Assistant</div>
          <div class="chatbot-subtitle">System & Scheduling Guide • Non-Clinical</div>
        </div>
        <button type="button" class="chatbot-close" id="chatbot-close-btn" aria-label="Close Reliance Assistant">&times;</button>
      </div>
      <div class="chatbot-messages" id="chatbot-messages">
        <div class="chat-bubble bot">
          Welcome to <strong>Reliance Dialysis Center Inc.</strong> (Mabini, Batangas). How can I assist you with registration, required documents, appointment booking, clinic hours, or viewing your records?
        </div>
      </div>
      <div class="chatbot-quick-topics" id="chatbot-quick-topics">
        ${QUICK_TOPICS.map(t => `<button type="button" class="chat-chip" data-topic="${escapeHtml(t.label)}">${escapeHtml(t.label)}</button>`).join('')}
      </div>
      <form class="chatbot-form" id="chatbot-form">
        <input type="text" id="chatbot-input" placeholder="Ask about booking, documents, hours..." autocomplete="off" required />
        <button type="submit" class="btn btn-primary btn-sm">Send</button>
      </form>
    </div>
    <button type="button" class="chatbot-launcher" id="chatbot-launcher" aria-expanded="false">
      <span>Reliance Assistant</span>
    </button>
  `;

  document.body.appendChild(root);

  const launcher = root.querySelector('#chatbot-launcher');
  const win = root.querySelector('#chatbot-window');
  const closeBtn = root.querySelector('#chatbot-close-btn');
  const messagesEl = root.querySelector('#chatbot-messages');
  const form = root.querySelector('#chatbot-form');
  const input = root.querySelector('#chatbot-input');

  function appendMessage(text, sender = 'bot') {
    const div = document.createElement('div');
    div.className = `chat-bubble ${sender}`;
    div.innerHTML = escapeHtml(text).replace(/\n/g, '<br>');
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function handleQuestion(questionText) {
    if (!questionText.trim()) return;
    appendMessage(questionText, 'user');
    setTimeout(() => {
      appendMessage(generateAssistantReply(questionText), 'bot');
    }, 180);
  }

  launcher.addEventListener('click', () => {
    const willOpen = win.hidden;
    win.hidden = !willOpen;
    launcher.setAttribute('aria-expanded', String(willOpen));
    if (willOpen) input.focus();
  });

  closeBtn.addEventListener('click', () => {
    win.hidden = true;
    launcher.setAttribute('aria-expanded', 'false');
  });

  root.querySelectorAll('.chat-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      handleQuestion(chip.dataset.topic);
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const val = input.value;
    input.value = '';
    handleQuestion(val);
  });
}
