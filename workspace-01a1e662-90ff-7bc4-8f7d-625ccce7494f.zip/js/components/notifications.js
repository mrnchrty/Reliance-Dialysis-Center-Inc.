/**
 * Reliance Dialysis Center Inc. — Notification Bell & Dropdown Component
 * Reads and updates the centralized `notifications` table in Supabase.
 */

import { supabase } from '../supabaseClient.js';
import { escapeHtml, formatDateTime } from '../utils.js';

export class NotificationBell {
  constructor({ userId, bellButton, badgeElement, dropdownElement, onViewAll }) {
    this.userId = userId;
    this.bellButton = bellButton;
    this.badgeElement = badgeElement;
    this.dropdownElement = dropdownElement;
    this.onViewAll = onViewAll;
    this.notifications = [];
    this.isOpen = false;
    this.channel = null;
  }

  async init() {
    await this.refresh();

    this.bellButton.addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggle();
    });

    document.addEventListener('click', (e) => {
      if (this.isOpen && !this.dropdownElement.contains(e.target) && e.target !== this.bellButton) {
        this.close();
      }
    });

    // Subscribe to realtime inserts on notifications for this user
    try {
      this.channel = supabase
        .channel(`notif_${this.userId}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'notifications',
            filter: `recipient_user_id=eq.${this.userId}`
          },
          () => this.refresh()
        )
        .subscribe();
    } catch {
      // Realtime optional fallback
    }
  }

  async refresh() {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('recipient_user_id', this.userId)
      .order('created_at', { ascending: false })
      .limit(25);

    if (!error && data) {
      this.notifications = data;
      this.render();
    }
    return this.notifications;
  }

  render() {
    const unreadCount = this.notifications.filter(n => !n.is_read).length;
    if (unreadCount > 0) {
      this.badgeElement.textContent = unreadCount > 99 ? '99+' : String(unreadCount);
      this.badgeElement.hidden = false;
    } else {
      this.badgeElement.hidden = true;
    }

    const preview = this.notifications.slice(0, 6);
    const itemsHtml = preview.length === 0
      ? `<div class="notif-empty">No notifications yet.</div>`
      : preview.map(n => `
          <div class="notif-item ${n.is_read ? '' : 'unread'}" data-notif-id="${escapeHtml(n.notification_id)}">
            <div class="notif-item-top">
              <span class="notif-type-tag">${escapeHtml(n.notification_type || 'Update')}</span>
              <span class="notif-time">${escapeHtml(formatDateTime(n.created_at))}</span>
            </div>
            <div class="notif-title">${escapeHtml(n.title)}</div>
            <div class="notif-msg">${escapeHtml(n.message)}</div>
          </div>
        `).join('');

    this.dropdownElement.innerHTML = `
      <div class="notif-dropdown-header">
        <strong>Notifications</strong>
        ${unreadCount > 0 ? `<button type="button" class="btn-link-sm" id="mark-all-notif-read">Mark all read</button>` : ''}
      </div>
      <div class="notif-dropdown-list">${itemsHtml}</div>
      <div class="notif-dropdown-footer">
        <button type="button" class="btn-link-sm" id="view-all-notifs-btn">View all notifications</button>
      </div>
    `;

    const markAllBtn = this.dropdownElement.querySelector('#mark-all-notif-read');
    if (markAllBtn) {
      markAllBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await this.markAllRead();
      });
    }

    this.dropdownElement.querySelectorAll('.notif-item').forEach(item => {
      item.addEventListener('click', async () => {
        const id = item.dataset.notifId;
        await this.markOneRead(id);
      });
    });

    const viewAllBtn = this.dropdownElement.querySelector('#view-all-notifs-btn');
    if (viewAllBtn) {
      viewAllBtn.addEventListener('click', () => {
        this.close();
        if (typeof this.onViewAll === 'function') this.onViewAll();
      });
    }
  }

  async markOneRead(notificationId) {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('notification_id', notificationId)
      .eq('recipient_user_id', this.userId);
    await this.refresh();
  }

  async markAllRead() {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('recipient_user_id', this.userId)
      .eq('is_read', false);
    await this.refresh();
  }

  toggle() {
    this.isOpen ? this.close() : this.open();
  }

  open() {
    this.isOpen = true;
    this.dropdownElement.hidden = false;
  }

  close() {
    this.isOpen = false;
    this.dropdownElement.hidden = true;
  }
}
