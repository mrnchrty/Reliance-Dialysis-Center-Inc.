/**
 * Reliance Dialysis Center Inc. — Toast Alerts & Modal Dialog Helpers
 */

import { escapeHtml } from '../utils.js';

function ensureToastContainer() {
  let el = document.getElementById('rdc-toast-container');
  if (!el) {
    el = document.createElement('div');
    el.id = 'rdc-toast-container';
    el.className = 'toast-container';
    document.body.appendChild(el);
  }
  return el;
}

export function showToast(message, type = 'info', duration = 4200) {
  const container = ensureToastContainer();
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  const icon = type === 'success' ? '✓' : type === 'error' ? '!' : 'i';
  toast.innerHTML = `
    <span class="toast-icon">${icon}</span>
    <span class="toast-msg">${escapeHtml(message)}</span>
    <button type="button" class="toast-close" aria-label="Close">&times;</button>
  `;
  toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());
  container.appendChild(toast);

  if (duration > 0) {
    setTimeout(() => {
      if (toast.isConnected) toast.remove();
    }, duration);
  }
}

export function openModal({ title, bodyHtml, footerHtml = '', size = 'md', onMount = null }) {
  closeModal();
  const overlay = document.createElement('div');
  overlay.id = 'rdc-modal-overlay';
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-dialog modal-${size}" role="dialog" aria-modal="true">
      <div class="modal-header">
        <h3 class="modal-title">${escapeHtml(title)}</h3>
        <button type="button" class="modal-close-btn" aria-label="Close modal">&times;</button>
      </div>
      <div class="modal-body">${bodyHtml}</div>
      ${footerHtml ? `<div class="modal-footer">${footerHtml}</div>` : ''}
    </div>
  `;

  overlay.querySelector('.modal-close-btn').addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  document.body.appendChild(overlay);
  if (typeof onMount === 'function') {
    onMount(overlay);
  }
  return overlay;
}

export function closeModal() {
  const existing = document.getElementById('rdc-modal-overlay');
  if (existing) existing.remove();
}
