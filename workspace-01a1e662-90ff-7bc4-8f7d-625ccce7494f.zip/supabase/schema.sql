-- ============================================================================
-- RELIANCE DIALYSIS CENTER INC. (Mabini, Batangas)
-- Web-Based Appointment and Medical Record Management System with Analytics
-- Centralized Supabase PostgreSQL Schema, RLS Policies, Storage & Secure RPCs
-- STRICTLY 10 CORE TABLES IN PUBLIC SCHEMA
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- ============================================================================
-- UTILITY TRIGGER FUNCTION FOR updated_at
-- ============================================================================
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- ============================================================================
-- 1. PATIENTS
-- Purpose: Stores the patient's personal and contact information.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.patients (
  patient_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT NOT NULL,
  date_of_birth DATE,
  sex TEXT CHECK (sex IS NULL OR sex IN ('Male', 'Female', 'Prefer not to say')),
  address TEXT,
  contact_number TEXT,
  emergency_contact_name TEXT,
  emergency_contact_number TEXT,
  account_status TEXT NOT NULL DEFAULT 'Active' CHECK (account_status IN ('Active', 'Inactive')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_patients_user_id ON public.patients(user_id);
CREATE INDEX IF NOT EXISTS idx_patients_full_name ON public.patients(full_name);

DROP TRIGGER IF EXISTS trg_patients_updated_at ON public.patients;
CREATE TRIGGER trg_patients_updated_at
BEFORE UPDATE ON public.patients
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 2. STAFF
-- Purpose: Stores staff and administrator information.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.staff (
  staff_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT NOT NULL,
  position TEXT NOT NULL DEFAULT 'Dialysis Nurse',
  role TEXT NOT NULL DEFAULT 'staff' CHECK (role IN ('staff', 'super_admin')),
  contact_number TEXT,
  account_status TEXT NOT NULL DEFAULT 'Active' CHECK (account_status IN ('Active', 'Inactive')),
  permissions JSONB NOT NULL DEFAULT '{"verify_documents": true, "manage_appointments": true, "manage_machines": true, "record_sessions": true, "release_records": true}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_staff_user_id ON public.staff(user_id);
CREATE INDEX IF NOT EXISTS idx_staff_role ON public.staff(role);

DROP TRIGGER IF EXISTS trg_staff_updated_at ON public.staff;
CREATE TRIGGER trg_staff_updated_at
BEFORE UPDATE ON public.staff
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 3. PATIENT_MEDICAL_PROFILES
-- Purpose: Stores each patient's health and dialysis information.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.patient_medical_profiles (
  medical_profile_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID UNIQUE NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  height NUMERIC(5,2),
  weight NUMERIC(5,2),
  blood_type TEXT CHECK (blood_type IS NULL OR blood_type IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown')),
  allergies TEXT,
  diagnosis TEXT,
  existing_medical_conditions TEXT,
  previous_surgeries TEXT,
  current_medications TEXT,
  attending_nephrologist TEXT,
  prescribed_dialysis_frequency TEXT,
  dialysis_start_date DATE,
  previous_dialysis_center TEXT,
  recurring_days TEXT[] DEFAULT '{}'::TEXT[],
  preferred_time TEXT,
  correction_request_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_medical_profiles_patient_id ON public.patient_medical_profiles(patient_id);

DROP TRIGGER IF EXISTS trg_medical_profiles_updated_at ON public.patient_medical_profiles;
CREATE TRIGGER trg_medical_profiles_updated_at
BEFORE UPDATE ON public.patient_medical_profiles
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 4. PATIENT_DOCUMENTS
-- Purpose: Stores submitted appointment documents and their verification info.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.patient_documents (
  document_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  document_type TEXT NOT NULL CHECK (document_type IN (
    'Nephrologist''s Endorsement',
    'Medical Abstract',
    'Latest Laboratory Results',
    'Valid Identification',
    'Authorized Medical Record'
  )),
  file_path TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_size BIGINT,
  mime_type TEXT,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  verification_status TEXT NOT NULL DEFAULT 'Pending' CHECK (verification_status IN ('Pending', 'Verified', 'Needs Correction', 'Rejected')),
  reviewed_by UUID REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  remarks TEXT,
  is_released_to_patient BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_patient_documents_patient_id ON public.patient_documents(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_documents_status ON public.patient_documents(verification_status);

-- ============================================================================
-- 6. DIALYSIS_MACHINES (Created before machine_slots & appointments FKs)
-- Purpose: Stores the clinic's dialysis machine information.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.dialysis_machines (
  machine_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_code TEXT UNIQUE NOT NULL,
  machine_name TEXT NOT NULL,
  machine_status TEXT NOT NULL DEFAULT 'Available' CHECK (machine_status IN ('Available', 'Occupied', 'Maintenance', 'Offline')),
  description TEXT,
  maintenance_remarks TEXT,
  schedule_config JSONB DEFAULT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dialysis_machines_status ON public.dialysis_machines(machine_status);

DROP TRIGGER IF EXISTS trg_dialysis_machines_updated_at ON public.dialysis_machines;
CREATE TRIGGER trg_dialysis_machines_updated_at
BEFORE UPDATE ON public.dialysis_machines
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 7. MACHINE_SLOTS
-- Purpose: Manages individual machine schedules and prevents double booking.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.machine_slots (
  machine_slot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_id UUID NOT NULL REFERENCES public.dialysis_machines(machine_id) ON DELETE CASCADE,
  schedule_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  slot_status TEXT NOT NULL DEFAULT 'Booked' CHECK (slot_status IN ('Available', 'Booked', 'Completed', 'Maintenance', 'Cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_slot_time_order CHECK (end_time > start_time)
);

CREATE INDEX IF NOT EXISTS idx_machine_slots_date ON public.machine_slots(schedule_date);
CREATE INDEX IF NOT EXISTS idx_machine_slots_machine_date ON public.machine_slots(machine_id, schedule_date);

-- Prevent overlapping active slots on the same machine & date using GiST exclusion constraint
ALTER TABLE public.machine_slots DROP CONSTRAINT IF EXISTS excl_machine_slot_no_overlap;
ALTER TABLE public.machine_slots
  ADD CONSTRAINT excl_machine_slot_no_overlap
  EXCLUDE USING gist (
    machine_id WITH =,
    schedule_date WITH =,
    tsrange(
      ('2000-01-01'::date + start_time),
      ('2000-01-01'::date + end_time)
    ) WITH &&
  )
  WHERE (slot_status IN ('Booked', 'Maintenance'));

DROP TRIGGER IF EXISTS trg_machine_slots_updated_at ON public.machine_slots;
CREATE TRIGGER trg_machine_slots_updated_at
BEFORE UPDATE ON public.machine_slots
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 5. APPOINTMENTS
-- Purpose: Manages patient appointment requests, scheduling, approval, and machine assignment.
-- ONLY FOUR MAIN STATUSES: Pending, Under Review, Confirmed, Rejected
-- Cancellations & No-shows recorded separately without adding extra main status.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.appointments (
  appointment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  machine_slot_id UUID UNIQUE REFERENCES public.machine_slots(machine_slot_id) ON DELETE SET NULL,
  processed_by UUID REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  requested_date DATE NOT NULL,
  requested_time TEXT NOT NULL,
  confirmed_date DATE,
  confirmed_start_time TIME,
  confirmed_end_time TIME,
  appointment_status TEXT NOT NULL DEFAULT 'Pending' CHECK (appointment_status IN (
    'Pending',
    'Under Review',
    'Confirmed',
    'Rejected'
  )),
  staff_remarks TEXT,
  recurrence_group_id UUID,
  is_recurring BOOLEAN NOT NULL DEFAULT FALSE,
  is_cancelled BOOLEAN NOT NULL DEFAULT FALSE,
  cancelled_at TIMESTAMPTZ,
  cancellation_reason TEXT,
  cancelled_by_role TEXT,
  reschedule_requested BOOLEAN NOT NULL DEFAULT FALSE,
  reschedule_notes TEXT,
  attendance_flag TEXT NOT NULL DEFAULT 'Scheduled' CHECK (attendance_flag IN ('Scheduled', 'Attended', 'No-Show')),
  status_history JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON public.appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_requested_date ON public.appointments(requested_date);
CREATE INDEX IF NOT EXISTS idx_appointments_confirmed_date ON public.appointments(confirmed_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON public.appointments(appointment_status);

DROP TRIGGER IF EXISTS trg_appointments_updated_at ON public.appointments;
CREATE TRIGGER trg_appointments_updated_at
BEFORE UPDATE ON public.appointments
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 8. DIALYSIS_SESSIONS
-- Purpose: Stores actual dialysis treatment records.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.dialysis_sessions (
  session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID UNIQUE REFERENCES public.appointments(appointment_id) ON DELETE SET NULL,
  patient_id UUID NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  machine_id UUID NOT NULL REFERENCES public.dialysis_machines(machine_id) ON DELETE RESTRICT,
  recorded_by UUID REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  treatment_date DATE NOT NULL,
  actual_start_time TIME NOT NULL,
  actual_end_time TIME NOT NULL,
  pre_dialysis_weight NUMERIC(5,2),
  post_dialysis_weight NUMERIC(5,2),
  blood_pressure_pre TEXT,
  blood_pressure_post TEXT,
  ultrafiltration_volume NUMERIC(6,2),
  session_status TEXT NOT NULL DEFAULT 'Completed' CHECK (session_status IN ('In Progress', 'Completed', 'Terminated Early')),
  is_released_to_patient BOOLEAN NOT NULL DEFAULT TRUE,
  treatment_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dialysis_sessions_patient_id ON public.dialysis_sessions(patient_id);
CREATE INDEX IF NOT EXISTS idx_dialysis_sessions_treatment_date ON public.dialysis_sessions(treatment_date);

DROP TRIGGER IF EXISTS trg_dialysis_sessions_updated_at ON public.dialysis_sessions;
CREATE TRIGGER trg_dialysis_sessions_updated_at
BEFORE UPDATE ON public.dialysis_sessions
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================================
-- 9. NOTIFICATIONS
-- Purpose: Stores notifications for patients, staff, and administrators.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.notifications (
  notification_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  notification_type TEXT NOT NULL DEFAULT 'System',
  related_appointment_id UUID REFERENCES public.appointments(appointment_id) ON DELETE SET NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON public.notifications(recipient_user_id, is_read, created_at DESC);

-- ============================================================================
-- 10. AUDIT_LOGS
-- Purpose: Records important system activities for accountability and monitoring.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.audit_logs (
  audit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  activity TEXT NOT NULL,
  affected_module TEXT NOT NULL,
  affected_record_id TEXT,
  details JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON public.audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_module ON public.audit_logs(affected_module);

-- ============================================================================
-- SECURITY HELPER FUNCTIONS (SECURITY DEFINER to prevent RLS recursion)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.is_active_staff()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.staff
    WHERE user_id = auth.uid()
      AND account_status = 'Active'
      AND role IN ('staff', 'super_admin')
  );
$$;

CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.staff
    WHERE user_id = auth.uid()
      AND account_status = 'Active'
      AND role = 'super_admin'
  );
$$;

CREATE OR REPLACE FUNCTION public.current_patient_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT patient_id FROM public.patients WHERE user_id = auth.uid() LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.current_staff_id()
RETURNS UUID
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT staff_id FROM public.staff WHERE user_id = auth.uid() AND account_status = 'Active' LIMIT 1;
$$;

-- ============================================================================
-- AUTO-PROVISION PATIENT RECORD ON AUTH USER SIGNUP (Unless created as Staff)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role TEXT;
  v_name TEXT;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data->>'intended_role', 'patient');
  v_name := COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data->>'full_name'), ''), split_part(NEW.email, '@', 1));

  IF v_role = 'patient' THEN
    INSERT INTO public.patients (user_id, email, full_name)
    VALUES (NEW.id, NEW.email, v_name)
    ON CONFLICT (user_id) DO NOTHING;

    INSERT INTO public.notifications (recipient_user_id, title, message, notification_type)
    VALUES (
      NEW.id,
      'Welcome to Reliance Dialysis Center Inc.',
      'Your patient account has been created. Please complete your Personal and Medical Profile to start booking hemodialysis appointments.',
      'Welcome'
    );

    INSERT INTO public.audit_logs (user_id, activity, affected_module, affected_record_id, details)
    VALUES (
      NEW.id,
      'Patient Account Registered',
      'Authentication',
      NEW.id::text,
      jsonb_build_object('email', NEW.email, 'full_name', v_name)
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- ============================================================================
-- PROTECT STAFF ROLE ESCALATION TRIGGER
-- ============================================================================
CREATE OR REPLACE FUNCTION public.protect_staff_role_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only super_admin or postgres/service_role (auth.uid() IS NULL) can change role or account_status
  IF auth.uid() IS NOT NULL AND NOT public.is_super_admin() THEN
    IF NEW.role IS DISTINCT FROM OLD.role OR NEW.account_status IS DISTINCT FROM OLD.account_status OR NEW.permissions IS DISTINCT FROM OLD.permissions THEN
      RAISE EXCEPTION 'Unauthorized: Only a Super Administrator can modify staff roles, status, or permissions.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_staff_role ON public.staff;
CREATE TRIGGER trg_protect_staff_role
BEFORE UPDATE ON public.staff
FOR EACH ROW EXECUTE FUNCTION public.protect_staff_role_changes();

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES ACROSS ALL 10 TABLES
-- ============================================================================
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_medical_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dialysis_machines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.machine_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dialysis_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 1. PATIENTS POLICIES
DROP POLICY IF EXISTS "patients_select" ON public.patients;
CREATE POLICY "patients_select" ON public.patients
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_active_staff());

DROP POLICY IF EXISTS "patients_insert" ON public.patients;
CREATE POLICY "patients_insert" ON public.patients
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() OR public.is_super_admin());

DROP POLICY IF EXISTS "patients_update" ON public.patients;
CREATE POLICY "patients_update" ON public.patients
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.is_active_staff())
  WITH CHECK (user_id = auth.uid() OR public.is_active_staff());

-- 2. STAFF POLICIES
DROP POLICY IF EXISTS "staff_select" ON public.staff;
CREATE POLICY "staff_select" ON public.staff
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_active_staff());

DROP POLICY IF EXISTS "staff_insert_super_admin" ON public.staff;
CREATE POLICY "staff_insert_super_admin" ON public.staff
  FOR INSERT TO authenticated
  WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "staff_update" ON public.staff;
CREATE POLICY "staff_update" ON public.staff
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.is_super_admin())
  WITH CHECK (user_id = auth.uid() OR public.is_super_admin());

-- 3. PATIENT_MEDICAL_PROFILES POLICIES
DROP POLICY IF EXISTS "medical_profiles_select" ON public.patient_medical_profiles;
CREATE POLICY "medical_profiles_select" ON public.patient_medical_profiles
  FOR SELECT TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff());

DROP POLICY IF EXISTS "medical_profiles_insert" ON public.patient_medical_profiles;
CREATE POLICY "medical_profiles_insert" ON public.patient_medical_profiles
  FOR INSERT TO authenticated
  WITH CHECK (patient_id = public.current_patient_id() OR public.is_active_staff());

DROP POLICY IF EXISTS "medical_profiles_update" ON public.patient_medical_profiles;
CREATE POLICY "medical_profiles_update" ON public.patient_medical_profiles
  FOR UPDATE TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff())
  WITH CHECK (patient_id = public.current_patient_id() OR public.is_active_staff());

-- 4. PATIENT_DOCUMENTS POLICIES
DROP POLICY IF EXISTS "documents_select" ON public.patient_documents;
CREATE POLICY "documents_select" ON public.patient_documents
  FOR SELECT TO authenticated
  USING (
    (patient_id = public.current_patient_id() AND is_released_to_patient = TRUE)
    OR public.is_active_staff()
  );

DROP POLICY IF EXISTS "documents_insert" ON public.patient_documents;
CREATE POLICY "documents_insert" ON public.patient_documents
  FOR INSERT TO authenticated
  WITH CHECK (patient_id = public.current_patient_id() OR public.is_active_staff());

DROP POLICY IF EXISTS "documents_update" ON public.patient_documents;
CREATE POLICY "documents_update" ON public.patient_documents
  FOR UPDATE TO authenticated
  USING (
    (patient_id = public.current_patient_id() AND verification_status IN ('Pending', 'Needs Correction', 'Rejected'))
    OR public.is_active_staff()
  )
  WITH CHECK (
    patient_id = public.current_patient_id() OR public.is_active_staff()
  );

DROP POLICY IF EXISTS "documents_delete" ON public.patient_documents;
CREATE POLICY "documents_delete" ON public.patient_documents
  FOR DELETE TO authenticated
  USING (
    (patient_id = public.current_patient_id() AND verification_status <> 'Verified')
    OR public.is_active_staff()
  );

-- 5. APPOINTMENTS POLICIES
DROP POLICY IF EXISTS "appointments_select" ON public.appointments;
CREATE POLICY "appointments_select" ON public.appointments
  FOR SELECT TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff());

DROP POLICY IF EXISTS "appointments_insert" ON public.appointments;
CREATE POLICY "appointments_insert" ON public.appointments
  FOR INSERT TO authenticated
  WITH CHECK (
    (patient_id = public.current_patient_id() AND machine_slot_id IS NULL AND appointment_status = 'Pending')
    OR public.is_active_staff()
  );

DROP POLICY IF EXISTS "appointments_update" ON public.appointments;
CREATE POLICY "appointments_update" ON public.appointments
  FOR UPDATE TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff())
  WITH CHECK (patient_id = public.current_patient_id() OR public.is_active_staff());

-- 6. DIALYSIS_MACHINES POLICIES (Readable by authenticated & public capacity function; writable by staff/admin)
DROP POLICY IF EXISTS "machines_select" ON public.dialysis_machines;
CREATE POLICY "machines_select" ON public.dialysis_machines
  FOR SELECT TO anon, authenticated
  USING (TRUE);

DROP POLICY IF EXISTS "machines_insert" ON public.dialysis_machines;
CREATE POLICY "machines_insert" ON public.dialysis_machines
  FOR INSERT TO authenticated
  WITH CHECK (public.is_super_admin());

DROP POLICY IF EXISTS "machines_update" ON public.dialysis_machines;
CREATE POLICY "machines_update" ON public.dialysis_machines
  FOR UPDATE TO authenticated
  USING (public.is_active_staff())
  WITH CHECK (public.is_active_staff());

-- 7. MACHINE_SLOTS POLICIES
DROP POLICY IF EXISTS "machine_slots_select" ON public.machine_slots;
CREATE POLICY "machine_slots_select" ON public.machine_slots
  FOR SELECT TO authenticated
  USING (TRUE);

DROP POLICY IF EXISTS "machine_slots_write_staff" ON public.machine_slots;
CREATE POLICY "machine_slots_write_staff" ON public.machine_slots
  FOR ALL TO authenticated
  USING (public.is_active_staff())
  WITH CHECK (public.is_active_staff());

-- 8. DIALYSIS_SESSIONS POLICIES (Patients view only released records; cannot edit)
DROP POLICY IF EXISTS "sessions_select" ON public.dialysis_sessions;
CREATE POLICY "sessions_select" ON public.dialysis_sessions
  FOR SELECT TO authenticated
  USING (
    (patient_id = public.current_patient_id() AND is_released_to_patient = TRUE)
    OR public.is_active_staff()
  );

DROP POLICY IF EXISTS "sessions_write_staff" ON public.dialysis_sessions;
CREATE POLICY "sessions_write_staff" ON public.dialysis_sessions
  FOR ALL TO authenticated
  USING (public.is_active_staff())
  WITH CHECK (public.is_active_staff());

-- 9. NOTIFICATIONS POLICIES
DROP POLICY IF EXISTS "notifications_select" ON public.notifications;
CREATE POLICY "notifications_select" ON public.notifications
  FOR SELECT TO authenticated
  USING (recipient_user_id = auth.uid() OR public.is_super_admin());

DROP POLICY IF EXISTS "notifications_update_own" ON public.notifications;
CREATE POLICY "notifications_update_own" ON public.notifications
  FOR UPDATE TO authenticated
  USING (recipient_user_id = auth.uid())
  WITH CHECK (recipient_user_id = auth.uid());

DROP POLICY IF EXISTS "notifications_insert" ON public.notifications;
CREATE POLICY "notifications_insert" ON public.notifications
  FOR INSERT TO authenticated
  WITH CHECK (recipient_user_id = auth.uid() OR public.is_active_staff());

-- 10. AUDIT_LOGS POLICIES (Append-only via RPC/staff; viewable by super_admin & staff for operational feed, NEVER editable/deletable)
DROP POLICY IF EXISTS "audit_logs_select" ON public.audit_logs;
CREATE POLICY "audit_logs_select" ON public.audit_logs
  FOR SELECT TO authenticated
  USING (public.is_super_admin() OR user_id = auth.uid());

-- ============================================================================
-- SECURE BACKEND RPC FUNCTIONS (Concurrency-safe scheduling, Audit, Config, Staff Provisioning)
-- ============================================================================

-- A. Log Audit Event securely (SECURITY DEFINER, append-only)
CREATE OR REPLACE FUNCTION public.log_audit_event(
  p_activity TEXT,
  p_module TEXT,
  p_record_id TEXT DEFAULT NULL,
  p_details JSONB DEFAULT '{}'::jsonb
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id UUID;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  INSERT INTO public.audit_logs (user_id, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), p_activity, p_module, p_record_id, COALESCE(p_details, '{}'::jsonb))
  RETURNING audit_id INTO v_id;

  RETURN v_id;
END;
$$;

-- B. Notify all active staff (e.g., when a patient submits an appointment or uploads corrected docs)
CREATE OR REPLACE FUNCTION public.notify_all_staff(
  p_title TEXT,
  p_message TEXT,
  p_type TEXT DEFAULT 'Appointment',
  p_appointment_id UUID DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  INSERT INTO public.notifications (recipient_user_id, title, message, notification_type, related_appointment_id)
  SELECT s.user_id, p_title, p_message, p_type, p_appointment_id
  FROM public.staff s
  WHERE s.account_status = 'Active';
END;
$$;

-- C. Get Clinic System & Schedule Configuration (stored on DIALYSIS_MACHINES schedule_config without extra table)
CREATE OR REPLACE FUNCTION public.get_clinic_schedule_config()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
DECLARE
  v_cfg JSONB;
BEGIN
  SELECT schedule_config INTO v_cfg
  FROM public.dialysis_machines
  WHERE schedule_config IS NOT NULL
  ORDER BY machine_code ASC
  LIMIT 1;

  RETURN COALESCE(v_cfg, jsonb_build_object(
    'operating_days', jsonb_build_array(1, 2, 3, 4, 5, 6),
    'operating_hours', jsonb_build_object('open', '08:00', 'close', '17:00'),
    'max_advance_days', 60,
    'allow_recurring_generation', true,
    'time_slots', jsonb_build_array(
      jsonb_build_object('id', 'Morning', 'label', 'Morning', 'display', '8:00 AM–11:00 AM', 'start_time', '08:00', 'end_time', '11:00'),
      jsonb_build_object('id', 'Midday', 'label', 'Midday', 'display', '11:00 AM–2:00 PM', 'start_time', '11:00', 'end_time', '14:00'),
      jsonb_build_object('id', 'Afternoon', 'label', 'Afternoon', 'display', '2:00 PM–5:00 PM', 'start_time', '14:00', 'end_time', '17:00')
    )
  ));
END;
$$;

-- D. Update Clinic System Configuration (Super Admin only)
CREATE OR REPLACE FUNCTION public.update_clinic_schedule_config(p_config JSONB)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_target UUID;
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Unauthorized: Only Super Administrator can update system configuration.';
  END IF;

  SELECT machine_id INTO v_target FROM public.dialysis_machines ORDER BY machine_code ASC LIMIT 1;
  IF v_target IS NULL THEN
    RAISE EXCEPTION 'No dialysis machines registered to attach schedule configuration.';
  END IF;

  UPDATE public.dialysis_machines
  SET schedule_config = p_config
  WHERE machine_id = v_target;

  INSERT INTO public.audit_logs (user_id, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), 'Updated Clinic Operating & Slot Configuration', 'System Configuration', v_target::text, p_config);

  RETURN p_config;
END;
$$;

-- E. Get Date & Time-Slot Capacity Summary (Safe for Patients without exposing other patients' PII)
CREATE OR REPLACE FUNCTION public.get_schedule_availability(
  p_start_date DATE,
  p_end_date DATE
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
DECLARE
  v_active_machines INT;
  v_slots JSONB;
  v_pending JSONB;
BEGIN
  SELECT COUNT(*) INTO v_active_machines
  FROM public.dialysis_machines
  WHERE machine_status IN ('Available', 'Occupied');

  SELECT COALESCE(jsonb_agg(row_to_json(t)), '[]'::jsonb) INTO v_slots
  FROM (
    SELECT schedule_date, start_time::text AS start_time, end_time::text AS end_time, COUNT(*)::int AS booked_count
    FROM public.machine_slots
    WHERE schedule_date BETWEEN p_start_date AND p_end_date
      AND slot_status IN ('Booked', 'Maintenance')
    GROUP BY schedule_date, start_time, end_time
  ) t;

  SELECT COALESCE(jsonb_agg(row_to_json(p)), '[]'::jsonb) INTO v_pending
  FROM (
    SELECT requested_date, requested_time, COUNT(*)::int AS request_count
    FROM public.appointments
    WHERE requested_date BETWEEN p_start_date AND p_end_date
      AND appointment_status IN ('Pending', 'Under Review')
      AND is_cancelled = FALSE
    GROUP BY requested_date, requested_time
  ) p;

  RETURN jsonb_build_object(
    'active_machine_capacity', v_active_machines,
    'booked_slots', v_slots,
    'pending_requests', v_pending
  );
END;
$$;

-- F. Atomic Concurrent Machine Assignment & Appointment Confirmation (Staff / Super Admin)
CREATE OR REPLACE FUNCTION public.assign_machine_and_confirm_appointment(
  p_appointment_id UUID,
  p_machine_id UUID,
  p_confirmed_date DATE,
  p_start_time TIME,
  p_end_time TIME,
  p_remarks TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_staff_id UUID;
  v_appt RECORD;
  v_machine RECORD;
  v_slot_id UUID;
  v_patient_user_id UUID;
  v_history JSONB;
BEGIN
  IF NOT public.is_active_staff() THEN
    RAISE EXCEPTION 'Unauthorized: Active staff privileges required.';
  END IF;

  v_staff_id := public.current_staff_id();

  -- Lock appointment row
  SELECT * INTO v_appt
  FROM public.appointments
  WHERE appointment_id = p_appointment_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Appointment not found.';
  END IF;

  IF v_appt.is_cancelled THEN
    RAISE EXCEPTION 'Cannot confirm a cancelled appointment.';
  END IF;

  -- Check machine operational status
  SELECT * INTO v_machine
  FROM public.dialysis_machines
  WHERE machine_id = p_machine_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Selected dialysis machine not found.';
  END IF;

  IF v_machine.machine_status IN ('Maintenance', 'Offline') THEN
    RAISE EXCEPTION 'Machine % is currently marked as % and cannot be assigned.', v_machine.machine_code, v_machine.machine_status;
  END IF;

  -- If appointment previously had a slot, free/remove old booked slot first
  IF v_appt.machine_slot_id IS NOT NULL THEN
    UPDATE public.appointments SET machine_slot_id = NULL WHERE appointment_id = p_appointment_id;
    DELETE FROM public.machine_slots WHERE machine_slot_id = v_appt.machine_slot_id;
  END IF;

  -- Insert new machine_slot (GiST exclusion constraint guarantees zero overlapping assignments)
  INSERT INTO public.machine_slots (machine_id, schedule_date, start_time, end_time, slot_status)
  VALUES (p_machine_id, p_confirmed_date, p_start_time, p_end_time, 'Booked')
  RETURNING machine_slot_id INTO v_slot_id;

  v_history := COALESCE(v_appt.status_history, '[]'::jsonb) || jsonb_build_array(
    jsonb_build_object(
      'status', 'Confirmed',
      'timestamp', NOW(),
      'by_staff_id', v_staff_id,
      'machine_code', v_machine.machine_code,
      'remarks', COALESCE(p_remarks, 'Appointment approved and dialysis machine assigned.')
    )
  );

  UPDATE public.appointments
  SET machine_slot_id = v_slot_id,
      processed_by = v_staff_id,
      confirmed_date = p_confirmed_date,
      confirmed_start_time = p_start_time,
      confirmed_end_time = p_end_time,
      appointment_status = 'Confirmed',
      reschedule_requested = FALSE,
      staff_remarks = COALESCE(p_remarks, staff_remarks),
      status_history = v_history
  WHERE appointment_id = p_appointment_id;

  SELECT user_id INTO v_patient_user_id FROM public.patients WHERE patient_id = v_appt.patient_id;

  IF v_patient_user_id IS NOT NULL THEN
    INSERT INTO public.notifications (recipient_user_id, title, message, notification_type, related_appointment_id)
    VALUES (
      v_patient_user_id,
      'Appointment Confirmed',
      format('Your hemodialysis appointment on %s (%s - %s) has been confirmed. Assigned Machine: %s.',
        to_char(p_confirmed_date, 'Mon DD, YYYY'),
        to_char(p_start_time, 'HH12:MI AM'),
        to_char(p_end_time, 'HH12:MI AM'),
        v_machine.machine_code
      ),
      'Confirmation',
      p_appointment_id
    );
  END IF;

  INSERT INTO public.audit_logs (user_id, activity, affected_module, affected_record_id, details)
  VALUES (
    auth.uid(),
    'Confirmed Appointment & Assigned Machine',
    'Appointments',
    p_appointment_id::text,
    jsonb_build_object(
      'machine_code', v_machine.machine_code,
      'confirmed_date', p_confirmed_date,
      'start_time', p_start_time,
      'end_time', p_end_time
    )
  );

  RETURN jsonb_build_object('success', true, 'machine_slot_id', v_slot_id, 'machine_code', v_machine.machine_code);
END;
$$;

-- G. Super Admin: Create Staff / Admin Account directly in Supabase Auth + Staff Table
CREATE OR REPLACE FUNCTION public.admin_create_staff_account(
  p_email TEXT,
  p_password TEXT,
  p_full_name TEXT,
  p_position TEXT,
  p_role TEXT,
  p_contact_number TEXT,
  p_permissions JSONB DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  v_new_user_id UUID := gen_random_uuid();
  v_staff_id UUID;
  v_clean_email TEXT := lower(trim(p_email));
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Unauthorized: Only Super Administrator can create staff accounts.';
  END IF;

  IF p_role NOT IN ('staff', 'super_admin') THEN
    RAISE EXCEPTION 'Invalid role. Must be staff or super_admin.';
  END IF;

  IF EXISTS (SELECT 1 FROM auth.users WHERE email = v_clean_email) THEN
    RAISE EXCEPTION 'An account with email % already exists.', v_clean_email;
  END IF;

  INSERT INTO auth.users (
    instance_id, id, aud, role, email, encrypted_password,
    email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
    created_at, updated_at, confirmation_token, email_change, email_change_token_new, recovery_token
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    v_new_user_id,
    'authenticated',
    'authenticated',
    v_clean_email,
    crypt(p_password, gen_salt('bf')),
    NOW(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    jsonb_build_object('full_name', p_full_name, 'intended_role', p_role),
    NOW(),
    NOW(),
    '', '', '', ''
  );

  INSERT INTO auth.identities (
    id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at
  ) VALUES (
    gen_random_uuid(),
    v_new_user_id,
    jsonb_build_object('sub', v_new_user_id::text, 'email', v_clean_email, 'email_verified', true),
    'email',
    v_new_user_id::text,
    NOW(),
    NOW(),
    NOW()
  );

  INSERT INTO public.staff (user_id, email, full_name, position, role, contact_number, account_status, permissions)
  VALUES (
    v_new_user_id,
    v_clean_email,
    p_full_name,
    p_position,
    p_role,
    p_contact_number,
    'Active',
    COALESCE(p_permissions, '{"verify_documents": true, "manage_appointments": true, "manage_machines": true, "record_sessions": true, "release_records": true}'::jsonb)
  )
  RETURNING staff_id INTO v_staff_id;

  INSERT INTO public.notifications (recipient_user_id, title, message, notification_type)
  VALUES (
    v_new_user_id,
    'Staff Account Activated',
    format('Welcome %s! Your %s account at Reliance Dialysis Center Inc. is active.', p_full_name, p_position),
    'System'
  );

  INSERT INTO public.audit_logs (user_id, activity, affected_module, affected_record_id, details)
  VALUES (
    auth.uid(),
    'Created Staff Account',
    'Staff Management',
    v_staff_id::text,
    jsonb_build_object('email', v_clean_email, 'full_name', p_full_name, 'role', p_role, 'position', p_position)
  );

  RETURN v_staff_id;
END;
$$;

-- H. Super Admin: Convert / Assign Role between User Accounts
CREATE OR REPLACE FUNCTION public.admin_assign_user_role(
  p_target_user_id UUID,
  p_new_role TEXT,
  p_position TEXT DEFAULT 'Dialysis Nurse'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name TEXT;
  v_email TEXT;
  v_contact TEXT;
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Unauthorized: Super Administrator privileges required.';
  END IF;

  IF p_target_user_id = auth.uid() AND p_new_role <> 'super_admin' THEN
    RAISE EXCEPTION 'Cannot demote your own active Super Administrator account.';
  END IF;

  SELECT email, COALESCE(raw_user_meta_data->>'full_name', split_part(email, '@', 1))
  INTO v_email, v_name
  FROM auth.users WHERE id = p_target_user_id;

  IF p_new_role IN ('staff', 'super_admin') THEN
    SELECT COALESCE(full_name, v_name), contact_number INTO v_name, v_contact
    FROM public.patients WHERE user_id = p_target_user_id;

    INSERT INTO public.staff (user_id, email, full_name, position, role, contact_number, account_status)
    VALUES (p_target_user_id, v_email, COALESCE(v_name, 'Staff Member'), p_position, p_new_role, v_contact, 'Active')
    ON CONFLICT (user_id) DO UPDATE
      SET role = EXCLUDED.role,
          position = EXCLUDED.position,
          account_status = 'Active';
  ELSIF p_new_role = 'patient' THEN
    UPDATE public.staff SET account_status = 'Inactive' WHERE user_id = p_target_user_id;
    INSERT INTO public.patients (user_id, email, full_name, account_status)
    VALUES (p_target_user_id, v_email, v_name, 'Active')
    ON CONFLICT (user_id) DO UPDATE SET account_status = 'Active';
  ELSE
    RAISE EXCEPTION 'Invalid role specified.';
  END IF;

  INSERT INTO public.audit_logs (user_id, activity, affected_module, affected_record_id, details)
  VALUES (
    auth.uid(),
    'Updated User Authorized Role',
    'User Management',
    p_target_user_id::text,
    jsonb_build_object('new_role', p_new_role, 'position', p_position)
  );

  RETURN jsonb_build_object('success', true, 'role', p_new_role);
END;
$$;

-- ============================================================================
-- SUPABASE STORAGE BUCKET: patient-documents (Private with strict RLS)
-- ============================================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'patient-documents',
  'patient-documents',
  FALSE,
  10485760, -- 10 MB limit enforced at storage level too
  ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO UPDATE
SET public = FALSE,
    file_size_limit = 10485760,
    allowed_mime_types = ARRAY['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];

-- Storage RLS Policies on storage.objects
DROP POLICY IF EXISTS "patient_docs_storage_select" ON storage.objects;
CREATE POLICY "patient_docs_storage_select" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR public.is_active_staff()
    )
  );

DROP POLICY IF EXISTS "patient_docs_storage_insert" ON storage.objects;
CREATE POLICY "patient_docs_storage_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'patient-documents'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR public.is_active_staff()
    )
  );

DROP POLICY IF EXISTS "patient_docs_storage_update" ON storage.objects;
CREATE POLICY "patient_docs_storage_update" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR public.is_active_staff()
    )
  );

DROP POLICY IF EXISTS "patient_docs_storage_delete" ON storage.objects;
CREATE POLICY "patient_docs_storage_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'patient-documents'
    AND (
      (storage.foldername(name))[1] = auth.uid()::text
      OR public.is_active_staff()
    )
  );
