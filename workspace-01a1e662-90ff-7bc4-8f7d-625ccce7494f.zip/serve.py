#!/usr/bin/env python3
"""
Threaded HTTP server for Reliance Dialysis Center Inc. web application.
Binds to 0.0.0.0:8080, serves concurrent ES module & asset requests without blocking,
ensures proper MIME types, and avoids browser caching issues during live previews.
"""

import os
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

ROOT_DIR = "/home/user"
PORT = 8080


class RelianceRequestHandler(SimpleHTTPRequestHandler):
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        ".js": "application/javascript; charset=utf-8",
        ".mjs": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".html": "text/html; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".svg": "image/svg+xml",
        ".webp": "image/webp",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT_DIR, **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True


if __name__ == "__main__":
    os.chdir(ROOT_DIR)
    server = ReusableThreadingHTTPServer(("0.0.0.0", PORT), RelianceRequestHandler)
    print(f"Serving Reliance Dialysis Center Inc. at http://0.0.0.0:{PORT}", flush=True)
    server.serve_forever()
