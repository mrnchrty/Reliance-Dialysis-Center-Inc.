# Architecture

## Frontend

- HTML5, CSS3 and Vanilla JavaScript ES Modules only.
- No React, Vue, Angular, Next.js, Bootstrap, Tailwind or frontend frameworks.
- Separate HTML, CSS and JS modules:
  - `public/` — landing page and authentication.
  - `patient/` — Patient Panel.
  - `staff/` — Staff Panel.
  - `super-admin/` — Super Administrator Panel.
  - `js/core/` — reusable Supabase client, Auth, DOM, UI, forms, calendar, charts, reports, documents, chatbot and layout helpers.
  - `js/vendor/supabase.esm.js` — local ESM bundle of `@supabase/supabase-js@2.58.0`; no UMD fallback and no CDN dependency.

## Backend

One centralized Supabase project provides:

- Supabase Auth (`auth.users`)
- PostgreSQL
- Private Storage buckets
- Row Level Security
- Database functions and atomic safeguards
- Edge Function `admin-accounts`

The browser uses only the publishable/anon key through same-origin `/api/config`. The service-role key is used only inside the Edge Function.

## Data model

Exactly ten custom application tables are used:

1. `PATIENTS`
2. `STAFF`
3. `PATIENT_MEDICAL_PROFILES`
4. `PATIENT_DOCUMENTS`
5. `APPOINTMENTS`
6. `DIALYSIS_MACHINES`
7. `MACHINE_SLOTS`
8. `DIALYSIS_SESSIONS`
9. `NOTIFICATIONS`
10. `AUDIT_LOGS`

No extra tables are created. System configuration snapshots are stored append-only in `AUDIT_LOGS.details`. Cancellation, rescheduling, correction, history, notification destinations, release controls and document decisions are modeled with structured fields/JSON inside the approved tables.

## Security model

- RLS is enabled on all ten tables.
- Roles come from protected `STAFF` and `PATIENTS` records.
- Patients can access only their own permitted records and released sessions.
- Staff access is limited to authorized operational records and permissions.
- Super administrators have system-wide access.
- Sensitive writes use `SECURITY DEFINER` RPCs and the secure Edge Function.
- Storage buckets are private; document access uses short-lived signed URLs.
- Audit logs are append-only for ordinary users.

## Appointment model

Main appointment statuses are only:

- `Pending`
- `Under Review`
- `Confirmed`
- `Rejected`

There is no `Cancelled`, `Completed` or `Rescheduled` main status. Cancellation and rescheduling are separate request/action histories. Completed dialysis is recorded in `DIALYSIS_SESSIONS`.

## Capacity model

- Operating days: Monday–Saturday; Sunday closed.
- Reference hours: 8:00 AM–5:00 PM.
- Configurable time slots default to Morning 8–11, Midday 11–2 and Afternoon 2–5.
- One patient per machine per time window.
- `MACHINE_SLOTS` are generated from actual `DIALYSIS_MACHINES` records and system configuration.
- Database functions lock/check capacity to prevent simultaneous overbooking.
