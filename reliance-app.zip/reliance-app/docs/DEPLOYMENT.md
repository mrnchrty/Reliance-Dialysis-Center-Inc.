# Deployment Guide

This project uses **one centralized Supabase project** for Auth, PostgreSQL, Storage, RLS and the `admin-accounts` Edge Function. The frontend is a static ES-module app deployed to **Vercel**. GitHub stores source code and connects to Vercel; every push to the configured deployment branch auto-redeploys the frontend.

> Database schema, functions, RLS and Storage policies are deployed separately to Supabase. A frontend GitHub push does **not** update Supabase schema.

## 1. Supabase database deployment

Apply SQL in order. The modular source files are in `sql/`; ordered migration files are in `sql/migrations/`.

Recommended order:

1. `sql/migrations/202611180001_schema_constraints.sql`
2. `sql/migrations/202611180002_rls_storage.sql`
3. `sql/migrations/202611180003_config_capacity.sql`
4. `sql/migrations/202611180004_appointment_core.sql`
5. `sql/migrations/202611180005_appointment_workflows.sql`
6. `sql/migrations/202611180006_records_sessions.sql`
7. `sql/migrations/202611180007_admin_analytics.sql`

You can run them from Supabase Dashboard → SQL Editor, or with the Supabase CLI against the selected project. Verify after applying:

- Exactly 10 public application tables exist.
- RLS is enabled on all 10 tables.
- Storage buckets `patient-documents` and `authorized-medical-files` are private.
- `get_system_config()` returns Monday–Saturday operating days, Sunday closed, and the three configured time slots.

## 2. Edge Function deployment

The secure account-administration function is `supabase/functions/admin-accounts/index.ts`.

Deploy with the Supabase CLI:

```bash
supabase functions deploy admin-accounts --no-verify-jwt
```

`--no-verify-jwt` is safe here because the function itself verifies the caller JWT and checks that the caller is an active `super_admin` in `STAFF` before using the service role.

Required Edge Function secrets (Supabase Dashboard → Edge Functions → `admin-accounts` → Secrets):

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` or `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

Never put the service-role key in Vercel frontend environment variables or in browser code.

## 3. GitHub setup

1. Create a GitHub repository.
2. Push this project to the repository.
3. Choose a deployment branch, commonly `main`.
4. Do not commit `.env`, `.arena/`, or any real credentials.

## 4. Vercel setup

1. Import the GitHub repository into Vercel.
2. Framework preset: **Other** / static. No build command is required.
3. Add environment variables:

   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`

4. Deploy. The `api/config.js` serverless endpoint returns only the publishable config to the browser.
5. Every push to the configured deployment branch auto-redeploys the frontend.

## 5. Supabase Auth URL configuration

After Vercel deployment, update Supabase Dashboard → Authentication → URL Configuration:

- Site URL: your Vercel production URL.
- Redirect URLs: include the production URL, preview URLs if needed, and local development URLs such as `http://localhost:5500/**`.

## 6. Local preview

```bash
cp .env.example .env
# Edit .env with your Supabase URL and publishable key.
npm start
```

Open `http://localhost:5500/public/index.html`.
