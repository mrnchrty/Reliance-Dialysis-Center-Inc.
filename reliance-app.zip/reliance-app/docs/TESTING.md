# Testing Guide

## Automated smoke checks

Run:

```bash
npm test
```

The smoke test verifies:

- Required frontend, SQL, Edge Function and deployment files exist.
- Frontend files contain no service-role key or hardcoded publishable key.
- `sql/01_schema.sql` defines exactly 10 custom tables.
- Seven ordered migration files exist.
- JavaScript files pass `node --check`.

## Manual verification checklist

### Public pages

- Landing page loads without network access to CDNs.
- Navigation links scroll to Home, About, Mission and Vision, Services, How to Book and Find Us.
- Booking buttons route to registration/login before booking.
- FAQ chatbot refuses medical advice and directs medical questions to providers or authorized center personnel.

### Authentication

- Patient registration creates a Supabase Auth user and a `PATIENTS` row.
- Login redirects by protected role: patient → `/patient/`, staff → `/staff/`, super administrator → `/super-admin/`.
- Forgot password sends a Supabase Auth reset link.
- Reset password updates the Auth password and returns to login.

### Patient Panel

- Sidebar shows only Dashboard, Book Appointment and My Records.
- Profile completion gates booking until personal and medical profiles are complete.
- Booking wizard follows: Complete Profile → Select Appointment Date → Select Preferred Time → Submit Required Documents → Review and Submit.
- Calendar disables past dates, Sundays and no-capacity dates.
- Document uploads validate type/size, verify private Storage upload and show filenames.
- Tracker shows status, confirmed details, machine, staff remarks and status history.
- Reschedule and cancellation requests preserve history and notify staff.
- My Records shows only Medical Information, Submitted Documents and Dialysis History; sessions are released-only and read-only.

### Staff Panel

- Sidebar shows only Dashboard, Appointment Management, Machine Management and Patient Record.
- Appointment detail supports confirm-and-assign, status changes, document correction, reschedule/cancellation processing, attendance, session recording and print/PDF.
- Document verification is separate from appointment status.
- Machine management prevents duplicate codes and unavailable assignments through database safeguards.
- Patient Record supports authorized medical file upload, document release and session release.

### Super Administrator Panel

- Sidebar shows only Dashboard, User Management, Staff Management and Roles, System Configuration, Machine and Schedule Configuration, Analytics and Reports and Audit Logs.
- User activation/deactivation and role assignment use protected records and the secure Edge Function.
- System configuration validates operating days, hours, non-overlapping slots and capacity defaults.
- Analytics defines the measurement period and slot definitions; utilization excludes unavailable/maintenance machines.
- Audit logs are filterable and exportable to CSV/print.

## Database verification queries

Run in Supabase SQL Editor:

```sql
select count(*) from information_schema.tables
where table_schema = 'public' and table_type = 'BASE TABLE';
-- Expected: 10

select tablename, rowsecurity
from pg_tables
where schemaname = 'public'
order by tablename;
-- Expected: rowsecurity = true for all 10 tables

select * from public.get_system_config();
-- Expected: operating_days [1,2,3,4,5,6], Sunday closed, three time slots.
```
