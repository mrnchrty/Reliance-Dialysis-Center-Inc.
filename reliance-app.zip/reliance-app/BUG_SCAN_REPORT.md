# Reliance Dialysis Center — Bug & Unresponsive UI Scan Report

**Date:** 2026-11-18 (Asia/Manila)  
**Scope:** Frontend logic (`js/`), CSS responsiveness, Supabase RLS/RPC, Edge Function, server config  
**Method:** Static analysis, `node --check`, RPC-vs-SQL cross-check, runtime formatter tests, manual code review  
**Status:** `npm test` passes (43 files, 27 secret-scan, 10 tables, 7 migrations, 22 syntax checks). Local preview on `:5500` healthy.

---

## 🔴 Critical — Fix Before Production

### 1. `formatTime()` shows wrong times (+8 hours) — `js/core/dom.js:123`

```js
const d = new Date(Date.UTC(2026, 0, 1, h, m));
return timeFormatter.format(d); // timeFormatter uses Asia/Manila
```

`Date.UTC(8:00)` = 08:00 UTC = **16:00 Manila**. Verified in Node:

| Input | Expected | Actual |
|-------|----------|--------|
| `08:00` | 8:00 AM | **4:00 PM** |
| `11:00` | 11:00 AM | **7:00 PM** |
| `14:00` | 2:00 PM | **10:00 PM** |
| `17:00` | 5:00 PM | **1:00 AM** |

**Impact:** Every confirmed appointment time, session time, and printed report is wrong. Patients will arrive at the wrong time.

**Fix:** Format manually without timezone conversion:
```js
const hour12 = h % 12 || 12;
const ampm = h < 12 ? 'AM' : 'PM';
return `${hour12}:${String(m).padStart(2,'0')} ${ampm}`;
```

**Files affected:** `js/patient/panel.js:71,108,332,623`, `js/staff/panel.js:191,485,627,778,797`, `js/core/reports.js:23`

---

### 2. Search inputs lose focus after 1 keystroke — Unresponsive UI

Every search field re-renders the **entire container** on each `input` event:

```js
$('#appt-search', container)?.addEventListener('input', (event) => {
  state.search = event.target.value;
  render(); // container.innerHTML = `...` — destroys the input element
});
```

**Affected:**
- `js/staff/panel.js:506` — `#appt-search`
- `js/staff/panel.js:686` — `#machine-search`
- `js/super-admin/panel.js:232` — `#user-search`
- `js/super-admin/panel.js:304` — `#staff-search`
- `js/super-admin/panel.js:740` — `#audit-search`

**Impact:** User types one character → DOM replaced → focus lost → cannot type second character. Keyboard and mobile users are blocked. This is the #1 unresponsive UI bug.

**Fix (pick one):**
- Debounce (200 ms) + restore focus & caret after render, **or**
- Render toolbar once, update only the table body on filter change.

`debounce()` already exists in `js/core/dom.js:50` but is never used for search.

---

## 🟠 High

### 3. `slotDisplay({}, ...)` with empty config — `js/patient/panel.js:70`, `js/super-admin/panel.js:674`

```js
slotDisplay({}, a.requested_time) // config is {}
```

`slotDisplay` looks up `config.time_slots` — with `{}` it falls back to raw ID (`"Morning"` instead of `"8:00 AM – 11:00 AM"`). Not a crash, but inconsistent display. Pass the real `config` from `loadPatientData()` / analytics bundle.

### 4. Duplicate `id="modal-title"` — `js/core/ui.js:107,134`

Every `openModal()` creates `<h2 id="modal-title">`. With 2+ dialogs open (e.g., detail modal → document preview), IDs duplicate and `aria-labelledby="modal-title"` points to the first match. Invalid HTML, broken screen-reader labeling.

**Fix:** Generate unique ID per dialog: `modal-title-${crypto.randomUUID().slice(0,8)}`.

### 5. `confirmDialog` fragile double-resolve — `js/core/ui.js:148`

Cancel resolves `false`, then `onClose` also resolves `false`. Confirm calls `api.close()` then resolves `true`, but `onClose` will also try to resolve `{confirmed:false}`. It works today only because the `close` event fires **asynchronously** after `onClick` resolves. If the browser ever fires it synchronously, Confirm returns `false`.

**Fix:** Guard with a `settled` flag.

---

## 🟡 Medium

### 6. Double render on back/forward — `js/core/layout.js:351-352`

```js
window.addEventListener('hashchange', renderCurrent);
window.addEventListener('popstate', renderCurrent);
```

Browser back fires `popstate`, and if the hash changed, also `hashchange` → two full section renders (double RPC load). Remove one listener or dedupe with a timestamp guard.

### 7. No auth-state listener in panels

`onAuthStateChange` is exported from `js/core/supabase.js:81` but never used. If the session expires mid-use, panels keep showing stale data until the next RPC fails with a confusing error. Add a `SIGNED_OUT` listener in `setupPanel()` that redirects to login.

### 8. Patient audit trigger missing INSERT — `sql/03_rls.sql:244`

```sql
CREATE TRIGGER trg_patients_audit AFTER UPDATE ... -- UPDATE only
CREATE TRIGGER trg_medical_profiles_audit AFTER INSERT OR UPDATE ... -- both
```

New patient registrations (via `handle_new_auth_user`) are not audited. Inconsistent with medical profiles.

### 9. Unbounded appointment load — `js/staff/panel.js:38`

```js
client.from('appointments').select('*').order('created_at', {ascending:false})
```

No `.limit()`. Audit logs are capped at 500, but staff loads **all** appointments into memory and renders them all. Will degrade as data grows. Add pagination or a date-range filter at the query level.

### 10. Inline `onclick` — `js/public/auth.js:216`

```html
<button onclick="location.reload()">Try again</button>
```

Only inline handler in the codebase. Breaks under a strict CSP and is inconsistent with the `addEventListener` pattern used everywhere else.

### 11. `dateISO()` timezone mismatch — `js/core/dom.js:86`

`dateISO()` reads local `getFullYear()/getMonth()/getDate()`, but `parseISODate()` creates UTC-noon dates. Works in Asia/Manila (UTC noon = 20:00 local, same day) but is fragile. Use UTC getters consistently: `getUTCFullYear()/getUTCMonth()/getUTCDate()`.

### 12. CORS wildcard on Edge Function — `supabase/functions/admin-accounts/index.ts:7`

```ts
'Access-Control-Allow-Origin': '*'
```

Mitigated by JWT verification, but should be restricted to the app origin(s). Low risk, but overly permissive for an admin endpoint.

---

## 🔵 Low / Code Quality

| # | Issue | Location |
|---|-------|----------|
| 13 | Unused imports (dead code) | `patient/panel.js`: `$`, `$$`, `loadRoleContext`, `rawHtml`; `staff/panel.js`: `$`, `$$`, `SELECT_PLACEHOLDER`, `documentMeta`, `rawHtml`; `super-admin/panel.js`: `$`, `$$`, `parseISODate`, `prettyDocumentType`, `rawHtml`, `downloadCSV`; `profile.js`: `$`, `textareaField`, `showLoading` |
| 14 | `setTimeout(...,150)` for deep-link modal | `patient/panel.js:559`, `staff/panel.js:557` — magic delay, no cleanup if user navigates away |
| 15 | No `loading="lazy"` on images | `public/index.html` hero/about images — minor LCP impact |

---

## 📱 Responsive UI Assessment

**Overall: Good.** Breakpoints are well-chosen and consistent.

| Breakpoint | What changes |
|------------|--------------|
| `≤1080px` | Panel grids 4→2, 3→2; detail layout stacks |
| `≤980px` | Landing nav becomes fixed dropdown; hero/about/find stack; booking steps 5→3 |
| `≤900px` | Shared grids 4→2, 3→2; stepper scrolls horizontally |
| `≤860px` | Auth split-screen stacks |
| `≤820px` | Sidebar becomes fixed overlay drawer; header hides title/user-name |
| `≤640px` | All grids 1-column; calendar shrinks; chatbot icon-only; toasts full-width |

**Issues found:**

1. **Hero overflow on 320px devices** — `landing.css:13` uses `minmax(320px, .92fr)` for the media column plus `1.25rem` padding each side = 360px minimum. On a 320px phone this overflows. Change to `minmax(0, .92fr)` or `minmax(min(320px, 100%), .92fr)`.

2. **Calendar day text on small screens** — `.calendar-day .day-capacity` at `0.62rem` in a ~40px-wide cell can wrap awkwardly. Consider hiding the capacity text below 480px and showing only the dot.

3. **Tables** — `.data-table { min-width: 680px }` inside `.table-wrap { overflow-x: auto }` is correct (horizontal scroll, no page overflow). Good pattern.

4. **Modal / chatbot / sidebar** — All use `min(96vw, …)` / `min(92vw, …)` — no overflow. Good.

5. **No horizontal page scroll** — `overflow-x` is only on `.table-wrap`, `.stepper`, and `.chart`. Body itself never scrolls sideways. Good.

---

## ⚡ Performance

| Issue | Impact |
|-------|--------|
| Full `innerHTML` re-render on every keystroke (search) | Layout thrash; with 500 audit rows this janks noticeably |
| No debounce on search | Unnecessary re-renders; `debounce()` exists but unused |
| Staff loads all appointments, no pagination | Grows linearly with data; will slow down over months |
| 500 audit rows rendered at once, no virtualization | Heavy DOM; consider pagination (50/page) |
| Charts are inline SVG, no external library | ✅ Good — zero chart.js dependency |
| Vendor bundle is local (127 KB), no CDN | ✅ Good — works offline / in sandboxed preview |
| No image lazy-loading | Minor; hero is above-the-fold so eager is correct, but about images could be lazy |

---

## 🔒 Security — What Passed

- ✅ All dynamic values escaped via `esc()` before `innerHTML` — no XSS found
- ✅ `rawHtml()` only wraps `badge()` output (already escaped)
- ✅ No hardcoded keys, no `service_role` in frontend (verified by smoke test)
- ✅ RLS enabled on all 10 tables; least-privilege grants; sensitive writes via SECURITY DEFINER RPCs
- ✅ Edge Function verifies caller JWT + `super_admin` role before using service-role key
- ✅ Private Storage buckets with signed URLs (60s expiry)
- ✅ `printReport` escapes title/subtitle; content built from escaped values

**Remaining:** CORS wildcard (#12), inline `onclick` (#10).

---

## ♿ Accessibility

- ✅ Native `<dialog>` with `showModal()` — proper focus trap
- ✅ Calendar days are `<button>` elements — keyboard navigable
- ✅ `aria-expanded`, `aria-current`, `aria-live` used correctly in most places
- ❌ Duplicate `modal-title` IDs break `aria-labelledby` (#4)
- ❌ Search focus loss blocks keyboard users entirely (#2)
- ✅ Color contrast: `--muted #617086` on white ≈ 4.6:1 — passes WCAG AA for normal text

---

## ✅ What Passed Clean

- All 32 JS RPC calls have matching SQL function definitions (0 missing)
- All RPC argument names (`p_*`) match SQL signatures (0 unknown)
- Edge Function actions match exactly: `list_users`, `create_staff`, `set_status`, `update_staff`, `set_role`
- `node --check` passes on all 22 JS files
- No `eval()`, no `document.write` (except print helper with escaped input), no hardcoded secrets
- `createClient` import flag from earlier scan is a false positive (minified vendor export `Ei as createClient`)
- RLS policies correctly scope patients to own records, staff to all, super-admin to audit logs
- `handle_new_auth_user` trigger correctly creates patient/staff rows on signup

---

## Recommended Fix Order

1. **#1 `formatTime`** — 5-minute fix, critical correctness
2. **#2 Search focus** — debounce + focus restore, or split render into toolbar/table
3. **#4 Modal title ID** — unique ID per dialog
4. **#3 `slotDisplay` config** — pass real config in 2 places
5. **#5 `confirmDialog` guard** — settled flag
6. **#6 Double render** — remove `popstate` or dedupe
7. **#8 Audit INSERT trigger** — one-line SQL migration
8. **#9 Pagination** — add `.limit()` / date filter to staff appointment query
9. **#11 `dateISO`** — switch to UTC getters
10. **#10 Inline onclick** — replace with `addEventListener`

*Report generated by static scan on 2026-11-18. No files were modified during this scan.*
