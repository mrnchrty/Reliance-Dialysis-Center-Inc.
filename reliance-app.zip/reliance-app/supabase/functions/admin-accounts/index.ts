// Secure account administration Edge Function for Reliance Dialysis Center Inc.
// The browser sends its own Supabase user JWT. This function verifies that JWT,
// checks the protected STAFF.role record with the service role, and only then
// calls Supabase Auth Admin APIs. No service-role key is ever sent to the browser.

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}

function required(value: unknown, label: string): string {
  const text = typeof value === 'string' ? value.trim() : '';
  if (!text) throw new Error(`${label} is required.`);
  return text;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? Deno.env.get('SUPABASE_PUBLISHABLE_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !anonKey || !serviceKey) {
    return json({ error: 'Supabase server environment is incomplete.' }, 500);
  }

  const authHeader = req.headers.get('Authorization') ?? '';
  if (!authHeader.startsWith('Bearer ')) return json({ error: 'Authentication required.' }, 401);

  const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
    headers: { apikey: anonKey, Authorization: authHeader },
  });
  if (!userResponse.ok) return json({ error: 'Invalid or expired session.' }, 401);
  const caller = await userResponse.json();

  const serviceHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };

  async function rest(method: string, path: string, body?: unknown, prefer?: string): Promise<any> {
    const response = await fetch(`${supabaseUrl}/rest/v1/${path}`, {
      method,
      headers: { ...serviceHeaders, ...(prefer ? { Prefer: prefer } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await response.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) {
      throw new Error(typeof data?.message === 'string' ? data.message : `Database request failed (${response.status}).`);
    }
    return data;
  }

  async function authAdmin(method: string, path: string, body?: unknown): Promise<any> {
    const response = await fetch(`${supabaseUrl}/auth/v1/admin/${path}`, {
      method,
      headers: serviceHeaders,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await response.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    if (!response.ok) {
      const message = data?.msg ?? data?.message ?? data?.error_description ?? `Auth admin request failed (${response.status}).`;
      throw new Error(typeof message === 'string' ? message : JSON.stringify(message));
    }
    return data;
  }

  async function audit(activity: string, module: string, recordId: string, details: unknown, severity = 'Info'): Promise<void> {
    await rest('POST', 'audit_logs', {
      user_id: caller.id,
      actor_email: caller.email ?? null,
      actor_name: caller.user_metadata?.full_name ?? caller.email?.split('@')[0] ?? 'Super Administrator',
      actor_role: 'super_admin',
      activity,
      affected_module: module,
      affected_record_id: recordId,
      details,
      severity,
    }, 'return=minimal');
  }

  async function setAuthBan(userId: string, status: string): Promise<void> {
    await authAdmin('PUT', `users/${userId}`, {
      ban_duration: status === 'Inactive' ? '876000h' : 'none',
    });
  }

  try {
    const staffRows = await rest('GET', `staff?user_id=eq.${caller.id}&select=staff_id,full_name,email,role,account_status,permissions`);
    const callerStaff = Array.isArray(staffRows) ? staffRows[0] : null;
    if (!callerStaff || callerStaff.role !== 'super_admin' || callerStaff.account_status !== 'Active') {
      return json({ error: 'Active Super Administrator authorization required.' }, 403);
    }

    const body = await req.json();
    const action = required(body.action, 'Action');

    if (action === 'list_users') {
      const page = Math.max(1, Number(body.page ?? 1));
      const perPage = Math.min(1000, Math.max(1, Number(body.per_page ?? 200)));
      const authData = await authAdmin('GET', `users?page=${page}&per_page=${perPage}`);
      const users: any[] = Array.isArray(authData) ? authData : (authData?.users ?? []);
      const [patients, staff] = await Promise.all([
        rest('GET', 'patients?select=patient_id,user_id,email,full_name,contact_number,account_status,created_at'),
        rest('GET', 'staff?select=staff_id,user_id,email,full_name,position,role,contact_number,account_status,permissions,created_at'),
      ]);
      const patientMap = new Map((patients ?? []).map((p: any) => [p.user_id, p]));
      const staffMap = new Map((staff ?? []).map((s: any) => [s.user_id, s]));
      const records = users.map((u: any) => {
        const s = staffMap.get(u.id);
        const p = patientMap.get(u.id);
        const activeStaff = s && s.account_status === 'Active';
        return {
          user_id: u.id,
          email: u.email ?? '',
          created_at: u.created_at ?? null,
          last_sign_in_at: u.last_sign_in_at ?? null,
          banned_until: u.banned_until ?? null,
          email_confirmed_at: u.email_confirmed_at ?? null,
          role: activeStaff ? s.role : 'patient',
          account_status: activeStaff ? s.account_status : (p?.account_status ?? 'Active'),
          full_name: activeStaff ? s.full_name : (p?.full_name ?? u.user_metadata?.full_name ?? u.email?.split('@')[0] ?? 'User'),
          patient_id: p?.patient_id ?? null,
          staff_id: s?.staff_id ?? null,
          position: s?.position ?? null,
          contact_number: activeStaff ? s.contact_number : (p?.contact_number ?? null),
          permissions: s?.permissions ?? null,
          registration_date: p?.created_at ?? s?.created_at ?? u.created_at ?? null,
        };
      });
      return json({ success: true, users: records, page, per_page: perPage });
    }

    if (action === 'create_staff') {
      const email = required(body.email, 'Email').toLowerCase();
      const password = required(body.password, 'Temporary password');
      const fullName = required(body.full_name, 'Full name');
      const position = required(body.position, 'Position');
      const role = required(body.role, 'Role');
      const contactNumber = typeof body.contact_number === 'string' ? body.contact_number.trim() : '';
      const permissions = body.permissions && typeof body.permissions === 'object' ? body.permissions : {
        verify_documents: true, manage_appointments: true, manage_machines: true,
        record_sessions: true, release_records: true,
      };
      if (password.length < 8) throw new Error('Temporary password must be at least 8 characters.');
      if (!['staff', 'super_admin'].includes(role)) throw new Error('Role must be staff or super_admin.');

      const created = await authAdmin('POST', 'users', {
        email,
        password,
        email_confirm: true,
        user_metadata: { full_name: fullName, intended_role: role, position, contact_number: contactNumber, permissions },
      });
      const userId = created?.id ?? created?.user?.id;
      if (!userId) throw new Error('Supabase Auth did not return the new user identifier.');

      const staffRowsForUser = await rest('GET', `staff?user_id=eq.${userId}&select=staff_id`);
      const staffId = staffRowsForUser?.[0]?.staff_id;
      const staffPayload = {
        user_id: userId, email, full_name: fullName, position, role,
        contact_number: contactNumber || null, account_status: 'Active', permissions,
      };
      if (staffId) {
        await rest('PATCH', `staff?staff_id=eq.${staffId}`, staffPayload, 'return=minimal');
      } else {
        await rest('POST', 'staff', staffPayload, 'return=representation,resolution=merge-duplicates');
      }
      await audit('Created Staff Account', 'Staff Management', userId, {
        email, full_name: fullName, role, position,
      }, 'Warning');
      return json({ success: true, user_id: userId, message: 'Staff account created. Share the temporary password securely and ask the staff member to change it.' }, 201);
    }

    if (action === 'set_status') {
      const userId = required(body.user_id, 'User ID');
      const status = required(body.status, 'Status');
      if (!['Active', 'Inactive'].includes(status)) throw new Error('Status must be Active or Inactive.');
      if (userId === caller.id && status === 'Inactive') throw new Error('You cannot deactivate your own active Super Administrator account.');
      await setAuthBan(userId, status);
      const now = new Date().toISOString();
      const statusPayload = {
        account_status: status,
        deactivated_at: status === 'Inactive' ? now : null,
        deactivated_by: status === 'Inactive' ? caller.id : null,
      };
      await rest('PATCH', `patients?user_id=eq.${userId}`, statusPayload, 'return=minimal');
      await rest('PATCH', `staff?user_id=eq.${userId}`, statusPayload, 'return=minimal');
      await audit(status === 'Active' ? 'Account Activated' : 'Account Deactivated', 'User Management', userId, { status }, 'Warning');
      return json({ success: true, user_id: userId, account_status: status });
    }

    if (action === 'update_staff') {
      const staffId = required(body.staff_id, 'Staff ID');
      const rows = await rest('GET', `staff?staff_id=eq.${staffId}&select=staff_id,user_id,role,account_status`);
      const target = rows?.[0];
      if (!target) throw new Error('Staff record not found.');
      const role = required(body.role, 'Role');
      const status = required(body.account_status, 'Account status');
      if (!['staff', 'super_admin'].includes(role)) throw new Error('Invalid staff role.');
      if (!['Active', 'Inactive'].includes(status)) throw new Error('Invalid account status.');
      if (target.user_id === caller.id && (role !== 'super_admin' || status !== 'Active')) {
        throw new Error('You cannot change your own role, status, or privileges.');
      }
      const payload = {
        full_name: required(body.full_name, 'Full name'),
        position: required(body.position, 'Position'),
        contact_number: typeof body.contact_number === 'string' ? body.contact_number.trim() : null,
        role,
        account_status: status,
        permissions: body.permissions && typeof body.permissions === 'object' ? body.permissions : {},
      };
      await rest('PATCH', `staff?staff_id=eq.${staffId}`, payload, 'return=minimal');
      if (status !== target.account_status) await setAuthBan(target.user_id, status);
      await audit('Updated Staff Information & Permissions', 'Staff Management', staffId, {
        role, account_status: status, position: payload.position,
      }, 'Warning');
      return json({ success: true, staff_id: staffId });
    }

    if (action === 'set_role') {
      const userId = required(body.user_id, 'User ID');
      const role = required(body.role, 'Role');
      const position = typeof body.position === 'string' && body.position.trim() ? body.position.trim() : 'Dialysis Nurse';
      if (!['patient', 'staff', 'super_admin'].includes(role)) throw new Error('Invalid authorized role.');
      if (userId === caller.id && role !== 'super_admin') throw new Error('You cannot demote your own active Super Administrator account.');

      const authData = await authAdmin('GET', `users/${userId}`);
      const email = authData?.email ?? '';
      const fullName = authData?.user_metadata?.full_name ?? email.split('@')[0] ?? 'User';
      const [patientRows, staffRowsForUser] = await Promise.all([
        rest('GET', `patients?user_id=eq.${userId}&select=patient_id,full_name,contact_number`),
        rest('GET', `staff?user_id=eq.${userId}&select=staff_id`),
      ]);
      const patient = patientRows?.[0];
      const existingStaff = staffRowsForUser?.[0];

      if (role === 'staff' || role === 'super_admin') {
        const payload = {
          user_id: userId,
          email,
          full_name: patient?.full_name ?? fullName,
          position,
          role,
          contact_number: patient?.contact_number ?? null,
          account_status: 'Active',
          permissions: body.permissions && typeof body.permissions === 'object' ? body.permissions : {
            verify_documents: true, manage_appointments: true, manage_machines: true,
            record_sessions: true, release_records: true,
          },
        };
        if (existingStaff?.staff_id) {
          await rest('PATCH', `staff?staff_id=eq.${existingStaff.staff_id}`, payload, 'return=minimal');
        } else {
          await rest('POST', 'staff', payload, 'return=representation,resolution=merge-duplicates');
        }
        await rest('PATCH', `patients?user_id=eq.${userId}`, { account_status: 'Inactive' }, 'return=minimal');
      } else {
        await rest('PATCH', `staff?user_id=eq.${userId}`, { account_status: 'Inactive' }, 'return=minimal');
        const patientPayload = { user_id: userId, email, full_name: fullName, account_status: 'Active' };
        if (patient?.patient_id) {
          await rest('PATCH', `patients?patient_id=eq.${patient.patient_id}`, patientPayload, 'return=minimal');
        } else {
          await rest('POST', 'patients', patientPayload, 'return=representation,resolution=merge-duplicates');
        }
      }
      await audit('Updated User Authorized Role', 'User Management', userId, { role, position, email }, 'Warning');
      return json({ success: true, user_id: userId, role });
    }

    return json({ error: 'Unknown account administration action.' }, 400);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unexpected account administration error.';
    return json({ error: message }, 400);
  }
});
