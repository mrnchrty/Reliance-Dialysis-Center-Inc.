# Reliance Dialysis Center Inc.

A production-oriented, Supabase-backed web application for **Reliance Dialysis Center Inc., Mabini, Batangas**. It includes a public landing page, Patient Panel, Staff Panel and Super Administrator Panel using one centralized Supabase project for Auth, PostgreSQL, Storage, RLS and Edge Functions.

## What is included

- Public landing page with Home, About, Mission and Vision, Services, How to Book, Log In and Book Your Appointment Now.
- Patient Panel with exactly: Dashboard, Book Appointment, My Records.
- Staff Panel with exactly: Dashboard, Appointment Management, Machine Management, Patient Record.
- Super Administrator Panel with exactly: Dashboard, User Management, Staff Management and Roles, System Configuration, Machine and Schedule Configuration, Analytics and Reports, Audit Logs.
- Supabase Auth registration, login, logout, forgot/reset password, session persistence and role redirect.
- Five-step patient booking sequence: Complete Profile → Select Appointment Date → Select Preferred Time → Submit Required Documents → Review and Submit.
- Private document uploads, staff verification, appointment tracking, rescheduling/cancellation requests, recurring suggestions, dialysis session recording, record release, notifications with deep links, analytics, reports and audit logs.
- Exactly ten custom application tables; no extra tables.

## Tech stack

- HTML5, CSS3, Vanilla JavaScript ES Modules only.
- No React, Vue, Angular, Next.js, Bootstrap, Tailwind or frontend frameworks.
- Supabase Auth, PostgreSQL, Storage, RLS, database functions and Edge Functions.
- Local ESM Supabase client bundle in `js/vendor/supabase.esm.js`.
- Vercel serverless `/api/config` endpoint for runtime publishable config.

## Project structure

```text
public/                 Landing page and authentication pages
patient/                Patient Panel shell
staff/                  Staff Panel shell
super-admin/            Super Administrator Panel shell
css/                    Shared base, landing, panel and auth styles
js/core/                Reusable Supabase/Auth/DOM/UI/forms/calendar/charts/reports modules
js/public/              Landing and auth page modules
js/patient/             Patient Panel module
js/staff/               Staff Panel module
js/super-admin/         Super Administrator Panel module
js/vendor/              Local ESM Supabase client bundle and license
api/config.js           Vercel runtime config endpoint
server.mjs              Local preview server with /api/config
sql/                    Modular schema, constraints, RLS, functions, Storage and seed guidance
sql/migrations/         Ordered deployment migrations
supabase/functions/     admin-accounts Edge Function
docs/                   Deployment, architecture and testing guides
tests/smoke.mjs         Automated smoke checks
```

## Local setup

Requirements: Node.js 18+.

```bash
cp .env.example .env
# Edit .env and set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY.
npm start
```

Open:

```text
http://localhost:5500/public/index.html
```

Run smoke checks:

```bash
npm test
```

## Supabase setup

1. Create/select the centralized Supabase project.
2. Apply SQL migrations in `sql/migrations/` in order.
3. Confirm the two private Storage buckets exist:
   - `patient-documents`
   - `authorized-medical-files`
4. Deploy the Edge Function:

   ```bash
   supabase functions deploy admin-accounts --no-verify-jwt
   ```

5. Set Edge Function secrets in Supabase Dashboard:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY` or `SUPABASE_PUBLISHABLE_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`

See `docs/DEPLOYMENT.md` for the full deployment guide.

## GitHub and Vercel deployment

1. Push this repository to GitHub.
2. Import the repository into Vercel.
3. Add Vercel environment variables:
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
4. Deploy. Every push to the configured deployment branch auto-redeploys the frontend.
5. Update Supabase Auth Site URL and Redirect URLs to the Vercel production domain.

> Frontend GitHub pushes do not update Supabase schema. Database changes must be applied separately to Supabase.

## Security notes

- The browser never receives the service-role key.
- Roles come from protected `STAFF` and `PATIENTS` records.
- RLS is enabled on all ten application tables.
- Storage buckets are private; documents use signed URLs.
- Audit logs are append-only for ordinary users.
- Never commit `.env`, `.arena/` or real credentials.

## Content notes

- Mission and vision wording is subject to final center confirmation.
- Reference operating hours are Monday–Saturday, 8:00 AM–5:00 PM; Sunday closed.
- Proposed time windows are Morning 8:00 AM–11:00 AM, Midday 11:00 AM–2:00 PM and Afternoon 2:00 PM–5:00 PM; duration and turnaround are subject to final center confirmation.
- Services are limited to Hemodialysis Care and Patient Support.

## Documentation

- `docs/DEPLOYMENT.md` — Supabase, GitHub and Vercel deployment.
- `docs/ARCHITECTURE.md` — frontend, backend, data and security architecture.
- `docs/TESTING.md` — automated and manual verification checklists.
