-- Reliance Dialysis Center Inc. — civil status on the patient personal profile
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS civil_status text;

ALTER TABLE public.patients DROP CONSTRAINT IF EXISTS patients_civil_status_check;
ALTER TABLE public.patients ADD CONSTRAINT patients_civil_status_check
  CHECK (civil_status IS NULL OR civil_status IN ('Single', 'Married', 'Widowed', 'Separated', 'Divorced'));
