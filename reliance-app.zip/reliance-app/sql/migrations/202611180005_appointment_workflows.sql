-- Reliance appointment workflows (continued). Requires 202611180004_appointment_core.sql.
CREATE OR REPLACE FUNCTION public.request_document_correction(
  p_appointment_id uuid, p_document_type text, p_notes text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_doc public.patient_documents%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('verify_documents') THEN RAISE EXCEPTION 'Unauthorized: document verification permission required.'; END IF;
  IF NULLIF(trim(COALESCE(p_notes,'')),'') IS NULL THEN RAISE EXCEPTION 'Provide a correction notice for the patient.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  SELECT * INTO v_doc FROM public.patient_documents
  WHERE patient_id = v_appt.patient_id AND document_type = p_document_type AND is_current = true
  ORDER BY uploaded_at DESC LIMIT 1 FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Current % document was not found.', p_document_type; END IF;

  UPDATE public.patient_documents SET
    verification_status = 'Needs Correction', remarks = p_notes, reviewed_by = public.current_staff_id(),
    reviewed_at = now(), correction_requested = true, correction_notes = p_notes,
    correction_requested_by = public.current_staff_id(), correction_requested_at = now(), is_outdated = true
  WHERE document_id = v_doc.document_id;

  UPDATE public.appointments SET
    appointment_status = 'Under Review',
    processed_by = public.current_staff_id(),
    correction_request = jsonb_build_object('document_type',p_document_type,'document_id',v_doc.document_id,
      'notes',p_notes,'requested_at',now(),'requested_by',public.current_staff_id(),'status','Open'),
    status_history = public.append_status_history(status_history,'Under Review','Document Correction Requested',p_notes,
      jsonb_build_object('document_id',v_doc.document_id,'document_type',p_document_type))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',v_doc.document_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Document Correction Required',
    format('Please submit an updated %s. Staff notice: %s', p_document_type, p_notes),
    'Document Correction Required', p_appointment_id, v_doc.document_id, NULL, v_destination, 'Open document');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Document Correction Requested', 'Documents', v_doc.document_id::text,
    jsonb_build_object('appointment_id',p_appointment_id,'document_type',p_document_type,'notes',p_notes));
  RETURN jsonb_build_object('success',true,'appointment_status','Under Review','document_id',v_doc.document_id);
END $$;

CREATE OR REPLACE FUNCTION public.request_reschedule(
  p_appointment_id uuid, p_new_date date, p_new_time text, p_reason text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_cfg jsonb := public.get_system_config(); v_slot jsonb;
        v_patient_user uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the staff rescheduling workflow for operational changes.'; END IF;
  SELECT * INTO v_appt FROM public.appointments
  WHERE appointment_id = p_appointment_id AND patient_id = public.current_patient_id() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled OR v_appt.appointment_status = 'Rejected' THEN
    RAISE EXCEPTION 'This appointment cannot be rescheduled.';
  END IF;
  IF v_appt.reschedule_requested THEN RAISE EXCEPTION 'A rescheduling request is already awaiting staff review.'; END IF;
  PERFORM public.assert_booking_date(p_new_date, p_new_time);
  v_slot := public.config_slot(p_new_time);
  PERFORM public.lock_schedule_slot(p_new_date, p_new_time);
  PERFORM public.internal_ensure_capacity(p_new_date, p_new_date);
  IF public.slot_remaining_capacity(p_new_date, p_new_time) <= 0 THEN
    RAISE EXCEPTION 'The requested new date and time have no remaining capacity.';
  END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    reschedule_request = jsonb_build_object(
      'status','Pending','requested_at',now(),'requested_by',auth.uid(),'reason',p_reason,
      'original_date',v_appt.requested_date,'original_time',v_appt.requested_time,
      'original_confirmed_date',v_appt.confirmed_date,'original_machine_slot_id',v_appt.machine_slot_id,
      'new_date',p_new_date,'new_time',p_new_time,'new_start_time',(v_slot ->> 'start_time')::time,
      'new_end_time',(v_slot ->> 'end_time')::time),
    reschedule_requested = true, reschedule_notes = p_reason,
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Requested',
      COALESCE(p_reason,'Patient requested a new appointment date and time.'),
      jsonb_build_object('new_date',p_new_date,'new_time',p_new_time))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = v_appt.patient_id;
  PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Request Sent',
    format('Your request to move appointment %s to %s (%s) is awaiting staff review.',
      left(p_appointment_id::text,8), to_char(p_new_date,'Mon DD, YYYY'), v_slot ->> 'display'),
    'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  PERFORM public.notify_all_staff('Rescheduling Request',
    format('Rescheduling request for appointment %s: %s (%s).', left(p_appointment_id::text,8), p_new_date, p_new_time),
    'Rescheduling Request', p_appointment_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id,'action','reschedule'));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Rescheduling Requested', 'Appointments', p_appointment_id::text,
    jsonb_build_object('new_date',p_new_date,'new_time',p_new_time,'reason',p_reason));
  RETURN jsonb_build_object('success',true,'status','Pending','new_date',p_new_date,'new_time',p_new_time);
END $$;

CREATE OR REPLACE FUNCTION public.process_reschedule_request(
  p_appointment_id uuid, p_action text, p_machine_id uuid DEFAULT NULL,
  p_remarks text DEFAULT NULL, p_new_date date DEFAULT NULL, p_new_time text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_req jsonb; v_date date; v_time text; v_slot jsonb;
  v_capacity int; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_action NOT IN ('approve','deny') THEN RAISE EXCEPTION 'Action must be approve or deny.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF NOT v_appt.reschedule_requested OR COALESCE(v_appt.reschedule_request ->> 'status','') <> 'Pending' THEN
    RAISE EXCEPTION 'No pending rescheduling request was found.';
  END IF;
  v_req := v_appt.reschedule_request;
  v_date := COALESCE(p_new_date, (v_req ->> 'new_date')::date);
  v_time := COALESCE(p_new_time, v_req ->> 'new_time');

  IF p_action = 'deny' THEN
    UPDATE public.appointments SET
      reschedule_request = v_req || jsonb_build_object('status','Denied','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      reschedule_requested = false,
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Denied', p_remarks, v_req)
    WHERE appointment_id = p_appointment_id;
    v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
    PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Update',
      format('Your rescheduling request for appointment %s was not approved.%s', left(p_appointment_id::text,8),
        CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
      'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
    INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
    VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
      'Rescheduling Denied', 'Appointments', p_appointment_id::text, jsonb_build_object('remarks',p_remarks));
    RETURN jsonb_build_object('success',true,'action','deny','appointment_status',v_appt.appointment_status);
  END IF;

  PERFORM public.assert_booking_date(v_date, v_time);
  v_slot := public.config_slot(v_time);
  PERFORM public.lock_schedule_slot(v_date, v_time);
  PERFORM public.internal_ensure_capacity(v_date, v_date);
  v_capacity := public.slot_remaining_capacity(v_date, v_time);
  IF v_appt.machine_slot_id IS NULL AND v_appt.requested_date = v_date AND v_appt.requested_time = v_time THEN
    v_capacity := v_capacity + 1;
  END IF;
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'The new date and time have no remaining capacity.'; END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    requested_date = v_date, requested_time = v_time,
    requested_start_time = (v_slot ->> 'start_time')::time, requested_end_time = (v_slot ->> 'end_time')::time,
    request_type = 'Reschedule',
    reschedule_request = v_req || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id(),'approved_new_date',v_date,'approved_new_time',v_time,'remarks',p_remarks),
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Approved', p_remarks,
      jsonb_build_object('new_date',v_date,'new_time',v_time))
  WHERE appointment_id = p_appointment_id;

  IF v_appt.appointment_status = 'Confirmed' THEN
    IF p_machine_id IS NULL THEN RAISE EXCEPTION 'Select an available machine before approving a reschedule for a confirmed appointment.'; END IF;
    PERFORM public.assign_machine_and_confirm_appointment(
      p_appointment_id, p_machine_id, v_date, (v_slot ->> 'start_time')::time,
      (v_slot ->> 'end_time')::time, COALESCE(p_remarks,'Rescheduling approved by authorized staff.'), v_time);
  ELSE
    UPDATE public.appointments SET
      appointment_status = 'Under Review', processed_by = public.current_staff_id(),
      reschedule_requested = false,
      staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks)
    WHERE appointment_id = p_appointment_id;
  END IF;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Update',
    format('Your rescheduling request for appointment %s was approved for %s (%s).',
      left(p_appointment_id::text,8), to_char(v_date,'Mon DD, YYYY'), v_slot ->> 'display'),
    'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Rescheduling Approved', 'Appointments', p_appointment_id::text,
    jsonb_build_object('new_date',v_date,'new_time',v_time,'machine_id',p_machine_id,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'action','approve','new_date',v_date,'new_time',v_time);
END $$;

CREATE OR REPLACE FUNCTION public.request_cancellation(
  p_appointment_id uuid, p_reason text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the staff cancellation workflow for operational changes.'; END IF;
  SELECT * INTO v_appt FROM public.appointments
  WHERE appointment_id = p_appointment_id AND patient_id = public.current_patient_id() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled OR COALESCE(v_appt.cancellation_request ->> 'status','') = 'Pending' THEN
    RAISE EXCEPTION 'This appointment is already cancelled or has a pending cancellation request.';
  END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    cancellation_request = jsonb_build_object('status','Pending','reason',p_reason,'requested_at',now(),
      'requested_by',auth.uid(),'original_status',v_appt.appointment_status,'original_snapshot',public.appointment_snapshot(p_appointment_id)),
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Requested',
      COALESCE(p_reason,'Patient requested cancellation.'), '{}'::jsonb)
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Cancellation Request Sent',
    format('Your cancellation request for appointment %s is awaiting staff processing.', left(p_appointment_id::text,8)),
    'Cancellation Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  PERFORM public.notify_all_staff('Cancellation Request',
    format('Cancellation request for appointment %s. Reason: %s', left(p_appointment_id::text,8), COALESCE(p_reason,'Not specified')),
    'Cancellation Request', p_appointment_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id,'action','cancellation'));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Cancellation Requested', 'Appointments', p_appointment_id::text, jsonb_build_object('reason',p_reason));
  RETURN jsonb_build_object('success',true,'status','Pending');
END $$;

CREATE OR REPLACE FUNCTION public.process_cancellation_request(
  p_appointment_id uuid, p_action text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_req jsonb; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_action NOT IN ('approve','deny') THEN RAISE EXCEPTION 'Action must be approve or deny.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF COALESCE(v_appt.cancellation_request ->> 'status','') <> 'Pending' THEN
    RAISE EXCEPTION 'No pending cancellation request was found.';
  END IF;
  v_req := v_appt.cancellation_request;

  IF p_action = 'deny' THEN
    UPDATE public.appointments SET
      cancellation_request = v_req || jsonb_build_object('status','Denied','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Denied', p_remarks, v_req)
    WHERE appointment_id = p_appointment_id;
  ELSE
    PERFORM public.release_machine_slot(p_appointment_id);
    UPDATE public.appointments SET
      is_cancelled = true, cancelled_at = now(),
      cancellation_reason = COALESCE(v_req ->> 'reason', p_remarks),
      cancelled_by_role = COALESCE((SELECT role FROM public.staff WHERE staff_id = public.current_staff_id()), 'staff'),
      cancellation_request = v_req || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Processed',
        COALESCE(p_remarks,'Cancellation processed and capacity released.'), v_req)
    WHERE appointment_id = p_appointment_id;
  END IF;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Cancellation Update',
    format('Your cancellation request for appointment %s was %s.%s', left(p_appointment_id::text,8),
      CASE WHEN p_action='approve' THEN 'processed' ELSE 'not approved' END,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    'Cancellation Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_action='approve' THEN 'Cancellation Processed' ELSE 'Cancellation Denied' END,
    'Appointments', p_appointment_id::text, jsonb_build_object('action',p_action,'remarks',p_remarks,'released_capacity',p_action='approve'));
  RETURN jsonb_build_object('success',true,'action',p_action,'is_cancelled',p_action='approve');
END $$;

CREATE OR REPLACE FUNCTION public.record_appointment_attendance(
  p_appointment_id uuid, p_attendance_flag text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_old text; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('record_sessions') THEN RAISE EXCEPTION 'Unauthorized: attendance-recording permission required.'; END IF;
  IF p_attendance_flag NOT IN ('Scheduled','Attended','No-Show') THEN RAISE EXCEPTION 'Invalid attendance outcome.'; END IF;
  SELECT attendance_flag INTO v_old FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  UPDATE public.appointments SET
    attendance_flag = p_attendance_flag, attendance_recorded_by = public.current_staff_id(),
    attendance_recorded_at = now(), staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks)
  WHERE appointment_id = p_appointment_id;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Attendance Recorded', 'Appointments', p_appointment_id::text,
    jsonb_build_object('from',v_old,'to',p_attendance_flag,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'attendance_flag',p_attendance_flag);
END $$;

CREATE OR REPLACE FUNCTION public.generate_recurring_appointments(
  p_patient_id uuid, p_recurring_days text[], p_preferred_time text,
  p_start_date date, p_end_date date
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_cfg jsonb := public.get_system_config(); v_days int[]; v_day_nums int[];
  v_day date; v_slot jsonb; v_group uuid := gen_random_uuid(); v_id uuid;
  v_generated jsonb := '[]'::jsonb; v_skipped jsonb := '[]'::jsonb;
  v_conflict int; v_capacity int; v_patient_user uuid; v_frequency text;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Select a valid date range of up to 120 days.';
  END IF;
  IF p_start_date < public.app_today() THEN RAISE EXCEPTION 'Recurring suggestions cannot start in the past.'; END IF;
  v_slot := public.config_slot(p_preferred_time);
  IF v_slot IS NULL THEN RAISE EXCEPTION 'Select a configured preferred time.'; END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  SELECT array_agg(CASE d WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
    WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 END)
  INTO v_day_nums FROM unnest(COALESCE(p_recurring_days, ARRAY[]::text[])) d;
  IF v_day_nums IS NULL OR array_position(v_day_nums, NULL) IS NOT NULL
     OR EXISTS (SELECT 1 FROM unnest(v_day_nums) d WHERE NOT (d = ANY(v_days))) THEN
    RAISE EXCEPTION 'Recurring days must be configured operating days; Sundays are excluded.';
  END IF;

  SELECT prescribed_dialysis_frequency INTO v_frequency
  FROM public.patient_medical_profiles WHERE patient_id = p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Complete the patient medical profile before generating recurring suggestions.'; END IF;

  UPDATE public.patient_medical_profiles
  SET recurring_days = COALESCE(p_recurring_days, ARRAY[]::text[]),
      preferred_time = p_preferred_time,
      profile_updated_by = auth.uid()
  WHERE patient_id = p_patient_id;

  PERFORM public.internal_ensure_capacity(p_start_date, p_end_date);
  FOR v_day IN SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date LOOP
    CONTINUE WHEN NOT (EXTRACT(ISODOW FROM v_day)::int = ANY(v_day_nums));
    PERFORM public.lock_schedule_slot(v_day, p_preferred_time);
    SELECT count(*)::int INTO v_conflict FROM public.appointments
    WHERE patient_id = p_patient_id AND requested_date = v_day AND requested_time = p_preferred_time
      AND is_cancelled = false AND appointment_status IN ('Pending','Under Review','Confirmed');
    IF v_conflict > 0 THEN
      v_skipped := v_skipped || jsonb_build_array(jsonb_build_object('date',v_day,'reason','Existing appointment conflict'));
      CONTINUE;
    END IF;
    v_capacity := public.slot_remaining_capacity(v_day, p_preferred_time);
    IF v_capacity <= 0 THEN
      v_skipped := v_skipped || jsonb_build_array(jsonb_build_object('date',v_day,'reason','No machine capacity'));
      CONTINUE;
    END IF;

    INSERT INTO public.appointments (
      patient_id, requested_date, requested_time, requested_start_time, requested_end_time,
      appointment_status, recurrence_group_id, is_recurring, status_history, request_type, submitted_by
    ) VALUES (
      p_patient_id, v_day, p_preferred_time, (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
      'Pending', v_group, true,
      public.append_status_history('[]'::jsonb,'Pending','Recurring Appointment Suggestion Generated',
        format('Staff-reviewed recurring suggestion. Prescribed frequency: %s. Days: %s.',
          COALESCE(v_frequency,'Not recorded'), array_to_string(p_recurring_days,', ')),
        jsonb_build_object('recurrence_group_id',v_group,'preferred_time',p_preferred_time)),
      'New', auth.uid()
    ) RETURNING appointment_id INTO v_id;
    v_generated := v_generated || jsonb_build_array(jsonb_build_object('date',v_day,'appointment_id',v_id,'time',p_preferred_time));
  END LOOP;

  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = p_patient_id;
  IF v_patient_user IS NOT NULL THEN
    v_destination := jsonb_build_object('panel','patient','section','book-appointment','recurrence_group_id',v_group);
    PERFORM public.notify_patient(p_patient_id, 'Recurring Appointment Requests Generated',
      format('%s appointment request(s) were prepared by authorized staff for your review.', jsonb_array_length(v_generated)),
      'Appointment Request', NULL, NULL, NULL, v_destination, 'Open appointments');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Recurring Appointment Suggestions Generated', 'Appointments', v_group::text,
    jsonb_build_object('patient_id',p_patient_id,'days',p_recurring_days,'preferred_time',p_preferred_time,
      'prescribed_frequency',v_frequency,'generated',v_generated,'skipped',v_skipped));
  RETURN jsonb_build_object('success',true,'recurrence_group_id',v_group,'generated',v_generated,'skipped',v_skipped,
    'note','These are Pending requests. Staff must still verify documents and assign machines before confirmation.');
END $$;

-- Function privileges: public workflow RPCs; internal helpers are not exposed to clients.
DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'create_appointment_request(date,text,text)',
    'set_appointment_status(uuid,text,text)',
    'assign_machine_and_confirm_appointment(uuid,uuid,date,time without time zone,time without time zone,text,text)',
    'request_document_correction(uuid,text,text)',
    'request_reschedule(uuid,date,text,text)',
    'process_reschedule_request(uuid,text,uuid,text,date,text)',
    'request_cancellation(uuid,text)',
    'process_cancellation_request(uuid,text,text)',
    'record_appointment_attendance(uuid,text,text)',
    'generate_recurring_appointments(uuid,text[],text,date,date)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY[
    'config_slot(text)','assert_booking_date(date,text)','append_status_history(jsonb,text,text,text,jsonb)',
    'appointment_snapshot(uuid)','notify_patient(uuid,text,text,text,uuid,uuid,uuid,jsonb,text)',
    'lock_schedule_slot(date,text)','missing_verified_documents(uuid)','release_machine_slot(uuid)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;
