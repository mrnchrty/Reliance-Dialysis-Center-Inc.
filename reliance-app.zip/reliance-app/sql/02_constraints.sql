-- Reliance Dialysis Center Inc. — idempotent column, relationship, constraint and index upgrade
-- This file preserves existing rows. Run after 01_schema.sql.

-- Add columns that extend the ten approved tables without creating an eleventh table.
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS sex_other text;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS profile_completed_at timestamptz;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS change_history jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS deactivated_at timestamptz;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS deactivated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.patients ADD COLUMN IF NOT EXISTS last_login_at timestamptz;

ALTER TABLE public.staff ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE public.staff ADD COLUMN IF NOT EXISTS deactivated_at timestamptz;
ALTER TABLE public.staff ADD COLUMN IF NOT EXISTS deactivated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.staff ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS allergy_other text;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS condition_other text;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS surgery_other text;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS frequency_other text;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS preferred_time_other text;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS change_history jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS profile_updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.patient_medical_profiles ADD COLUMN IF NOT EXISTS profile_completed_at timestamptz;

ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS storage_bucket text NOT NULL DEFAULT 'patient-documents';
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS uploaded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS is_current boolean NOT NULL DEFAULT true;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS version integer NOT NULL DEFAULT 1;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS replaces_document_id uuid;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS correction_requested boolean NOT NULL DEFAULT false;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS correction_notes text;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS correction_requested_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS correction_requested_at timestamptz;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS is_outdated boolean NOT NULL DEFAULT false;
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.patient_documents ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS requested_start_time time;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS requested_end_time time;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS attendance_recorded_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS attendance_recorded_at timestamptz;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS request_type text NOT NULL DEFAULT 'New';
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS original_details jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS reschedule_request jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS cancellation_request jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS correction_request jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS machine_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.appointments ADD COLUMN IF NOT EXISTS submitted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS daily_capacity integer NOT NULL DEFAULT 3;
ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;
ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS maintenance_started_at timestamptz;
ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS maintenance_ends_at timestamptz;
ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS last_service_date date;
ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.dialysis_machines ADD COLUMN IF NOT EXISTS updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE public.machine_slots ADD COLUMN IF NOT EXISTS slot_key text NOT NULL DEFAULT 'Legacy';
ALTER TABLE public.machine_slots ADD COLUMN IF NOT EXISTS slot_label text;
ALTER TABLE public.machine_slots ADD COLUMN IF NOT EXISTS appointment_id uuid UNIQUE;
ALTER TABLE public.machine_slots ADD COLUMN IF NOT EXISTS capacity_source text NOT NULL DEFAULT 'Generated';

ALTER TABLE public.dialysis_sessions ADD COLUMN IF NOT EXISTS released_at timestamptz;
ALTER TABLE public.dialysis_sessions ADD COLUMN IF NOT EXISTS released_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL;
ALTER TABLE public.dialysis_sessions ADD COLUMN IF NOT EXISTS released_remarks text;
ALTER TABLE public.dialysis_sessions ADD COLUMN IF NOT EXISTS patient_visible_notes text;
ALTER TABLE public.dialysis_sessions ALTER COLUMN is_released_to_patient SET DEFAULT false;

ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS related_document_id uuid;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS related_session_id uuid;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS related_patient_id uuid;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS destination jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS action_label text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS read_at timestamptz;

ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS actor_email text;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS actor_name text;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS actor_role text;
ALTER TABLE public.audit_logs ADD COLUMN IF NOT EXISTS severity text NOT NULL DEFAULT 'Info';

-- Backfill structured columns from existing records.
UPDATE public.patient_documents d
SET uploaded_by = p.user_id,
    storage_bucket = COALESCE(d.storage_bucket, 'patient-documents'),
    is_current = COALESCE(d.is_current, true),
    version = COALESCE(d.version, 1)
FROM public.patients p
WHERE p.patient_id = d.patient_id AND d.uploaded_by IS NULL;

UPDATE public.appointments a
SET submitted_by = p.user_id,
    request_type = COALESCE(a.request_type, 'New'),
    requested_start_time = CASE a.requested_time
      WHEN 'Morning' THEN '08:00'::time WHEN 'Midday' THEN '11:00'::time
      WHEN 'Afternoon' THEN '14:00'::time ELSE a.requested_start_time END,
    requested_end_time = CASE a.requested_time
      WHEN 'Morning' THEN '11:00'::time WHEN 'Midday' THEN '14:00'::time
      WHEN 'Afternoon' THEN '17:00'::time ELSE a.requested_end_time END
FROM public.patients p
WHERE p.patient_id = a.patient_id AND a.submitted_by IS NULL;

UPDATE public.appointments a
SET original_details = jsonb_build_object(
  'requested_date', a.requested_date, 'requested_time', a.requested_time,
  'confirmed_date', a.confirmed_date, 'confirmed_start_time', a.confirmed_start_time,
  'confirmed_end_time', a.confirmed_end_time, 'machine_slot_id', a.machine_slot_id
)
WHERE a.original_details = '{}'::jsonb;

UPDATE public.machine_slots
SET slot_key = CASE
      WHEN start_time = '08:00'::time AND end_time = '11:00'::time THEN 'Morning'
      WHEN start_time = '11:00'::time AND end_time = '14:00'::time THEN 'Midday'
      WHEN start_time = '14:00'::time AND end_time = '17:00'::time THEN 'Afternoon'
      ELSE 'Custom' END,
    slot_label = CASE
      WHEN start_time = '08:00'::time AND end_time = '11:00'::time THEN '8:00 AM – 11:00 AM'
      WHEN start_time = '11:00'::time AND end_time = '14:00'::time THEN '11:00 AM – 2:00 PM'
      WHEN start_time = '14:00'::time AND end_time = '17:00'::time THEN '2:00 PM – 5:00 PM'
      ELSE to_char(start_time, 'HH12:MI AM') || ' – ' || to_char(end_time, 'HH12:MI AM') END,
    capacity_source = 'Legacy'
WHERE slot_key = 'Legacy';

UPDATE public.machine_slots ms
SET appointment_id = a.appointment_id
FROM public.appointments a
WHERE a.machine_slot_id = ms.machine_slot_id AND ms.appointment_id IS NULL;

UPDATE public.appointments a
SET machine_snapshot = jsonb_build_object('machine_code', m.machine_code, 'machine_name', m.machine_name, 'schedule_date', ms.schedule_date)
FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
WHERE a.machine_slot_id = ms.machine_slot_id AND a.machine_snapshot = '{}'::jsonb;

-- Refresh check constraints while retaining the four allowed appointment statuses only.
ALTER TABLE public.patients DROP CONSTRAINT IF EXISTS patients_sex_check;
ALTER TABLE public.patients ADD CONSTRAINT patients_sex_check CHECK (sex IS NULL OR sex IN ('Male','Female','Prefer not to say','Other'));

ALTER TABLE public.dialysis_machines DROP CONSTRAINT IF EXISTS dialysis_machines_machine_status_check;
ALTER TABLE public.dialysis_machines ADD CONSTRAINT dialysis_machines_machine_status_check CHECK (machine_status IN ('Available','Occupied','Maintenance','Offline','Unavailable'));
ALTER TABLE public.dialysis_machines DROP CONSTRAINT IF EXISTS dialysis_machines_daily_capacity_check;
ALTER TABLE public.dialysis_machines ADD CONSTRAINT dialysis_machines_daily_capacity_check CHECK (daily_capacity > 0);

ALTER TABLE public.machine_slots DROP CONSTRAINT IF EXISTS machine_slots_slot_status_check;
ALTER TABLE public.machine_slots ADD CONSTRAINT machine_slots_slot_status_check CHECK (slot_status IN ('Available','Reserved','Booked','Completed','Maintenance','Cancelled'));
ALTER TABLE public.machine_slots DROP CONSTRAINT IF EXISTS chk_slot_time_order;
ALTER TABLE public.machine_slots ADD CONSTRAINT chk_slot_time_order CHECK (end_time > start_time);
ALTER TABLE public.machine_slots DROP CONSTRAINT IF EXISTS excl_machine_slot_no_overlap;
ALTER TABLE public.machine_slots ADD CONSTRAINT excl_machine_slot_no_overlap
  EXCLUDE USING gist (
    machine_id WITH =,
    schedule_date WITH =,
    tsrange(('2000-01-01'::date + start_time), ('2000-01-01'::date + end_time), '[)') WITH &&
  ) WHERE (slot_status IN ('Available','Reserved','Booked','Maintenance'));

ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_appointment_status_check;
ALTER TABLE public.appointments ADD CONSTRAINT appointments_appointment_status_check CHECK (appointment_status IN ('Pending','Under Review','Confirmed','Rejected'));
ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_attendance_flag_check;
ALTER TABLE public.appointments ADD CONSTRAINT appointments_attendance_flag_check CHECK (attendance_flag IN ('Scheduled','Attended','No-Show'));
ALTER TABLE public.appointments DROP CONSTRAINT IF EXISTS appointments_request_type_check;
ALTER TABLE public.appointments ADD CONSTRAINT appointments_request_type_check CHECK (request_type IN ('New','Reschedule'));

ALTER TABLE public.patient_documents DROP CONSTRAINT IF EXISTS patient_documents_document_type_check;
ALTER TABLE public.patient_documents ADD CONSTRAINT patient_documents_document_type_check CHECK (document_type IN ('Nephrologist''s Endorsement','Medical Abstract','Latest Laboratory Results','Valid Identification','Authorized Medical Record'));
ALTER TABLE public.patient_documents DROP CONSTRAINT IF EXISTS patient_documents_verification_status_check;
ALTER TABLE public.patient_documents ADD CONSTRAINT patient_documents_verification_status_check CHECK (verification_status IN ('Pending','Verified','Needs Correction','Rejected'));
ALTER TABLE public.patient_documents DROP CONSTRAINT IF EXISTS patient_documents_version_check;
ALTER TABLE public.patient_documents ADD CONSTRAINT patient_documents_version_check CHECK (version > 0);

ALTER TABLE public.dialysis_sessions DROP CONSTRAINT IF EXISTS dialysis_sessions_session_status_check;
ALTER TABLE public.dialysis_sessions ADD CONSTRAINT dialysis_sessions_session_status_check CHECK (session_status IN ('In Progress','Completed','Terminated Early'));

ALTER TABLE public.staff DROP CONSTRAINT IF EXISTS staff_role_check;
ALTER TABLE public.staff ADD CONSTRAINT staff_role_check CHECK (role IN ('staff','super_admin'));
ALTER TABLE public.staff DROP CONSTRAINT IF EXISTS staff_account_status_check;
ALTER TABLE public.staff ADD CONSTRAINT staff_account_status_check CHECK (account_status IN ('Active','Inactive'));
ALTER TABLE public.patients DROP CONSTRAINT IF EXISTS patients_account_status_check;
ALTER TABLE public.patients ADD CONSTRAINT patients_account_status_check CHECK (account_status IN ('Active','Inactive'));
ALTER TABLE public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_severity_check;
ALTER TABLE public.audit_logs ADD CONSTRAINT audit_logs_severity_check CHECK (severity IN ('Info','Warning','Critical'));

-- Circular / optional foreign keys (safe for both fresh and upgraded databases).
DO $fk$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='appointments_machine_slot_id_fkey') THEN
    ALTER TABLE public.appointments ADD CONSTRAINT appointments_machine_slot_id_fkey FOREIGN KEY (machine_slot_id) REFERENCES public.machine_slots(machine_slot_id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='machine_slots_appointment_id_fkey') THEN
    ALTER TABLE public.machine_slots ADD CONSTRAINT machine_slots_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(appointment_id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='patient_documents_replaces_document_id_fkey') THEN
    ALTER TABLE public.patient_documents ADD CONSTRAINT patient_documents_replaces_document_id_fkey FOREIGN KEY (replaces_document_id) REFERENCES public.patient_documents(document_id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='notifications_related_document_id_fkey') THEN
    ALTER TABLE public.notifications ADD CONSTRAINT notifications_related_document_id_fkey FOREIGN KEY (related_document_id) REFERENCES public.patient_documents(document_id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='notifications_related_session_id_fkey') THEN
    ALTER TABLE public.notifications ADD CONSTRAINT notifications_related_session_id_fkey FOREIGN KEY (related_session_id) REFERENCES public.dialysis_sessions(session_id) ON DELETE SET NULL;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='notifications_related_patient_id_fkey') THEN
    ALTER TABLE public.notifications ADD CONSTRAINT notifications_related_patient_id_fkey FOREIGN KEY (related_patient_id) REFERENCES public.patients(patient_id) ON DELETE SET NULL;
  END IF;
END $fk$;

-- Uniqueness and performance indexes.
CREATE UNIQUE INDEX IF NOT EXISTS appointments_one_active_request_per_patient_slot
  ON public.appointments (patient_id, requested_date, requested_time)
  WHERE is_cancelled = false AND appointment_status IN ('Pending','Under Review','Confirmed');
CREATE UNIQUE INDEX IF NOT EXISTS patient_documents_one_current_per_type
  ON public.patient_documents (patient_id, document_type)
  WHERE is_current = true AND document_type <> 'Authorized Medical Record';
CREATE UNIQUE INDEX IF NOT EXISTS machine_slots_one_capacity_per_machine_slot
  ON public.machine_slots (machine_id, schedule_date, slot_key) WHERE slot_status <> 'Cancelled';
CREATE INDEX IF NOT EXISTS idx_appointments_date_time ON public.appointments (requested_date, requested_time);
CREATE INDEX IF NOT EXISTS idx_appointments_status_date ON public.appointments (appointment_status, requested_date);
CREATE INDEX IF NOT EXISTS idx_appointments_reschedule ON public.appointments (reschedule_requested) WHERE reschedule_requested = true;
CREATE INDEX IF NOT EXISTS idx_appointments_cancellation ON public.appointments (is_cancelled, cancelled_at);
CREATE INDEX IF NOT EXISTS idx_machine_slots_date_key ON public.machine_slots (schedule_date, slot_key, slot_status);
CREATE INDEX IF NOT EXISTS idx_machines_active_status ON public.dialysis_machines (is_active, machine_status);
CREATE INDEX IF NOT EXISTS idx_documents_current_type ON public.patient_documents (patient_id, document_type, is_current);
CREATE INDEX IF NOT EXISTS idx_documents_verification ON public.patient_documents (verification_status, reviewed_at);
CREATE INDEX IF NOT EXISTS idx_sessions_release_date ON public.dialysis_sessions (is_released_to_patient, treatment_date DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_destination ON public.notifications USING gin (destination jsonb_path_ops);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON public.notifications (notification_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_created ON public.audit_logs (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_activity ON public.audit_logs (activity);
CREATE INDEX IF NOT EXISTS idx_audit_logs_config ON public.audit_logs (created_at DESC) WHERE affected_module = 'System Configuration';
CREATE INDEX IF NOT EXISTS idx_patients_name ON public.patients (full_name);
CREATE INDEX IF NOT EXISTS idx_staff_status_role ON public.staff (account_status, role);
