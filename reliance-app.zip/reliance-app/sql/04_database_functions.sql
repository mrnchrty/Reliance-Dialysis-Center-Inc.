-- Reliance Dialysis Center Inc. — system configuration, generated capacity and atomic availability
-- Design note: system configuration is stored as an append-only snapshot in AUDIT_LOGS.details.
-- This preserves the exactly-ten-table rule and gives a complete configuration audit trail.

CREATE OR REPLACE FUNCTION public.default_system_config()
RETURNS jsonb LANGUAGE sql IMMUTABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT jsonb_build_object(
    'version', 1,
    'timezone', 'Asia/Manila',
    'operating_days', jsonb_build_array(1,2,3,4,5,6),
    'operating_hours', jsonb_build_object('open','08:00','close','17:00'),
    'time_slots', jsonb_build_array(
      jsonb_build_object('id','Morning','label','Morning','display','8:00 AM – 11:00 AM','start_time','08:00','end_time','11:00','capacity_per_machine',1),
      jsonb_build_object('id','Midday','label','Midday','display','11:00 AM – 2:00 PM','start_time','11:00','end_time','14:00','capacity_per_machine',1),
      jsonb_build_object('id','Afternoon','label','Afternoon','display','2:00 PM – 5:00 PM','start_time','14:00','end_time','17:00','capacity_per_machine',1)
    ),
    'required_document_types', jsonb_build_array('Nephrologist''s Endorsement','Medical Abstract','Latest Laboratory Results','Valid Identification'),
    'patients_per_machine_per_day', 3,
    'require_staff_machine_assignment', true,
    'require_verified_documents_for_confirmation', true,
    'max_advance_days', 90,
    'min_lead_days', 1,
    'allow_same_day', false,
    'allow_multiple_open_requests', true,
    'max_open_requests', 6
  );
$$;

CREATE OR REPLACE FUNCTION public.get_clinic_schedule_config()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_cfg jsonb; v_default jsonb := public.default_system_config(); v_slots jsonb;
BEGIN
  SELECT details INTO v_cfg FROM public.audit_logs
  WHERE activity = 'System Configuration Updated' AND affected_module = 'System Configuration'
  ORDER BY created_at DESC, audit_id DESC LIMIT 1;

  IF v_cfg IS NULL OR v_cfg = '{}'::jsonb THEN
    SELECT schedule_config INTO v_cfg FROM public.dialysis_machines
    WHERE schedule_config IS NOT NULL ORDER BY machine_code ASC LIMIT 1;
  END IF;

  -- Normalize legacy/custom slot definitions so every configured slot has one patient per machine.
  v_slots := COALESCE(v_cfg -> 'time_slots', v_default -> 'time_slots');
  SELECT COALESCE(jsonb_agg(
    COALESCE((
      SELECT value FROM jsonb_array_elements(v_default -> 'time_slots')
      WHERE value ->> 'id' = slot ->> 'id' LIMIT 1
    ), '{}'::jsonb) || slot || jsonb_build_object('capacity_per_machine', 1)
    ORDER BY slot ->> 'start_time'
  ), '[]'::jsonb) INTO v_slots
  FROM jsonb_array_elements(v_slots) slot;

  RETURN v_default || COALESCE(v_cfg, '{}'::jsonb) || jsonb_build_object('time_slots', v_slots);
END $$;

CREATE OR REPLACE FUNCTION public.get_system_config()
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT public.get_clinic_schedule_config(); $$;

CREATE OR REPLACE FUNCTION public.validate_system_config(p_config jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_days int[]; v_slot_count int; v_open time; v_close time;
  v_slot_ids text[]; v_conflicts int; v_slot_conflicts int;
BEGIN
  IF p_config IS NULL OR jsonb_typeof(p_config) <> 'object' THEN
    RAISE EXCEPTION 'System configuration must be a JSON object.';
  END IF;

  SELECT array_agg(value::int ORDER BY value::int) INTO v_days
  FROM jsonb_array_elements_text(p_config -> 'operating_days');
  IF v_days IS NULL OR cardinality(v_days) = 0 OR EXISTS (SELECT 1 FROM unnest(v_days) d WHERE d < 1 OR d > 6) THEN
    RAISE EXCEPTION 'Operating days must be Monday through Saturday only; Sunday remains closed.';
  END IF;

  v_open := (p_config -> 'operating_hours' ->> 'open')::time;
  v_close := (p_config -> 'operating_hours' ->> 'close')::time;
  IF v_open IS NULL OR v_close IS NULL OR v_close <= v_open THEN
    RAISE EXCEPTION 'Clinic closing time must be later than opening time.';
  END IF;

  SELECT count(*), array_agg(value ->> 'id') INTO v_slot_count, v_slot_ids
  FROM jsonb_array_elements(p_config -> 'time_slots');
  IF v_slot_count IS NULL OR v_slot_count = 0 THEN
    RAISE EXCEPTION 'At least one appointment time slot is required.';
  END IF;
  IF (SELECT count(*) FROM unnest(v_slot_ids) s WHERE s IS NULL OR trim(s) = '') > 0 OR
     (SELECT count(DISTINCT s) FROM unnest(v_slot_ids) s) <> cardinality(v_slot_ids) THEN
    RAISE EXCEPTION 'Every time slot needs a unique identifier.';
  END IF;
  IF COALESCE((p_config ->> 'patients_per_machine_per_day')::int, 0) <> v_slot_count THEN
    RAISE EXCEPTION 'Patients per machine per day must equal the number of configured time slots (one patient per machine per time window).';
  END IF;

  IF EXISTS (
    SELECT 1 FROM (
      SELECT (value ->> 'start_time')::time AS s, (value ->> 'end_time')::time AS e,
             (value ->> 'capacity_per_machine')::int AS cap,
             lag((value ->> 'end_time')::time) OVER (ORDER BY (value ->> 'start_time')::time) AS prev_e
      FROM jsonb_array_elements(p_config -> 'time_slots')
    ) t
    WHERE s IS NULL OR e IS NULL OR e <= s OR s < v_open OR e > v_close OR cap IS NULL OR cap <> 1 OR prev_e > s
  ) THEN
    RAISE EXCEPTION 'Time slots must be within operating hours, non-overlapping, and allow one patient per machine.';
  END IF;

  SELECT count(*) INTO v_conflicts FROM public.appointments a
  WHERE a.is_cancelled = false AND a.requested_date >= public.app_today()
    AND (
      NOT (EXTRACT(ISODOW FROM a.requested_date)::int = ANY(v_days))
      OR NOT (a.requested_time = ANY(v_slot_ids))
    );
  IF v_conflicts > 0 THEN
    RAISE EXCEPTION 'Configuration conflicts with % future appointment request(s). Reassign or process those requests before changing operating days or time slots.', v_conflicts;
  END IF;

  SELECT count(*) INTO v_slot_conflicts FROM public.machine_slots ms
  WHERE ms.schedule_date >= public.app_today()
    AND ms.slot_status IN ('Booked','Reserved','Maintenance')
    AND (
      NOT (EXTRACT(ISODOW FROM ms.schedule_date)::int = ANY(v_days))
      OR NOT (ms.slot_key = ANY(v_slot_ids))
    );
  IF v_slot_conflicts > 0 THEN
    RAISE EXCEPTION 'Configuration conflicts with % reserved machine slot(s). Resolve machine schedules before saving.', v_slot_conflicts;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.update_clinic_schedule_config(p_config jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_config jsonb; v_machine uuid; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Unauthorized: only an active Super Administrator can update system configuration.';
  END IF;
  PERFORM public.validate_system_config(p_config);
  v_config := p_config || jsonb_build_object(
    'version', COALESCE((p_config ->> 'version')::int, 0) + 1,
    'updated_at', now(), 'updated_by', auth.uid()
  );

  INSERT INTO public.audit_logs (
    user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details, severity
  ) VALUES (
    auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'System Configuration Updated', 'System Configuration', 'clinic', v_config, 'Warning'
  );

  SELECT machine_id INTO v_machine FROM public.dialysis_machines ORDER BY machine_code ASC LIMIT 1;
  IF v_machine IS NOT NULL THEN
    UPDATE public.dialysis_machines SET schedule_config = v_config, updated_by = auth.uid() WHERE machine_id = v_machine;
  END IF;
  RETURN v_config;
END $$;

CREATE OR REPLACE FUNCTION public.update_system_config(p_config jsonb)
RETURNS jsonb LANGUAGE sql SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT public.update_clinic_schedule_config(p_config); $$;

CREATE OR REPLACE FUNCTION public.internal_ensure_capacity(p_start_date date, p_end_date date)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_cfg jsonb := public.get_system_config(); v_days int[]; v_day date; v_slot jsonb;
  v_machine record; v_count int := 0;
BEGIN
  IF p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Capacity generation range must be between 0 and 120 days.';
  END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');

  FOR v_day IN SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date LOOP
    CONTINUE WHEN NOT (EXTRACT(ISODOW FROM v_day)::int = ANY(v_days));
    FOR v_machine IN SELECT * FROM public.dialysis_machines
                     WHERE is_active = true AND machine_status IN ('Available','Occupied') LOOP
      FOR v_slot IN SELECT value FROM jsonb_array_elements(v_cfg -> 'time_slots') LOOP
        BEGIN
          INSERT INTO public.machine_slots (
            machine_id, schedule_date, start_time, end_time, slot_status, slot_key, slot_label, capacity_source
          ) VALUES (
            v_machine.machine_id, v_day, (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
            'Available', v_slot ->> 'id', COALESCE(v_slot ->> 'display', v_slot ->> 'label'), 'Generated'
          ) ON CONFLICT (machine_id, schedule_date, slot_key) WHERE slot_status <> 'Cancelled' DO NOTHING;
          IF FOUND THEN v_count := v_count + 1; END IF;
        EXCEPTION WHEN exclusion_violation THEN
          -- A legacy/custom booked schedule already occupies this machine window.
          CONTINUE;
        END;
      END LOOP;
    END LOOP;
  END LOOP;
  RETURN v_count;
END $$;

CREATE OR REPLACE FUNCTION public.ensure_capacity_slots(p_start_date date, p_end_date date)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF public.current_patient_id() IS NULL AND NOT public.is_active_staff() THEN
    RAISE EXCEPTION 'Your account is not active.';
  END IF;
  RETURN public.internal_ensure_capacity(p_start_date, p_end_date);
END $$;

CREATE OR REPLACE FUNCTION public.slot_remaining_capacity(p_date date, p_slot_id text)
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  WITH s AS (
    SELECT ms.slot_status
    FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
    WHERE ms.schedule_date = p_date AND ms.slot_key = p_slot_id
      AND ms.slot_status <> 'Cancelled' AND m.is_active = true
      AND m.machine_status IN ('Available','Occupied')
  ), p AS (
    SELECT count(*)::int AS n FROM public.appointments a
    WHERE a.requested_date = p_date AND a.requested_time = p_slot_id
      AND a.machine_slot_id IS NULL AND a.is_cancelled = false
      AND a.appointment_status IN ('Pending','Under Review','Confirmed')
  )
  SELECT GREATEST(
    (SELECT count(*)::int FROM s)
    - (SELECT count(*)::int FROM s WHERE slot_status IN ('Booked','Reserved','Completed'))
    - (SELECT count(*)::int FROM s WHERE slot_status = 'Maintenance')
    - (SELECT n FROM p), 0
  )::int;
$$;

CREATE OR REPLACE FUNCTION public.get_schedule_availability(p_start_date date, p_end_date date)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_cfg jsonb; v_days int[]; v_active int; v_dates jsonb;
        v_min int; v_max int; v_allow boolean;
BEGIN
  IF p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Availability range must be between 0 and 120 days.';
  END IF;
  v_cfg := public.get_system_config();
  v_min := COALESCE((v_cfg ->> 'min_lead_days')::int, 1);
  v_max := COALESCE((v_cfg ->> 'max_advance_days')::int, 90);
  v_allow := COALESCE((v_cfg ->> 'allow_same_day')::boolean, false);
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  SELECT count(*)::int INTO v_active FROM public.dialysis_machines
  WHERE is_active = true AND machine_status IN ('Available','Occupied');

  WITH days AS (
    SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date AS d
  ), slots AS (
    SELECT value ->> 'id' AS slot_id, value ->> 'label' AS label,
           value ->> 'display' AS display, (value ->> 'start_time')::time AS start_time,
           (value ->> 'end_time')::time AS end_time
    FROM jsonb_array_elements(v_cfg -> 'time_slots')
  ), grid AS (
    SELECT days.d, slots.* FROM days CROSS JOIN slots
  ), slot_state AS (
    SELECT ms.schedule_date AS d, ms.slot_key,
           count(*)::int AS total,
           count(*) FILTER (WHERE ms.slot_status IN ('Booked','Reserved','Completed'))::int AS booked,
           count(*) FILTER (WHERE ms.slot_status = 'Maintenance')::int AS blocked
    FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
    WHERE ms.schedule_date BETWEEN p_start_date AND p_end_date AND ms.slot_status <> 'Cancelled'
      AND m.is_active = true AND m.machine_status IN ('Available','Occupied')
    GROUP BY ms.schedule_date, ms.slot_key
  ), pending AS (
    SELECT requested_date AS d, requested_time AS slot_id, count(*)::int AS pending
    FROM public.appointments
    WHERE requested_date BETWEEN p_start_date AND p_end_date AND machine_slot_id IS NULL
      AND is_cancelled = false AND appointment_status IN ('Pending','Under Review','Confirmed')
    GROUP BY requested_date, requested_time
  ), date_slots AS (
    SELECT g.d, jsonb_agg(jsonb_build_object(
      'slot_id', g.slot_id, 'label', g.label, 'display', g.display,
      'start_time', to_char(g.start_time,'HH24:MI'), 'end_time', to_char(g.end_time,'HH24:MI'),
      'total', COALESCE(ss.total,0), 'booked', COALESCE(ss.booked,0), 'blocked', COALESCE(ss.blocked,0),
      'pending', COALESCE(p.pending,0),
      'available', GREATEST(COALESCE(ss.total,0) - COALESCE(ss.booked,0) - COALESCE(ss.blocked,0) - COALESCE(p.pending,0), 0),
      'enabled', false
    ) ORDER BY g.start_time) AS slots
    FROM grid g
    LEFT JOIN slot_state ss ON ss.d = g.d AND ss.slot_key = g.slot_id
    LEFT JOIN pending p ON p.d = g.d AND p.slot_id = g.slot_id
    GROUP BY g.d
  )
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'date', ds.d,
    'operating_day', EXTRACT(ISODOW FROM ds.d)::int = ANY(v_days),
    'slots', (
      SELECT jsonb_agg(slot || jsonb_build_object(
        'enabled', ds.d >= public.app_today() + GREATEST(v_min,0)
          AND (ds.d > public.app_today() OR (v_min = 0 AND v_allow))
          AND ds.d <= public.app_today() + v_max
          AND EXTRACT(ISODOW FROM ds.d)::int = ANY(v_days)
          AND (slot ->> 'available')::int > 0
      ) ORDER BY slot ->> 'start_time')
      FROM jsonb_array_elements(ds.slots) slot
    ),
    'available', (
      SELECT COALESCE(sum((slot ->> 'available')::int),0) FROM jsonb_array_elements(ds.slots) slot
    )
  ) ORDER BY ds.d), '[]'::jsonb) INTO v_dates FROM date_slots ds;

  RETURN jsonb_build_object(
    'config', v_cfg, 'active_machines', v_active,
    'measurement', 'One generated MACHINE_SLOTS row per active machine per configured time window. Available = total - booked - blocked - unassigned active requests.',
    'timezone', 'Asia/Manila', 'generated_at', now(), 'dates', v_dates
  );
END $$;

CREATE OR REPLACE FUNCTION public.get_appointment_availability(p_start_date date, p_end_date date)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT public.get_schedule_availability(p_start_date, p_end_date); $$;

CREATE OR REPLACE FUNCTION public.get_machine_availability(p_start_date date, p_end_date date)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb;
BEGIN
  IF NOT public.is_active_staff() THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'machine_id', m.machine_id, 'machine_code', m.machine_code, 'machine_name', m.machine_name,
    'machine_status', m.machine_status, 'schedule_date', ms.schedule_date, 'slot_key', ms.slot_key,
    'slot_label', ms.slot_label, 'start_time', ms.start_time, 'end_time', ms.end_time,
    'slot_status', ms.slot_status, 'appointment_id', ms.appointment_id
  ) ORDER BY m.machine_code, ms.schedule_date, ms.start_time), '[]'::jsonb) INTO v_result
  FROM public.dialysis_machines m LEFT JOIN public.machine_slots ms
    ON ms.machine_id = m.machine_id AND ms.schedule_date BETWEEN p_start_date AND p_end_date
  WHERE m.is_active = true;
  RETURN jsonb_build_object('machines', v_result, 'config', public.get_system_config());
END $$;

-- Function privileges for this module.
DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'get_clinic_schedule_config()','get_system_config()','default_system_config()',
    'update_clinic_schedule_config(jsonb)','update_system_config(jsonb)',
    'ensure_capacity_slots(date,date)','get_schedule_availability(date,date)',
    'get_appointment_availability(date,date)','get_machine_availability(date,date)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY['validate_system_config(jsonb)','internal_ensure_capacity(date,date)','slot_remaining_capacity(date,text)'] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;

-- Reliance Dialysis Center Inc. — appointment requests, status processing, capacity, rescheduling, cancellation and recurrence
-- All appointment writes are atomic SECURITY DEFINER operations. Patients never select or assign a machine.

DROP FUNCTION IF EXISTS public.assign_machine_and_confirm_appointment(uuid, uuid, date, time without time zone, time without time zone, text);

CREATE OR REPLACE FUNCTION public.config_slot(p_slot_id text)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT value FROM jsonb_array_elements(public.get_system_config() -> 'time_slots') WHERE value ->> 'id' = p_slot_id LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.assert_booking_date(p_date date, p_slot_id text)
RETURNS void LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_cfg jsonb := public.get_system_config(); v_days int[]; v_slot jsonb;
        v_min int; v_max int; v_allow boolean;
BEGIN
  IF p_date IS NULL OR p_slot_id IS NULL OR trim(p_slot_id) = '' THEN
    RAISE EXCEPTION 'Select a valid appointment date and time slot.';
  END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  v_slot := public.config_slot(p_slot_id);
  v_min := COALESCE((v_cfg ->> 'min_lead_days')::int, 1);
  v_max := COALESCE((v_cfg ->> 'max_advance_days')::int, 90);
  v_allow := COALESCE((v_cfg ->> 'allow_same_day')::boolean, false);

  IF v_slot IS NULL THEN RAISE EXCEPTION 'The selected appointment time is no longer configured.'; END IF;
  IF NOT (EXTRACT(ISODOW FROM p_date)::int = ANY(v_days)) THEN
    RAISE EXCEPTION 'The center is closed on the selected date. Operating days are Monday to Saturday.';
  END IF;
  IF p_date < public.app_today() THEN RAISE EXCEPTION 'Past dates cannot be booked.'; END IF;
  IF p_date = public.app_today() AND (v_min > 0 OR NOT v_allow) THEN
    RAISE EXCEPTION 'Same-day booking is not enabled for this center.';
  END IF;
  IF p_date > public.app_today() + v_max THEN
    RAISE EXCEPTION 'Appointments can only be requested up to % days in advance.', v_max;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.append_status_history(
  p_history jsonb, p_status text, p_event_type text, p_remarks text, p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT COALESCE(p_history, '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
    'status', p_status, 'event_type', COALESCE(p_event_type, p_status),
    'remarks', p_remarks, 'timestamp', now(), 'actor_user_id', auth.uid(),
    'metadata', COALESCE(p_metadata, '{}'::jsonb)
  ));
$$;

CREATE OR REPLACE FUNCTION public.appointment_snapshot(p_appointment_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v jsonb;
BEGIN
  SELECT jsonb_build_object(
    'appointment', to_jsonb(a),
    'machine', COALESCE((
      SELECT jsonb_build_object('machine_slot_id', ms.machine_slot_id, 'machine_id', m.machine_id,
        'machine_code', m.machine_code, 'machine_name', m.machine_name, 'schedule_date', ms.schedule_date,
        'start_time', ms.start_time, 'end_time', ms.end_time)
      FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
      WHERE ms.machine_slot_id = a.machine_slot_id), '{}'::jsonb)
  ) INTO v FROM public.appointments a WHERE a.appointment_id = p_appointment_id;
  RETURN COALESCE(v, '{}'::jsonb);
END $$;

CREATE OR REPLACE FUNCTION public.notify_patient(
  p_patient_id uuid, p_title text, p_message text, p_type text,
  p_appointment_id uuid DEFAULT NULL, p_document_id uuid DEFAULT NULL,
  p_session_id uuid DEFAULT NULL, p_destination jsonb DEFAULT '{}'::jsonb,
  p_action_label text DEFAULT 'Open record'
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_user uuid;
BEGIN
  SELECT user_id INTO v_user FROM public.patients WHERE patient_id = p_patient_id;
  IF v_user IS NOT NULL THEN
    PERFORM public.write_notification(v_user, p_title, p_message, p_type, p_appointment_id,
      p_document_id, p_session_id, p_patient_id, p_destination, p_action_label);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.lock_schedule_slot(p_date date, p_slot_id text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT pg_advisory_xact_lock(hashtextextended(p_date::text || ':' || p_slot_id, 714229)); $$;

CREATE OR REPLACE FUNCTION public.missing_verified_documents(p_patient_id uuid)
RETURNS text[] LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_required text[]; v_missing text[];
BEGIN
  IF NOT COALESCE((public.get_system_config() ->> 'require_verified_documents_for_confirmation')::boolean, true) THEN
    RETURN ARRAY[]::text[];
  END IF;
  SELECT array_agg(value) INTO v_required FROM jsonb_array_elements_text(public.get_system_config() -> 'required_document_types');
  SELECT COALESCE(array_agg(req), ARRAY[]::text[]) INTO v_missing
  FROM unnest(v_required) req
  WHERE NOT EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.patient_id = p_patient_id AND d.document_type = req AND d.is_current = true
      AND d.verification_status = 'Verified' AND d.correction_requested = false AND d.is_outdated = false
  );
  RETURN v_missing;
END $$;

CREATE OR REPLACE FUNCTION public.release_machine_slot(p_appointment_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_slot_id uuid; v_status text;
BEGIN
  SELECT machine_slot_id INTO v_slot_id FROM public.appointments WHERE appointment_id = p_appointment_id;
  IF v_slot_id IS NULL THEN RETURN; END IF;
  SELECT slot_status INTO v_status FROM public.machine_slots WHERE machine_slot_id = v_slot_id FOR UPDATE;
  IF v_status IS NOT NULL THEN
    UPDATE public.machine_slots
    SET appointment_id = NULL,
        slot_status = CASE WHEN slot_status IN ('Booked','Reserved') THEN 'Available' ELSE slot_status END
    WHERE machine_slot_id = v_slot_id;
  END IF;
  UPDATE public.appointments SET machine_slot_id = NULL WHERE appointment_id = p_appointment_id;
END $$;

CREATE OR REPLACE FUNCTION public.create_appointment_request(
  p_requested_date date, p_requested_time text, p_notes text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_patient public.patients%ROWTYPE; v_medical public.patient_medical_profiles%ROWTYPE;
  v_cfg jsonb := public.get_system_config(); v_slot jsonb; v_missing_docs text[];
  v_open int; v_capacity int; v_id uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Staff accounts cannot submit patient appointment requests.'; END IF;
  SELECT * INTO v_patient FROM public.patients WHERE patient_id = public.current_patient_id();
  IF v_patient.patient_id IS NULL THEN RAISE EXCEPTION 'Active patient account required.'; END IF;

  IF v_patient.full_name IS NULL OR v_patient.date_of_birth IS NULL OR v_patient.sex IS NULL
     OR v_patient.address IS NULL OR v_patient.contact_number IS NULL
     OR v_patient.emergency_contact_name IS NULL OR v_patient.emergency_contact_number IS NULL THEN
    RAISE EXCEPTION 'Complete your personal profile before booking.';
  END IF;
  SELECT * INTO v_medical FROM public.patient_medical_profiles WHERE patient_id = v_patient.patient_id;
  IF v_medical.medical_profile_id IS NULL OR v_medical.height IS NULL OR v_medical.weight IS NULL
     OR v_medical.blood_type IS NULL OR v_medical.diagnosis IS NULL
     OR v_medical.allergies IS NULL OR v_medical.existing_medical_conditions IS NULL
     OR v_medical.previous_surgeries IS NULL OR v_medical.current_medications IS NULL
     OR v_medical.attending_nephrologist IS NULL OR v_medical.prescribed_dialysis_frequency IS NULL THEN
    RAISE EXCEPTION 'Complete your medical profile before booking.';
  END IF;

  SELECT array_agg(req) INTO v_missing_docs
  FROM unnest(ARRAY(SELECT jsonb_array_elements_text(v_cfg -> 'required_document_types'))) req
  WHERE NOT EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.patient_id = v_patient.patient_id AND d.document_type = req AND d.is_current = true
      AND d.verification_status IN ('Pending','Verified') AND d.is_outdated = false
  );
  IF COALESCE(array_length(v_missing_docs,1),0) > 0 THEN
    RAISE EXCEPTION 'Submit the current required documents before booking: %.', array_to_string(v_missing_docs, ', ');
  END IF;

  PERFORM public.assert_booking_date(p_requested_date, p_requested_time);
  v_slot := public.config_slot(p_requested_time);
  PERFORM public.lock_schedule_slot(p_requested_date, p_requested_time);
  PERFORM public.internal_ensure_capacity(p_requested_date, p_requested_date);
  v_capacity := public.slot_remaining_capacity(p_requested_date, p_requested_time);
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'The selected date and time no longer have available capacity.'; END IF;

  IF EXISTS (
    SELECT 1 FROM public.appointments
    WHERE patient_id = v_patient.patient_id AND requested_date = p_requested_date
      AND requested_time = p_requested_time AND is_cancelled = false
      AND appointment_status IN ('Pending','Under Review','Confirmed')
  ) THEN
    RAISE EXCEPTION 'You already have an active appointment request for this date and time.';
  END IF;

  SELECT count(*)::int INTO v_open FROM public.appointments
  WHERE patient_id = v_patient.patient_id AND is_cancelled = false
    AND appointment_status IN ('Pending','Under Review') AND requested_date >= public.app_today();
  IF NOT COALESCE((v_cfg ->> 'allow_multiple_open_requests')::boolean, true)
     AND v_open >= COALESCE((v_cfg ->> 'max_open_requests')::int, 6) THEN
    RAISE EXCEPTION 'The maximum number of open appointment requests has been reached.';
  END IF;

  INSERT INTO public.appointments (
    patient_id, requested_date, requested_time, requested_start_time, requested_end_time,
    appointment_status, staff_remarks, status_history, request_type, submitted_by, original_details
  ) VALUES (
    v_patient.patient_id, p_requested_date, p_requested_time,
    (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
    'Pending', NULLIF(trim(COALESCE(p_notes,'')), ''),
    public.append_status_history('[]'::jsonb, 'Pending', 'Appointment Request Submitted',
      'Appointment request submitted through the Patient Panel.', jsonb_build_object('requested_time', p_requested_time)),
    'New', auth.uid(), jsonb_build_object('requested_date', p_requested_date, 'requested_time', p_requested_time)
  ) RETURNING appointment_id INTO v_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',v_id);
  PERFORM public.notify_patient(v_patient.patient_id, 'Appointment Request Received',
    format('We received your appointment request for %s, %s. Track its progress in Book Appointment.',
      to_char(p_requested_date,'Mon DD, YYYY'), COALESCE(v_slot ->> 'display', p_requested_time)),
    'Appointment Request', v_id, NULL, NULL, v_destination, 'Open appointment tracker');
  PERFORM public.notify_all_staff('New Appointment Request',
    format('New appointment request %s from %s for %s (%s).', left(v_id::text,8), v_patient.full_name,
      to_char(p_requested_date,'Mon DD, YYYY'), p_requested_time),
    'New Appointment Request', v_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',v_id));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Appointment Request Created', 'Appointments', v_id::text,
    jsonb_build_object('requested_date', p_requested_date, 'requested_time', p_requested_time, 'capacity_remaining_before', v_capacity));

  RETURN jsonb_build_object('success',true,'appointment_id',v_id,'status','Pending','remaining_capacity',v_capacity - 1);
END $$;

CREATE OR REPLACE FUNCTION public.set_appointment_status(
  p_appointment_id uuid, p_status text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_patient_user uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.is_active_staff() THEN RAISE EXCEPTION 'Unauthorized: active staff access required.'; END IF;
  IF p_status NOT IN ('Pending','Under Review','Confirmed','Rejected') THEN
    RAISE EXCEPTION 'Invalid appointment status. Use Pending, Under Review, Confirmed, or Rejected only.';
  END IF;
  IF p_status = 'Confirmed' THEN
    RAISE EXCEPTION 'Use the confirm-and-assign action so an authorized staff member records a machine.';
  END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled THEN RAISE EXCEPTION 'A processed cancellation is recorded for this appointment.'; END IF;
  IF p_status = 'Rejected' AND NULLIF(trim(COALESCE(p_remarks,'')),'') IS NULL THEN
    RAISE EXCEPTION 'A reason is required when rejecting an appointment.';
  END IF;

  UPDATE public.appointments SET
    appointment_status = p_status,
    processed_by = public.current_staff_id(),
    staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks),
    status_history = public.append_status_history(status_history, p_status, 'Status Updated', p_remarks, jsonb_build_object('previous_status', v_appt.appointment_status))
  WHERE appointment_id = p_appointment_id;

  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = v_appt.patient_id;
  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Appointment Status Updated',
    format('Your appointment %s status is now %s.%s', left(p_appointment_id::text,8), p_status,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    'Appointment Status Updated', p_appointment_id, NULL, NULL, v_destination, 'Open appointment tracker');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Appointment Status Changed', 'Appointments', p_appointment_id::text,
    jsonb_build_object('from', v_appt.appointment_status, 'to', p_status, 'remarks', p_remarks));
  RETURN jsonb_build_object('success',true,'appointment_id',p_appointment_id,'status',p_status);
END $$;

CREATE OR REPLACE FUNCTION public.assign_machine_and_confirm_appointment(
  p_appointment_id uuid, p_machine_id uuid, p_confirmed_date date,
  p_start_time time without time zone, p_end_time time without time zone,
  p_remarks text DEFAULT NULL, p_slot_id text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_machine public.dialysis_machines%ROWTYPE;
  v_slot public.machine_slots%ROWTYPE; v_slot_cfg jsonb; v_capacity int;
  v_missing text[]; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN
    RAISE EXCEPTION 'Unauthorized: staff appointment-management permission required.';
  END IF;
  SELECT * INTO v_machine FROM public.dialysis_machines WHERE machine_id = p_machine_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Selected dialysis machine not found.'; END IF;
  IF v_machine.is_active = false OR v_machine.machine_status IN ('Maintenance','Offline','Unavailable') THEN
    RAISE EXCEPTION 'Machine % is % and cannot be assigned.', v_machine.machine_code, v_machine.machine_status;
  END IF;

  v_slot_cfg := public.config_slot(p_slot_id);
  IF v_slot_cfg IS NULL THEN
    SELECT value INTO v_slot_cfg FROM jsonb_array_elements(public.get_system_config() -> 'time_slots')
    WHERE (value ->> 'start_time')::time = p_start_time AND (value ->> 'end_time')::time = p_end_time LIMIT 1;
  END IF;
  IF v_slot_cfg IS NULL THEN RAISE EXCEPTION 'Confirmed time must match a configured appointment slot.'; END IF;
  p_slot_id := v_slot_cfg ->> 'id';
  p_start_time := (v_slot_cfg ->> 'start_time')::time;
  p_end_time := (v_slot_cfg ->> 'end_time')::time;
  PERFORM public.assert_booking_date(p_confirmed_date, p_slot_id);
  PERFORM public.lock_schedule_slot(p_confirmed_date, p_slot_id);
  PERFORM public.internal_ensure_capacity(p_confirmed_date, p_confirmed_date);

  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled THEN RAISE EXCEPTION 'Cannot confirm an appointment with a processed cancellation.'; END IF;
  IF v_appt.appointment_status = 'Rejected' THEN RAISE EXCEPTION 'Cannot confirm a rejected appointment.'; END IF;

  v_missing := public.missing_verified_documents(v_appt.patient_id);
  IF array_length(v_missing,1) > 0 THEN
    RAISE EXCEPTION 'All current required documents must be verified before confirmation. Missing: %.', array_to_string(v_missing, ', ');
  END IF;

  v_capacity := public.slot_remaining_capacity(p_confirmed_date, p_slot_id);
  IF v_appt.machine_slot_id IS NULL AND v_appt.requested_date = p_confirmed_date
     AND v_appt.requested_time = p_slot_id AND v_appt.appointment_status IN ('Pending','Under Review') THEN
    v_capacity := v_capacity + 1;
  END IF;
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'No eligible machine capacity remains for this date and time.'; END IF;

  SELECT * INTO v_slot FROM public.machine_slots
  WHERE machine_id = p_machine_id AND schedule_date = p_confirmed_date
    AND start_time = p_start_time AND end_time = p_end_time AND slot_key = p_slot_id
    AND slot_status IN ('Available','Reserved','Booked')
    AND (appointment_id IS NULL OR appointment_id = p_appointment_id)
  ORDER BY slot_status = 'Available' DESC, created_at ASC
  FOR UPDATE SKIP LOCKED LIMIT 1;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'No available machine slot exists for % on % (%). Reassign or generate capacity first.',
      v_machine.machine_code, p_confirmed_date, p_slot_id;
  END IF;

  IF v_appt.machine_slot_id IS NOT NULL AND v_appt.machine_slot_id <> v_slot.machine_slot_id THEN
    PERFORM public.release_machine_slot(p_appointment_id);
  END IF;

  UPDATE public.machine_slots SET slot_status = 'Booked', appointment_id = p_appointment_id
  WHERE machine_slot_id = v_slot.machine_slot_id;

  UPDATE public.appointments SET
    machine_slot_id = v_slot.machine_slot_id,
    processed_by = public.current_staff_id(),
    confirmed_date = p_confirmed_date,
    confirmed_start_time = p_start_time,
    confirmed_end_time = p_end_time,
    appointment_status = 'Confirmed',
    reschedule_requested = false,
    reschedule_request = CASE WHEN reschedule_request = '{}'::jsonb THEN reschedule_request
      ELSE reschedule_request || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id()) END,
    staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks),
    machine_snapshot = jsonb_build_object('machine_code',v_machine.machine_code,'machine_name',v_machine.machine_name,
      'schedule_date',p_confirmed_date,'start_time',p_start_time,'end_time',p_end_time),
    status_history = public.append_status_history(status_history,'Confirmed','Appointment Confirmed',
      COALESCE(p_remarks,'Appointment approved and dialysis machine assigned.'),
      jsonb_build_object('machine_code',v_machine.machine_code,'confirmed_date',p_confirmed_date,'slot_id',p_slot_id))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Appointment Confirmed',
    format('Your appointment %s is confirmed for %s, %s. Assigned machine: %s.',
      left(p_appointment_id::text,8), to_char(p_confirmed_date,'Mon DD, YYYY'),
      v_slot_cfg ->> 'display', v_machine.machine_code),
    'Appointment Confirmed', p_appointment_id, NULL, NULL, v_destination, 'Open confirmed appointment');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Appointment Confirmed & Machine Assigned', 'Appointments', p_appointment_id::text,
    jsonb_build_object('machine_code',v_machine.machine_code,'confirmed_date',p_confirmed_date,
      'start_time',p_start_time,'end_time',p_end_time,'slot_id',p_slot_id,'capacity_before',v_capacity));
  RETURN jsonb_build_object('success',true,'appointment_id',p_appointment_id,'machine_slot_id',v_slot.machine_slot_id,'machine_code',v_machine.machine_code);
END $$;

CREATE OR REPLACE FUNCTION public.request_document_correction(
  p_appointment_id uuid, p_document_type text, p_notes text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_doc public.patient_documents%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('verify_documents') THEN RAISE EXCEPTION 'Unauthorized: document verification permission required.'; END IF;
  IF NULLIF(trim(COALESCE(p_notes,'')),'') IS NULL THEN RAISE EXCEPTION 'Provide a correction notice for the patient.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  SELECT * INTO v_doc FROM public.patient_documents
  WHERE patient_id = v_appt.patient_id AND document_type = p_document_type AND is_current = true
  ORDER BY uploaded_at DESC LIMIT 1 FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Current % document was not found.', p_document_type; END IF;

  UPDATE public.patient_documents SET
    verification_status = 'Needs Correction', remarks = p_notes, reviewed_by = public.current_staff_id(),
    reviewed_at = now(), correction_requested = true, correction_notes = p_notes,
    correction_requested_by = public.current_staff_id(), correction_requested_at = now(), is_outdated = true
  WHERE document_id = v_doc.document_id;

  UPDATE public.appointments SET
    appointment_status = 'Under Review',
    processed_by = public.current_staff_id(),
    correction_request = jsonb_build_object('document_type',p_document_type,'document_id',v_doc.document_id,
      'notes',p_notes,'requested_at',now(),'requested_by',public.current_staff_id(),'status','Open'),
    status_history = public.append_status_history(status_history,'Under Review','Document Correction Requested',p_notes,
      jsonb_build_object('document_id',v_doc.document_id,'document_type',p_document_type))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',v_doc.document_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Document Correction Required',
    format('Please submit an updated %s. Staff notice: %s', p_document_type, p_notes),
    'Document Correction Required', p_appointment_id, v_doc.document_id, NULL, v_destination, 'Open document');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Document Correction Requested', 'Documents', v_doc.document_id::text,
    jsonb_build_object('appointment_id',p_appointment_id,'document_type',p_document_type,'notes',p_notes));
  RETURN jsonb_build_object('success',true,'appointment_status','Under Review','document_id',v_doc.document_id);
END $$;

CREATE OR REPLACE FUNCTION public.request_reschedule(
  p_appointment_id uuid, p_new_date date, p_new_time text, p_reason text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_cfg jsonb := public.get_system_config(); v_slot jsonb;
        v_patient_user uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the staff rescheduling workflow for operational changes.'; END IF;
  SELECT * INTO v_appt FROM public.appointments
  WHERE appointment_id = p_appointment_id AND patient_id = public.current_patient_id() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled OR v_appt.appointment_status = 'Rejected' THEN
    RAISE EXCEPTION 'This appointment cannot be rescheduled.';
  END IF;
  IF v_appt.reschedule_requested THEN RAISE EXCEPTION 'A rescheduling request is already awaiting staff review.'; END IF;
  PERFORM public.assert_booking_date(p_new_date, p_new_time);
  v_slot := public.config_slot(p_new_time);
  PERFORM public.lock_schedule_slot(p_new_date, p_new_time);
  PERFORM public.internal_ensure_capacity(p_new_date, p_new_date);
  IF public.slot_remaining_capacity(p_new_date, p_new_time) <= 0 THEN
    RAISE EXCEPTION 'The requested new date and time have no remaining capacity.';
  END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    reschedule_request = jsonb_build_object(
      'status','Pending','requested_at',now(),'requested_by',auth.uid(),'reason',p_reason,
      'original_date',v_appt.requested_date,'original_time',v_appt.requested_time,
      'original_confirmed_date',v_appt.confirmed_date,'original_machine_slot_id',v_appt.machine_slot_id,
      'new_date',p_new_date,'new_time',p_new_time,'new_start_time',(v_slot ->> 'start_time')::time,
      'new_end_time',(v_slot ->> 'end_time')::time),
    reschedule_requested = true, reschedule_notes = p_reason,
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Requested',
      COALESCE(p_reason,'Patient requested a new appointment date and time.'),
      jsonb_build_object('new_date',p_new_date,'new_time',p_new_time))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = v_appt.patient_id;
  PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Request Sent',
    format('Your request to move appointment %s to %s (%s) is awaiting staff review.',
      left(p_appointment_id::text,8), to_char(p_new_date,'Mon DD, YYYY'), v_slot ->> 'display'),
    'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  PERFORM public.notify_all_staff('Rescheduling Request',
    format('Rescheduling request for appointment %s: %s (%s).', left(p_appointment_id::text,8), p_new_date, p_new_time),
    'Rescheduling Request', p_appointment_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id,'action','reschedule'));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Rescheduling Requested', 'Appointments', p_appointment_id::text,
    jsonb_build_object('new_date',p_new_date,'new_time',p_new_time,'reason',p_reason));
  RETURN jsonb_build_object('success',true,'status','Pending','new_date',p_new_date,'new_time',p_new_time);
END $$;

CREATE OR REPLACE FUNCTION public.process_reschedule_request(
  p_appointment_id uuid, p_action text, p_machine_id uuid DEFAULT NULL,
  p_remarks text DEFAULT NULL, p_new_date date DEFAULT NULL, p_new_time text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_req jsonb; v_date date; v_time text; v_slot jsonb;
  v_capacity int; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_action NOT IN ('approve','deny') THEN RAISE EXCEPTION 'Action must be approve or deny.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF NOT v_appt.reschedule_requested OR COALESCE(v_appt.reschedule_request ->> 'status','') <> 'Pending' THEN
    RAISE EXCEPTION 'No pending rescheduling request was found.';
  END IF;
  v_req := v_appt.reschedule_request;
  v_date := COALESCE(p_new_date, (v_req ->> 'new_date')::date);
  v_time := COALESCE(p_new_time, v_req ->> 'new_time');

  IF p_action = 'deny' THEN
    UPDATE public.appointments SET
      reschedule_request = v_req || jsonb_build_object('status','Denied','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      reschedule_requested = false,
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Denied', p_remarks, v_req)
    WHERE appointment_id = p_appointment_id;
    v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
    PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Update',
      format('Your rescheduling request for appointment %s was not approved.%s', left(p_appointment_id::text,8),
        CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
      'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
    INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
    VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
      'Rescheduling Denied', 'Appointments', p_appointment_id::text, jsonb_build_object('remarks',p_remarks));
    RETURN jsonb_build_object('success',true,'action','deny','appointment_status',v_appt.appointment_status);
  END IF;

  PERFORM public.assert_booking_date(v_date, v_time);
  v_slot := public.config_slot(v_time);
  PERFORM public.lock_schedule_slot(v_date, v_time);
  PERFORM public.internal_ensure_capacity(v_date, v_date);
  v_capacity := public.slot_remaining_capacity(v_date, v_time);
  IF v_appt.machine_slot_id IS NULL AND v_appt.requested_date = v_date AND v_appt.requested_time = v_time THEN
    v_capacity := v_capacity + 1;
  END IF;
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'The new date and time have no remaining capacity.'; END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    requested_date = v_date, requested_time = v_time,
    requested_start_time = (v_slot ->> 'start_time')::time, requested_end_time = (v_slot ->> 'end_time')::time,
    request_type = 'Reschedule',
    reschedule_request = v_req || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id(),'approved_new_date',v_date,'approved_new_time',v_time,'remarks',p_remarks),
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Approved', p_remarks,
      jsonb_build_object('new_date',v_date,'new_time',v_time))
  WHERE appointment_id = p_appointment_id;

  IF v_appt.appointment_status = 'Confirmed' THEN
    IF p_machine_id IS NULL THEN RAISE EXCEPTION 'Select an available machine before approving a reschedule for a confirmed appointment.'; END IF;
    PERFORM public.assign_machine_and_confirm_appointment(
      p_appointment_id, p_machine_id, v_date, (v_slot ->> 'start_time')::time,
      (v_slot ->> 'end_time')::time, COALESCE(p_remarks,'Rescheduling approved by authorized staff.'), v_time);
  ELSE
    UPDATE public.appointments SET
      appointment_status = 'Under Review', processed_by = public.current_staff_id(),
      reschedule_requested = false,
      staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks)
    WHERE appointment_id = p_appointment_id;
  END IF;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Update',
    format('Your rescheduling request for appointment %s was approved for %s (%s).',
      left(p_appointment_id::text,8), to_char(v_date,'Mon DD, YYYY'), v_slot ->> 'display'),
    'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Rescheduling Approved', 'Appointments', p_appointment_id::text,
    jsonb_build_object('new_date',v_date,'new_time',v_time,'machine_id',p_machine_id,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'action','approve','new_date',v_date,'new_time',v_time);
END $$;

CREATE OR REPLACE FUNCTION public.request_cancellation(
  p_appointment_id uuid, p_reason text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the staff cancellation workflow for operational changes.'; END IF;
  SELECT * INTO v_appt FROM public.appointments
  WHERE appointment_id = p_appointment_id AND patient_id = public.current_patient_id() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled OR COALESCE(v_appt.cancellation_request ->> 'status','') = 'Pending' THEN
    RAISE EXCEPTION 'This appointment is already cancelled or has a pending cancellation request.';
  END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    cancellation_request = jsonb_build_object('status','Pending','reason',p_reason,'requested_at',now(),
      'requested_by',auth.uid(),'original_status',v_appt.appointment_status,'original_snapshot',public.appointment_snapshot(p_appointment_id)),
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Requested',
      COALESCE(p_reason,'Patient requested cancellation.'), '{}'::jsonb)
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Cancellation Request Sent',
    format('Your cancellation request for appointment %s is awaiting staff processing.', left(p_appointment_id::text,8)),
    'Cancellation Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  PERFORM public.notify_all_staff('Cancellation Request',
    format('Cancellation request for appointment %s. Reason: %s', left(p_appointment_id::text,8), COALESCE(p_reason,'Not specified')),
    'Cancellation Request', p_appointment_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id,'action','cancellation'));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Cancellation Requested', 'Appointments', p_appointment_id::text, jsonb_build_object('reason',p_reason));
  RETURN jsonb_build_object('success',true,'status','Pending');
END $$;

CREATE OR REPLACE FUNCTION public.process_cancellation_request(
  p_appointment_id uuid, p_action text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_req jsonb; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_action NOT IN ('approve','deny') THEN RAISE EXCEPTION 'Action must be approve or deny.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF COALESCE(v_appt.cancellation_request ->> 'status','') <> 'Pending' THEN
    RAISE EXCEPTION 'No pending cancellation request was found.';
  END IF;
  v_req := v_appt.cancellation_request;

  IF p_action = 'deny' THEN
    UPDATE public.appointments SET
      cancellation_request = v_req || jsonb_build_object('status','Denied','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Denied', p_remarks, v_req)
    WHERE appointment_id = p_appointment_id;
  ELSE
    PERFORM public.release_machine_slot(p_appointment_id);
    UPDATE public.appointments SET
      is_cancelled = true, cancelled_at = now(),
      cancellation_reason = COALESCE(v_req ->> 'reason', p_remarks),
      cancelled_by_role = COALESCE((SELECT role FROM public.staff WHERE staff_id = public.current_staff_id()), 'staff'),
      cancellation_request = v_req || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Processed',
        COALESCE(p_remarks,'Cancellation processed and capacity released.'), v_req)
    WHERE appointment_id = p_appointment_id;
  END IF;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Cancellation Update',
    format('Your cancellation request for appointment %s was %s.%s', left(p_appointment_id::text,8),
      CASE WHEN p_action='approve' THEN 'processed' ELSE 'not approved' END,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    'Cancellation Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_action='approve' THEN 'Cancellation Processed' ELSE 'Cancellation Denied' END,
    'Appointments', p_appointment_id::text, jsonb_build_object('action',p_action,'remarks',p_remarks,'released_capacity',p_action='approve'));
  RETURN jsonb_build_object('success',true,'action',p_action,'is_cancelled',p_action='approve');
END $$;

CREATE OR REPLACE FUNCTION public.record_appointment_attendance(
  p_appointment_id uuid, p_attendance_flag text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_old text; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('record_sessions') THEN RAISE EXCEPTION 'Unauthorized: attendance-recording permission required.'; END IF;
  IF p_attendance_flag NOT IN ('Scheduled','Attended','No-Show') THEN RAISE EXCEPTION 'Invalid attendance outcome.'; END IF;
  SELECT attendance_flag INTO v_old FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  UPDATE public.appointments SET
    attendance_flag = p_attendance_flag, attendance_recorded_by = public.current_staff_id(),
    attendance_recorded_at = now(), staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks)
  WHERE appointment_id = p_appointment_id;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Attendance Recorded', 'Appointments', p_appointment_id::text,
    jsonb_build_object('from',v_old,'to',p_attendance_flag,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'attendance_flag',p_attendance_flag);
END $$;

CREATE OR REPLACE FUNCTION public.generate_recurring_appointments(
  p_patient_id uuid, p_recurring_days text[], p_preferred_time text,
  p_start_date date, p_end_date date
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_cfg jsonb := public.get_system_config(); v_days int[]; v_day_nums int[];
  v_day date; v_slot jsonb; v_group uuid := gen_random_uuid(); v_id uuid;
  v_generated jsonb := '[]'::jsonb; v_skipped jsonb := '[]'::jsonb;
  v_conflict int; v_capacity int; v_patient_user uuid; v_frequency text;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Select a valid date range of up to 120 days.';
  END IF;
  IF p_start_date < public.app_today() THEN RAISE EXCEPTION 'Recurring suggestions cannot start in the past.'; END IF;
  v_slot := public.config_slot(p_preferred_time);
  IF v_slot IS NULL THEN RAISE EXCEPTION 'Select a configured preferred time.'; END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  SELECT array_agg(CASE d WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
    WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 END)
  INTO v_day_nums FROM unnest(COALESCE(p_recurring_days, ARRAY[]::text[])) d;
  IF v_day_nums IS NULL OR array_position(v_day_nums, NULL) IS NOT NULL
     OR EXISTS (SELECT 1 FROM unnest(v_day_nums) d WHERE NOT (d = ANY(v_days))) THEN
    RAISE EXCEPTION 'Recurring days must be configured operating days; Sundays are excluded.';
  END IF;

  SELECT prescribed_dialysis_frequency INTO v_frequency
  FROM public.patient_medical_profiles WHERE patient_id = p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Complete the patient medical profile before generating recurring suggestions.'; END IF;

  UPDATE public.patient_medical_profiles
  SET recurring_days = COALESCE(p_recurring_days, ARRAY[]::text[]),
      preferred_time = p_preferred_time,
      profile_updated_by = auth.uid()
  WHERE patient_id = p_patient_id;

  PERFORM public.internal_ensure_capacity(p_start_date, p_end_date);
  FOR v_day IN SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date LOOP
    CONTINUE WHEN NOT (EXTRACT(ISODOW FROM v_day)::int = ANY(v_day_nums));
    PERFORM public.lock_schedule_slot(v_day, p_preferred_time);
    SELECT count(*)::int INTO v_conflict FROM public.appointments
    WHERE patient_id = p_patient_id AND requested_date = v_day AND requested_time = p_preferred_time
      AND is_cancelled = false AND appointment_status IN ('Pending','Under Review','Confirmed');
    IF v_conflict > 0 THEN
      v_skipped := v_skipped || jsonb_build_array(jsonb_build_object('date',v_day,'reason','Existing appointment conflict'));
      CONTINUE;
    END IF;
    v_capacity := public.slot_remaining_capacity(v_day, p_preferred_time);
    IF v_capacity <= 0 THEN
      v_skipped := v_skipped || jsonb_build_array(jsonb_build_object('date',v_day,'reason','No machine capacity'));
      CONTINUE;
    END IF;

    INSERT INTO public.appointments (
      patient_id, requested_date, requested_time, requested_start_time, requested_end_time,
      appointment_status, recurrence_group_id, is_recurring, status_history, request_type, submitted_by
    ) VALUES (
      p_patient_id, v_day, p_preferred_time, (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
      'Pending', v_group, true,
      public.append_status_history('[]'::jsonb,'Pending','Recurring Appointment Suggestion Generated',
        format('Staff-reviewed recurring suggestion. Prescribed frequency: %s. Days: %s.',
          COALESCE(v_frequency,'Not recorded'), array_to_string(p_recurring_days,', ')),
        jsonb_build_object('recurrence_group_id',v_group,'preferred_time',p_preferred_time)),
      'New', auth.uid()
    ) RETURNING appointment_id INTO v_id;
    v_generated := v_generated || jsonb_build_array(jsonb_build_object('date',v_day,'appointment_id',v_id,'time',p_preferred_time));
  END LOOP;

  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = p_patient_id;
  IF v_patient_user IS NOT NULL THEN
    v_destination := jsonb_build_object('panel','patient','section','book-appointment','recurrence_group_id',v_group);
    PERFORM public.notify_patient(p_patient_id, 'Recurring Appointment Requests Generated',
      format('%s appointment request(s) were prepared by authorized staff for your review.', jsonb_array_length(v_generated)),
      'Appointment Request', NULL, NULL, NULL, v_destination, 'Open appointments');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Recurring Appointment Suggestions Generated', 'Appointments', v_group::text,
    jsonb_build_object('patient_id',p_patient_id,'days',p_recurring_days,'preferred_time',p_preferred_time,
      'prescribed_frequency',v_frequency,'generated',v_generated,'skipped',v_skipped));
  RETURN jsonb_build_object('success',true,'recurrence_group_id',v_group,'generated',v_generated,'skipped',v_skipped,
    'note','These are Pending requests. Staff must still verify documents and assign machines before confirmation.');
END $$;

-- Function privileges: public workflow RPCs; internal helpers are not exposed to clients.
DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'create_appointment_request(date,text,text)',
    'set_appointment_status(uuid,text,text)',
    'assign_machine_and_confirm_appointment(uuid,uuid,date,time without time zone,time without time zone,text,text)',
    'request_document_correction(uuid,text,text)',
    'request_reschedule(uuid,date,text,text)',
    'process_reschedule_request(uuid,text,uuid,text,date,text)',
    'request_cancellation(uuid,text)',
    'process_cancellation_request(uuid,text,text)',
    'record_appointment_attendance(uuid,text,text)',
    'generate_recurring_appointments(uuid,text[],text,date,date)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY[
    'config_slot(text)','assert_booking_date(date,text)','append_status_history(jsonb,text,text,text,jsonb)',
    'appointment_snapshot(uuid)','notify_patient(uuid,text,text,text,uuid,uuid,uuid,jsonb,text)',
    'lock_schedule_slot(date,text)','missing_verified_documents(uuid)','release_machine_slot(uuid)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;

-- Reliance Dialysis Center Inc. — private document workflow, official dialysis records, record release and detail bundles

CREATE OR REPLACE FUNCTION public.register_patient_document(
  p_document_type text, p_file_path text, p_file_name text,
  p_file_size bigint, p_mime_type text, p_replaces_document_id uuid DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
DECLARE
  v_patient public.patients%ROWTYPE; v_old public.patient_documents%ROWTYPE;
  v_required text[]; v_id uuid; v_version int := 1; v_appointment uuid;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the authorized medical file workflow for staff uploads.'; END IF;
  SELECT * INTO v_patient FROM public.patients WHERE patient_id = public.current_patient_id();
  IF v_patient.patient_id IS NULL THEN RAISE EXCEPTION 'Active patient account required.'; END IF;

  SELECT array_agg(value) INTO v_required FROM jsonb_array_elements_text(public.get_system_config() -> 'required_document_types');
  IF NOT (p_document_type = ANY(v_required)) THEN RAISE EXCEPTION 'Select one of the four required document categories.'; END IF;
  IF p_file_path IS NULL OR p_file_path = '' OR p_file_path LIKE '%..%' OR p_file_path NOT LIKE auth.uid()::text || '/%' THEN
    RAISE EXCEPTION 'Invalid private document path.';
  END IF;
  IF COALESCE(p_file_size,0) <= 0 OR p_file_size > 10485760 THEN RAISE EXCEPTION 'File size must be greater than zero and no larger than 10 MB.'; END IF;
  IF p_mime_type NOT IN ('application/pdf','image/jpeg','image/png','image/webp') THEN
    RAISE EXCEPTION 'Allowed file types are PDF, JPEG, PNG, and WebP.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM storage.objects WHERE bucket_id = 'patient-documents' AND name = p_file_path) THEN
    RAISE EXCEPTION 'The uploaded file was not found in private Storage. Please upload it again.';
  END IF;

  IF p_replaces_document_id IS NOT NULL THEN
    SELECT * INTO v_old FROM public.patient_documents
    WHERE document_id = p_replaces_document_id AND patient_id = v_patient.patient_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Document to replace was not found.'; END IF;
    IF v_old.verification_status = 'Verified' AND v_old.correction_requested = false AND v_old.is_outdated = false THEN
      RAISE EXCEPTION 'Verified documents remain available for succeeding bookings. Replacement requires a staff update request.';
    END IF;
  ELSE
    SELECT * INTO v_old FROM public.patient_documents
    WHERE patient_id = v_patient.patient_id AND document_type = p_document_type AND is_current = true
    ORDER BY uploaded_at DESC LIMIT 1 FOR UPDATE;
    IF FOUND AND v_old.verification_status = 'Verified' AND v_old.correction_requested = false AND v_old.is_outdated = false THEN
      RAISE EXCEPTION 'This document is already verified and can be reused. Ask the center if an updated copy is required.';
    END IF;
  END IF;

  IF v_old.document_id IS NOT NULL THEN
    v_version := v_old.version + 1;
    UPDATE public.patient_documents
    SET is_current = false, is_outdated = true
    WHERE document_id = v_old.document_id;
  END IF;

  INSERT INTO public.patient_documents (
    patient_id, document_type, file_path, file_name, file_size, mime_type, storage_bucket,
    uploaded_by, verification_status, is_released_to_patient, is_current, version,
    replaces_document_id, created_at, updated_at
  ) VALUES (
    v_patient.patient_id, p_document_type, p_file_path, p_file_name, p_file_size, p_mime_type,
    'patient-documents', auth.uid(), 'Pending', true, true, v_version,
    v_old.document_id, now(), now()
  ) RETURNING document_id INTO v_id;

  SELECT appointment_id INTO v_appointment FROM public.appointments
  WHERE patient_id = v_patient.patient_id AND is_cancelled = false
    AND appointment_status IN ('Pending','Under Review','Confirmed')
  ORDER BY created_at DESC LIMIT 1;

  PERFORM public.notify_all_staff(
    CASE WHEN v_old.document_id IS NULL THEN 'New Document Submission' ELSE 'Corrected Document Submitted' END,
    format('%s submitted %s (%s).', v_patient.full_name, p_document_type, p_file_name),
    CASE WHEN v_old.document_id IS NULL THEN 'New Document Submission' ELSE 'Corrected Document Submitted' END,
    v_appointment,
    jsonb_build_object('panel','staff','section','patient-record','patient_id',v_patient.patient_id,
      'document_id',v_id,'tab','documents','appointment_id',v_appointment)
  );

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Patient Document Uploaded', 'Documents', v_id::text,
    jsonb_build_object('document_type',p_document_type,'file_name',p_file_name,'file_size',p_file_size,
      'mime_type',p_mime_type,'version',v_version,'replaces',v_old.document_id));
  RETURN jsonb_build_object('success',true,'document_id',v_id,'verification_status','Pending','version',v_version);
END $$;

CREATE OR REPLACE FUNCTION public.verify_document(
  p_document_id uuid, p_status text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_doc public.patient_documents%ROWTYPE; v_title text; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('verify_documents') THEN RAISE EXCEPTION 'Unauthorized: document verification permission required.'; END IF;
  IF p_status NOT IN ('Verified','Needs Correction','Rejected') THEN RAISE EXCEPTION 'Invalid document verification status.'; END IF;
  IF p_status <> 'Verified' AND NULLIF(trim(COALESCE(p_remarks,'')),'') IS NULL THEN
    RAISE EXCEPTION 'Provide remarks when rejecting a document or requesting correction.';
  END IF;
  SELECT * INTO v_doc FROM public.patient_documents WHERE document_id = p_document_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Document not found.'; END IF;

  UPDATE public.patient_documents SET
    verification_status = p_status, remarks = p_remarks,
    reviewed_by = public.current_staff_id(), reviewed_at = now(),
    correction_requested = p_status <> 'Verified',
    correction_notes = CASE WHEN p_status = 'Verified' THEN NULL ELSE p_remarks END,
    correction_requested_by = CASE WHEN p_status = 'Verified' THEN NULL ELSE public.current_staff_id() END,
    correction_requested_at = CASE WHEN p_status = 'Verified' THEN NULL ELSE now() END,
    is_outdated = p_status <> 'Verified',
    is_released_to_patient = true
  WHERE document_id = p_document_id;

  v_title := CASE p_status WHEN 'Verified' THEN 'Document Verified'
    WHEN 'Needs Correction' THEN 'Document Correction Required' ELSE 'Document Rejected' END;
  v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',p_document_id);
  PERFORM public.notify_patient(v_doc.patient_id, v_title,
    format('Your %s was marked %s.%s', v_doc.document_type, p_status,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    v_title, NULL, p_document_id, NULL, v_destination, 'Open document');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE p_status WHEN 'Verified' THEN 'Document Verified' ELSE 'Document Verification Action' END,
    'Documents', p_document_id::text, jsonb_build_object('status',p_status,'remarks',p_remarks,'document_type',v_doc.document_type));
  RETURN jsonb_build_object('success',true,'document_id',p_document_id,'verification_status',p_status);
END $$;

CREATE OR REPLACE FUNCTION public.register_authorized_medical_file(
  p_patient_id uuid, p_file_path text, p_file_name text, p_file_size bigint,
  p_mime_type text, p_is_released boolean DEFAULT false, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
DECLARE v_patient public.patients%ROWTYPE; v_id uuid; v_version int; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('release_records') THEN RAISE EXCEPTION 'Unauthorized: record-release permission required.'; END IF;
  SELECT * INTO v_patient FROM public.patients WHERE patient_id = p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Patient not found.'; END IF;
  IF p_file_path IS NULL OR p_file_path LIKE '%..%' OR p_file_path NOT LIKE v_patient.user_id::text || '/%' THEN
    RAISE EXCEPTION 'Invalid authorized medical file path.';
  END IF;
  IF COALESCE(p_file_size,0) <= 0 OR p_file_size > 10485760 THEN RAISE EXCEPTION 'File size must be no larger than 10 MB.'; END IF;
  IF p_mime_type NOT IN ('application/pdf','image/jpeg','image/png','image/webp') THEN RAISE EXCEPTION 'Unsupported file type.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM storage.objects WHERE bucket_id = 'authorized-medical-files' AND name = p_file_path) THEN
    RAISE EXCEPTION 'The uploaded file was not found in private Storage.';
  END IF;
  SELECT COALESCE(max(version),0) + 1 INTO v_version FROM public.patient_documents
  WHERE patient_id = p_patient_id AND document_type = 'Authorized Medical Record';

  INSERT INTO public.patient_documents (
    patient_id, document_type, file_path, file_name, file_size, mime_type, storage_bucket,
    uploaded_by, verification_status, reviewed_by, reviewed_at, remarks,
    is_released_to_patient, is_current, version
  ) VALUES (
    p_patient_id, 'Authorized Medical Record', p_file_path, p_file_name, p_file_size, p_mime_type,
    'authorized-medical-files', auth.uid(), 'Verified', public.current_staff_id(), now(), p_remarks,
    COALESCE(p_is_released,false), true, v_version
  ) RETURNING document_id INTO v_id;

  IF COALESCE(p_is_released,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',v_id);
    PERFORM public.notify_patient(p_patient_id, 'New Medical Record',
      'An authorized medical file has been released to your records.',
      'New Medical Record', NULL, v_id, NULL, v_destination, 'Open medical record');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Authorized Medical File Uploaded', 'Documents', v_id::text,
    jsonb_build_object('patient_id',p_patient_id,'file_name',p_file_name,'released',p_is_released));
  RETURN jsonb_build_object('success',true,'document_id',v_id,'is_released',COALESCE(p_is_released,false));
END $$;

CREATE OR REPLACE FUNCTION public.set_document_release(
  p_document_id uuid, p_release boolean, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_doc public.patient_documents%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('release_records') THEN RAISE EXCEPTION 'Unauthorized: record-release permission required.'; END IF;
  SELECT * INTO v_doc FROM public.patient_documents WHERE document_id = p_document_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Document not found.'; END IF;
  UPDATE public.patient_documents SET
    is_released_to_patient = COALESCE(p_release,false),
    remarks = COALESCE(NULLIF(trim(p_remarks),''), remarks),
    reviewed_by = public.current_staff_id(), reviewed_at = now()
  WHERE document_id = p_document_id;
  IF COALESCE(p_release,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',p_document_id);
    PERFORM public.notify_patient(v_doc.patient_id, 'New Medical Record',
      'An authorized medical document is now available in My Records.',
      'New Medical Record', NULL, p_document_id, NULL, v_destination, 'Open medical record');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Document Release Changed', 'Documents', p_document_id::text,
    jsonb_build_object('released',p_release,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'is_released',COALESCE(p_release,false));
END $$;

CREATE OR REPLACE FUNCTION public.record_dialysis_session(
  p_appointment_id uuid, p_treatment_date date, p_start_time time without time zone,
  p_end_time time without time zone, p_pre_weight numeric DEFAULT NULL,
  p_post_weight numeric DEFAULT NULL, p_bp_pre text DEFAULT NULL, p_bp_post text DEFAULT NULL,
  p_ultrafiltration numeric DEFAULT NULL, p_session_status text DEFAULT 'Completed',
  p_treatment_notes text DEFAULT NULL, p_patient_visible_notes text DEFAULT NULL,
  p_is_released boolean DEFAULT false, p_released_remarks text DEFAULT NULL,
  p_attendance_flag text DEFAULT 'Attended'
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_machine_id uuid; v_id uuid;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('record_sessions') THEN RAISE EXCEPTION 'Unauthorized: session-recording permission required.'; END IF;
  IF p_end_time <= p_start_time THEN RAISE EXCEPTION 'Actual end time must be later than actual start time.'; END IF;
  IF p_attendance_flag NOT IN ('Scheduled','Attended','No-Show') THEN RAISE EXCEPTION 'Select an explicit attendance outcome.'; END IF;
  IF p_session_status NOT IN ('In Progress','Completed','Terminated Early') THEN RAISE EXCEPTION 'Invalid session status.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;

  SELECT ms.machine_id INTO v_machine_id
  FROM public.machine_slots ms WHERE ms.machine_slot_id = v_appt.machine_slot_id;
  IF v_machine_id IS NULL THEN
    SELECT m.machine_id INTO v_machine_id FROM public.dialysis_machines m
    WHERE m.machine_code = v_appt.machine_snapshot ->> 'machine_code' LIMIT 1;
  END IF;
  IF v_machine_id IS NULL THEN RAISE EXCEPTION 'Assign a machine to the appointment before recording a dialysis session.'; END IF;

  INSERT INTO public.dialysis_sessions (
    appointment_id, patient_id, machine_id, recorded_by, treatment_date, actual_start_time, actual_end_time,
    pre_dialysis_weight, post_dialysis_weight, blood_pressure_pre, blood_pressure_post, ultrafiltration_volume,
    session_status, is_released_to_patient, released_at, released_by, released_remarks,
    patient_visible_notes, treatment_notes
  ) VALUES (
    p_appointment_id, v_appt.patient_id, v_machine_id, public.current_staff_id(), p_treatment_date,
    p_start_time, p_end_time, p_pre_weight, p_post_weight, p_bp_pre, p_bp_post, p_ultrafiltration,
    p_session_status, COALESCE(p_is_released,false),
    CASE WHEN COALESCE(p_is_released,false) THEN now() ELSE NULL END,
    CASE WHEN COALESCE(p_is_released,false) THEN public.current_staff_id() ELSE NULL END,
    p_released_remarks, p_patient_visible_notes, p_treatment_notes
  ) ON CONFLICT (appointment_id) DO UPDATE SET
    patient_id = EXCLUDED.patient_id, machine_id = EXCLUDED.machine_id, recorded_by = EXCLUDED.recorded_by,
    treatment_date = EXCLUDED.treatment_date, actual_start_time = EXCLUDED.actual_start_time,
    actual_end_time = EXCLUDED.actual_end_time, pre_dialysis_weight = EXCLUDED.pre_dialysis_weight,
    post_dialysis_weight = EXCLUDED.post_dialysis_weight, blood_pressure_pre = EXCLUDED.blood_pressure_pre,
    blood_pressure_post = EXCLUDED.blood_pressure_post, ultrafiltration_volume = EXCLUDED.ultrafiltration_volume,
    session_status = EXCLUDED.session_status, is_released_to_patient = EXCLUDED.is_released_to_patient,
    released_at = EXCLUDED.released_at, released_by = EXCLUDED.released_by,
    released_remarks = EXCLUDED.released_remarks, patient_visible_notes = EXCLUDED.patient_visible_notes,
    treatment_notes = EXCLUDED.treatment_notes
  RETURNING session_id INTO v_id;

  UPDATE public.appointments SET
    attendance_flag = p_attendance_flag,
    attendance_recorded_by = public.current_staff_id(),
    attendance_recorded_at = now()
  WHERE appointment_id = p_appointment_id;

  UPDATE public.machine_slots SET slot_status = 'Completed'
  WHERE machine_slot_id = v_appt.machine_slot_id AND slot_status IN ('Booked','Reserved');

  IF COALESCE(p_is_released,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','history','session_id',v_id);
    PERFORM public.notify_patient(v_appt.patient_id, 'New Medical Record',
      format('Your dialysis session record for %s has been released.', to_char(p_treatment_date,'Mon DD, YYYY')),
      'New Medical Record', p_appointment_id, NULL, v_id, v_destination, 'Open session details');
  END IF;

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Dialysis Session Recorded', 'Dialysis Sessions', v_id::text,
    jsonb_build_object('appointment_id',p_appointment_id,'treatment_date',p_treatment_date,
      'session_status',p_session_status,'released',p_is_released,'attendance',p_attendance_flag));
  RETURN jsonb_build_object('success',true,'session_id',v_id,'is_released',COALESCE(p_is_released,false));
END $$;

CREATE OR REPLACE FUNCTION public.set_session_release(
  p_session_id uuid, p_release boolean, p_released_remarks text DEFAULT NULL,
  p_patient_visible_notes text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_session public.dialysis_sessions%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('release_records') THEN RAISE EXCEPTION 'Unauthorized: record-release permission required.'; END IF;
  SELECT * INTO v_session FROM public.dialysis_sessions WHERE session_id = p_session_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Session not found.'; END IF;
  UPDATE public.dialysis_sessions SET
    is_released_to_patient = COALESCE(p_release,false),
    released_at = CASE WHEN COALESCE(p_release,false) THEN now() ELSE NULL END,
    released_by = CASE WHEN COALESCE(p_release,false) THEN public.current_staff_id() ELSE NULL END,
    released_remarks = p_released_remarks,
    patient_visible_notes = COALESCE(p_patient_visible_notes, patient_visible_notes)
  WHERE session_id = p_session_id;
  IF COALESCE(p_release,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','history','session_id',p_session_id);
    PERFORM public.notify_patient(v_session.patient_id, 'New Medical Record',
      'An official dialysis session record has been released to your account.',
      'New Medical Record', v_session.appointment_id, NULL, p_session_id, v_destination, 'Open session details');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Dialysis Session Release Changed', 'Dialysis Sessions', p_session_id::text,
    jsonb_build_object('released',p_release,'remarks',p_released_remarks));
  RETURN jsonb_build_object('success',true,'session_id',p_session_id,'is_released',COALESCE(p_release,false));
END $$;

CREATE OR REPLACE FUNCTION public.assert_record_access(p_patient_id uuid)
RETURNS void LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required.'; END IF;
  IF NOT public.is_active_staff() AND p_patient_id IS DISTINCT FROM public.current_patient_id() THEN
    RAISE EXCEPTION 'You are not authorized to view this patient record.';
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.get_appointment_detail(p_appointment_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb; v_patient_id uuid;
BEGIN
  SELECT patient_id INTO v_patient_id FROM public.appointments WHERE appointment_id = p_appointment_id;
  IF v_patient_id IS NULL THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  PERFORM public.assert_record_access(v_patient_id);

  SELECT jsonb_build_object(
    'appointment', to_jsonb(a),
    'patient', to_jsonb(p),
    'medical_profile', COALESCE((SELECT to_jsonb(m) FROM public.patient_medical_profiles m WHERE m.patient_id = p.patient_id), '{}'::jsonb),
    'documents', COALESCE((
      SELECT jsonb_agg(to_jsonb(d) || jsonb_build_object(
        'reviewer_name', COALESCE((SELECT full_name FROM public.staff s WHERE s.staff_id = d.reviewed_by), '—')
      ) ORDER BY d.document_type, d.uploaded_at DESC)
      FROM public.patient_documents d WHERE d.patient_id = p.patient_id AND d.is_current = true), '[]'::jsonb),
    'machine', COALESCE((
      SELECT jsonb_build_object('machine_slot_id',ms.machine_slot_id,'machine_id',m.machine_id,
        'machine_code',m.machine_code,'machine_name',m.machine_name,'slot_status',ms.slot_status,
        'schedule_date',ms.schedule_date,'start_time',ms.start_time,'end_time',ms.end_time)
      FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
      WHERE ms.machine_slot_id = a.machine_slot_id), '{}'::jsonb),
    'processed_by_name', COALESCE((SELECT full_name FROM public.staff s WHERE s.staff_id = a.processed_by), '—'),
    'config', public.get_system_config()
  ) INTO v_result
  FROM public.appointments a JOIN public.patients p ON p.patient_id = a.patient_id
  WHERE a.appointment_id = p_appointment_id;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.get_patient_record(p_patient_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb;
BEGIN
  PERFORM public.assert_record_access(p_patient_id);
  SELECT jsonb_build_object(
    'patient', to_jsonb(p),
    'medical_profile', COALESCE((SELECT to_jsonb(m) FROM public.patient_medical_profiles m WHERE m.patient_id = p.patient_id), '{}'::jsonb),
    'documents', COALESCE((
      SELECT jsonb_agg(to_jsonb(d) || jsonb_build_object('reviewer_name',
        COALESCE((SELECT full_name FROM public.staff s WHERE s.staff_id = d.reviewed_by),'—'))
        ORDER BY d.uploaded_at DESC)
      FROM public.patient_documents d WHERE d.patient_id = p.patient_id), '[]'::jsonb),
    'appointments', COALESCE((
      SELECT jsonb_agg(to_jsonb(a) || jsonb_build_object('machine_code',
        COALESCE((SELECT m.machine_code FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id=ms.machine_id WHERE ms.machine_slot_id=a.machine_slot_id), a.machine_snapshot ->> 'machine_code','—'))
        ORDER BY a.created_at DESC)
      FROM public.appointments a WHERE a.patient_id = p.patient_id), '[]'::jsonb),
    'sessions', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) || jsonb_build_object('machine_code',
        COALESCE((SELECT machine_code FROM public.dialysis_machines m WHERE m.machine_id=s.machine_id),'—'),
        'recorded_by_name', COALESCE((SELECT full_name FROM public.staff st WHERE st.staff_id=s.recorded_by),'—'))
        ORDER BY s.treatment_date DESC)
      FROM public.dialysis_sessions s WHERE s.patient_id = p.patient_id), '[]'::jsonb)
  ) INTO v_result FROM public.patients p WHERE p.patient_id = p_patient_id;
  IF v_result IS NULL THEN RAISE EXCEPTION 'Patient not found.'; END IF;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.upsert_machine(
  p_machine_id uuid DEFAULT NULL, p_machine_code text DEFAULT NULL, p_machine_name text DEFAULT NULL,
  p_machine_status text DEFAULT 'Available', p_description text DEFAULT NULL,
  p_maintenance_remarks text DEFAULT NULL, p_daily_capacity integer DEFAULT NULL,
  p_is_active boolean DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_id uuid; v_capacity int; v_future int; v_active boolean; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_machines') THEN RAISE EXCEPTION 'Unauthorized: machine-management permission required.'; END IF;
  IF NULLIF(trim(COALESCE(p_machine_code,'')),'') IS NULL OR NULLIF(trim(COALESCE(p_machine_name,'')),'') IS NULL THEN
    RAISE EXCEPTION 'Machine code and machine name are required.';
  END IF;
  IF p_machine_status NOT IN ('Available','Occupied','Maintenance','Offline','Unavailable') THEN
    RAISE EXCEPTION 'Invalid machine status.';
  END IF;
  v_capacity := COALESCE(p_daily_capacity, jsonb_array_length(public.get_system_config() -> 'time_slots'));
  IF v_capacity < 1 THEN RAISE EXCEPTION 'Daily capacity must be at least one.'; END IF;
  v_active := COALESCE(p_is_active, p_machine_status NOT IN ('Offline','Unavailable'));

  IF p_machine_id IS NULL THEN
    IF EXISTS (SELECT 1 FROM public.dialysis_machines WHERE lower(machine_code)=lower(trim(p_machine_code))) THEN
      RAISE EXCEPTION 'Machine code % is already registered.', p_machine_code;
    END IF;
    INSERT INTO public.dialysis_machines (
      machine_code,machine_name,machine_status,description,maintenance_remarks,daily_capacity,
      is_active,maintenance_started_at,created_by,updated_by
    ) VALUES (
      trim(p_machine_code),trim(p_machine_name),p_machine_status,p_description,p_maintenance_remarks,
      v_capacity,v_active,CASE WHEN p_machine_status IN ('Maintenance','Offline','Unavailable') THEN now() ELSE NULL END,
      auth.uid(),auth.uid()
    ) RETURNING machine_id INTO v_id;
  ELSE
    SELECT machine_id INTO v_id FROM public.dialysis_machines WHERE machine_id = p_machine_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Machine not found.'; END IF;
    IF EXISTS (SELECT 1 FROM public.dialysis_machines
      WHERE lower(machine_code)=lower(trim(p_machine_code)) AND machine_id <> v_id) THEN
      RAISE EXCEPTION 'Machine code % is already registered.', p_machine_code;
    END IF;
    IF p_machine_status IN ('Maintenance','Offline','Unavailable') THEN
      SELECT count(*)::int INTO v_future FROM public.machine_slots
      WHERE machine_id = v_id AND schedule_date >= public.app_today()
        AND slot_status IN ('Booked','Reserved');
      IF v_future > 0 THEN
        RAISE EXCEPTION 'This machine has % future reserved appointment(s). Reassign those appointments before marking it unavailable.', v_future;
      END IF;
    END IF;
    UPDATE public.dialysis_machines SET
      machine_code = trim(p_machine_code), machine_name = trim(p_machine_name),
      machine_status = p_machine_status, description = p_description,
      maintenance_remarks = p_maintenance_remarks, daily_capacity = v_capacity,
      is_active = v_active,
      maintenance_started_at = CASE WHEN p_machine_status IN ('Maintenance','Offline','Unavailable') THEN COALESCE(maintenance_started_at, now()) ELSE NULL END,
      updated_by = auth.uid()
    WHERE machine_id = v_id;

    IF p_machine_status IN ('Maintenance','Offline','Unavailable') THEN
      UPDATE public.machine_slots SET slot_status = 'Maintenance'
      WHERE machine_id = v_id AND schedule_date >= public.app_today() AND slot_status IN ('Available','Reserved');
    ELSE
      UPDATE public.machine_slots SET slot_status = 'Available'
      WHERE machine_id = v_id AND schedule_date >= public.app_today() AND slot_status = 'Maintenance';
    END IF;
  END IF;

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_machine_id IS NULL THEN 'Machine Registered' ELSE 'Machine Status / Information Updated' END,
    'Machine Management', v_id::text,
    jsonb_build_object('machine_code',p_machine_code,'machine_status',p_machine_status,
      'daily_capacity',v_capacity,'maintenance_remarks',p_maintenance_remarks,'is_active',v_active));
  RETURN jsonb_build_object('success',true,'machine_id',v_id,'machine_status',p_machine_status);
END $$;

DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'register_patient_document(text,text,text,bigint,text,uuid)',
    'verify_document(uuid,text,text)',
    'register_authorized_medical_file(uuid,text,text,bigint,text,boolean,text)',
    'set_document_release(uuid,boolean,text)',
    'record_dialysis_session(uuid,date,time without time zone,time without time zone,numeric,numeric,text,text,numeric,text,text,text,boolean,text,text)',
    'set_session_release(uuid,boolean,text,text)',
    'get_appointment_detail(uuid)',
    'get_patient_record(uuid)',
    'upsert_machine(uuid,text,text,text,text,text,integer,boolean)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY['assert_record_access(uuid)'] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;

-- Reliance Dialysis Center Inc. — protected account operations and operational analytics from actual records

CREATE OR REPLACE FUNCTION public.admin_set_account_status(
  p_target_user_id uuid, p_status text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'auth'
AS $$
DECLARE v_email text; v_actor jsonb := public.current_actor(); v_role text;
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  IF p_status NOT IN ('Active','Inactive') THEN RAISE EXCEPTION 'Status must be Active or Inactive.'; END IF;
  IF p_target_user_id = auth.uid() AND p_status = 'Inactive' THEN
    RAISE EXCEPTION 'You cannot deactivate your own active Super Administrator account.';
  END IF;
  SELECT email INTO v_email FROM auth.users WHERE id = p_target_user_id;
  IF v_email IS NULL THEN RAISE EXCEPTION 'User account not found.'; END IF;

  UPDATE public.patients SET
    account_status = p_status,
    deactivated_at = CASE WHEN p_status = 'Inactive' THEN now() ELSE NULL END,
    deactivated_by = CASE WHEN p_status = 'Inactive' THEN auth.uid() ELSE NULL END
  WHERE user_id = p_target_user_id;
  UPDATE public.staff SET
    account_status = p_status,
    deactivated_at = CASE WHEN p_status = 'Inactive' THEN now() ELSE NULL END,
    deactivated_by = CASE WHEN p_status = 'Inactive' THEN auth.uid() ELSE NULL END
  WHERE user_id = p_target_user_id;

  UPDATE auth.users SET
    banned_until = CASE WHEN p_status = 'Inactive' THEN now() + interval '100 years' ELSE NULL END,
    updated_at = now()
  WHERE id = p_target_user_id;

  SELECT role INTO v_role FROM public.staff WHERE user_id = p_target_user_id;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details, severity)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_status='Active' THEN 'Account Activated' ELSE 'Account Deactivated' END,
    'User Management', p_target_user_id::text,
    jsonb_build_object('email',v_email,'status',p_status,'target_role',COALESCE(v_role,'patient')), 'Warning');
  RETURN jsonb_build_object('success',true,'user_id',p_target_user_id,'status',p_status);
END $$;

CREATE OR REPLACE FUNCTION public.admin_assign_user_role(
  p_target_user_id uuid, p_new_role text, p_position text DEFAULT 'Dialysis Nurse'
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'auth'
AS $$
DECLARE v_email text; v_name text; v_contact text; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  IF p_target_user_id = auth.uid() AND p_new_role <> 'super_admin' THEN
    RAISE EXCEPTION 'You cannot demote your own active Super Administrator account.';
  END IF;
  IF p_new_role NOT IN ('patient','staff','super_admin') THEN RAISE EXCEPTION 'Invalid authorized role.'; END IF;
  SELECT email, COALESCE(raw_user_meta_data ->> 'full_name', split_part(email,'@',1)) INTO v_email, v_name
  FROM auth.users WHERE id = p_target_user_id;
  IF v_email IS NULL THEN RAISE EXCEPTION 'User account not found.'; END IF;

  IF p_new_role IN ('staff','super_admin') THEN
    SELECT COALESCE(full_name,v_name), contact_number INTO v_name, v_contact
    FROM public.patients WHERE user_id = p_target_user_id;
    INSERT INTO public.staff (user_id,email,full_name,position,role,contact_number,account_status)
    VALUES (p_target_user_id,v_email,COALESCE(v_name,'Staff Member'),p_position,p_new_role,v_contact,'Active')
    ON CONFLICT (user_id) DO UPDATE SET
      role = EXCLUDED.role, position = EXCLUDED.position, account_status = 'Active',
      email = EXCLUDED.email, full_name = EXCLUDED.full_name;
    UPDATE public.patients SET account_status = 'Inactive' WHERE user_id = p_target_user_id;
  ELSE
    UPDATE public.staff SET account_status = 'Inactive' WHERE user_id = p_target_user_id;
    INSERT INTO public.patients (user_id,email,full_name,account_status)
    VALUES (p_target_user_id,v_email,v_name,'Active')
    ON CONFLICT (user_id) DO UPDATE SET account_status = 'Active', email = EXCLUDED.email;
  END IF;

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details, severity)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Updated User Authorized Role', 'User Management', p_target_user_id::text,
    jsonb_build_object('email',v_email,'new_role',p_new_role,'position',p_position), 'Warning');
  RETURN jsonb_build_object('success',true,'role',p_new_role);
END $$;

CREATE OR REPLACE FUNCTION public.get_staff_dashboard_stats()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_today date := public.app_today(); v_result jsonb;
BEGIN
  IF NOT public.is_active_staff() THEN RAISE EXCEPTION 'Unauthorized: active staff access required.'; END IF;
  SELECT jsonb_build_object(
    'today', v_today,
    'todays_appointments', (SELECT count(*)::int FROM public.appointments WHERE COALESCE(confirmed_date,requested_date)=v_today AND is_cancelled=false),
    'new_requests', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Pending' AND is_cancelled=false),
    'under_review', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Under Review' AND is_cancelled=false),
    'confirmed', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Confirmed' AND is_cancelled=false),
    'available_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE is_active=true AND machine_status IN ('Available','Occupied')),
    'occupied_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE machine_status='Occupied'),
    'documents_awaiting_verification', (SELECT count(*)::int FROM public.patient_documents WHERE is_current=true AND verification_status IN ('Pending','Needs Correction')),
    'completed_sessions_today', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date=v_today AND session_status='Completed'),
    'recent_activities', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('audit_id',audit_id,'activity',activity,'module',affected_module,
        'record_id',affected_record_id,'actor',COALESCE(actor_name,actor_email,'System'),'created_at',created_at)
        ORDER BY created_at DESC)
      FROM (SELECT * FROM public.audit_logs ORDER BY created_at DESC LIMIT 8) q), '[]'::jsonb)
  ) INTO v_result;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.get_analytics_bundle(
  p_start_date date, p_end_date date, p_granularity text DEFAULT 'daily'
) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_gran text; v_result jsonb; v_total_slots int; v_occupied_slots int;
  v_attended int; v_no_show int;
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date OR p_end_date - p_start_date > 366 THEN
    RAISE EXCEPTION 'Select a valid date range of up to 366 days.';
  END IF;
  v_gran := CASE WHEN lower(p_granularity) IN ('weekly','monthly') THEN lower(p_granularity) ELSE 'daily' END;

  SELECT count(*)::int INTO v_total_slots
  FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id=ms.machine_id
  WHERE ms.schedule_date BETWEEN p_start_date AND p_end_date
    AND m.is_active=true AND m.machine_status IN ('Available','Occupied')
    AND ms.slot_status NOT IN ('Cancelled','Maintenance');
  SELECT count(*)::int INTO v_occupied_slots
  FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id=ms.machine_id
  WHERE ms.schedule_date BETWEEN p_start_date AND p_end_date
    AND m.is_active=true AND m.machine_status IN ('Available','Occupied')
    AND ms.slot_status IN ('Reserved','Booked','Completed');
  SELECT count(*) FILTER (WHERE attendance_flag='Attended')::int,
         count(*) FILTER (WHERE attendance_flag='No-Show')::int
  INTO v_attended, v_no_show
  FROM public.appointments
  WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date;

  WITH appointment_trend AS (
    SELECT to_char(date_trunc(v_gran, COALESCE(confirmed_date,requested_date)::timestamp),'YYYY-MM-DD') AS period,
      count(*)::int AS total,
      count(*) FILTER (WHERE appointment_status='Pending')::int AS pending,
      count(*) FILTER (WHERE appointment_status='Under Review')::int AS under_review,
      count(*) FILTER (WHERE appointment_status='Confirmed')::int AS confirmed,
      count(*) FILTER (WHERE appointment_status='Rejected')::int AS rejected
    FROM public.appointments
    WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date
    GROUP BY 1 ORDER BY 1
  ), patient_trend AS (
    SELECT to_char(date_trunc(v_gran, created_at::timestamp),'YYYY-MM-DD') AS period, count(*)::int AS registrations
    FROM public.patients WHERE created_at::date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 1
  ), session_trend AS (
    SELECT to_char(date_trunc(v_gran, treatment_date::timestamp),'YYYY-MM-DD') AS period,
      count(*)::int AS total, count(*) FILTER (WHERE session_status='Completed')::int AS completed
    FROM public.dialysis_sessions WHERE treatment_date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 1
  ), demand_days AS (
    SELECT trim(to_char(requested_date,'Day')) AS label, count(*)::int AS requests
    FROM public.appointments WHERE requested_date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 2 DESC,1
  ), demand_slots AS (
    SELECT requested_time AS label, count(*)::int AS requests
    FROM public.appointments WHERE requested_date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 2 DESC,1
  ), machine_util AS (
    SELECT m.machine_code, m.machine_name,
      count(ms.machine_slot_id) FILTER (WHERE ms.slot_status NOT IN ('Cancelled','Maintenance'))::int AS available_slots,
      count(ms.machine_slot_id) FILTER (WHERE ms.slot_status IN ('Reserved','Booked','Completed'))::int AS occupied_slots
    FROM public.dialysis_machines m LEFT JOIN public.machine_slots ms
      ON ms.machine_id=m.machine_id AND ms.schedule_date BETWEEN p_start_date AND p_end_date
    WHERE m.is_active=true AND m.machine_status IN ('Available','Occupied')
    GROUP BY m.machine_id,m.machine_code,m.machine_name ORDER BY m.machine_code
  )
  SELECT jsonb_build_object(
    'period', jsonb_build_object('start',p_start_date,'end',p_end_date,'granularity',v_gran,'timezone','Asia/Manila'),
    'definition', jsonb_build_object(
      'available_slot','One generated MACHINE_SLOTS row for an active machine not marked Maintenance/Offline/Unavailable during the selected range.',
      'occupied_slot','A reserved, booked, or completed machine slot in the same range.',
      'utilization_formula','(occupied machine slots / total available machine slots) × 100',
      'no_show_formula','(explicit No-Show appointments / (explicit Attended + explicit No-Show appointments)) × 100. Scheduled records are excluded; no assumption is made from missing status.'
    ),
    'patients', jsonb_build_object(
      'total_registered', (SELECT count(*)::int FROM public.patients),
      'new_in_range', (SELECT count(*)::int FROM public.patients WHERE created_at::date BETWEEN p_start_date AND p_end_date),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(patient_trend)) FROM patient_trend),'[]'::jsonb)
    ),
    'appointments', jsonb_build_object(
      'total_in_range', (SELECT count(*)::int FROM public.appointments WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'pending', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Pending' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'under_review', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Under Review' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'confirmed', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Confirmed' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'rejected', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Rejected' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'rescheduling_requests', (SELECT count(*)::int FROM public.appointments WHERE created_at::date BETWEEN p_start_date AND p_end_date AND (status_history::text ILIKE '%Reschedule Requested%' OR reschedule_request <> '{}'::jsonb)),
      'cancellation_requests', (SELECT count(*)::int FROM public.appointments WHERE created_at::date BETWEEN p_start_date AND p_end_date AND (status_history::text ILIKE '%Cancellation%' OR cancellation_request <> '{}'::jsonb OR is_cancelled=true)),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(appointment_trend)) FROM appointment_trend),'[]'::jsonb)
    ),
    'sessions', jsonb_build_object(
      'completed_in_range', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date BETWEEN p_start_date AND p_end_date AND session_status='Completed'),
      'daily', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date = public.app_today()),
      'weekly', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date >= date_trunc('week', public.app_today()::timestamp)::date),
      'monthly', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date >= date_trunc('month', public.app_today()::timestamp)::date),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(session_trend)) FROM session_trend),'[]'::jsonb)
    ),
    'machine_utilization', jsonb_build_object(
      'total_available_slots', v_total_slots, 'occupied_slots', v_occupied_slots,
      'rate', CASE WHEN v_total_slots > 0 THEN round((v_occupied_slots::numeric / v_total_slots::numeric) * 100, 2) ELSE 0 END,
      'by_machine', COALESCE((SELECT jsonb_agg(row_to_json(machine_util)) FROM machine_util),'[]'::jsonb)
    ),
    'demand', jsonb_build_object(
      'by_day', COALESCE((SELECT jsonb_agg(row_to_json(demand_days)) FROM demand_days),'[]'::jsonb),
      'by_slot', COALESCE((SELECT jsonb_agg(row_to_json(demand_slots)) FROM demand_slots),'[]'::jsonb),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(appointment_trend)) FROM appointment_trend),'[]'::jsonb),
      'high_demand_periods', COALESCE((SELECT jsonb_agg(row_to_json(q)) FROM (SELECT * FROM appointment_trend ORDER BY total DESC LIMIT 5) q),'[]'::jsonb)
    ),
    'no_show', jsonb_build_object(
      'attended_recorded', v_attended, 'no_show_recorded', v_no_show,
      'expected_recorded', v_attended + v_no_show,
      'rate', CASE WHEN (v_attended+v_no_show) > 0 THEN round((v_no_show::numeric / (v_attended+v_no_show)::numeric) * 100, 2) ELSE 0 END,
      'note', 'Only explicit staff-recorded Attended and No-Show outcomes are included. Scheduled records are excluded.'
    ),
    'appointment_status_counts', COALESCE((
      SELECT jsonb_object_agg(appointment_status, n) FROM (
        SELECT appointment_status, count(*)::int AS n FROM public.appointments
        WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date GROUP BY appointment_status
      ) q), '{}'::jsonb)
  ) INTO v_result;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.get_admin_dashboard_stats()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb;
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  SELECT jsonb_build_object(
    'total_patients', (SELECT count(*)::int FROM public.patients),
    'active_staff', (SELECT count(*)::int FROM public.staff WHERE account_status='Active'),
    'total_appointments', (SELECT count(*)::int FROM public.appointments),
    'pending', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Pending'),
    'under_review', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Under Review'),
    'confirmed', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Confirmed'),
    'rejected', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Rejected'),
    'completed_sessions', (SELECT count(*)::int FROM public.dialysis_sessions WHERE session_status='Completed'),
    'available_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE is_active=true AND machine_status IN ('Available','Occupied')),
    'total_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE is_active=true),
    'analytics', public.get_analytics_bundle((public.app_today() - interval '29 days')::date, public.app_today(), 'daily'),
    'recent_activities', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('audit_id',audit_id,'activity',activity,'module',affected_module,
        'record_id',affected_record_id,'actor',COALESCE(actor_name,actor_email,'System'),'created_at',created_at,'severity',severity)
        ORDER BY created_at DESC)
      FROM (SELECT * FROM public.audit_logs ORDER BY created_at DESC LIMIT 10) q), '[]'::jsonb)
  ) INTO v_result;
  RETURN v_result;
END $$;

-- Legacy staff-creation SQL RPC uses direct auth.users inserts; the frontend uses the secure Edge Function instead.
DO $revoke$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
             WHERE n.nspname='public' AND p.proname='admin_create_staff_account') THEN
    EXECUTE 'REVOKE EXECUTE ON FUNCTION public.admin_create_staff_account(text,text,text,text,text,text,jsonb) FROM PUBLIC, anon, authenticated';
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.admin_create_staff_account(text,text,text,text,text,text,jsonb) TO service_role';
  END IF;
END $revoke$;

DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'admin_set_account_status(uuid,text)',
    'admin_assign_user_role(uuid,text,text)',
    'get_staff_dashboard_stats()',
    'get_analytics_bundle(date,date,text)',
    'get_admin_dashboard_stats()'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
END $grants$;
