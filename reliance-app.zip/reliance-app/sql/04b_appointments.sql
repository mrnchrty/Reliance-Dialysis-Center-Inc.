-- Reliance Dialysis Center Inc. — appointment requests, status processing, capacity, rescheduling, cancellation and recurrence
-- All appointment writes are atomic SECURITY DEFINER operations. Patients never select or assign a machine.

DROP FUNCTION IF EXISTS public.assign_machine_and_confirm_appointment(uuid, uuid, date, time without time zone, time without time zone, text);

CREATE OR REPLACE FUNCTION public.config_slot(p_slot_id text)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT value FROM jsonb_array_elements(public.get_system_config() -> 'time_slots') WHERE value ->> 'id' = p_slot_id LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.assert_booking_date(p_date date, p_slot_id text)
RETURNS void LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_cfg jsonb := public.get_system_config(); v_days int[]; v_slot jsonb;
        v_min int; v_max int; v_allow boolean;
BEGIN
  IF p_date IS NULL OR p_slot_id IS NULL OR trim(p_slot_id) = '' THEN
    RAISE EXCEPTION 'Select a valid appointment date and time slot.';
  END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  v_slot := public.config_slot(p_slot_id);
  v_min := COALESCE((v_cfg ->> 'min_lead_days')::int, 1);
  v_max := COALESCE((v_cfg ->> 'max_advance_days')::int, 90);
  v_allow := COALESCE((v_cfg ->> 'allow_same_day')::boolean, false);

  IF v_slot IS NULL THEN RAISE EXCEPTION 'The selected appointment time is no longer configured.'; END IF;
  IF NOT (EXTRACT(ISODOW FROM p_date)::int = ANY(v_days)) THEN
    RAISE EXCEPTION 'The center is closed on the selected date. Operating days are Monday to Saturday.';
  END IF;
  IF p_date < public.app_today() THEN RAISE EXCEPTION 'Past dates cannot be booked.'; END IF;
  IF p_date = public.app_today() AND (v_min > 0 OR NOT v_allow) THEN
    RAISE EXCEPTION 'Same-day booking is not enabled for this center.';
  END IF;
  IF p_date > public.app_today() + v_max THEN
    RAISE EXCEPTION 'Appointments can only be requested up to % days in advance.', v_max;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.append_status_history(
  p_history jsonb, p_status text, p_event_type text, p_remarks text, p_metadata jsonb DEFAULT '{}'::jsonb
) RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT COALESCE(p_history, '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
    'status', p_status, 'event_type', COALESCE(p_event_type, p_status),
    'remarks', p_remarks, 'timestamp', now(), 'actor_user_id', auth.uid(),
    'metadata', COALESCE(p_metadata, '{}'::jsonb)
  ));
$$;

CREATE OR REPLACE FUNCTION public.appointment_snapshot(p_appointment_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v jsonb;
BEGIN
  SELECT jsonb_build_object(
    'appointment', to_jsonb(a),
    'machine', COALESCE((
      SELECT jsonb_build_object('machine_slot_id', ms.machine_slot_id, 'machine_id', m.machine_id,
        'machine_code', m.machine_code, 'machine_name', m.machine_name, 'schedule_date', ms.schedule_date,
        'start_time', ms.start_time, 'end_time', ms.end_time)
      FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
      WHERE ms.machine_slot_id = a.machine_slot_id), '{}'::jsonb)
  ) INTO v FROM public.appointments a WHERE a.appointment_id = p_appointment_id;
  RETURN COALESCE(v, '{}'::jsonb);
END $$;

CREATE OR REPLACE FUNCTION public.notify_patient(
  p_patient_id uuid, p_title text, p_message text, p_type text,
  p_appointment_id uuid DEFAULT NULL, p_document_id uuid DEFAULT NULL,
  p_session_id uuid DEFAULT NULL, p_destination jsonb DEFAULT '{}'::jsonb,
  p_action_label text DEFAULT 'Open record'
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_user uuid;
BEGIN
  SELECT user_id INTO v_user FROM public.patients WHERE patient_id = p_patient_id;
  IF v_user IS NOT NULL THEN
    PERFORM public.write_notification(v_user, p_title, p_message, p_type, p_appointment_id,
      p_document_id, p_session_id, p_patient_id, p_destination, p_action_label);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.lock_schedule_slot(p_date date, p_slot_id text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT pg_advisory_xact_lock(hashtextextended(p_date::text || ':' || p_slot_id, 714229)); $$;

CREATE OR REPLACE FUNCTION public.missing_verified_documents(p_patient_id uuid)
RETURNS text[] LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_required text[]; v_missing text[];
BEGIN
  IF NOT COALESCE((public.get_system_config() ->> 'require_verified_documents_for_confirmation')::boolean, true) THEN
    RETURN ARRAY[]::text[];
  END IF;
  SELECT array_agg(value) INTO v_required FROM jsonb_array_elements_text(public.get_system_config() -> 'required_document_types');
  SELECT COALESCE(array_agg(req), ARRAY[]::text[]) INTO v_missing
  FROM unnest(v_required) req
  WHERE NOT EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.patient_id = p_patient_id AND d.document_type = req AND d.is_current = true
      AND d.verification_status = 'Verified' AND d.correction_requested = false AND d.is_outdated = false
  );
  RETURN v_missing;
END $$;

CREATE OR REPLACE FUNCTION public.release_machine_slot(p_appointment_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_slot_id uuid; v_status text;
BEGIN
  SELECT machine_slot_id INTO v_slot_id FROM public.appointments WHERE appointment_id = p_appointment_id;
  IF v_slot_id IS NULL THEN RETURN; END IF;
  SELECT slot_status INTO v_status FROM public.machine_slots WHERE machine_slot_id = v_slot_id FOR UPDATE;
  IF v_status IS NOT NULL THEN
    UPDATE public.machine_slots
    SET appointment_id = NULL,
        slot_status = CASE WHEN slot_status IN ('Booked','Reserved') THEN 'Available' ELSE slot_status END
    WHERE machine_slot_id = v_slot_id;
  END IF;
  UPDATE public.appointments SET machine_slot_id = NULL WHERE appointment_id = p_appointment_id;
END $$;

CREATE OR REPLACE FUNCTION public.create_appointment_request(
  p_requested_date date, p_requested_time text, p_notes text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_patient public.patients%ROWTYPE; v_medical public.patient_medical_profiles%ROWTYPE;
  v_cfg jsonb := public.get_system_config(); v_slot jsonb; v_missing_docs text[];
  v_open int; v_capacity int; v_id uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Staff accounts cannot submit patient appointment requests.'; END IF;
  SELECT * INTO v_patient FROM public.patients WHERE patient_id = public.current_patient_id();
  IF v_patient.patient_id IS NULL THEN RAISE EXCEPTION 'Active patient account required.'; END IF;

  IF v_patient.full_name IS NULL OR v_patient.date_of_birth IS NULL OR v_patient.sex IS NULL
     OR v_patient.address IS NULL OR v_patient.contact_number IS NULL
     OR v_patient.emergency_contact_name IS NULL OR v_patient.emergency_contact_number IS NULL THEN
    RAISE EXCEPTION 'Complete your personal profile before booking.';
  END IF;
  SELECT * INTO v_medical FROM public.patient_medical_profiles WHERE patient_id = v_patient.patient_id;
  IF v_medical.medical_profile_id IS NULL OR v_medical.height IS NULL OR v_medical.weight IS NULL
     OR v_medical.blood_type IS NULL OR v_medical.diagnosis IS NULL
     OR v_medical.allergies IS NULL OR v_medical.existing_medical_conditions IS NULL
     OR v_medical.previous_surgeries IS NULL OR v_medical.current_medications IS NULL
     OR v_medical.attending_nephrologist IS NULL OR v_medical.prescribed_dialysis_frequency IS NULL THEN
    RAISE EXCEPTION 'Complete your medical profile before booking.';
  END IF;

  SELECT array_agg(req) INTO v_missing_docs
  FROM unnest(ARRAY(SELECT jsonb_array_elements_text(v_cfg -> 'required_document_types'))) req
  WHERE NOT EXISTS (
    SELECT 1 FROM public.patient_documents d
    WHERE d.patient_id = v_patient.patient_id AND d.document_type = req AND d.is_current = true
      AND d.verification_status IN ('Pending','Verified') AND d.is_outdated = false
  );
  IF COALESCE(array_length(v_missing_docs,1),0) > 0 THEN
    RAISE EXCEPTION 'Submit the current required documents before booking: %.', array_to_string(v_missing_docs, ', ');
  END IF;

  PERFORM public.assert_booking_date(p_requested_date, p_requested_time);
  v_slot := public.config_slot(p_requested_time);
  PERFORM public.lock_schedule_slot(p_requested_date, p_requested_time);
  PERFORM public.internal_ensure_capacity(p_requested_date, p_requested_date);
  v_capacity := public.slot_remaining_capacity(p_requested_date, p_requested_time);
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'The selected date and time no longer have available capacity.'; END IF;

  IF EXISTS (
    SELECT 1 FROM public.appointments
    WHERE patient_id = v_patient.patient_id AND requested_date = p_requested_date
      AND requested_time = p_requested_time AND is_cancelled = false
      AND appointment_status IN ('Pending','Under Review','Confirmed')
  ) THEN
    RAISE EXCEPTION 'You already have an active appointment request for this date and time.';
  END IF;

  SELECT count(*)::int INTO v_open FROM public.appointments
  WHERE patient_id = v_patient.patient_id AND is_cancelled = false
    AND appointment_status IN ('Pending','Under Review') AND requested_date >= public.app_today();
  IF NOT COALESCE((v_cfg ->> 'allow_multiple_open_requests')::boolean, true)
     AND v_open >= COALESCE((v_cfg ->> 'max_open_requests')::int, 6) THEN
    RAISE EXCEPTION 'The maximum number of open appointment requests has been reached.';
  END IF;

  INSERT INTO public.appointments (
    patient_id, requested_date, requested_time, requested_start_time, requested_end_time,
    appointment_status, staff_remarks, status_history, request_type, submitted_by, original_details
  ) VALUES (
    v_patient.patient_id, p_requested_date, p_requested_time,
    (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
    'Pending', NULLIF(trim(COALESCE(p_notes,'')), ''),
    public.append_status_history('[]'::jsonb, 'Pending', 'Appointment Request Submitted',
      'Appointment request submitted through the Patient Panel.', jsonb_build_object('requested_time', p_requested_time)),
    'New', auth.uid(), jsonb_build_object('requested_date', p_requested_date, 'requested_time', p_requested_time)
  ) RETURNING appointment_id INTO v_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',v_id);
  PERFORM public.notify_patient(v_patient.patient_id, 'Appointment Request Received',
    format('We received your appointment request for %s, %s. Track its progress in Book Appointment.',
      to_char(p_requested_date,'Mon DD, YYYY'), COALESCE(v_slot ->> 'display', p_requested_time)),
    'Appointment Request', v_id, NULL, NULL, v_destination, 'Open appointment tracker');
  PERFORM public.notify_all_staff('New Appointment Request',
    format('New appointment request %s from %s for %s (%s).', left(v_id::text,8), v_patient.full_name,
      to_char(p_requested_date,'Mon DD, YYYY'), p_requested_time),
    'New Appointment Request', v_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',v_id));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Appointment Request Created', 'Appointments', v_id::text,
    jsonb_build_object('requested_date', p_requested_date, 'requested_time', p_requested_time, 'capacity_remaining_before', v_capacity));

  RETURN jsonb_build_object('success',true,'appointment_id',v_id,'status','Pending','remaining_capacity',v_capacity - 1);
END $$;

CREATE OR REPLACE FUNCTION public.set_appointment_status(
  p_appointment_id uuid, p_status text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_patient_user uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.is_active_staff() THEN RAISE EXCEPTION 'Unauthorized: active staff access required.'; END IF;
  IF p_status NOT IN ('Pending','Under Review','Confirmed','Rejected') THEN
    RAISE EXCEPTION 'Invalid appointment status. Use Pending, Under Review, Confirmed, or Rejected only.';
  END IF;
  IF p_status = 'Confirmed' THEN
    RAISE EXCEPTION 'Use the confirm-and-assign action so an authorized staff member records a machine.';
  END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled THEN RAISE EXCEPTION 'A processed cancellation is recorded for this appointment.'; END IF;
  IF p_status = 'Rejected' AND NULLIF(trim(COALESCE(p_remarks,'')),'') IS NULL THEN
    RAISE EXCEPTION 'A reason is required when rejecting an appointment.';
  END IF;

  UPDATE public.appointments SET
    appointment_status = p_status,
    processed_by = public.current_staff_id(),
    staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks),
    status_history = public.append_status_history(status_history, p_status, 'Status Updated', p_remarks, jsonb_build_object('previous_status', v_appt.appointment_status))
  WHERE appointment_id = p_appointment_id;

  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = v_appt.patient_id;
  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Appointment Status Updated',
    format('Your appointment %s status is now %s.%s', left(p_appointment_id::text,8), p_status,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    'Appointment Status Updated', p_appointment_id, NULL, NULL, v_destination, 'Open appointment tracker');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Appointment Status Changed', 'Appointments', p_appointment_id::text,
    jsonb_build_object('from', v_appt.appointment_status, 'to', p_status, 'remarks', p_remarks));
  RETURN jsonb_build_object('success',true,'appointment_id',p_appointment_id,'status',p_status);
END $$;

CREATE OR REPLACE FUNCTION public.assign_machine_and_confirm_appointment(
  p_appointment_id uuid, p_machine_id uuid, p_confirmed_date date,
  p_start_time time without time zone, p_end_time time without time zone,
  p_remarks text DEFAULT NULL, p_slot_id text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_machine public.dialysis_machines%ROWTYPE;
  v_slot public.machine_slots%ROWTYPE; v_slot_cfg jsonb; v_capacity int;
  v_missing text[]; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN
    RAISE EXCEPTION 'Unauthorized: staff appointment-management permission required.';
  END IF;
  SELECT * INTO v_machine FROM public.dialysis_machines WHERE machine_id = p_machine_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Selected dialysis machine not found.'; END IF;
  IF v_machine.is_active = false OR v_machine.machine_status IN ('Maintenance','Offline','Unavailable') THEN
    RAISE EXCEPTION 'Machine % is % and cannot be assigned.', v_machine.machine_code, v_machine.machine_status;
  END IF;

  v_slot_cfg := public.config_slot(p_slot_id);
  IF v_slot_cfg IS NULL THEN
    SELECT value INTO v_slot_cfg FROM jsonb_array_elements(public.get_system_config() -> 'time_slots')
    WHERE (value ->> 'start_time')::time = p_start_time AND (value ->> 'end_time')::time = p_end_time LIMIT 1;
  END IF;
  IF v_slot_cfg IS NULL THEN RAISE EXCEPTION 'Confirmed time must match a configured appointment slot.'; END IF;
  p_slot_id := v_slot_cfg ->> 'id';
  p_start_time := (v_slot_cfg ->> 'start_time')::time;
  p_end_time := (v_slot_cfg ->> 'end_time')::time;
  PERFORM public.assert_booking_date(p_confirmed_date, p_slot_id);
  PERFORM public.lock_schedule_slot(p_confirmed_date, p_slot_id);
  PERFORM public.internal_ensure_capacity(p_confirmed_date, p_confirmed_date);

  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled THEN RAISE EXCEPTION 'Cannot confirm an appointment with a processed cancellation.'; END IF;
  IF v_appt.appointment_status = 'Rejected' THEN RAISE EXCEPTION 'Cannot confirm a rejected appointment.'; END IF;

  v_missing := public.missing_verified_documents(v_appt.patient_id);
  IF array_length(v_missing,1) > 0 THEN
    RAISE EXCEPTION 'All current required documents must be verified before confirmation. Missing: %.', array_to_string(v_missing, ', ');
  END IF;

  v_capacity := public.slot_remaining_capacity(p_confirmed_date, p_slot_id);
  IF v_appt.machine_slot_id IS NULL AND v_appt.requested_date = p_confirmed_date
     AND v_appt.requested_time = p_slot_id AND v_appt.appointment_status IN ('Pending','Under Review') THEN
    v_capacity := v_capacity + 1;
  END IF;
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'No eligible machine capacity remains for this date and time.'; END IF;

  SELECT * INTO v_slot FROM public.machine_slots
  WHERE machine_id = p_machine_id AND schedule_date = p_confirmed_date
    AND start_time = p_start_time AND end_time = p_end_time AND slot_key = p_slot_id
    AND slot_status IN ('Available','Reserved','Booked')
    AND (appointment_id IS NULL OR appointment_id = p_appointment_id)
  ORDER BY slot_status = 'Available' DESC, created_at ASC
  FOR UPDATE SKIP LOCKED LIMIT 1;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'No available machine slot exists for % on % (%). Reassign or generate capacity first.',
      v_machine.machine_code, p_confirmed_date, p_slot_id;
  END IF;

  IF v_appt.machine_slot_id IS NOT NULL AND v_appt.machine_slot_id <> v_slot.machine_slot_id THEN
    PERFORM public.release_machine_slot(p_appointment_id);
  END IF;

  UPDATE public.machine_slots SET slot_status = 'Booked', appointment_id = p_appointment_id
  WHERE machine_slot_id = v_slot.machine_slot_id;

  UPDATE public.appointments SET
    machine_slot_id = v_slot.machine_slot_id,
    processed_by = public.current_staff_id(),
    confirmed_date = p_confirmed_date,
    confirmed_start_time = p_start_time,
    confirmed_end_time = p_end_time,
    appointment_status = 'Confirmed',
    reschedule_requested = false,
    reschedule_request = CASE WHEN reschedule_request = '{}'::jsonb THEN reschedule_request
      ELSE reschedule_request || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id()) END,
    staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks),
    machine_snapshot = jsonb_build_object('machine_code',v_machine.machine_code,'machine_name',v_machine.machine_name,
      'schedule_date',p_confirmed_date,'start_time',p_start_time,'end_time',p_end_time),
    status_history = public.append_status_history(status_history,'Confirmed','Appointment Confirmed',
      COALESCE(p_remarks,'Appointment approved and dialysis machine assigned.'),
      jsonb_build_object('machine_code',v_machine.machine_code,'confirmed_date',p_confirmed_date,'slot_id',p_slot_id))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Appointment Confirmed',
    format('Your appointment %s is confirmed for %s, %s. Assigned machine: %s.',
      left(p_appointment_id::text,8), to_char(p_confirmed_date,'Mon DD, YYYY'),
      v_slot_cfg ->> 'display', v_machine.machine_code),
    'Appointment Confirmed', p_appointment_id, NULL, NULL, v_destination, 'Open confirmed appointment');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Appointment Confirmed & Machine Assigned', 'Appointments', p_appointment_id::text,
    jsonb_build_object('machine_code',v_machine.machine_code,'confirmed_date',p_confirmed_date,
      'start_time',p_start_time,'end_time',p_end_time,'slot_id',p_slot_id,'capacity_before',v_capacity));
  RETURN jsonb_build_object('success',true,'appointment_id',p_appointment_id,'machine_slot_id',v_slot.machine_slot_id,'machine_code',v_machine.machine_code);
END $$;

CREATE OR REPLACE FUNCTION public.request_document_correction(
  p_appointment_id uuid, p_document_type text, p_notes text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_doc public.patient_documents%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('verify_documents') THEN RAISE EXCEPTION 'Unauthorized: document verification permission required.'; END IF;
  IF NULLIF(trim(COALESCE(p_notes,'')),'') IS NULL THEN RAISE EXCEPTION 'Provide a correction notice for the patient.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  SELECT * INTO v_doc FROM public.patient_documents
  WHERE patient_id = v_appt.patient_id AND document_type = p_document_type AND is_current = true
  ORDER BY uploaded_at DESC LIMIT 1 FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Current % document was not found.', p_document_type; END IF;

  UPDATE public.patient_documents SET
    verification_status = 'Needs Correction', remarks = p_notes, reviewed_by = public.current_staff_id(),
    reviewed_at = now(), correction_requested = true, correction_notes = p_notes,
    correction_requested_by = public.current_staff_id(), correction_requested_at = now(), is_outdated = true
  WHERE document_id = v_doc.document_id;

  UPDATE public.appointments SET
    appointment_status = 'Under Review',
    processed_by = public.current_staff_id(),
    correction_request = jsonb_build_object('document_type',p_document_type,'document_id',v_doc.document_id,
      'notes',p_notes,'requested_at',now(),'requested_by',public.current_staff_id(),'status','Open'),
    status_history = public.append_status_history(status_history,'Under Review','Document Correction Requested',p_notes,
      jsonb_build_object('document_id',v_doc.document_id,'document_type',p_document_type))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',v_doc.document_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Document Correction Required',
    format('Please submit an updated %s. Staff notice: %s', p_document_type, p_notes),
    'Document Correction Required', p_appointment_id, v_doc.document_id, NULL, v_destination, 'Open document');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Document Correction Requested', 'Documents', v_doc.document_id::text,
    jsonb_build_object('appointment_id',p_appointment_id,'document_type',p_document_type,'notes',p_notes));
  RETURN jsonb_build_object('success',true,'appointment_status','Under Review','document_id',v_doc.document_id);
END $$;

CREATE OR REPLACE FUNCTION public.request_reschedule(
  p_appointment_id uuid, p_new_date date, p_new_time text, p_reason text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_cfg jsonb := public.get_system_config(); v_slot jsonb;
        v_patient_user uuid; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the staff rescheduling workflow for operational changes.'; END IF;
  SELECT * INTO v_appt FROM public.appointments
  WHERE appointment_id = p_appointment_id AND patient_id = public.current_patient_id() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled OR v_appt.appointment_status = 'Rejected' THEN
    RAISE EXCEPTION 'This appointment cannot be rescheduled.';
  END IF;
  IF v_appt.reschedule_requested THEN RAISE EXCEPTION 'A rescheduling request is already awaiting staff review.'; END IF;
  PERFORM public.assert_booking_date(p_new_date, p_new_time);
  v_slot := public.config_slot(p_new_time);
  PERFORM public.lock_schedule_slot(p_new_date, p_new_time);
  PERFORM public.internal_ensure_capacity(p_new_date, p_new_date);
  IF public.slot_remaining_capacity(p_new_date, p_new_time) <= 0 THEN
    RAISE EXCEPTION 'The requested new date and time have no remaining capacity.';
  END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    reschedule_request = jsonb_build_object(
      'status','Pending','requested_at',now(),'requested_by',auth.uid(),'reason',p_reason,
      'original_date',v_appt.requested_date,'original_time',v_appt.requested_time,
      'original_confirmed_date',v_appt.confirmed_date,'original_machine_slot_id',v_appt.machine_slot_id,
      'new_date',p_new_date,'new_time',p_new_time,'new_start_time',(v_slot ->> 'start_time')::time,
      'new_end_time',(v_slot ->> 'end_time')::time),
    reschedule_requested = true, reschedule_notes = p_reason,
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Requested',
      COALESCE(p_reason,'Patient requested a new appointment date and time.'),
      jsonb_build_object('new_date',p_new_date,'new_time',p_new_time))
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = v_appt.patient_id;
  PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Request Sent',
    format('Your request to move appointment %s to %s (%s) is awaiting staff review.',
      left(p_appointment_id::text,8), to_char(p_new_date,'Mon DD, YYYY'), v_slot ->> 'display'),
    'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  PERFORM public.notify_all_staff('Rescheduling Request',
    format('Rescheduling request for appointment %s: %s (%s).', left(p_appointment_id::text,8), p_new_date, p_new_time),
    'Rescheduling Request', p_appointment_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id,'action','reschedule'));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Rescheduling Requested', 'Appointments', p_appointment_id::text,
    jsonb_build_object('new_date',p_new_date,'new_time',p_new_time,'reason',p_reason));
  RETURN jsonb_build_object('success',true,'status','Pending','new_date',p_new_date,'new_time',p_new_time);
END $$;

CREATE OR REPLACE FUNCTION public.process_reschedule_request(
  p_appointment_id uuid, p_action text, p_machine_id uuid DEFAULT NULL,
  p_remarks text DEFAULT NULL, p_new_date date DEFAULT NULL, p_new_time text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_req jsonb; v_date date; v_time text; v_slot jsonb;
  v_capacity int; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_action NOT IN ('approve','deny') THEN RAISE EXCEPTION 'Action must be approve or deny.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF NOT v_appt.reschedule_requested OR COALESCE(v_appt.reschedule_request ->> 'status','') <> 'Pending' THEN
    RAISE EXCEPTION 'No pending rescheduling request was found.';
  END IF;
  v_req := v_appt.reschedule_request;
  v_date := COALESCE(p_new_date, (v_req ->> 'new_date')::date);
  v_time := COALESCE(p_new_time, v_req ->> 'new_time');

  IF p_action = 'deny' THEN
    UPDATE public.appointments SET
      reschedule_request = v_req || jsonb_build_object('status','Denied','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      reschedule_requested = false,
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Denied', p_remarks, v_req)
    WHERE appointment_id = p_appointment_id;
    v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
    PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Update',
      format('Your rescheduling request for appointment %s was not approved.%s', left(p_appointment_id::text,8),
        CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
      'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
    INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
    VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
      'Rescheduling Denied', 'Appointments', p_appointment_id::text, jsonb_build_object('remarks',p_remarks));
    RETURN jsonb_build_object('success',true,'action','deny','appointment_status',v_appt.appointment_status);
  END IF;

  PERFORM public.assert_booking_date(v_date, v_time);
  v_slot := public.config_slot(v_time);
  PERFORM public.lock_schedule_slot(v_date, v_time);
  PERFORM public.internal_ensure_capacity(v_date, v_date);
  v_capacity := public.slot_remaining_capacity(v_date, v_time);
  IF v_appt.machine_slot_id IS NULL AND v_appt.requested_date = v_date AND v_appt.requested_time = v_time THEN
    v_capacity := v_capacity + 1;
  END IF;
  IF v_capacity <= 0 THEN RAISE EXCEPTION 'The new date and time have no remaining capacity.'; END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    requested_date = v_date, requested_time = v_time,
    requested_start_time = (v_slot ->> 'start_time')::time, requested_end_time = (v_slot ->> 'end_time')::time,
    request_type = 'Reschedule',
    reschedule_request = v_req || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id(),'approved_new_date',v_date,'approved_new_time',v_time,'remarks',p_remarks),
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Reschedule Approved', p_remarks,
      jsonb_build_object('new_date',v_date,'new_time',v_time))
  WHERE appointment_id = p_appointment_id;

  IF v_appt.appointment_status = 'Confirmed' THEN
    IF p_machine_id IS NULL THEN RAISE EXCEPTION 'Select an available machine before approving a reschedule for a confirmed appointment.'; END IF;
    PERFORM public.assign_machine_and_confirm_appointment(
      p_appointment_id, p_machine_id, v_date, (v_slot ->> 'start_time')::time,
      (v_slot ->> 'end_time')::time, COALESCE(p_remarks,'Rescheduling approved by authorized staff.'), v_time);
  ELSE
    UPDATE public.appointments SET
      appointment_status = 'Under Review', processed_by = public.current_staff_id(),
      reschedule_requested = false,
      staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks)
    WHERE appointment_id = p_appointment_id;
  END IF;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Rescheduling Update',
    format('Your rescheduling request for appointment %s was approved for %s (%s).',
      left(p_appointment_id::text,8), to_char(v_date,'Mon DD, YYYY'), v_slot ->> 'display'),
    'Rescheduling Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Rescheduling Approved', 'Appointments', p_appointment_id::text,
    jsonb_build_object('new_date',v_date,'new_time',v_time,'machine_id',p_machine_id,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'action','approve','new_date',v_date,'new_time',v_time);
END $$;

CREATE OR REPLACE FUNCTION public.request_cancellation(
  p_appointment_id uuid, p_reason text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the staff cancellation workflow for operational changes.'; END IF;
  SELECT * INTO v_appt FROM public.appointments
  WHERE appointment_id = p_appointment_id AND patient_id = public.current_patient_id() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF v_appt.is_cancelled OR COALESCE(v_appt.cancellation_request ->> 'status','') = 'Pending' THEN
    RAISE EXCEPTION 'This appointment is already cancelled or has a pending cancellation request.';
  END IF;

  UPDATE public.appointments SET
    original_details = CASE WHEN original_details = '{}'::jsonb THEN public.appointment_snapshot(p_appointment_id) ELSE original_details END,
    cancellation_request = jsonb_build_object('status','Pending','reason',p_reason,'requested_at',now(),
      'requested_by',auth.uid(),'original_status',v_appt.appointment_status,'original_snapshot',public.appointment_snapshot(p_appointment_id)),
    status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Requested',
      COALESCE(p_reason,'Patient requested cancellation.'), '{}'::jsonb)
  WHERE appointment_id = p_appointment_id;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Cancellation Request Sent',
    format('Your cancellation request for appointment %s is awaiting staff processing.', left(p_appointment_id::text,8)),
    'Cancellation Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  PERFORM public.notify_all_staff('Cancellation Request',
    format('Cancellation request for appointment %s. Reason: %s', left(p_appointment_id::text,8), COALESCE(p_reason,'Not specified')),
    'Cancellation Request', p_appointment_id,
    jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id,'action','cancellation'));

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Cancellation Requested', 'Appointments', p_appointment_id::text, jsonb_build_object('reason',p_reason));
  RETURN jsonb_build_object('success',true,'status','Pending');
END $$;

CREATE OR REPLACE FUNCTION public.process_cancellation_request(
  p_appointment_id uuid, p_action text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_appt public.appointments%ROWTYPE; v_req jsonb; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_action NOT IN ('approve','deny') THEN RAISE EXCEPTION 'Action must be approve or deny.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  IF COALESCE(v_appt.cancellation_request ->> 'status','') <> 'Pending' THEN
    RAISE EXCEPTION 'No pending cancellation request was found.';
  END IF;
  v_req := v_appt.cancellation_request;

  IF p_action = 'deny' THEN
    UPDATE public.appointments SET
      cancellation_request = v_req || jsonb_build_object('status','Denied','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Denied', p_remarks, v_req)
    WHERE appointment_id = p_appointment_id;
  ELSE
    PERFORM public.release_machine_slot(p_appointment_id);
    UPDATE public.appointments SET
      is_cancelled = true, cancelled_at = now(),
      cancellation_reason = COALESCE(v_req ->> 'reason', p_remarks),
      cancelled_by_role = COALESCE((SELECT role FROM public.staff WHERE staff_id = public.current_staff_id()), 'staff'),
      cancellation_request = v_req || jsonb_build_object('status','Approved','processed_at',now(),'processed_by',public.current_staff_id(),'remarks',p_remarks),
      status_history = public.append_status_history(status_history, v_appt.appointment_status, 'Cancellation Processed',
        COALESCE(p_remarks,'Cancellation processed and capacity released.'), v_req)
    WHERE appointment_id = p_appointment_id;
  END IF;

  v_destination := jsonb_build_object('panel','patient','section','book-appointment','appointment_id',p_appointment_id);
  PERFORM public.notify_patient(v_appt.patient_id, 'Cancellation Update',
    format('Your cancellation request for appointment %s was %s.%s', left(p_appointment_id::text,8),
      CASE WHEN p_action='approve' THEN 'processed' ELSE 'not approved' END,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    'Cancellation Update', p_appointment_id, NULL, NULL, v_destination, 'Open appointment');
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_action='approve' THEN 'Cancellation Processed' ELSE 'Cancellation Denied' END,
    'Appointments', p_appointment_id::text, jsonb_build_object('action',p_action,'remarks',p_remarks,'released_capacity',p_action='approve'));
  RETURN jsonb_build_object('success',true,'action',p_action,'is_cancelled',p_action='approve');
END $$;

CREATE OR REPLACE FUNCTION public.record_appointment_attendance(
  p_appointment_id uuid, p_attendance_flag text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_old text; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('record_sessions') THEN RAISE EXCEPTION 'Unauthorized: attendance-recording permission required.'; END IF;
  IF p_attendance_flag NOT IN ('Scheduled','Attended','No-Show') THEN RAISE EXCEPTION 'Invalid attendance outcome.'; END IF;
  SELECT attendance_flag INTO v_old FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  UPDATE public.appointments SET
    attendance_flag = p_attendance_flag, attendance_recorded_by = public.current_staff_id(),
    attendance_recorded_at = now(), staff_remarks = COALESCE(NULLIF(trim(p_remarks),''), staff_remarks)
  WHERE appointment_id = p_appointment_id;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Attendance Recorded', 'Appointments', p_appointment_id::text,
    jsonb_build_object('from',v_old,'to',p_attendance_flag,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'attendance_flag',p_attendance_flag);
END $$;

CREATE OR REPLACE FUNCTION public.generate_recurring_appointments(
  p_patient_id uuid, p_recurring_days text[], p_preferred_time text,
  p_start_date date, p_end_date date
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_cfg jsonb := public.get_system_config(); v_days int[]; v_day_nums int[];
  v_day date; v_slot jsonb; v_group uuid := gen_random_uuid(); v_id uuid;
  v_generated jsonb := '[]'::jsonb; v_skipped jsonb := '[]'::jsonb;
  v_conflict int; v_capacity int; v_patient_user uuid; v_frequency text;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_appointments') THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Select a valid date range of up to 120 days.';
  END IF;
  IF p_start_date < public.app_today() THEN RAISE EXCEPTION 'Recurring suggestions cannot start in the past.'; END IF;
  v_slot := public.config_slot(p_preferred_time);
  IF v_slot IS NULL THEN RAISE EXCEPTION 'Select a configured preferred time.'; END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  SELECT array_agg(CASE d WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3
    WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 END)
  INTO v_day_nums FROM unnest(COALESCE(p_recurring_days, ARRAY[]::text[])) d;
  IF v_day_nums IS NULL OR array_position(v_day_nums, NULL) IS NOT NULL
     OR EXISTS (SELECT 1 FROM unnest(v_day_nums) d WHERE NOT (d = ANY(v_days))) THEN
    RAISE EXCEPTION 'Recurring days must be configured operating days; Sundays are excluded.';
  END IF;

  SELECT prescribed_dialysis_frequency INTO v_frequency
  FROM public.patient_medical_profiles WHERE patient_id = p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Complete the patient medical profile before generating recurring suggestions.'; END IF;

  UPDATE public.patient_medical_profiles
  SET recurring_days = COALESCE(p_recurring_days, ARRAY[]::text[]),
      preferred_time = p_preferred_time,
      profile_updated_by = auth.uid()
  WHERE patient_id = p_patient_id;

  PERFORM public.internal_ensure_capacity(p_start_date, p_end_date);
  FOR v_day IN SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date LOOP
    CONTINUE WHEN NOT (EXTRACT(ISODOW FROM v_day)::int = ANY(v_day_nums));
    PERFORM public.lock_schedule_slot(v_day, p_preferred_time);
    SELECT count(*)::int INTO v_conflict FROM public.appointments
    WHERE patient_id = p_patient_id AND requested_date = v_day AND requested_time = p_preferred_time
      AND is_cancelled = false AND appointment_status IN ('Pending','Under Review','Confirmed');
    IF v_conflict > 0 THEN
      v_skipped := v_skipped || jsonb_build_array(jsonb_build_object('date',v_day,'reason','Existing appointment conflict'));
      CONTINUE;
    END IF;
    v_capacity := public.slot_remaining_capacity(v_day, p_preferred_time);
    IF v_capacity <= 0 THEN
      v_skipped := v_skipped || jsonb_build_array(jsonb_build_object('date',v_day,'reason','No machine capacity'));
      CONTINUE;
    END IF;

    INSERT INTO public.appointments (
      patient_id, requested_date, requested_time, requested_start_time, requested_end_time,
      appointment_status, recurrence_group_id, is_recurring, status_history, request_type, submitted_by
    ) VALUES (
      p_patient_id, v_day, p_preferred_time, (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
      'Pending', v_group, true,
      public.append_status_history('[]'::jsonb,'Pending','Recurring Appointment Suggestion Generated',
        format('Staff-reviewed recurring suggestion. Prescribed frequency: %s. Days: %s.',
          COALESCE(v_frequency,'Not recorded'), array_to_string(p_recurring_days,', ')),
        jsonb_build_object('recurrence_group_id',v_group,'preferred_time',p_preferred_time)),
      'New', auth.uid()
    ) RETURNING appointment_id INTO v_id;
    v_generated := v_generated || jsonb_build_array(jsonb_build_object('date',v_day,'appointment_id',v_id,'time',p_preferred_time));
  END LOOP;

  SELECT user_id INTO v_patient_user FROM public.patients WHERE patient_id = p_patient_id;
  IF v_patient_user IS NOT NULL THEN
    v_destination := jsonb_build_object('panel','patient','section','book-appointment','recurrence_group_id',v_group);
    PERFORM public.notify_patient(p_patient_id, 'Recurring Appointment Requests Generated',
      format('%s appointment request(s) were prepared by authorized staff for your review.', jsonb_array_length(v_generated)),
      'Appointment Request', NULL, NULL, NULL, v_destination, 'Open appointments');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Recurring Appointment Suggestions Generated', 'Appointments', v_group::text,
    jsonb_build_object('patient_id',p_patient_id,'days',p_recurring_days,'preferred_time',p_preferred_time,
      'prescribed_frequency',v_frequency,'generated',v_generated,'skipped',v_skipped));
  RETURN jsonb_build_object('success',true,'recurrence_group_id',v_group,'generated',v_generated,'skipped',v_skipped,
    'note','These are Pending requests. Staff must still verify documents and assign machines before confirmation.');
END $$;

-- Function privileges: public workflow RPCs; internal helpers are not exposed to clients.
DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'create_appointment_request(date,text,text)',
    'set_appointment_status(uuid,text,text)',
    'assign_machine_and_confirm_appointment(uuid,uuid,date,time without time zone,time without time zone,text,text)',
    'request_document_correction(uuid,text,text)',
    'request_reschedule(uuid,date,text,text)',
    'process_reschedule_request(uuid,text,uuid,text,date,text)',
    'request_cancellation(uuid,text)',
    'process_cancellation_request(uuid,text,text)',
    'record_appointment_attendance(uuid,text,text)',
    'generate_recurring_appointments(uuid,text[],text,date,date)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY[
    'config_slot(text)','assert_booking_date(date,text)','append_status_history(jsonb,text,text,text,jsonb)',
    'appointment_snapshot(uuid)','notify_patient(uuid,text,text,text,uuid,uuid,uuid,jsonb,text)',
    'lock_schedule_slot(date,text)','missing_verified_documents(uuid)','release_machine_slot(uuid)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;
