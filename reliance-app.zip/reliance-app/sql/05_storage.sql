-- Reliance Dialysis Center Inc. — private Supabase Storage buckets and object policies
-- No public URLs are used. The frontend uses short-lived signed URLs after these policies authorize access.

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('patient-documents', 'patient-documents', false, 10485760, ARRAY['application/pdf','image/jpeg','image/png','image/webp']),
  ('authorized-medical-files', 'authorized-medical-files', false, 10485760, ARRAY['application/pdf','image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO UPDATE SET
  public = false,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

CREATE OR REPLACE FUNCTION public.can_read_storage_object(p_bucket text, p_object_name text)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF p_bucket = 'patient-documents' THEN
    RETURN public.is_active_staff()
      OR (public.current_patient_id() IS NOT NULL AND (storage.foldername(p_object_name))[1] = auth.uid()::text);
  ELSIF p_bucket = 'authorized-medical-files' THEN
    RETURN public.is_active_staff() OR EXISTS (
      SELECT 1
      FROM public.patient_documents d JOIN public.patients p ON p.patient_id = d.patient_id
      WHERE d.storage_bucket = 'authorized-medical-files' AND d.file_path = p_object_name
        AND d.is_released_to_patient = true AND p.user_id = auth.uid() AND p.account_status = 'Active'
    );
  END IF;
  RETURN false;
END $$;

CREATE OR REPLACE FUNCTION public.can_write_patient_storage_object(p_bucket text, p_object_name text)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF p_bucket <> 'patient-documents' THEN RETURN false; END IF;
  IF public.is_active_staff() THEN RETURN true; END IF;
  RETURN public.current_patient_id() IS NOT NULL
    AND p_object_name NOT LIKE '%..%'
    AND (storage.foldername(p_object_name))[1] = auth.uid()::text;
END $$;

CREATE OR REPLACE FUNCTION public.can_write_authorized_storage_object(p_bucket text, p_object_name text)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
DECLARE v_folder text;
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF p_bucket <> 'authorized-medical-files' OR NOT public.is_active_staff() THEN RETURN false; END IF;
  v_folder := (storage.foldername(p_object_name))[1];
  RETURN p_object_name NOT LIKE '%..%'
    AND EXISTS (SELECT 1 FROM public.patients p WHERE p.user_id::text = v_folder);
END $$;

CREATE OR REPLACE FUNCTION public.can_delete_storage_object(p_bucket text, p_object_name text)
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
BEGIN
  RETURN auth.uid() IS NOT NULL
    AND p_bucket IN ('patient-documents','authorized-medical-files')
    AND public.is_active_staff();
END $$;

-- Supabase enables RLS on storage.objects by default. Creating policies is supported;
-- changing ownership or toggling RLS on the managed table is not required.

DROP POLICY IF EXISTS patient_docs_storage_select ON storage.objects;
DROP POLICY IF EXISTS patient_docs_storage_insert ON storage.objects;
DROP POLICY IF EXISTS patient_docs_storage_update ON storage.objects;
DROP POLICY IF EXISTS patient_docs_storage_delete ON storage.objects;
DROP POLICY IF EXISTS reliance_private_docs_select ON storage.objects;
DROP POLICY IF EXISTS reliance_private_docs_insert ON storage.objects;
DROP POLICY IF EXISTS reliance_private_docs_update ON storage.objects;
DROP POLICY IF EXISTS reliance_private_docs_delete ON storage.objects;

CREATE POLICY reliance_private_docs_select ON storage.objects FOR SELECT TO authenticated
  USING (public.can_read_storage_object(bucket_id, name));

CREATE POLICY reliance_private_docs_insert ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    public.can_write_patient_storage_object(bucket_id, name)
    OR public.can_write_authorized_storage_object(bucket_id, name)
  );

CREATE POLICY reliance_private_docs_update ON storage.objects FOR UPDATE TO authenticated
  USING (
    public.can_write_patient_storage_object(bucket_id, name)
    OR public.can_write_authorized_storage_object(bucket_id, name)
  )
  WITH CHECK (
    public.can_write_patient_storage_object(bucket_id, name)
    OR public.can_write_authorized_storage_object(bucket_id, name)
  );

CREATE POLICY reliance_private_docs_delete ON storage.objects FOR DELETE TO authenticated
  USING (public.can_delete_storage_object(bucket_id, name));

DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'can_read_storage_object(text,text)','can_write_patient_storage_object(text,text)',
    'can_write_authorized_storage_object(text,text)','can_delete_storage_object(text,text)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
END $grants$;
