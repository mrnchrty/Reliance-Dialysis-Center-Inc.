-- Reliance Dialysis Center Inc. — system configuration, generated capacity and atomic availability
-- Design note: system configuration is stored as an append-only snapshot in AUDIT_LOGS.details.
-- This preserves the exactly-ten-table rule and gives a complete configuration audit trail.

CREATE OR REPLACE FUNCTION public.default_system_config()
RETURNS jsonb LANGUAGE sql IMMUTABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT jsonb_build_object(
    'version', 1,
    'timezone', 'Asia/Manila',
    'operating_days', jsonb_build_array(1,2,3,4,5,6),
    'operating_hours', jsonb_build_object('open','08:00','close','17:00'),
    'time_slots', jsonb_build_array(
      jsonb_build_object('id','Morning','label','Morning','display','8:00 AM – 11:00 AM','start_time','08:00','end_time','11:00','capacity_per_machine',1),
      jsonb_build_object('id','Midday','label','Midday','display','11:00 AM – 2:00 PM','start_time','11:00','end_time','14:00','capacity_per_machine',1),
      jsonb_build_object('id','Afternoon','label','Afternoon','display','2:00 PM – 5:00 PM','start_time','14:00','end_time','17:00','capacity_per_machine',1)
    ),
    'required_document_types', jsonb_build_array('Nephrologist''s Endorsement','Medical Abstract','Latest Laboratory Results','Valid Identification'),
    'patients_per_machine_per_day', 3,
    'require_staff_machine_assignment', true,
    'require_verified_documents_for_confirmation', true,
    'max_advance_days', 90,
    'min_lead_days', 1,
    'allow_same_day', false,
    'allow_multiple_open_requests', true,
    'max_open_requests', 6
  );
$$;

CREATE OR REPLACE FUNCTION public.get_clinic_schedule_config()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_cfg jsonb; v_default jsonb := public.default_system_config(); v_slots jsonb;
BEGIN
  SELECT details INTO v_cfg FROM public.audit_logs
  WHERE activity = 'System Configuration Updated' AND affected_module = 'System Configuration'
  ORDER BY created_at DESC, audit_id DESC LIMIT 1;

  IF v_cfg IS NULL OR v_cfg = '{}'::jsonb THEN
    SELECT schedule_config INTO v_cfg FROM public.dialysis_machines
    WHERE schedule_config IS NOT NULL ORDER BY machine_code ASC LIMIT 1;
  END IF;

  -- Normalize legacy/custom slot definitions so every configured slot has one patient per machine.
  v_slots := COALESCE(v_cfg -> 'time_slots', v_default -> 'time_slots');
  SELECT COALESCE(jsonb_agg(
    COALESCE((
      SELECT value FROM jsonb_array_elements(v_default -> 'time_slots')
      WHERE value ->> 'id' = slot ->> 'id' LIMIT 1
    ), '{}'::jsonb) || slot || jsonb_build_object('capacity_per_machine', 1)
    ORDER BY slot ->> 'start_time'
  ), '[]'::jsonb) INTO v_slots
  FROM jsonb_array_elements(v_slots) slot;

  RETURN v_default || COALESCE(v_cfg, '{}'::jsonb) || jsonb_build_object('time_slots', v_slots);
END $$;

CREATE OR REPLACE FUNCTION public.get_system_config()
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT public.get_clinic_schedule_config(); $$;

CREATE OR REPLACE FUNCTION public.validate_system_config(p_config jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_days int[]; v_slot_count int; v_open time; v_close time;
  v_slot_ids text[]; v_conflicts int; v_slot_conflicts int;
BEGIN
  IF p_config IS NULL OR jsonb_typeof(p_config) <> 'object' THEN
    RAISE EXCEPTION 'System configuration must be a JSON object.';
  END IF;

  SELECT array_agg(value::int ORDER BY value::int) INTO v_days
  FROM jsonb_array_elements_text(p_config -> 'operating_days');
  IF v_days IS NULL OR cardinality(v_days) = 0 OR EXISTS (SELECT 1 FROM unnest(v_days) d WHERE d < 1 OR d > 6) THEN
    RAISE EXCEPTION 'Operating days must be Monday through Saturday only; Sunday remains closed.';
  END IF;

  v_open := (p_config -> 'operating_hours' ->> 'open')::time;
  v_close := (p_config -> 'operating_hours' ->> 'close')::time;
  IF v_open IS NULL OR v_close IS NULL OR v_close <= v_open THEN
    RAISE EXCEPTION 'Clinic closing time must be later than opening time.';
  END IF;

  SELECT count(*), array_agg(value ->> 'id') INTO v_slot_count, v_slot_ids
  FROM jsonb_array_elements(p_config -> 'time_slots');
  IF v_slot_count IS NULL OR v_slot_count = 0 THEN
    RAISE EXCEPTION 'At least one appointment time slot is required.';
  END IF;
  IF (SELECT count(*) FROM unnest(v_slot_ids) s WHERE s IS NULL OR trim(s) = '') > 0 OR
     (SELECT count(DISTINCT s) FROM unnest(v_slot_ids) s) <> cardinality(v_slot_ids) THEN
    RAISE EXCEPTION 'Every time slot needs a unique identifier.';
  END IF;
  IF COALESCE((p_config ->> 'patients_per_machine_per_day')::int, 0) <> v_slot_count THEN
    RAISE EXCEPTION 'Patients per machine per day must equal the number of configured time slots (one patient per machine per time window).';
  END IF;

  IF EXISTS (
    SELECT 1 FROM (
      SELECT (value ->> 'start_time')::time AS s, (value ->> 'end_time')::time AS e,
             (value ->> 'capacity_per_machine')::int AS cap,
             lag((value ->> 'end_time')::time) OVER (ORDER BY (value ->> 'start_time')::time) AS prev_e
      FROM jsonb_array_elements(p_config -> 'time_slots')
    ) t
    WHERE s IS NULL OR e IS NULL OR e <= s OR s < v_open OR e > v_close OR cap IS NULL OR cap <> 1 OR prev_e > s
  ) THEN
    RAISE EXCEPTION 'Time slots must be within operating hours, non-overlapping, and allow one patient per machine.';
  END IF;

  SELECT count(*) INTO v_conflicts FROM public.appointments a
  WHERE a.is_cancelled = false AND a.requested_date >= public.app_today()
    AND (
      NOT (EXTRACT(ISODOW FROM a.requested_date)::int = ANY(v_days))
      OR NOT (a.requested_time = ANY(v_slot_ids))
    );
  IF v_conflicts > 0 THEN
    RAISE EXCEPTION 'Configuration conflicts with % future appointment request(s). Reassign or process those requests before changing operating days or time slots.', v_conflicts;
  END IF;

  SELECT count(*) INTO v_slot_conflicts FROM public.machine_slots ms
  WHERE ms.schedule_date >= public.app_today()
    AND ms.slot_status IN ('Booked','Reserved','Maintenance')
    AND (
      NOT (EXTRACT(ISODOW FROM ms.schedule_date)::int = ANY(v_days))
      OR NOT (ms.slot_key = ANY(v_slot_ids))
    );
  IF v_slot_conflicts > 0 THEN
    RAISE EXCEPTION 'Configuration conflicts with % reserved machine slot(s). Resolve machine schedules before saving.', v_slot_conflicts;
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.update_clinic_schedule_config(p_config jsonb)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_config jsonb; v_machine uuid; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Unauthorized: only an active Super Administrator can update system configuration.';
  END IF;
  PERFORM public.validate_system_config(p_config);
  v_config := p_config || jsonb_build_object(
    'version', COALESCE((p_config ->> 'version')::int, 0) + 1,
    'updated_at', now(), 'updated_by', auth.uid()
  );

  INSERT INTO public.audit_logs (
    user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details, severity
  ) VALUES (
    auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'System Configuration Updated', 'System Configuration', 'clinic', v_config, 'Warning'
  );

  SELECT machine_id INTO v_machine FROM public.dialysis_machines ORDER BY machine_code ASC LIMIT 1;
  IF v_machine IS NOT NULL THEN
    UPDATE public.dialysis_machines SET schedule_config = v_config, updated_by = auth.uid() WHERE machine_id = v_machine;
  END IF;
  RETURN v_config;
END $$;

CREATE OR REPLACE FUNCTION public.update_system_config(p_config jsonb)
RETURNS jsonb LANGUAGE sql SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT public.update_clinic_schedule_config(p_config); $$;

CREATE OR REPLACE FUNCTION public.internal_ensure_capacity(p_start_date date, p_end_date date)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_cfg jsonb := public.get_system_config(); v_days int[]; v_day date; v_slot jsonb;
  v_machine record; v_count int := 0;
BEGIN
  IF p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Capacity generation range must be between 0 and 120 days.';
  END IF;
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');

  FOR v_day IN SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date LOOP
    CONTINUE WHEN NOT (EXTRACT(ISODOW FROM v_day)::int = ANY(v_days));
    FOR v_machine IN SELECT * FROM public.dialysis_machines
                     WHERE is_active = true AND machine_status IN ('Available','Occupied') LOOP
      FOR v_slot IN SELECT value FROM jsonb_array_elements(v_cfg -> 'time_slots') LOOP
        BEGIN
          INSERT INTO public.machine_slots (
            machine_id, schedule_date, start_time, end_time, slot_status, slot_key, slot_label, capacity_source
          ) VALUES (
            v_machine.machine_id, v_day, (v_slot ->> 'start_time')::time, (v_slot ->> 'end_time')::time,
            'Available', v_slot ->> 'id', COALESCE(v_slot ->> 'display', v_slot ->> 'label'), 'Generated'
          ) ON CONFLICT (machine_id, schedule_date, slot_key) WHERE slot_status <> 'Cancelled' DO NOTHING;
          IF FOUND THEN v_count := v_count + 1; END IF;
        EXCEPTION WHEN exclusion_violation THEN
          -- A legacy/custom booked schedule already occupies this machine window.
          CONTINUE;
        END;
      END LOOP;
    END LOOP;
  END LOOP;
  RETURN v_count;
END $$;

CREATE OR REPLACE FUNCTION public.ensure_capacity_slots(p_start_date date, p_end_date date)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF public.current_patient_id() IS NULL AND NOT public.is_active_staff() THEN
    RAISE EXCEPTION 'Your account is not active.';
  END IF;
  RETURN public.internal_ensure_capacity(p_start_date, p_end_date);
END $$;

CREATE OR REPLACE FUNCTION public.slot_remaining_capacity(p_date date, p_slot_id text)
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  WITH s AS (
    SELECT ms.slot_status
    FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
    WHERE ms.schedule_date = p_date AND ms.slot_key = p_slot_id
      AND ms.slot_status <> 'Cancelled' AND m.is_active = true
      AND m.machine_status IN ('Available','Occupied')
  ), p AS (
    SELECT count(*)::int AS n FROM public.appointments a
    WHERE a.requested_date = p_date AND a.requested_time = p_slot_id
      AND a.machine_slot_id IS NULL AND a.is_cancelled = false
      AND a.appointment_status IN ('Pending','Under Review','Confirmed')
  )
  SELECT GREATEST(
    (SELECT count(*)::int FROM s)
    - (SELECT count(*)::int FROM s WHERE slot_status IN ('Booked','Reserved','Completed'))
    - (SELECT count(*)::int FROM s WHERE slot_status = 'Maintenance')
    - (SELECT n FROM p), 0
  )::int;
$$;

CREATE OR REPLACE FUNCTION public.get_schedule_availability(p_start_date date, p_end_date date)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_cfg jsonb; v_days int[]; v_active int; v_dates jsonb;
        v_min int; v_max int; v_allow boolean;
BEGIN
  IF p_end_date < p_start_date OR p_end_date - p_start_date > 120 THEN
    RAISE EXCEPTION 'Availability range must be between 0 and 120 days.';
  END IF;
  v_cfg := public.get_system_config();
  v_min := COALESCE((v_cfg ->> 'min_lead_days')::int, 1);
  v_max := COALESCE((v_cfg ->> 'max_advance_days')::int, 90);
  v_allow := COALESCE((v_cfg ->> 'allow_same_day')::boolean, false);
  SELECT array_agg(value::int) INTO v_days FROM jsonb_array_elements_text(v_cfg -> 'operating_days');
  SELECT count(*)::int INTO v_active FROM public.dialysis_machines
  WHERE is_active = true AND machine_status IN ('Available','Occupied');

  WITH days AS (
    SELECT generate_series(p_start_date, p_end_date, interval '1 day')::date AS d
  ), slots AS (
    SELECT value ->> 'id' AS slot_id, value ->> 'label' AS label,
           value ->> 'display' AS display, (value ->> 'start_time')::time AS start_time,
           (value ->> 'end_time')::time AS end_time
    FROM jsonb_array_elements(v_cfg -> 'time_slots')
  ), grid AS (
    SELECT days.d, slots.* FROM days CROSS JOIN slots
  ), slot_state AS (
    SELECT ms.schedule_date AS d, ms.slot_key,
           count(*)::int AS total,
           count(*) FILTER (WHERE ms.slot_status IN ('Booked','Reserved','Completed'))::int AS booked,
           count(*) FILTER (WHERE ms.slot_status = 'Maintenance')::int AS blocked
    FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
    WHERE ms.schedule_date BETWEEN p_start_date AND p_end_date AND ms.slot_status <> 'Cancelled'
      AND m.is_active = true AND m.machine_status IN ('Available','Occupied')
    GROUP BY ms.schedule_date, ms.slot_key
  ), pending AS (
    SELECT requested_date AS d, requested_time AS slot_id, count(*)::int AS pending
    FROM public.appointments
    WHERE requested_date BETWEEN p_start_date AND p_end_date AND machine_slot_id IS NULL
      AND is_cancelled = false AND appointment_status IN ('Pending','Under Review','Confirmed')
    GROUP BY requested_date, requested_time
  ), date_slots AS (
    SELECT g.d, jsonb_agg(jsonb_build_object(
      'slot_id', g.slot_id, 'label', g.label, 'display', g.display,
      'start_time', to_char(g.start_time,'HH24:MI'), 'end_time', to_char(g.end_time,'HH24:MI'),
      'total', COALESCE(ss.total,0), 'booked', COALESCE(ss.booked,0), 'blocked', COALESCE(ss.blocked,0),
      'pending', COALESCE(p.pending,0),
      'available', GREATEST(COALESCE(ss.total,0) - COALESCE(ss.booked,0) - COALESCE(ss.blocked,0) - COALESCE(p.pending,0), 0),
      'enabled', false
    ) ORDER BY g.start_time) AS slots
    FROM grid g
    LEFT JOIN slot_state ss ON ss.d = g.d AND ss.slot_key = g.slot_id
    LEFT JOIN pending p ON p.d = g.d AND p.slot_id = g.slot_id
    GROUP BY g.d
  )
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'date', ds.d,
    'operating_day', EXTRACT(ISODOW FROM ds.d)::int = ANY(v_days),
    'slots', (
      SELECT jsonb_agg(slot || jsonb_build_object(
        'enabled', ds.d >= public.app_today() + GREATEST(v_min,0)
          AND (ds.d > public.app_today() OR (v_min = 0 AND v_allow))
          AND ds.d <= public.app_today() + v_max
          AND EXTRACT(ISODOW FROM ds.d)::int = ANY(v_days)
          AND (slot ->> 'available')::int > 0
      ) ORDER BY slot ->> 'start_time')
      FROM jsonb_array_elements(ds.slots) slot
    ),
    'available', (
      SELECT COALESCE(sum((slot ->> 'available')::int),0) FROM jsonb_array_elements(ds.slots) slot
    )
  ) ORDER BY ds.d), '[]'::jsonb) INTO v_dates FROM date_slots ds;

  RETURN jsonb_build_object(
    'config', v_cfg, 'active_machines', v_active,
    'measurement', 'One generated MACHINE_SLOTS row per active machine per configured time window. Available = total - booked - blocked - unassigned active requests.',
    'timezone', 'Asia/Manila', 'generated_at', now(), 'dates', v_dates
  );
END $$;

CREATE OR REPLACE FUNCTION public.get_appointment_availability(p_start_date date, p_end_date date)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT public.get_schedule_availability(p_start_date, p_end_date); $$;

CREATE OR REPLACE FUNCTION public.get_machine_availability(p_start_date date, p_end_date date)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb;
BEGIN
  IF NOT public.is_active_staff() THEN RAISE EXCEPTION 'Unauthorized: staff access required.'; END IF;
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'machine_id', m.machine_id, 'machine_code', m.machine_code, 'machine_name', m.machine_name,
    'machine_status', m.machine_status, 'schedule_date', ms.schedule_date, 'slot_key', ms.slot_key,
    'slot_label', ms.slot_label, 'start_time', ms.start_time, 'end_time', ms.end_time,
    'slot_status', ms.slot_status, 'appointment_id', ms.appointment_id
  ) ORDER BY m.machine_code, ms.schedule_date, ms.start_time), '[]'::jsonb) INTO v_result
  FROM public.dialysis_machines m LEFT JOIN public.machine_slots ms
    ON ms.machine_id = m.machine_id AND ms.schedule_date BETWEEN p_start_date AND p_end_date
  WHERE m.is_active = true;
  RETURN jsonb_build_object('machines', v_result, 'config', public.get_system_config());
END $$;

-- Function privileges for this module.
DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'get_clinic_schedule_config()','get_system_config()','default_system_config()',
    'update_clinic_schedule_config(jsonb)','update_system_config(jsonb)',
    'ensure_capacity_slots(date,date)','get_schedule_availability(date,date)',
    'get_appointment_availability(date,date)','get_machine_availability(date,date)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY['validate_system_config(jsonb)','internal_ensure_capacity(date,date)','slot_remaining_capacity(date,text)'] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;
