-- Reliance Dialysis Center Inc. — private document workflow, official dialysis records, record release and detail bundles

CREATE OR REPLACE FUNCTION public.register_patient_document(
  p_document_type text, p_file_path text, p_file_name text,
  p_file_size bigint, p_mime_type text, p_replaces_document_id uuid DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
DECLARE
  v_patient public.patients%ROWTYPE; v_old public.patient_documents%ROWTYPE;
  v_required text[]; v_id uuid; v_version int := 1; v_appointment uuid;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF public.is_active_staff() THEN RAISE EXCEPTION 'Use the authorized medical file workflow for staff uploads.'; END IF;
  SELECT * INTO v_patient FROM public.patients WHERE patient_id = public.current_patient_id();
  IF v_patient.patient_id IS NULL THEN RAISE EXCEPTION 'Active patient account required.'; END IF;

  SELECT array_agg(value) INTO v_required FROM jsonb_array_elements_text(public.get_system_config() -> 'required_document_types');
  IF NOT (p_document_type = ANY(v_required)) THEN RAISE EXCEPTION 'Select one of the four required document categories.'; END IF;
  IF p_file_path IS NULL OR p_file_path = '' OR p_file_path LIKE '%..%' OR p_file_path NOT LIKE auth.uid()::text || '/%' THEN
    RAISE EXCEPTION 'Invalid private document path.';
  END IF;
  IF COALESCE(p_file_size,0) <= 0 OR p_file_size > 10485760 THEN RAISE EXCEPTION 'File size must be greater than zero and no larger than 10 MB.'; END IF;
  IF p_mime_type NOT IN ('application/pdf','image/jpeg','image/png','image/webp') THEN
    RAISE EXCEPTION 'Allowed file types are PDF, JPEG, PNG, and WebP.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM storage.objects WHERE bucket_id = 'patient-documents' AND name = p_file_path) THEN
    RAISE EXCEPTION 'The uploaded file was not found in private Storage. Please upload it again.';
  END IF;

  IF p_replaces_document_id IS NOT NULL THEN
    SELECT * INTO v_old FROM public.patient_documents
    WHERE document_id = p_replaces_document_id AND patient_id = v_patient.patient_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Document to replace was not found.'; END IF;
    IF v_old.verification_status = 'Verified' AND v_old.correction_requested = false AND v_old.is_outdated = false THEN
      RAISE EXCEPTION 'Verified documents remain available for succeeding bookings. Replacement requires a staff update request.';
    END IF;
  ELSE
    SELECT * INTO v_old FROM public.patient_documents
    WHERE patient_id = v_patient.patient_id AND document_type = p_document_type AND is_current = true
    ORDER BY uploaded_at DESC LIMIT 1 FOR UPDATE;
    IF FOUND AND v_old.verification_status = 'Verified' AND v_old.correction_requested = false AND v_old.is_outdated = false THEN
      RAISE EXCEPTION 'This document is already verified and can be reused. Ask the center if an updated copy is required.';
    END IF;
  END IF;

  IF v_old.document_id IS NOT NULL THEN
    v_version := v_old.version + 1;
    UPDATE public.patient_documents
    SET is_current = false, is_outdated = true
    WHERE document_id = v_old.document_id;
  END IF;

  INSERT INTO public.patient_documents (
    patient_id, document_type, file_path, file_name, file_size, mime_type, storage_bucket,
    uploaded_by, verification_status, is_released_to_patient, is_current, version,
    replaces_document_id, created_at, updated_at
  ) VALUES (
    v_patient.patient_id, p_document_type, p_file_path, p_file_name, p_file_size, p_mime_type,
    'patient-documents', auth.uid(), 'Pending', true, true, v_version,
    v_old.document_id, now(), now()
  ) RETURNING document_id INTO v_id;

  SELECT appointment_id INTO v_appointment FROM public.appointments
  WHERE patient_id = v_patient.patient_id AND is_cancelled = false
    AND appointment_status IN ('Pending','Under Review','Confirmed')
  ORDER BY created_at DESC LIMIT 1;

  PERFORM public.notify_all_staff(
    CASE WHEN v_old.document_id IS NULL THEN 'New Document Submission' ELSE 'Corrected Document Submitted' END,
    format('%s submitted %s (%s).', v_patient.full_name, p_document_type, p_file_name),
    CASE WHEN v_old.document_id IS NULL THEN 'New Document Submission' ELSE 'Corrected Document Submitted' END,
    v_appointment,
    jsonb_build_object('panel','staff','section','patient-record','patient_id',v_patient.patient_id,
      'document_id',v_id,'tab','documents','appointment_id',v_appointment)
  );

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Patient Document Uploaded', 'Documents', v_id::text,
    jsonb_build_object('document_type',p_document_type,'file_name',p_file_name,'file_size',p_file_size,
      'mime_type',p_mime_type,'version',v_version,'replaces',v_old.document_id));
  RETURN jsonb_build_object('success',true,'document_id',v_id,'verification_status','Pending','version',v_version);
END $$;

CREATE OR REPLACE FUNCTION public.verify_document(
  p_document_id uuid, p_status text, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_doc public.patient_documents%ROWTYPE; v_title text; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('verify_documents') THEN RAISE EXCEPTION 'Unauthorized: document verification permission required.'; END IF;
  IF p_status NOT IN ('Verified','Needs Correction','Rejected') THEN RAISE EXCEPTION 'Invalid document verification status.'; END IF;
  IF p_status <> 'Verified' AND NULLIF(trim(COALESCE(p_remarks,'')),'') IS NULL THEN
    RAISE EXCEPTION 'Provide remarks when rejecting a document or requesting correction.';
  END IF;
  SELECT * INTO v_doc FROM public.patient_documents WHERE document_id = p_document_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Document not found.'; END IF;

  UPDATE public.patient_documents SET
    verification_status = p_status, remarks = p_remarks,
    reviewed_by = public.current_staff_id(), reviewed_at = now(),
    correction_requested = p_status <> 'Verified',
    correction_notes = CASE WHEN p_status = 'Verified' THEN NULL ELSE p_remarks END,
    correction_requested_by = CASE WHEN p_status = 'Verified' THEN NULL ELSE public.current_staff_id() END,
    correction_requested_at = CASE WHEN p_status = 'Verified' THEN NULL ELSE now() END,
    is_outdated = p_status <> 'Verified',
    is_released_to_patient = true
  WHERE document_id = p_document_id;

  v_title := CASE p_status WHEN 'Verified' THEN 'Document Verified'
    WHEN 'Needs Correction' THEN 'Document Correction Required' ELSE 'Document Rejected' END;
  v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',p_document_id);
  PERFORM public.notify_patient(v_doc.patient_id, v_title,
    format('Your %s was marked %s.%s', v_doc.document_type, p_status,
      CASE WHEN p_remarks IS NULL THEN '' ELSE ' Staff remarks: ' || p_remarks END),
    v_title, NULL, p_document_id, NULL, v_destination, 'Open document');

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE p_status WHEN 'Verified' THEN 'Document Verified' ELSE 'Document Verification Action' END,
    'Documents', p_document_id::text, jsonb_build_object('status',p_status,'remarks',p_remarks,'document_type',v_doc.document_type));
  RETURN jsonb_build_object('success',true,'document_id',p_document_id,'verification_status',p_status);
END $$;

CREATE OR REPLACE FUNCTION public.register_authorized_medical_file(
  p_patient_id uuid, p_file_path text, p_file_name text, p_file_size bigint,
  p_mime_type text, p_is_released boolean DEFAULT false, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'storage'
AS $$
DECLARE v_patient public.patients%ROWTYPE; v_id uuid; v_version int; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('release_records') THEN RAISE EXCEPTION 'Unauthorized: record-release permission required.'; END IF;
  SELECT * INTO v_patient FROM public.patients WHERE patient_id = p_patient_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Patient not found.'; END IF;
  IF p_file_path IS NULL OR p_file_path LIKE '%..%' OR p_file_path NOT LIKE v_patient.user_id::text || '/%' THEN
    RAISE EXCEPTION 'Invalid authorized medical file path.';
  END IF;
  IF COALESCE(p_file_size,0) <= 0 OR p_file_size > 10485760 THEN RAISE EXCEPTION 'File size must be no larger than 10 MB.'; END IF;
  IF p_mime_type NOT IN ('application/pdf','image/jpeg','image/png','image/webp') THEN RAISE EXCEPTION 'Unsupported file type.'; END IF;
  IF NOT EXISTS (SELECT 1 FROM storage.objects WHERE bucket_id = 'authorized-medical-files' AND name = p_file_path) THEN
    RAISE EXCEPTION 'The uploaded file was not found in private Storage.';
  END IF;
  SELECT COALESCE(max(version),0) + 1 INTO v_version FROM public.patient_documents
  WHERE patient_id = p_patient_id AND document_type = 'Authorized Medical Record';

  INSERT INTO public.patient_documents (
    patient_id, document_type, file_path, file_name, file_size, mime_type, storage_bucket,
    uploaded_by, verification_status, reviewed_by, reviewed_at, remarks,
    is_released_to_patient, is_current, version
  ) VALUES (
    p_patient_id, 'Authorized Medical Record', p_file_path, p_file_name, p_file_size, p_mime_type,
    'authorized-medical-files', auth.uid(), 'Verified', public.current_staff_id(), now(), p_remarks,
    COALESCE(p_is_released,false), true, v_version
  ) RETURNING document_id INTO v_id;

  IF COALESCE(p_is_released,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',v_id);
    PERFORM public.notify_patient(p_patient_id, 'New Medical Record',
      'An authorized medical file has been released to your records.',
      'New Medical Record', NULL, v_id, NULL, v_destination, 'Open medical record');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Authorized Medical File Uploaded', 'Documents', v_id::text,
    jsonb_build_object('patient_id',p_patient_id,'file_name',p_file_name,'released',p_is_released));
  RETURN jsonb_build_object('success',true,'document_id',v_id,'is_released',COALESCE(p_is_released,false));
END $$;

CREATE OR REPLACE FUNCTION public.set_document_release(
  p_document_id uuid, p_release boolean, p_remarks text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_doc public.patient_documents%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('release_records') THEN RAISE EXCEPTION 'Unauthorized: record-release permission required.'; END IF;
  SELECT * INTO v_doc FROM public.patient_documents WHERE document_id = p_document_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Document not found.'; END IF;
  UPDATE public.patient_documents SET
    is_released_to_patient = COALESCE(p_release,false),
    remarks = COALESCE(NULLIF(trim(p_remarks),''), remarks),
    reviewed_by = public.current_staff_id(), reviewed_at = now()
  WHERE document_id = p_document_id;
  IF COALESCE(p_release,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','documents','document_id',p_document_id);
    PERFORM public.notify_patient(v_doc.patient_id, 'New Medical Record',
      'An authorized medical document is now available in My Records.',
      'New Medical Record', NULL, p_document_id, NULL, v_destination, 'Open medical record');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Document Release Changed', 'Documents', p_document_id::text,
    jsonb_build_object('released',p_release,'remarks',p_remarks));
  RETURN jsonb_build_object('success',true,'is_released',COALESCE(p_release,false));
END $$;

CREATE OR REPLACE FUNCTION public.record_dialysis_session(
  p_appointment_id uuid, p_treatment_date date, p_start_time time without time zone,
  p_end_time time without time zone, p_pre_weight numeric DEFAULT NULL,
  p_post_weight numeric DEFAULT NULL, p_bp_pre text DEFAULT NULL, p_bp_post text DEFAULT NULL,
  p_ultrafiltration numeric DEFAULT NULL, p_session_status text DEFAULT 'Completed',
  p_treatment_notes text DEFAULT NULL, p_patient_visible_notes text DEFAULT NULL,
  p_is_released boolean DEFAULT false, p_released_remarks text DEFAULT NULL,
  p_attendance_flag text DEFAULT 'Attended'
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_appt public.appointments%ROWTYPE; v_machine_id uuid; v_id uuid;
  v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('record_sessions') THEN RAISE EXCEPTION 'Unauthorized: session-recording permission required.'; END IF;
  IF p_end_time <= p_start_time THEN RAISE EXCEPTION 'Actual end time must be later than actual start time.'; END IF;
  IF p_attendance_flag NOT IN ('Scheduled','Attended','No-Show') THEN RAISE EXCEPTION 'Select an explicit attendance outcome.'; END IF;
  IF p_session_status NOT IN ('In Progress','Completed','Terminated Early') THEN RAISE EXCEPTION 'Invalid session status.'; END IF;
  SELECT * INTO v_appt FROM public.appointments WHERE appointment_id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Appointment not found.'; END IF;

  SELECT ms.machine_id INTO v_machine_id
  FROM public.machine_slots ms WHERE ms.machine_slot_id = v_appt.machine_slot_id;
  IF v_machine_id IS NULL THEN
    SELECT m.machine_id INTO v_machine_id FROM public.dialysis_machines m
    WHERE m.machine_code = v_appt.machine_snapshot ->> 'machine_code' LIMIT 1;
  END IF;
  IF v_machine_id IS NULL THEN RAISE EXCEPTION 'Assign a machine to the appointment before recording a dialysis session.'; END IF;

  INSERT INTO public.dialysis_sessions (
    appointment_id, patient_id, machine_id, recorded_by, treatment_date, actual_start_time, actual_end_time,
    pre_dialysis_weight, post_dialysis_weight, blood_pressure_pre, blood_pressure_post, ultrafiltration_volume,
    session_status, is_released_to_patient, released_at, released_by, released_remarks,
    patient_visible_notes, treatment_notes
  ) VALUES (
    p_appointment_id, v_appt.patient_id, v_machine_id, public.current_staff_id(), p_treatment_date,
    p_start_time, p_end_time, p_pre_weight, p_post_weight, p_bp_pre, p_bp_post, p_ultrafiltration,
    p_session_status, COALESCE(p_is_released,false),
    CASE WHEN COALESCE(p_is_released,false) THEN now() ELSE NULL END,
    CASE WHEN COALESCE(p_is_released,false) THEN public.current_staff_id() ELSE NULL END,
    p_released_remarks, p_patient_visible_notes, p_treatment_notes
  ) ON CONFLICT (appointment_id) DO UPDATE SET
    patient_id = EXCLUDED.patient_id, machine_id = EXCLUDED.machine_id, recorded_by = EXCLUDED.recorded_by,
    treatment_date = EXCLUDED.treatment_date, actual_start_time = EXCLUDED.actual_start_time,
    actual_end_time = EXCLUDED.actual_end_time, pre_dialysis_weight = EXCLUDED.pre_dialysis_weight,
    post_dialysis_weight = EXCLUDED.post_dialysis_weight, blood_pressure_pre = EXCLUDED.blood_pressure_pre,
    blood_pressure_post = EXCLUDED.blood_pressure_post, ultrafiltration_volume = EXCLUDED.ultrafiltration_volume,
    session_status = EXCLUDED.session_status, is_released_to_patient = EXCLUDED.is_released_to_patient,
    released_at = EXCLUDED.released_at, released_by = EXCLUDED.released_by,
    released_remarks = EXCLUDED.released_remarks, patient_visible_notes = EXCLUDED.patient_visible_notes,
    treatment_notes = EXCLUDED.treatment_notes
  RETURNING session_id INTO v_id;

  UPDATE public.appointments SET
    attendance_flag = p_attendance_flag,
    attendance_recorded_by = public.current_staff_id(),
    attendance_recorded_at = now()
  WHERE appointment_id = p_appointment_id;

  UPDATE public.machine_slots SET slot_status = 'Completed'
  WHERE machine_slot_id = v_appt.machine_slot_id AND slot_status IN ('Booked','Reserved');

  IF COALESCE(p_is_released,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','history','session_id',v_id);
    PERFORM public.notify_patient(v_appt.patient_id, 'New Medical Record',
      format('Your dialysis session record for %s has been released.', to_char(p_treatment_date,'Mon DD, YYYY')),
      'New Medical Record', p_appointment_id, NULL, v_id, v_destination, 'Open session details');
  END IF;

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Dialysis Session Recorded', 'Dialysis Sessions', v_id::text,
    jsonb_build_object('appointment_id',p_appointment_id,'treatment_date',p_treatment_date,
      'session_status',p_session_status,'released',p_is_released,'attendance',p_attendance_flag));
  RETURN jsonb_build_object('success',true,'session_id',v_id,'is_released',COALESCE(p_is_released,false));
END $$;

CREATE OR REPLACE FUNCTION public.set_session_release(
  p_session_id uuid, p_release boolean, p_released_remarks text DEFAULT NULL,
  p_patient_visible_notes text DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_session public.dialysis_sessions%ROWTYPE; v_destination jsonb; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('release_records') THEN RAISE EXCEPTION 'Unauthorized: record-release permission required.'; END IF;
  SELECT * INTO v_session FROM public.dialysis_sessions WHERE session_id = p_session_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Session not found.'; END IF;
  UPDATE public.dialysis_sessions SET
    is_released_to_patient = COALESCE(p_release,false),
    released_at = CASE WHEN COALESCE(p_release,false) THEN now() ELSE NULL END,
    released_by = CASE WHEN COALESCE(p_release,false) THEN public.current_staff_id() ELSE NULL END,
    released_remarks = p_released_remarks,
    patient_visible_notes = COALESCE(p_patient_visible_notes, patient_visible_notes)
  WHERE session_id = p_session_id;
  IF COALESCE(p_release,false) THEN
    v_destination := jsonb_build_object('panel','patient','section','my-records','tab','history','session_id',p_session_id);
    PERFORM public.notify_patient(v_session.patient_id, 'New Medical Record',
      'An official dialysis session record has been released to your account.',
      'New Medical Record', v_session.appointment_id, NULL, p_session_id, v_destination, 'Open session details');
  END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Dialysis Session Release Changed', 'Dialysis Sessions', p_session_id::text,
    jsonb_build_object('released',p_release,'remarks',p_released_remarks));
  RETURN jsonb_build_object('success',true,'session_id',p_session_id,'is_released',COALESCE(p_release,false));
END $$;

CREATE OR REPLACE FUNCTION public.assert_record_access(p_patient_id uuid)
RETURNS void LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required.'; END IF;
  IF NOT public.is_active_staff() AND p_patient_id IS DISTINCT FROM public.current_patient_id() THEN
    RAISE EXCEPTION 'You are not authorized to view this patient record.';
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.get_appointment_detail(p_appointment_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb; v_patient_id uuid;
BEGIN
  SELECT patient_id INTO v_patient_id FROM public.appointments WHERE appointment_id = p_appointment_id;
  IF v_patient_id IS NULL THEN RAISE EXCEPTION 'Appointment not found.'; END IF;
  PERFORM public.assert_record_access(v_patient_id);

  SELECT jsonb_build_object(
    'appointment', to_jsonb(a),
    'patient', to_jsonb(p),
    'medical_profile', COALESCE((SELECT to_jsonb(m) FROM public.patient_medical_profiles m WHERE m.patient_id = p.patient_id), '{}'::jsonb),
    'documents', COALESCE((
      SELECT jsonb_agg(to_jsonb(d) || jsonb_build_object(
        'reviewer_name', COALESCE((SELECT full_name FROM public.staff s WHERE s.staff_id = d.reviewed_by), '—')
      ) ORDER BY d.document_type, d.uploaded_at DESC)
      FROM public.patient_documents d WHERE d.patient_id = p.patient_id AND d.is_current = true), '[]'::jsonb),
    'machine', COALESCE((
      SELECT jsonb_build_object('machine_slot_id',ms.machine_slot_id,'machine_id',m.machine_id,
        'machine_code',m.machine_code,'machine_name',m.machine_name,'slot_status',ms.slot_status,
        'schedule_date',ms.schedule_date,'start_time',ms.start_time,'end_time',ms.end_time)
      FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id = ms.machine_id
      WHERE ms.machine_slot_id = a.machine_slot_id), '{}'::jsonb),
    'processed_by_name', COALESCE((SELECT full_name FROM public.staff s WHERE s.staff_id = a.processed_by), '—'),
    'config', public.get_system_config()
  ) INTO v_result
  FROM public.appointments a JOIN public.patients p ON p.patient_id = a.patient_id
  WHERE a.appointment_id = p_appointment_id;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.get_patient_record(p_patient_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb;
BEGIN
  PERFORM public.assert_record_access(p_patient_id);
  SELECT jsonb_build_object(
    'patient', to_jsonb(p),
    'medical_profile', COALESCE((SELECT to_jsonb(m) FROM public.patient_medical_profiles m WHERE m.patient_id = p.patient_id), '{}'::jsonb),
    'documents', COALESCE((
      SELECT jsonb_agg(to_jsonb(d) || jsonb_build_object('reviewer_name',
        COALESCE((SELECT full_name FROM public.staff s WHERE s.staff_id = d.reviewed_by),'—'))
        ORDER BY d.uploaded_at DESC)
      FROM public.patient_documents d WHERE d.patient_id = p.patient_id), '[]'::jsonb),
    'appointments', COALESCE((
      SELECT jsonb_agg(to_jsonb(a) || jsonb_build_object('machine_code',
        COALESCE((SELECT m.machine_code FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id=ms.machine_id WHERE ms.machine_slot_id=a.machine_slot_id), a.machine_snapshot ->> 'machine_code','—'))
        ORDER BY a.created_at DESC)
      FROM public.appointments a WHERE a.patient_id = p.patient_id), '[]'::jsonb),
    'sessions', COALESCE((
      SELECT jsonb_agg(to_jsonb(s) || jsonb_build_object('machine_code',
        COALESCE((SELECT machine_code FROM public.dialysis_machines m WHERE m.machine_id=s.machine_id),'—'),
        'recorded_by_name', COALESCE((SELECT full_name FROM public.staff st WHERE st.staff_id=s.recorded_by),'—'))
        ORDER BY s.treatment_date DESC)
      FROM public.dialysis_sessions s WHERE s.patient_id = p.patient_id), '[]'::jsonb)
  ) INTO v_result FROM public.patients p WHERE p.patient_id = p_patient_id;
  IF v_result IS NULL THEN RAISE EXCEPTION 'Patient not found.'; END IF;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.upsert_machine(
  p_machine_id uuid DEFAULT NULL, p_machine_code text DEFAULT NULL, p_machine_name text DEFAULT NULL,
  p_machine_status text DEFAULT 'Available', p_description text DEFAULT NULL,
  p_maintenance_remarks text DEFAULT NULL, p_daily_capacity integer DEFAULT NULL,
  p_is_active boolean DEFAULT NULL
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_id uuid; v_capacity int; v_future int; v_active boolean; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.has_staff_permission('manage_machines') THEN RAISE EXCEPTION 'Unauthorized: machine-management permission required.'; END IF;
  IF NULLIF(trim(COALESCE(p_machine_code,'')),'') IS NULL OR NULLIF(trim(COALESCE(p_machine_name,'')),'') IS NULL THEN
    RAISE EXCEPTION 'Machine code and machine name are required.';
  END IF;
  IF p_machine_status NOT IN ('Available','Occupied','Maintenance','Offline','Unavailable') THEN
    RAISE EXCEPTION 'Invalid machine status.';
  END IF;
  v_capacity := COALESCE(p_daily_capacity, jsonb_array_length(public.get_system_config() -> 'time_slots'));
  IF v_capacity < 1 THEN RAISE EXCEPTION 'Daily capacity must be at least one.'; END IF;
  v_active := COALESCE(p_is_active, p_machine_status NOT IN ('Offline','Unavailable'));

  IF p_machine_id IS NULL THEN
    IF EXISTS (SELECT 1 FROM public.dialysis_machines WHERE lower(machine_code)=lower(trim(p_machine_code))) THEN
      RAISE EXCEPTION 'Machine code % is already registered.', p_machine_code;
    END IF;
    INSERT INTO public.dialysis_machines (
      machine_code,machine_name,machine_status,description,maintenance_remarks,daily_capacity,
      is_active,maintenance_started_at,created_by,updated_by
    ) VALUES (
      trim(p_machine_code),trim(p_machine_name),p_machine_status,p_description,p_maintenance_remarks,
      v_capacity,v_active,CASE WHEN p_machine_status IN ('Maintenance','Offline','Unavailable') THEN now() ELSE NULL END,
      auth.uid(),auth.uid()
    ) RETURNING machine_id INTO v_id;
  ELSE
    SELECT machine_id INTO v_id FROM public.dialysis_machines WHERE machine_id = p_machine_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Machine not found.'; END IF;
    IF EXISTS (SELECT 1 FROM public.dialysis_machines
      WHERE lower(machine_code)=lower(trim(p_machine_code)) AND machine_id <> v_id) THEN
      RAISE EXCEPTION 'Machine code % is already registered.', p_machine_code;
    END IF;
    IF p_machine_status IN ('Maintenance','Offline','Unavailable') THEN
      SELECT count(*)::int INTO v_future FROM public.machine_slots
      WHERE machine_id = v_id AND schedule_date >= public.app_today()
        AND slot_status IN ('Booked','Reserved');
      IF v_future > 0 THEN
        RAISE EXCEPTION 'This machine has % future reserved appointment(s). Reassign those appointments before marking it unavailable.', v_future;
      END IF;
    END IF;
    UPDATE public.dialysis_machines SET
      machine_code = trim(p_machine_code), machine_name = trim(p_machine_name),
      machine_status = p_machine_status, description = p_description,
      maintenance_remarks = p_maintenance_remarks, daily_capacity = v_capacity,
      is_active = v_active,
      maintenance_started_at = CASE WHEN p_machine_status IN ('Maintenance','Offline','Unavailable') THEN COALESCE(maintenance_started_at, now()) ELSE NULL END,
      updated_by = auth.uid()
    WHERE machine_id = v_id;

    IF p_machine_status IN ('Maintenance','Offline','Unavailable') THEN
      UPDATE public.machine_slots SET slot_status = 'Maintenance'
      WHERE machine_id = v_id AND schedule_date >= public.app_today() AND slot_status IN ('Available','Reserved');
    ELSE
      UPDATE public.machine_slots SET slot_status = 'Available'
      WHERE machine_id = v_id AND schedule_date >= public.app_today() AND slot_status = 'Maintenance';
    END IF;
  END IF;

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_machine_id IS NULL THEN 'Machine Registered' ELSE 'Machine Status / Information Updated' END,
    'Machine Management', v_id::text,
    jsonb_build_object('machine_code',p_machine_code,'machine_status',p_machine_status,
      'daily_capacity',v_capacity,'maintenance_remarks',p_maintenance_remarks,'is_active',v_active));
  RETURN jsonb_build_object('success',true,'machine_id',v_id,'machine_status',p_machine_status);
END $$;

DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'register_patient_document(text,text,text,bigint,text,uuid)',
    'verify_document(uuid,text,text)',
    'register_authorized_medical_file(uuid,text,text,bigint,text,boolean,text)',
    'set_document_release(uuid,boolean,text)',
    'record_dialysis_session(uuid,date,time without time zone,time without time zone,numeric,numeric,text,text,numeric,text,text,text,boolean,text,text)',
    'set_session_release(uuid,boolean,text,text)',
    'get_appointment_detail(uuid)',
    'get_patient_record(uuid)',
    'upsert_machine(uuid,text,text,text,text,text,integer,boolean)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
  FOREACH fn IN ARRAY ARRAY['assert_record_access(uuid)'] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon, authenticated', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO service_role', fn);
  END LOOP;
END $grants$;
