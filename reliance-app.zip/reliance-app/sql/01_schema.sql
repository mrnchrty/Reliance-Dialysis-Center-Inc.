-- Reliance Dialysis Center Inc. — initial schema (exactly ten custom application tables)
-- Run this file first in the Supabase SQL Editor on a new project.
-- auth.users is Supabase's built-in authentication table and is intentionally not counted here.
-- Circular foreign keys are added in 02_constraints.sql after all tables exist.

CREATE EXTENSION IF NOT EXISTS btree_gist;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.patients (
  patient_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text NOT NULL,
  date_of_birth date,
  sex text,
  sex_other text,
  civil_status text,
  address text,
  contact_number text,
  emergency_contact_name text,
  emergency_contact_number text,
  account_status text NOT NULL DEFAULT 'Active',
  profile_completed_at timestamptz,
  change_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  deactivated_at timestamptz,
  deactivated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.staff (
  staff_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  full_name text NOT NULL,
  position text NOT NULL DEFAULT 'Dialysis Nurse',
  role text NOT NULL DEFAULT 'staff',
  contact_number text,
  account_status text NOT NULL DEFAULT 'Active',
  permissions jsonb NOT NULL DEFAULT '{"verify_documents":true,"manage_appointments":true,"manage_machines":true,"record_sessions":true,"release_records":true}'::jsonb,
  last_login_at timestamptz,
  deactivated_at timestamptz,
  deactivated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.patient_medical_profiles (
  medical_profile_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL UNIQUE REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  height numeric,
  weight numeric,
  blood_type text,
  allergies text,
  allergy_other text,
  diagnosis text,
  existing_medical_conditions text,
  condition_other text,
  previous_surgeries text,
  surgery_other text,
  current_medications text,
  attending_nephrologist text,
  prescribed_dialysis_frequency text,
  frequency_other text,
  dialysis_start_date date,
  previous_dialysis_center text,
  recurring_days text[] NOT NULL DEFAULT '{}'::text[],
  preferred_time text,
  preferred_time_other text,
  correction_request_notes text,
  change_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  profile_updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  profile_completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.patient_documents (
  document_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  document_type text NOT NULL,
  file_path text NOT NULL,
  file_name text NOT NULL,
  file_size bigint,
  mime_type text,
  storage_bucket text NOT NULL DEFAULT 'patient-documents',
  uploaded_at timestamptz NOT NULL DEFAULT now(),
  uploaded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  verification_status text NOT NULL DEFAULT 'Pending',
  reviewed_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  remarks text,
  is_released_to_patient boolean NOT NULL DEFAULT true,
  is_current boolean NOT NULL DEFAULT true,
  version integer NOT NULL DEFAULT 1,
  replaces_document_id uuid REFERENCES public.patient_documents(document_id) ON DELETE SET NULL,
  correction_requested boolean NOT NULL DEFAULT false,
  correction_notes text,
  correction_requested_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  correction_requested_at timestamptz,
  is_outdated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.dialysis_machines (
  machine_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_code text NOT NULL UNIQUE,
  machine_name text NOT NULL,
  machine_status text NOT NULL DEFAULT 'Available',
  description text,
  maintenance_remarks text,
  schedule_config jsonb,
  daily_capacity integer NOT NULL DEFAULT 3,
  is_active boolean NOT NULL DEFAULT true,
  maintenance_started_at timestamptz,
  maintenance_ends_at timestamptz,
  last_service_date date,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.machine_slots (
  machine_slot_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_id uuid NOT NULL REFERENCES public.dialysis_machines(machine_id) ON DELETE CASCADE,
  schedule_date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  slot_status text NOT NULL DEFAULT 'Available',
  slot_key text NOT NULL DEFAULT 'Legacy',
  slot_label text,
  appointment_id uuid UNIQUE,
  capacity_source text NOT NULL DEFAULT 'Generated',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.appointments (
  appointment_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  machine_slot_id uuid UNIQUE,
  processed_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  requested_date date NOT NULL,
  requested_time text NOT NULL,
  requested_start_time time,
  requested_end_time time,
  confirmed_date date,
  confirmed_start_time time,
  confirmed_end_time time,
  appointment_status text NOT NULL DEFAULT 'Pending',
  staff_remarks text,
  recurrence_group_id uuid,
  is_recurring boolean NOT NULL DEFAULT false,
  is_cancelled boolean NOT NULL DEFAULT false,
  cancelled_at timestamptz,
  cancellation_reason text,
  cancelled_by_role text,
  reschedule_requested boolean NOT NULL DEFAULT false,
  reschedule_notes text,
  attendance_flag text NOT NULL DEFAULT 'Scheduled',
  attendance_recorded_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  attendance_recorded_at timestamptz,
  status_history jsonb NOT NULL DEFAULT '[]'::jsonb,
  request_type text NOT NULL DEFAULT 'New',
  original_details jsonb NOT NULL DEFAULT '{}'::jsonb,
  reschedule_request jsonb NOT NULL DEFAULT '{}'::jsonb,
  cancellation_request jsonb NOT NULL DEFAULT '{}'::jsonb,
  correction_request jsonb NOT NULL DEFAULT '{}'::jsonb,
  machine_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  submitted_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.dialysis_sessions (
  session_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid UNIQUE REFERENCES public.appointments(appointment_id) ON DELETE SET NULL,
  patient_id uuid NOT NULL REFERENCES public.patients(patient_id) ON DELETE CASCADE,
  machine_id uuid NOT NULL REFERENCES public.dialysis_machines(machine_id) ON DELETE RESTRICT,
  recorded_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  treatment_date date NOT NULL,
  actual_start_time time NOT NULL,
  actual_end_time time NOT NULL,
  pre_dialysis_weight numeric,
  post_dialysis_weight numeric,
  blood_pressure_pre text,
  blood_pressure_post text,
  ultrafiltration_volume numeric,
  session_status text NOT NULL DEFAULT 'Completed',
  is_released_to_patient boolean NOT NULL DEFAULT false,
  released_at timestamptz,
  released_by uuid REFERENCES public.staff(staff_id) ON DELETE SET NULL,
  released_remarks text,
  patient_visible_notes text,
  treatment_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.notifications (
  notification_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  notification_type text NOT NULL DEFAULT 'System',
  related_appointment_id uuid REFERENCES public.appointments(appointment_id) ON DELETE SET NULL,
  related_document_id uuid REFERENCES public.patient_documents(document_id) ON DELETE SET NULL,
  related_session_id uuid REFERENCES public.dialysis_sessions(session_id) ON DELETE SET NULL,
  related_patient_id uuid REFERENCES public.patients(patient_id) ON DELETE SET NULL,
  destination jsonb NOT NULL DEFAULT '{}'::jsonb,
  action_label text,
  is_read boolean NOT NULL DEFAULT false,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.audit_logs (
  audit_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_email text,
  actor_name text,
  actor_role text,
  activity text NOT NULL,
  affected_module text NOT NULL,
  affected_record_id text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  severity text NOT NULL DEFAULT 'Info',
  created_at timestamptz NOT NULL DEFAULT now()
);
