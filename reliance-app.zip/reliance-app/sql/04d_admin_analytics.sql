-- Reliance Dialysis Center Inc. — protected account operations and operational analytics from actual records

CREATE OR REPLACE FUNCTION public.admin_set_account_status(
  p_target_user_id uuid, p_status text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'auth'
AS $$
DECLARE v_email text; v_actor jsonb := public.current_actor(); v_role text;
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  IF p_status NOT IN ('Active','Inactive') THEN RAISE EXCEPTION 'Status must be Active or Inactive.'; END IF;
  IF p_target_user_id = auth.uid() AND p_status = 'Inactive' THEN
    RAISE EXCEPTION 'You cannot deactivate your own active Super Administrator account.';
  END IF;
  SELECT email INTO v_email FROM auth.users WHERE id = p_target_user_id;
  IF v_email IS NULL THEN RAISE EXCEPTION 'User account not found.'; END IF;

  UPDATE public.patients SET
    account_status = p_status,
    deactivated_at = CASE WHEN p_status = 'Inactive' THEN now() ELSE NULL END,
    deactivated_by = CASE WHEN p_status = 'Inactive' THEN auth.uid() ELSE NULL END
  WHERE user_id = p_target_user_id;
  UPDATE public.staff SET
    account_status = p_status,
    deactivated_at = CASE WHEN p_status = 'Inactive' THEN now() ELSE NULL END,
    deactivated_by = CASE WHEN p_status = 'Inactive' THEN auth.uid() ELSE NULL END
  WHERE user_id = p_target_user_id;

  UPDATE auth.users SET
    banned_until = CASE WHEN p_status = 'Inactive' THEN now() + interval '100 years' ELSE NULL END,
    updated_at = now()
  WHERE id = p_target_user_id;

  SELECT role INTO v_role FROM public.staff WHERE user_id = p_target_user_id;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details, severity)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    CASE WHEN p_status='Active' THEN 'Account Activated' ELSE 'Account Deactivated' END,
    'User Management', p_target_user_id::text,
    jsonb_build_object('email',v_email,'status',p_status,'target_role',COALESCE(v_role,'patient')), 'Warning');
  RETURN jsonb_build_object('success',true,'user_id',p_target_user_id,'status',p_status);
END $$;

CREATE OR REPLACE FUNCTION public.admin_assign_user_role(
  p_target_user_id uuid, p_new_role text, p_position text DEFAULT 'Dialysis Nurse'
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'auth'
AS $$
DECLARE v_email text; v_name text; v_contact text; v_actor jsonb := public.current_actor();
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  IF p_target_user_id = auth.uid() AND p_new_role <> 'super_admin' THEN
    RAISE EXCEPTION 'You cannot demote your own active Super Administrator account.';
  END IF;
  IF p_new_role NOT IN ('patient','staff','super_admin') THEN RAISE EXCEPTION 'Invalid authorized role.'; END IF;
  SELECT email, COALESCE(raw_user_meta_data ->> 'full_name', split_part(email,'@',1)) INTO v_email, v_name
  FROM auth.users WHERE id = p_target_user_id;
  IF v_email IS NULL THEN RAISE EXCEPTION 'User account not found.'; END IF;

  IF p_new_role IN ('staff','super_admin') THEN
    SELECT COALESCE(full_name,v_name), contact_number INTO v_name, v_contact
    FROM public.patients WHERE user_id = p_target_user_id;
    INSERT INTO public.staff (user_id,email,full_name,position,role,contact_number,account_status)
    VALUES (p_target_user_id,v_email,COALESCE(v_name,'Staff Member'),p_position,p_new_role,v_contact,'Active')
    ON CONFLICT (user_id) DO UPDATE SET
      role = EXCLUDED.role, position = EXCLUDED.position, account_status = 'Active',
      email = EXCLUDED.email, full_name = EXCLUDED.full_name;
    UPDATE public.patients SET account_status = 'Inactive' WHERE user_id = p_target_user_id;
  ELSE
    UPDATE public.staff SET account_status = 'Inactive' WHERE user_id = p_target_user_id;
    INSERT INTO public.patients (user_id,email,full_name,account_status)
    VALUES (p_target_user_id,v_email,v_name,'Active')
    ON CONFLICT (user_id) DO UPDATE SET account_status = 'Active', email = EXCLUDED.email;
  END IF;

  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details, severity)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    'Updated User Authorized Role', 'User Management', p_target_user_id::text,
    jsonb_build_object('email',v_email,'new_role',p_new_role,'position',p_position), 'Warning');
  RETURN jsonb_build_object('success',true,'role',p_new_role);
END $$;

CREATE OR REPLACE FUNCTION public.get_staff_dashboard_stats()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_today date := public.app_today(); v_result jsonb;
BEGIN
  IF NOT public.is_active_staff() THEN RAISE EXCEPTION 'Unauthorized: active staff access required.'; END IF;
  SELECT jsonb_build_object(
    'today', v_today,
    'todays_appointments', (SELECT count(*)::int FROM public.appointments WHERE COALESCE(confirmed_date,requested_date)=v_today AND is_cancelled=false),
    'new_requests', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Pending' AND is_cancelled=false),
    'under_review', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Under Review' AND is_cancelled=false),
    'confirmed', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Confirmed' AND is_cancelled=false),
    'available_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE is_active=true AND machine_status IN ('Available','Occupied')),
    'occupied_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE machine_status='Occupied'),
    'documents_awaiting_verification', (SELECT count(*)::int FROM public.patient_documents WHERE is_current=true AND verification_status IN ('Pending','Needs Correction')),
    'completed_sessions_today', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date=v_today AND session_status='Completed'),
    'recent_activities', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('audit_id',audit_id,'activity',activity,'module',affected_module,
        'record_id',affected_record_id,'actor',COALESCE(actor_name,actor_email,'System'),'created_at',created_at)
        ORDER BY created_at DESC)
      FROM (SELECT * FROM public.audit_logs ORDER BY created_at DESC LIMIT 8) q), '[]'::jsonb)
  ) INTO v_result;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.get_analytics_bundle(
  p_start_date date, p_end_date date, p_granularity text DEFAULT 'daily'
) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  v_gran text; v_result jsonb; v_total_slots int; v_occupied_slots int;
  v_attended int; v_no_show int;
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  IF p_start_date IS NULL OR p_end_date IS NULL OR p_end_date < p_start_date OR p_end_date - p_start_date > 366 THEN
    RAISE EXCEPTION 'Select a valid date range of up to 366 days.';
  END IF;
  v_gran := CASE WHEN lower(p_granularity) IN ('weekly','monthly') THEN lower(p_granularity) ELSE 'daily' END;

  SELECT count(*)::int INTO v_total_slots
  FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id=ms.machine_id
  WHERE ms.schedule_date BETWEEN p_start_date AND p_end_date
    AND m.is_active=true AND m.machine_status IN ('Available','Occupied')
    AND ms.slot_status NOT IN ('Cancelled','Maintenance');
  SELECT count(*)::int INTO v_occupied_slots
  FROM public.machine_slots ms JOIN public.dialysis_machines m ON m.machine_id=ms.machine_id
  WHERE ms.schedule_date BETWEEN p_start_date AND p_end_date
    AND m.is_active=true AND m.machine_status IN ('Available','Occupied')
    AND ms.slot_status IN ('Reserved','Booked','Completed');
  SELECT count(*) FILTER (WHERE attendance_flag='Attended')::int,
         count(*) FILTER (WHERE attendance_flag='No-Show')::int
  INTO v_attended, v_no_show
  FROM public.appointments
  WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date;

  WITH appointment_trend AS (
    SELECT to_char(date_trunc(v_gran, COALESCE(confirmed_date,requested_date)::timestamp),'YYYY-MM-DD') AS period,
      count(*)::int AS total,
      count(*) FILTER (WHERE appointment_status='Pending')::int AS pending,
      count(*) FILTER (WHERE appointment_status='Under Review')::int AS under_review,
      count(*) FILTER (WHERE appointment_status='Confirmed')::int AS confirmed,
      count(*) FILTER (WHERE appointment_status='Rejected')::int AS rejected
    FROM public.appointments
    WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date
    GROUP BY 1 ORDER BY 1
  ), patient_trend AS (
    SELECT to_char(date_trunc(v_gran, created_at::timestamp),'YYYY-MM-DD') AS period, count(*)::int AS registrations
    FROM public.patients WHERE created_at::date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 1
  ), session_trend AS (
    SELECT to_char(date_trunc(v_gran, treatment_date::timestamp),'YYYY-MM-DD') AS period,
      count(*)::int AS total, count(*) FILTER (WHERE session_status='Completed')::int AS completed
    FROM public.dialysis_sessions WHERE treatment_date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 1
  ), demand_days AS (
    SELECT trim(to_char(requested_date,'Day')) AS label, count(*)::int AS requests
    FROM public.appointments WHERE requested_date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 2 DESC,1
  ), demand_slots AS (
    SELECT requested_time AS label, count(*)::int AS requests
    FROM public.appointments WHERE requested_date BETWEEN p_start_date AND p_end_date GROUP BY 1 ORDER BY 2 DESC,1
  ), machine_util AS (
    SELECT m.machine_code, m.machine_name,
      count(ms.machine_slot_id) FILTER (WHERE ms.slot_status NOT IN ('Cancelled','Maintenance'))::int AS available_slots,
      count(ms.machine_slot_id) FILTER (WHERE ms.slot_status IN ('Reserved','Booked','Completed'))::int AS occupied_slots
    FROM public.dialysis_machines m LEFT JOIN public.machine_slots ms
      ON ms.machine_id=m.machine_id AND ms.schedule_date BETWEEN p_start_date AND p_end_date
    WHERE m.is_active=true AND m.machine_status IN ('Available','Occupied')
    GROUP BY m.machine_id,m.machine_code,m.machine_name ORDER BY m.machine_code
  )
  SELECT jsonb_build_object(
    'period', jsonb_build_object('start',p_start_date,'end',p_end_date,'granularity',v_gran,'timezone','Asia/Manila'),
    'definition', jsonb_build_object(
      'available_slot','One generated MACHINE_SLOTS row for an active machine not marked Maintenance/Offline/Unavailable during the selected range.',
      'occupied_slot','A reserved, booked, or completed machine slot in the same range.',
      'utilization_formula','(occupied machine slots / total available machine slots) × 100',
      'no_show_formula','(explicit No-Show appointments / (explicit Attended + explicit No-Show appointments)) × 100. Scheduled records are excluded; no assumption is made from missing status.'
    ),
    'patients', jsonb_build_object(
      'total_registered', (SELECT count(*)::int FROM public.patients),
      'new_in_range', (SELECT count(*)::int FROM public.patients WHERE created_at::date BETWEEN p_start_date AND p_end_date),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(patient_trend)) FROM patient_trend),'[]'::jsonb)
    ),
    'appointments', jsonb_build_object(
      'total_in_range', (SELECT count(*)::int FROM public.appointments WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'pending', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Pending' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'under_review', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Under Review' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'confirmed', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Confirmed' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'rejected', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Rejected' AND COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date),
      'rescheduling_requests', (SELECT count(*)::int FROM public.appointments WHERE created_at::date BETWEEN p_start_date AND p_end_date AND (status_history::text ILIKE '%Reschedule Requested%' OR reschedule_request <> '{}'::jsonb)),
      'cancellation_requests', (SELECT count(*)::int FROM public.appointments WHERE created_at::date BETWEEN p_start_date AND p_end_date AND (status_history::text ILIKE '%Cancellation%' OR cancellation_request <> '{}'::jsonb OR is_cancelled=true)),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(appointment_trend)) FROM appointment_trend),'[]'::jsonb)
    ),
    'sessions', jsonb_build_object(
      'completed_in_range', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date BETWEEN p_start_date AND p_end_date AND session_status='Completed'),
      'daily', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date = public.app_today()),
      'weekly', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date >= date_trunc('week', public.app_today()::timestamp)::date),
      'monthly', (SELECT count(*)::int FROM public.dialysis_sessions WHERE treatment_date >= date_trunc('month', public.app_today()::timestamp)::date),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(session_trend)) FROM session_trend),'[]'::jsonb)
    ),
    'machine_utilization', jsonb_build_object(
      'total_available_slots', v_total_slots, 'occupied_slots', v_occupied_slots,
      'rate', CASE WHEN v_total_slots > 0 THEN round((v_occupied_slots::numeric / v_total_slots::numeric) * 100, 2) ELSE 0 END,
      'by_machine', COALESCE((SELECT jsonb_agg(row_to_json(machine_util)) FROM machine_util),'[]'::jsonb)
    ),
    'demand', jsonb_build_object(
      'by_day', COALESCE((SELECT jsonb_agg(row_to_json(demand_days)) FROM demand_days),'[]'::jsonb),
      'by_slot', COALESCE((SELECT jsonb_agg(row_to_json(demand_slots)) FROM demand_slots),'[]'::jsonb),
      'trend', COALESCE((SELECT jsonb_agg(row_to_json(appointment_trend)) FROM appointment_trend),'[]'::jsonb),
      'high_demand_periods', COALESCE((SELECT jsonb_agg(row_to_json(q)) FROM (SELECT * FROM appointment_trend ORDER BY total DESC LIMIT 5) q),'[]'::jsonb)
    ),
    'no_show', jsonb_build_object(
      'attended_recorded', v_attended, 'no_show_recorded', v_no_show,
      'expected_recorded', v_attended + v_no_show,
      'rate', CASE WHEN (v_attended+v_no_show) > 0 THEN round((v_no_show::numeric / (v_attended+v_no_show)::numeric) * 100, 2) ELSE 0 END,
      'note', 'Only explicit staff-recorded Attended and No-Show outcomes are included. Scheduled records are excluded.'
    ),
    'appointment_status_counts', COALESCE((
      SELECT jsonb_object_agg(appointment_status, n) FROM (
        SELECT appointment_status, count(*)::int AS n FROM public.appointments
        WHERE COALESCE(confirmed_date,requested_date) BETWEEN p_start_date AND p_end_date GROUP BY appointment_status
      ) q), '{}'::jsonb)
  ) INTO v_result;
  RETURN v_result;
END $$;

CREATE OR REPLACE FUNCTION public.get_admin_dashboard_stats()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_result jsonb;
BEGIN
  IF NOT public.is_super_admin() THEN RAISE EXCEPTION 'Unauthorized: active Super Administrator required.'; END IF;
  SELECT jsonb_build_object(
    'total_patients', (SELECT count(*)::int FROM public.patients),
    'active_staff', (SELECT count(*)::int FROM public.staff WHERE account_status='Active'),
    'total_appointments', (SELECT count(*)::int FROM public.appointments),
    'pending', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Pending'),
    'under_review', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Under Review'),
    'confirmed', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Confirmed'),
    'rejected', (SELECT count(*)::int FROM public.appointments WHERE appointment_status='Rejected'),
    'completed_sessions', (SELECT count(*)::int FROM public.dialysis_sessions WHERE session_status='Completed'),
    'available_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE is_active=true AND machine_status IN ('Available','Occupied')),
    'total_machines', (SELECT count(*)::int FROM public.dialysis_machines WHERE is_active=true),
    'analytics', public.get_analytics_bundle((public.app_today() - interval '29 days')::date, public.app_today(), 'daily'),
    'recent_activities', COALESCE((
      SELECT jsonb_agg(jsonb_build_object('audit_id',audit_id,'activity',activity,'module',affected_module,
        'record_id',affected_record_id,'actor',COALESCE(actor_name,actor_email,'System'),'created_at',created_at,'severity',severity)
        ORDER BY created_at DESC)
      FROM (SELECT * FROM public.audit_logs ORDER BY created_at DESC LIMIT 10) q), '[]'::jsonb)
  ) INTO v_result;
  RETURN v_result;
END $$;

-- Legacy staff-creation SQL RPC uses direct auth.users inserts; the frontend uses the secure Edge Function instead.
DO $revoke$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
             WHERE n.nspname='public' AND p.proname='admin_create_staff_account') THEN
    EXECUTE 'REVOKE EXECUTE ON FUNCTION public.admin_create_staff_account(text,text,text,text,text,text,jsonb) FROM PUBLIC, anon, authenticated';
    EXECUTE 'GRANT EXECUTE ON FUNCTION public.admin_create_staff_account(text,text,text,text,text,text,jsonb) TO service_role';
  END IF;
END $revoke$;

DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'admin_set_account_status(uuid,text)',
    'admin_assign_user_role(uuid,text,text)',
    'get_staff_dashboard_stats()',
    'get_analytics_bundle(date,date,text)',
    'get_admin_dashboard_stats()'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
END $grants$;
