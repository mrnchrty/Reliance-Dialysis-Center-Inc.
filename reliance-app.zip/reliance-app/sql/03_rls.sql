-- Reliance Dialysis Center Inc. — protected role helpers, audit triggers, RLS policies and table privileges
-- Run after 02_constraints.sql.

CREATE OR REPLACE FUNCTION public.app_today()
RETURNS date LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT (now() AT TIME ZONE 'Asia/Manila')::date; $$;

CREATE OR REPLACE FUNCTION public.current_patient_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT patient_id FROM public.patients WHERE user_id = auth.uid() AND account_status = 'Active' LIMIT 1; $$;

CREATE OR REPLACE FUNCTION public.current_staff_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT staff_id FROM public.staff WHERE user_id = auth.uid() AND account_status = 'Active' LIMIT 1; $$;

CREATE OR REPLACE FUNCTION public.is_active_staff()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT EXISTS (SELECT 1 FROM public.staff WHERE user_id = auth.uid() AND account_status = 'Active' AND role IN ('staff','super_admin')); $$;

CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT EXISTS (SELECT 1 FROM public.staff WHERE user_id = auth.uid() AND account_status = 'Active' AND role = 'super_admin'); $$;

CREATE OR REPLACE FUNCTION public.has_staff_permission(p_permission text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$ SELECT COALESCE((SELECT (permissions ->> p_permission)::boolean FROM public.staff WHERE user_id = auth.uid() AND account_status = 'Active' AND role IN ('staff','super_admin')), false) OR public.is_super_admin(); $$;

CREATE OR REPLACE FUNCTION public.current_actor()
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public', 'auth'
AS $$
  SELECT COALESCE((
    SELECT jsonb_build_object(
      'user_id', u.id, 'email', u.email,
      'name', COALESCE(NULLIF(u.raw_user_meta_data ->> 'full_name', ''), split_part(u.email, '@', 1)),
      'role', COALESCE((SELECT role FROM public.staff s WHERE s.user_id = u.id), 'patient')
    ) FROM auth.users u WHERE u.id = auth.uid()
  ), jsonb_build_object('user_id', auth.uid(), 'email', null, 'name', 'System', 'role', 'service'));
$$;

CREATE OR REPLACE FUNCTION public.log_audit_event(
  p_activity text, p_module text, p_record_id text DEFAULT NULL, p_details jsonb DEFAULT '{}'::jsonb
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_id uuid; v_actor jsonb := public.current_actor();
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role', p_activity, p_module, p_record_id, COALESCE(p_details, '{}'::jsonb))
  RETURNING audit_id INTO v_id;
  RETURN v_id;
END $$;

DROP FUNCTION IF EXISTS public.notify_all_staff(text, text, text, uuid);
CREATE OR REPLACE FUNCTION public.notify_all_staff(
  p_title text, p_message text, p_type text DEFAULT 'Appointment',
  p_appointment_id uuid DEFAULT NULL, p_destination jsonb DEFAULT '{}'::jsonb
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.notifications (recipient_user_id, title, message, notification_type, related_appointment_id, destination, action_label)
  SELECT s.user_id, p_title, p_message, p_type, p_appointment_id,
         CASE WHEN p_destination = '{}'::jsonb AND p_appointment_id IS NOT NULL
              THEN jsonb_build_object('panel','staff','section','appointment-management','appointment_id',p_appointment_id)
              ELSE COALESCE(p_destination,'{}'::jsonb) END,
         'Open appointment'
  FROM public.staff s WHERE s.account_status = 'Active';
END $$;

CREATE OR REPLACE FUNCTION public.write_notification(
  p_recipient uuid, p_title text, p_message text, p_type text DEFAULT 'System',
  p_appointment_id uuid DEFAULT NULL, p_document_id uuid DEFAULT NULL,
  p_session_id uuid DEFAULT NULL, p_patient_id uuid DEFAULT NULL,
  p_destination jsonb DEFAULT '{}'::jsonb, p_action_label text DEFAULT 'Open record'
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_id uuid;
BEGIN
  INSERT INTO public.notifications (
    recipient_user_id, title, message, notification_type, related_appointment_id,
    related_document_id, related_session_id, related_patient_id, destination, action_label
  ) VALUES (
    p_recipient, p_title, p_message, p_type, p_appointment_id,
    p_document_id, p_session_id, p_patient_id, COALESCE(p_destination,'{}'::jsonb), p_action_label
  ) RETURNING notification_id INTO v_id;
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public', 'auth'
AS $$
DECLARE v_role text; v_name text; v_staff_id uuid;
BEGIN
  v_role := COALESCE(NEW.raw_user_meta_data ->> 'intended_role', 'patient');
  v_name := COALESCE(NULLIF(TRIM(NEW.raw_user_meta_data ->> 'full_name'), ''), split_part(NEW.email, '@', 1));

  IF v_role = 'patient' THEN
    INSERT INTO public.patients (user_id, email, full_name)
    VALUES (NEW.id, NEW.email, v_name) ON CONFLICT (user_id) DO NOTHING;

    PERFORM public.write_notification(
      NEW.id, 'Welcome to Reliance Dialysis Center Inc.',
      'Your patient account has been created. Complete your Personal and Medical Profile before booking.',
      'Welcome', NULL, NULL, NULL, NULL,
      jsonb_build_object('panel','patient','section','dashboard'), 'Open dashboard'
    );

    INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
    VALUES (NEW.id, NEW.email, v_name, 'patient', 'Patient Account Registered', 'Authentication', NEW.id::text,
            jsonb_build_object('email', NEW.email, 'full_name', v_name));
  ELSIF v_role IN ('staff','super_admin') THEN
    INSERT INTO public.staff (
      user_id, email, full_name, position, role, contact_number, account_status, permissions, created_by
    ) VALUES (
      NEW.id, NEW.email, v_name,
      COALESCE(NEW.raw_user_meta_data ->> 'position', 'Dialysis Nurse'), v_role,
      NEW.raw_user_meta_data ->> 'contact_number', 'Active',
      COALESCE((NEW.raw_user_meta_data -> 'permissions')::jsonb,
               '{"verify_documents":true,"manage_appointments":true,"manage_machines":true,"record_sessions":true,"release_records":true}'::jsonb),
      NEW.id
    ) ON CONFLICT (user_id) DO UPDATE SET
      email = EXCLUDED.email, full_name = EXCLUDED.full_name,
      position = EXCLUDED.position, role = EXCLUDED.role,
      contact_number = EXCLUDED.contact_number, account_status = 'Active'
    RETURNING staff_id INTO v_staff_id;

    INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
    VALUES (NEW.id, NEW.email, v_name, v_role, 'Account Created', 'Authentication', NEW.id::text,
            jsonb_build_object('email', NEW.email, 'full_name', v_name, 'role', v_role));
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public'
AS $$ BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION public.record_profile_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_before jsonb; v_after jsonb; v_entry jsonb;
BEGIN
  v_before := to_jsonb(OLD) - 'updated_at' - 'change_history';
  v_after := to_jsonb(NEW) - 'updated_at' - 'change_history';
  v_entry := jsonb_build_object('timestamp', now(), 'actor_user_id', auth.uid(), 'before', v_before, 'after', v_after);
  NEW.change_history := COALESCE(OLD.change_history, '[]'::jsonb) || jsonb_build_array(v_entry);
  NEW.updated_at := now();
  IF TG_TABLE_NAME = 'patient_medical_profiles' THEN NEW.profile_updated_by := auth.uid(); END IF;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.audit_row_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE v_actor jsonb := public.current_actor(); v_module text; v_record text; v_before jsonb;
BEGIN
  v_module := CASE TG_TABLE_NAME WHEN 'patients' THEN 'Patient Information' WHEN 'patient_medical_profiles' THEN 'Medical Profile' ELSE 'Records' END;
  v_before := CASE WHEN TG_OP = 'INSERT' THEN NULL::jsonb ELSE to_jsonb(OLD) - 'change_history' END;
  v_record := COALESCE((to_jsonb(NEW) ->> 'patient_id'), (to_jsonb(NEW) ->> 'medical_profile_id'));
  INSERT INTO public.audit_logs (user_id, actor_email, actor_name, actor_role, activity, affected_module, affected_record_id, details)
  VALUES (
    auth.uid(), v_actor ->> 'email', v_actor ->> 'name', v_actor ->> 'role',
    TG_OP || ' ' || v_module, v_module, v_record,
    jsonb_build_object('before', v_before, 'after', to_jsonb(NEW) - 'change_history', 'table', TG_TABLE_NAME)
  );
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.protect_patient_sensitive_fields()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.is_active_staff() THEN
    NEW.patient_id := OLD.patient_id; NEW.user_id := OLD.user_id; NEW.email := OLD.email;
    NEW.account_status := OLD.account_status; NEW.created_at := OLD.created_at;
    NEW.deactivated_at := OLD.deactivated_at; NEW.deactivated_by := OLD.deactivated_by;
    NEW.last_login_at := OLD.last_login_at; NEW.change_history := OLD.change_history;
  END IF;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.protect_staff_role_changes()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN NEW; END IF;
  IF NEW.staff_id IS DISTINCT FROM OLD.staff_id OR NEW.user_id IS DISTINCT FROM OLD.user_id OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'Protected staff identity fields cannot be changed.';
  END IF;
  IF NEW.user_id = auth.uid() AND (
    NEW.role IS DISTINCT FROM OLD.role OR NEW.account_status IS DISTINCT FROM OLD.account_status OR NEW.permissions IS DISTINCT FROM OLD.permissions
  ) THEN
    RAISE EXCEPTION 'You cannot change your own role, account status, or permissions.';
  END IF;
  IF NOT public.is_super_admin() AND (
    NEW.role IS DISTINCT FROM OLD.role OR NEW.account_status IS DISTINCT FROM OLD.account_status OR NEW.permissions IS DISTINCT FROM OLD.permissions
  ) THEN
    RAISE EXCEPTION 'Only a Super Administrator can modify staff roles, status, or permissions.';
  END IF;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.protect_notification_update()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NEW.recipient_user_id = auth.uid() THEN
    NEW.recipient_user_id := OLD.recipient_user_id; NEW.title := OLD.title; NEW.message := OLD.message;
    NEW.notification_type := OLD.notification_type; NEW.related_appointment_id := OLD.related_appointment_id;
    NEW.related_document_id := OLD.related_document_id; NEW.related_session_id := OLD.related_session_id;
    NEW.related_patient_id := OLD.related_patient_id; NEW.destination := OLD.destination;
    NEW.action_label := OLD.action_label; NEW.created_at := OLD.created_at;
    IF NEW.is_read AND NOT OLD.is_read THEN NEW.read_at := now(); END IF;
    IF NOT NEW.is_read THEN NEW.read_at := NULL; END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION public.protect_audit_logs()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
BEGIN
  IF COALESCE(current_setting('request.jwt.claim.role', true), '') <> 'service_role' THEN
    RAISE EXCEPTION 'Audit logs are append-only and cannot be modified.';
  END IF;
  RETURN NULL;
END $$;

DO $triggers$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['patients','staff','patient_medical_profiles','patient_documents','appointments','dialysis_machines','machine_slots','dialysis_sessions'] LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_%s_updated_at ON public.%I', t, t);
    EXECUTE format('CREATE TRIGGER trg_%s_updated_at BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.set_updated_at()', t, t);
  END LOOP;
  DROP TRIGGER IF EXISTS trg_patients_record_change ON public.patients;
  CREATE TRIGGER trg_patients_record_change BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.record_profile_change();
  DROP TRIGGER IF EXISTS trg_medical_profiles_record_change ON public.patient_medical_profiles;
  CREATE TRIGGER trg_medical_profiles_record_change BEFORE UPDATE ON public.patient_medical_profiles FOR EACH ROW EXECUTE FUNCTION public.record_profile_change();
  DROP TRIGGER IF EXISTS trg_patients_audit ON public.patients;
  CREATE TRIGGER trg_patients_audit AFTER UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
  DROP TRIGGER IF EXISTS trg_medical_profiles_audit ON public.patient_medical_profiles;
  CREATE TRIGGER trg_medical_profiles_audit AFTER INSERT OR UPDATE ON public.patient_medical_profiles FOR EACH ROW EXECUTE FUNCTION public.audit_row_change();
  DROP TRIGGER IF EXISTS trg_protect_patient ON public.patients;
  CREATE TRIGGER trg_protect_patient BEFORE UPDATE ON public.patients FOR EACH ROW EXECUTE FUNCTION public.protect_patient_sensitive_fields();
  DROP TRIGGER IF EXISTS trg_protect_staff_role ON public.staff;
  CREATE TRIGGER trg_protect_staff_role BEFORE UPDATE ON public.staff FOR EACH ROW EXECUTE FUNCTION public.protect_staff_role_changes();
  DROP TRIGGER IF EXISTS trg_protect_notification ON public.notifications;
  CREATE TRIGGER trg_protect_notification BEFORE UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.protect_notification_update();
  DROP TRIGGER IF EXISTS trg_audit_logs_immutable ON public.audit_logs;
  CREATE TRIGGER trg_audit_logs_immutable BEFORE UPDATE OR DELETE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.protect_audit_logs();
END $triggers$;

-- Replace all public-table policies with the final least-privilege policy set.
DO $policies$
DECLARE r record;
BEGIN
  FOR r IN SELECT tablename, policyname FROM pg_policies WHERE schemaname = 'public' LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', r.policyname, r.tablename);
  END LOOP;
END $policies$;

ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_medical_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.patient_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dialysis_machines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.machine_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dialysis_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY patients_select ON public.patients FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_active_staff());
CREATE POLICY patients_update ON public.patients FOR UPDATE TO authenticated
  USING ((user_id = auth.uid() AND account_status = 'Active') OR public.is_active_staff())
  WITH CHECK ((user_id = auth.uid() AND account_status = 'Active') OR public.is_active_staff());

CREATE POLICY staff_select ON public.staff FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_active_staff());
CREATE POLICY staff_update ON public.staff FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.is_super_admin())
  WITH CHECK (user_id = auth.uid() OR public.is_super_admin());

CREATE POLICY medical_profiles_select ON public.patient_medical_profiles FOR SELECT TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff());
CREATE POLICY medical_profiles_insert ON public.patient_medical_profiles FOR INSERT TO authenticated
  WITH CHECK (patient_id = public.current_patient_id() OR public.is_active_staff());
CREATE POLICY medical_profiles_update ON public.patient_medical_profiles FOR UPDATE TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff())
  WITH CHECK (patient_id = public.current_patient_id() OR public.is_active_staff());

CREATE POLICY documents_select ON public.patient_documents FOR SELECT TO authenticated
  USING ((patient_id = public.current_patient_id() AND is_released_to_patient = true) OR public.is_active_staff());

CREATE POLICY appointments_select ON public.appointments FOR SELECT TO authenticated
  USING (patient_id = public.current_patient_id() OR public.is_active_staff());

CREATE POLICY machines_select ON public.dialysis_machines FOR SELECT TO authenticated
  USING (auth.uid() IS NOT NULL);

CREATE POLICY machine_slots_select ON public.machine_slots FOR SELECT TO authenticated
  USING (public.is_active_staff());

CREATE POLICY sessions_select ON public.dialysis_sessions FOR SELECT TO authenticated
  USING ((patient_id = public.current_patient_id() AND is_released_to_patient = true) OR public.is_active_staff());

CREATE POLICY notifications_select ON public.notifications FOR SELECT TO authenticated
  USING (recipient_user_id = auth.uid() OR public.is_super_admin());
CREATE POLICY notifications_update_own ON public.notifications FOR UPDATE TO authenticated
  USING (recipient_user_id = auth.uid()) WITH CHECK (recipient_user_id = auth.uid());

CREATE POLICY audit_logs_select ON public.audit_logs FOR SELECT TO authenticated
  USING (public.is_super_admin() OR user_id = auth.uid());

-- Table privileges: all writes that require business rules go through SECURITY DEFINER RPCs.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM authenticated;
GRANT SELECT ON public.patients, public.staff, public.patient_medical_profiles, public.patient_documents,
  public.appointments, public.dialysis_machines, public.machine_slots, public.dialysis_sessions,
  public.notifications, public.audit_logs TO authenticated;
GRANT UPDATE ON public.patients TO authenticated;
GRANT INSERT, UPDATE ON public.patient_medical_profiles TO authenticated;
GRANT UPDATE ON public.notifications TO authenticated;

-- Internal helpers are not directly callable by ordinary users.
REVOKE EXECUTE ON FUNCTION public.notify_all_staff(text,text,text,uuid,jsonb) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.write_notification(uuid,text,text,text,uuid,uuid,uuid,uuid,jsonb,text) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.current_actor() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.audit_row_change() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.record_profile_change() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.protect_patient_sensitive_fields() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.protect_staff_role_changes() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.protect_notification_update() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.protect_audit_logs() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.notify_all_staff(text,text,text,uuid,jsonb) TO service_role;
GRANT EXECUTE ON FUNCTION public.write_notification(uuid,text,text,text,uuid,uuid,uuid,uuid,jsonb,text) TO service_role;

DO $grants$
DECLARE fn text;
BEGIN
  FOREACH fn IN ARRAY ARRAY[
    'app_today()','current_patient_id()','current_staff_id()','is_active_staff()','is_super_admin()',
    'has_staff_permission(text)','log_audit_event(text,text,text,jsonb)'
  ] LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION public.%s FROM PUBLIC, anon', fn);
    EXECUTE format('GRANT EXECUTE ON FUNCTION public.%s TO authenticated, service_role', fn);
  END LOOP;
END $grants$;
