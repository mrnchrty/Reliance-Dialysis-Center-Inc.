// Vercel serverless endpoint: exposes only the publishable Supabase config to the browser.
// The service-role key must never be returned here or used by frontend code.
export default function handler(request, response) {
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('X-Content-Type-Options', 'nosniff');

  if (request.method !== 'GET') {
    response.statusCode = 405;
    return response.json({ error: 'Method not allowed' });
  }

  const supabaseUrl = process.env.SUPABASE_URL || '';
  const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '';

  if (!supabaseUrl || !publishableKey) {
    response.statusCode = 500;
    return response.json({ error: 'Supabase URL and publishable key must be set in Vercel environment variables.' });
  }

  return response.json({ supabaseUrl, publishableKey });
}
