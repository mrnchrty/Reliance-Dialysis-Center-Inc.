// Lightweight smoke checks: required files, no frontend secrets, SQL table count, JS syntax.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const failures = [];

function assert(condition, message) {
  if (!condition) failures.push(message);
}

function read(rel) {
  return readFileSync(path.join(root, rel), 'utf8');
}

function walk(dir, out = []) {
  const full = path.join(root, dir);
  if (!existsSync(full)) return out;
  for (const entry of readdirSync(full)) {
    const rel = path.join(dir, entry);
    const abs = path.join(root, rel);
    if (statSync(abs).isDirectory()) walk(rel, out);
    else out.push(rel);
  }
  return out;
}

const requiredFiles = [
  'public/index.html', 'public/auth.html', 'patient/index.html', 'staff/index.html', 'super-admin/index.html',
  'css/base.css', 'css/landing.css', 'css/panel.css', 'css/auth.css',
  'assets/images/reliance-logo.png', 'assets/images/reliance-mark.png', 'assets/logos/reliance-mark.svg', 'assets/fonts/fonts.css',
  'js/core/config.js', 'js/core/supabase.js', 'js/core/dom.js', 'js/core/ui.js', 'js/core/auth.js',
  'js/core/forms.js', 'js/core/profile.js', 'js/core/calendar.js', 'js/core/charts.js', 'js/core/reports.js',
  'js/core/documents.js', 'js/core/chatbot.js', 'js/core/layout.js',
  'js/public/landing.js', 'js/public/auth.js', 'js/patient/panel.js', 'js/staff/panel.js', 'js/super-admin/panel.js',
  'js/vendor/supabase.esm.js', 'js/vendor/SUPABASE-LICENSE.txt',
  'api/config.js', 'server.mjs', 'vercel.json', '.env.example', 'README.md',
  'sql/01_schema.sql', 'sql/02_constraints.sql', 'sql/03_rls.sql', 'sql/04a_config_capacity.sql',
  'sql/04b_appointments.sql', 'sql/04c_documents_sessions.sql', 'sql/04d_admin_analytics.sql', 'sql/05_storage.sql',
  'supabase/functions/admin-accounts/index.ts'
];
for (const file of requiredFiles) assert(existsSync(path.join(root, file)), `Missing required file: ${file}`);

const frontendFiles = [
  ...walk('public').filter((f) => /\.(html|js|css)$/.test(f)),
  ...walk('patient').filter((f) => /\.(html|js|css)$/.test(f)),
  ...walk('staff').filter((f) => /\.(html|js|css)$/.test(f)),
  ...walk('super-admin').filter((f) => /\.(html|js|css)$/.test(f)),
  ...walk('js').filter((f) => /\.(js|css)$/.test(f) && !f.includes('vendor')),
  ...walk('css').filter((f) => /\.css$/.test(f))
];
const secretPatterns = [/service_role/i, /SUPABASE_SERVICE_ROLE_KEY/, /sb_secret/i, /sb_publishable_[A-Za-z0-9_-]{10,}/];
for (const file of frontendFiles) {
  const text = read(file);
  for (const pattern of secretPatterns) assert(!pattern.test(text), `Frontend file contains a secret pattern: ${file}`);
}

const schema = read('sql/01_schema.sql');
const tableCount = (schema.match(/^CREATE TABLE IF NOT EXISTS public\./gm) || []).length;
assert(tableCount === 10, `Expected exactly 10 custom tables in sql/01_schema.sql, found ${tableCount}`);

const migrations = walk('sql/migrations').filter((f) => f.endsWith('.sql')).sort();
assert(migrations.length === 8, `Expected 8 ordered migration files, found ${migrations.length}`);

const jsFiles = [
  ...walk('js').filter((f) => f.endsWith('.js')),
  'api/config.js', 'server.mjs', 'tests/smoke.mjs'
];
for (const file of jsFiles) {
  try {
    execFileSync(process.execPath, ['--check', path.join(root, file)], { stdio: 'pipe' });
  } catch (error) {
    failures.push(`JS syntax check failed: ${file}\n${error.stderr?.toString() || error.message}`);
  }
}

if (failures.length) {
  console.error('Smoke checks failed:');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('Smoke checks passed.');
console.log(`- Required files: ${requiredFiles.length}`);
console.log(`- Frontend secret scan: ${frontendFiles.length} files`);
console.log(`- Custom tables in schema: ${tableCount}`);
console.log(`- Migration files: ${migrations.length}`);
console.log(`- JS syntax checks: ${jsFiles.length}`);
