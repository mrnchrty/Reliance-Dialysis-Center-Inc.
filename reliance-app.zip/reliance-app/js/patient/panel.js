// Patient Panel — Dashboard, Book Appointment wizard/tracker and My Records.
// All data is read from authorized Supabase records; no sample patient data is used.
import {
  $, $$, esc, formatDate, formatDateTime, formatTime, shortId, badge,
  manilaTodayISO, addDays, parseISODate, selectField, inputField, textareaField, formData
} from '../core/dom.js';
import { getSupabase, rpc } from '../core/supabase.js';
import { guardRole, loadRoleContext } from '../core/auth.js';
import { setupPanel } from '../core/layout.js';
import { renderProfileCompletion, slotDisplay, prettyDocumentType, configTimeSlots } from '../core/forms.js';
import {
  loadAvailabilityForMonth, availabilityByDate, renderAvailabilityCalendar,
  renderTimeSlotPicker, monthDate
} from '../core/calendar.js';
import { uploadPatientDocument, openDocument, documentReadiness, renderDocumentStatus, documentMeta } from '../core/documents.js';
import {
  toast, openModal, confirmDialog, renderTable, renderKeyValue, renderTimeline,
  rawHtml, renderSectionHeader, renderStatCard, validateForm, setFormMessage, withButton, showLoading
} from '../core/ui.js';
import { printAppointmentReport } from '../core/reports.js';
import { openProfileModal } from '../core/profile.js';

const ONBOARDING_KEY = 'reliance-onboarding';

const SIDEBAR = [
  { id: 'dashboard', label: 'Dashboard', icon: '▦' },
  { id: 'book-appointment', label: 'Book Appointment', icon: '▤' },
  { id: 'my-records', label: 'My Records', icon: '▧' }
];

async function selectOrThrow(builder) {
  const { data, error } = await builder;
  if (error) throw new Error(error.message);
  return data || [];
}

async function loadPatientData(context) {
  const client = await getSupabase();
  const [patientResult, medicalResult, config, appointments, documents, sessions, machines] = await Promise.all([
    client.from('patients').select('*').eq('patient_id', context.patientId).single(),
    client.from('patient_medical_profiles').select('*').eq('patient_id', context.patientId).maybeSingle(),
    rpc('get_system_config'),
    selectOrThrow(client.from('appointments').select('*').eq('patient_id', context.patientId).order('created_at', { ascending: false })),
    selectOrThrow(client.from('patient_documents').select('*').eq('patient_id', context.patientId).order('uploaded_at', { ascending: false })),
    selectOrThrow(client.from('dialysis_sessions').select('*').eq('patient_id', context.patientId).eq('is_released_to_patient', true).order('treatment_date', { ascending: false })),
    selectOrThrow(client.from('dialysis_machines').select('machine_id,machine_code,machine_name').order('machine_code'))
  ]);
  if (patientResult.error) throw new Error(patientResult.error.message);
  if (medicalResult.error) throw new Error(medicalResult.error.message);
  return {
    patient: patientResult.data,
    medical: medicalResult.data || {},
    config,
    appointments,
    documents,
    sessions,
    machinesById: new Map(machines.map((m) => [m.machine_id, m]))
  };
}

function appointmentStatusBadges(appt) {
  const parts = [badge(appt.appointment_status)];
  if (appt.is_cancelled) parts.push(badge('Cancellation processed', 'danger'));
  if (appt.reschedule_requested) parts.push(badge('Reschedule pending', 'warning'));
  if (appt.correction_request && Object.keys(appt.correction_request || {}).length) parts.push(badge('Document correction', 'warning'));
  return parts.join(' ');
}

function appointmentTable(appointments, { showActions = true } = {}) {
  return renderTable({
    columns: [
      { label: 'Appointment', render: (a) => `<strong>${esc(shortId(a.appointment_id))}</strong><small class="field-hint">${esc(formatDateTime(a.created_at))}</small>` },
      { label: 'Requested', render: (a) => `${esc(formatDate(a.requested_date, true))}<small class="field-hint">${esc(slotDisplay({}, a.requested_time))}</small>` },
      { label: 'Confirmed', render: (a) => a.confirmed_date ? `${esc(formatDate(a.confirmed_date, true))}<small class="field-hint">${esc(formatTime(a.confirmed_start_time))} – ${esc(formatTime(a.confirmed_end_time))}</small>` : 'Not yet confirmed' },
      { label: 'Status', render: (a) => appointmentStatusBadges(a) },
      ...(showActions ? [{ label: 'Actions', className: 'actions', render: (a) => `
        <button type="button" class="btn btn-secondary btn-small" data-view="${esc(a.appointment_id)}">View</button>
        <button type="button" class="btn btn-ghost btn-small" data-print="${esc(a.appointment_id)}">Print</button>
        ${!a.is_cancelled && a.appointment_status !== 'Rejected' ? `<button type="button" class="btn btn-ghost btn-small" data-reschedule="${esc(a.appointment_id)}">Reschedule</button><button type="button" class="btn btn-ghost btn-small" data-cancel="${esc(a.appointment_id)}">Cancel</button>` : ''}
      ` }] : [])
    ],
    rows: appointments,
    emptyTitle: 'No appointment requests yet',
    emptyMessage: 'Submit a new request through the booking wizard. Staff confirmation and machine assignment will appear here.'
  });
}

async function openAppointmentDetail(appointmentId, api) {
  const detail = await rpc('get_appointment_detail', { p_appointment_id: appointmentId });
  const a = detail.appointment || {};
  const p = detail.patient || {};
  const m = detail.medical_profile || {};
  const machine = detail.machine || {};
  const config = detail.config || {};
  const correction = a.correction_request || {};
  const reschedule = a.reschedule_request || {};
  const cancellation = a.cancellation_request || {};
  const content = `
    ${a.is_cancelled ? '<div class="notice notice-danger">This appointment has a processed cancellation. The original request and status history are preserved.</div>' : ''}
    ${a.reschedule_requested ? `<div class="notice notice-warning">Reschedule request pending staff review: ${esc(reschedule.new_date || '')} · ${esc(slotDisplay(config, reschedule.new_time || ''))}${reschedule.reason ? ` · ${esc(reschedule.reason)}` : ''}</div>` : ''}
    ${correction?.document_type ? `<div class="correction-banner">Document correction requested for <strong>${esc(prettyDocumentType(correction.document_type))}</strong>. The appointment remains Under Review while you upload a corrected copy.</div>` : ''}
    <div class="detail-layout">
      <div class="panel-stack">
        <section class="card">
          <div class="card-header"><div><h2>Appointment ${esc(shortId(a.appointment_id))}</h2><p>Live record from APPOINTMENTS and related Supabase tables.</p></div>${appointmentStatusBadges(a)}</div>
          ${renderKeyValue([
            ['Requested date', formatDate(a.requested_date, true)],
            ['Preferred time', slotDisplay(config, a.requested_time)],
            ['Submitted', formatDateTime(a.created_at)],
            ['Confirmed date', a.confirmed_date ? formatDate(a.confirmed_date, true) : 'Not yet confirmed'],
            ['Confirmed time', a.confirmed_start_time ? `${formatTime(a.confirmed_start_time)} – ${formatTime(a.confirmed_end_time)}` : 'Not yet confirmed'],
            ['Assigned machine', machine.machine_code || a.machine_snapshot?.machine_code || 'Staff assignment pending'],
            ['Staff remarks', a.staff_remarks || 'None recorded'],
            ['Attendance outcome', a.attendance_flag || 'Scheduled'],
            ['Recurrence group', a.recurrence_group_id ? shortId(a.recurrence_group_id) : '—'],
            ['Cancellation request', cancellation?.status || 'None'],
            ['Reschedule request', reschedule?.status || 'None']
          ])}
        </section>
        <section class="card"><div class="card-header"><div><h2>Status history</h2><p>Every status change is preserved in the appointment record.</p></div></div>${renderTimeline(a.status_history || [])}</section>
        <section class="card"><div class="card-header"><div><h2>Submitted documents</h2><p>Document verification is separate from appointment status.</p></div></div>${renderTable({
          columns: [
            { label: 'Category', render: (d) => esc(prettyDocumentType(d.document_type)) },
            { label: 'File', render: (d) => esc(d.file_name) },
            { label: 'Verification', render: (d) => renderDocumentStatus(d) },
            { label: 'Actions', render: (d) => `<button type="button" class="btn btn-secondary btn-small" data-doc-preview="${esc(d.document_id)}">Preview</button> <button type="button" class="btn btn-ghost btn-small" data-doc-download="${esc(d.document_id)}">Download</button>` }
          ],
          rows: detail.documents || [],
          emptyTitle: 'No documents returned',
          emptyMessage: 'No current documents were returned for this authorized appointment record.'
        })}</section>
      </div>
      <aside class="panel-stack">
        <section class="card"><div class="card-header"><div><h2>Patient</h2><p>Saved profile used for this request.</p></div></div>${renderKeyValue([
          ['Full name', p.full_name], ['Email', p.email], ['Date of birth', formatDate(p.date_of_birth)],
          ['Contact', p.contact_number], ['Address', p.address]
        ])}</section>
        <section class="card"><div class="card-header"><div><h2>Medical profile</h2><p>Baseline weight is separate from session weights.</p></div></div>${renderKeyValue([
          ['Diagnosis', m.diagnosis], ['Blood type', m.blood_type], ['Allergies', m.allergies],
          ['Attending nephrologist', m.attending_nephrologist], ['Prescribed frequency', m.prescribed_dialysis_frequency],
          ['Baseline weight', m.weight ? `${m.weight} kg` : null]
        ])}</section>
      </aside>
    </div>`;
  const modal = openModal({
    title: `Appointment ${shortId(a.appointment_id)}`,
    subtitle: 'Authorized appointment record',
    size: 'large',
    content,
    actions: [
      { label: 'Close', class: 'btn-secondary' },
      {
        label: 'Print / PDF', class: 'btn-secondary', close: false,
        onClick: async () => { printAppointmentReport(detail, { preparedBy: api.context.displayName }); return false; }
      },
      ...(!a.is_cancelled && a.appointment_status !== 'Rejected' ? [
        {
          label: 'Request reschedule', class: 'btn-secondary', close: false,
          onClick: async (apiModal) => { apiModal.close(); await openRescheduleModal(a, api); return false; }
        },
        {
          label: 'Request cancellation', class: 'btn-danger', close: false,
          onClick: async (apiModal) => { apiModal.close(); await requestCancellation(a, api); return false; }
        }
      ] : [])
    ]
  });
  $$('[data-doc-preview]', modal.body).forEach((button) => button.addEventListener('click', async () => {
    const doc = (detail.documents || []).find((d) => d.document_id === button.dataset.docPreview);
    if (doc) await openDocument(doc, 'preview');
  }));
  $$('[data-doc-download]', modal.body).forEach((button) => button.addEventListener('click', async () => {
    const doc = (detail.documents || []).find((d) => d.document_id === button.dataset.docDownload);
    if (doc) await openDocument(doc, 'download');
  }));
  return modal;
}

async function openRescheduleModal(appointment, api) {
  const config = await rpc('get_system_config');
  const slots = configTimeSlots(config);
  const minDate = addDays(manilaTodayISO(), 1);
  const modal = openModal({
    title: 'Request reschedule',
    subtitle: 'Original appointment details are preserved. Staff must review capacity before any change is applied.',
    content: `<form id="reschedule-form" novalidate><div class="form-grid">
      ${inputField({ name: 'new_date', label: 'New requested date', type: 'date', required: true, min: minDate, hint: 'Monday–Saturday only; Sunday is closed.' })}
      ${selectField({ name: 'new_time', label: 'New preferred time', options: slots.map((s) => ({ value: s.id, label: s.display || s.label || s.id })), required: true })}
      ${textareaField({ name: 'reason', label: 'Reason', required: false, placeholder: 'Optional reason for staff review', rows: 3, className: 'span-2' })}
    </div></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Submit reschedule request', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#reschedule-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          try {
            await rpc('request_reschedule', {
              p_appointment_id: appointment.appointment_id,
              p_new_date: data.new_date,
              p_new_time: data.new_time,
              p_reason: String(data.reason || '').trim() || null
            });
            toast('Reschedule request submitted for staff review.', 'success');
            apiModal.close();
            api.refresh();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function requestCancellation(appointment, api) {
  const result = await confirmDialog({
    title: 'Request cancellation?',
    message: `Request cancellation for appointment ${shortId(appointment.appointment_id)} on ${formatDate(appointment.requested_date, true)}? This preserves the appointment history and notifies staff. Capacity is released only when staff processes the request.`,
    confirmLabel: 'Request cancellation',
    danger: true,
    requireText: true
  });
  if (!result?.confirmed) return;
  try {
    await rpc('request_cancellation', { p_appointment_id: appointment.appointment_id, p_reason: result.note || null });
    toast('Cancellation request submitted for staff processing.', 'success');
    api.refresh();
  } catch (error) {
    toast(error.message, 'error');
  }
}

function bindAppointmentActions(container, appointments, api) {
  const byId = new Map(appointments.map((a) => [a.appointment_id, a]));
  $$('[data-view]', container).forEach((button) => button.addEventListener('click', async () => {
    try { await openAppointmentDetail(button.dataset.view, api); } catch (error) { toast(error.message, 'error'); }
  }));
  $$('[data-print]', container).forEach((button) => button.addEventListener('click', async () => {
    try {
      const detail = await rpc('get_appointment_detail', { p_appointment_id: button.dataset.print });
      printAppointmentReport(detail, { preparedBy: api.context.displayName });
    } catch (error) { toast(error.message, 'error'); }
  }));
  $$('[data-reschedule]', container).forEach((button) => button.addEventListener('click', async () => {
    const appointment = byId.get(button.dataset.reschedule);
    if (appointment) await openRescheduleModal(appointment, api);
  }));
  $$('[data-cancel]', container).forEach((button) => button.addEventListener('click', async () => {
    const appointment = byId.get(button.dataset.cancel);
    if (appointment) await requestCancellation(appointment, api);
  }));
}

function documentUploadCard({ type, readiness, context, config, onUploaded }) {
  const current = readiness.current;
  const canUpload = readiness.needsUpload;
  const id = `upload-${type.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}`;
  return `<article class="document-card" data-doc-type="${esc(type)}">
    <header><div><h3>${esc(prettyDocumentType(type))}</h3><p class="muted">${esc(documentMeta(current))}</p></div>${renderDocumentStatus(current)}</header>
    ${readiness.reusable ? '<div class="notice notice-success">Verified document is reusable for succeeding bookings.</div>' : ''}
    ${current?.correction_requested ? `<div class="notice notice-warning">Staff requested an updated copy: ${esc(current.correction_notes || 'Please upload a corrected document.')}</div>` : ''}
    ${canUpload ? `<div class="upload-drop">
      <label for="${id}">Upload ${canUpload ? 'replacement' : 'new'} file <span class="required" title="Required">*</span></label>
      <input id="${id}" type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" data-doc-file />
      <small class="field-hint">PDF, JPEG, PNG or WebP; maximum 10 MB. Private Storage only.</small>
      <button type="button" class="btn btn-primary btn-small" data-doc-upload disabled>Upload document</button>
    </div>` : '<p class="muted">No replacement is required unless staff marks this document outdated, rejected, or in need of correction.</p>'}
  </article>`;
}

function bindDocumentUploads(container, { context, config, readiness, onUploaded }) {
  $$('[data-doc-type]', container).forEach((card) => {
    const type = card.dataset.docType;
    const item = readiness.find((r) => r.type === type);
    const input = $('[data-doc-file]', card);
    const button = $('[data-doc-upload]', card);
    if (!input || !button || !item?.needsUpload) return;
    input.addEventListener('change', () => { button.disabled = !input.files?.[0]; });
    button.addEventListener('click', async () => {
      const file = input.files?.[0];
      if (!file) return;
      await withButton(button, async () => {
        await uploadPatientDocument({
          context,
          file,
          documentType: type,
          replacesDocumentId: item.current?.document_id || null,
          config
        });
        toast(`${prettyDocumentType(type)} uploaded and sent for staff verification.`, 'success');
        await onUploaded();
      }, { label: 'Uploading…' });
    });
  });
}

async function renderDashboard(container, api) {
  showLoading(container, 'Loading your dashboard…');
  const data = await loadPatientData(api.context);
  const { patient, medical, config, appointments, documents, sessions } = data;
  const completion = renderProfileCompletion(patient, medical, config);
  const today = manilaTodayISO();
  const upcoming = appointments
    .filter((a) => !a.is_cancelled && a.appointment_status === 'Confirmed' && String(a.confirmed_date || a.requested_date) >= today)
    .sort((a, b) => String(a.confirmed_date || a.requested_date).localeCompare(String(b.confirmed_date || b.requested_date)))[0];
  const readiness = documentReadiness(config, documents);
  const verifiedCount = readiness.filter((r) => r.verified).length;
  const counts = {
    total: appointments.length,
    pending: appointments.filter((a) => a.appointment_status === 'Pending' && !a.is_cancelled).length,
    review: appointments.filter((a) => a.appointment_status === 'Under Review' && !a.is_cancelled).length,
    confirmed: appointments.filter((a) => a.appointment_status === 'Confirmed' && !a.is_cancelled).length
  };
  container.innerHTML = `
    <div class="welcome-banner">
      <div>
        <p class="eyebrow">Patient Panel</p>
        <h1>Welcome, ${esc(patient.full_name || api.context.displayName)}</h1>
        <p>${upcoming ? `Next confirmed session: ${esc(formatDate(upcoming.confirmed_date || upcoming.requested_date, true))} · ${esc(formatTime(upcoming.confirmed_start_time))} – ${esc(formatTime(upcoming.confirmed_end_time))}` : 'Live appointments, required documents, and released dialysis records from Supabase.'}</p>
      </div>
      <div class="section-actions"><button type="button" class="btn btn-primary" data-nav="book-appointment">Book Appointment</button><button type="button" class="btn btn-secondary" data-nav="my-records">My Records</button></div>
    </div>
    <div class="panel-stack">
      ${completion.html}
      <div class="panel-grid four">
        ${renderStatCard({ label: 'Total requests', value: counts.total, note: 'All appointment records' })}
        ${renderStatCard({ label: 'Pending', value: counts.pending, note: 'Awaiting staff review', tone: 'amber' })}
        ${renderStatCard({ label: 'Under Review', value: counts.review, note: 'Document or schedule review', tone: 'red' })}
        ${renderStatCard({ label: 'Confirmed', value: counts.confirmed, note: 'Machine assigned by staff', tone: 'green' })}
      </div>
      <div class="detail-layout">
        <section class="card">
          <div class="card-header"><div><h2>Next confirmed appointment</h2><p>Confirmed details are assigned exclusively by authorized staff.</p></div></div>
          ${upcoming ? `<div class="appointment-card"><header><div><h3>${esc(shortId(upcoming.appointment_id))}</h3><p class="muted">${esc(formatDate(upcoming.confirmed_date || upcoming.requested_date, true))} · ${esc(formatTime(upcoming.confirmed_start_time))} – ${esc(formatTime(upcoming.confirmed_end_time))}</p></div>${badge(upcoming.appointment_status)}</header><div class="inline-actions"><button type="button" class="btn btn-secondary btn-small" data-view="${esc(upcoming.appointment_id)}">View details</button><button type="button" class="btn btn-ghost btn-small" data-print="${esc(upcoming.appointment_id)}">Print</button></div></div>` : '<div class="empty-inline">No confirmed upcoming appointment. Submit a request and wait for staff confirmation.</div>'}
        </section>
        <section class="card">
          <div class="card-header"><div><h2>Document readiness</h2><p>Verified documents remain reusable unless staff requests an update.</p></div></div>
          <div class="mini-list">${readiness.map((r) => `<div class="mini-row"><div><strong>${esc(prettyDocumentType(r.type))}</strong><small>${esc(r.current ? `${r.current.file_name} · v${r.current.version}` : 'Not submitted')}</small></div>${renderDocumentStatus(r.current)}</div>`).join('')}</div>
          <p class="muted">${verifiedCount} of ${readiness.length} required categories verified.</p>
        </section>
      </div>
      <section class="card">
        <div class="card-header"><div><h2>Recent appointment requests</h2><p>Track status, confirmed details, staff remarks and history.</p></div><button type="button" class="btn btn-secondary btn-small" data-nav="book-appointment">Open tracker</button></div>
        ${appointmentTable(appointments.slice(0, 5))}
      </section>
      <section class="card">
        <div class="card-header"><div><h2>Released dialysis history</h2><p>Only official sessions released by authorized staff are visible.</p></div></div>
        ${sessions.length ? renderTable({
          columns: [
            { label: 'Treatment date', render: (s) => esc(formatDate(s.treatment_date, true)) },
            { label: 'Machine', render: (s) => esc(data.machinesById.get(s.machine_id)?.machine_code || '—') },
            { label: 'Pre / Post weight', render: (s) => `${esc(s.pre_dialysis_weight ?? '—')} kg / ${esc(s.post_dialysis_weight ?? '—')} kg` },
            { label: 'Status', render: (s) => badge(s.session_status) }
          ], rows: sessions.slice(0, 5)
        }) : '<div class="empty-inline">No released dialysis sessions yet.</div>'}
      </section>
    </div>`;
  $$('[data-nav]', container).forEach((button) => button.addEventListener('click', () => api.navigate(button.dataset.nav)));
  bindAppointmentActions(container, appointments, api);
}

async function renderBookAppointment(container, api) {
  showLoading(container, 'Loading booking workspace…');
  const data = await loadPatientData(api.context);
  const state = {
    step: 1,
    month: monthDate(parseISODate(manilaTodayISO()).getUTCFullYear(), parseISODate(manilaTodayISO()).getUTCMonth()),
    availability: null,
    selectedDate: '',
    selectedSlot: '',
    notes: '',
    submitted: null
  };
  const steps = ['Complete Profile', 'Select Appointment Date', 'Select Preferred Time', 'Submit Required Documents', 'Review and Submit'];

  async function ensureAvailability() {
    const year = state.month.getUTCFullYear();
    const month = state.month.getUTCMonth();
    const loaded = await loadAvailabilityForMonth(year, month);
    state.availability = loaded.availability;
    state.config = loaded.config;
  }

  function stepper() {
    return `<div class="stepper" aria-label="Booking progress">${steps.map((label, index) => {
      const n = index + 1;
      const cls = n === state.step ? 'active' : n < state.step ? 'done' : '';
      return `<div class="stepper-step ${cls}"><span>${n < state.step ? '✓' : n}</span><span>${esc(label)}</span></div>`;
    }).join('')}</div>`;
  }

  function wizardShell(body, { nextLabel = 'Continue', nextDisabled = false, showBack = true, submit = false } = {}) {
    return `<section class="card wizard-card">
      <div class="card-header"><div><h2>New appointment request</h2><p>Saved profile information is reused. Patients select a preferred time only; staff assigns machines.</p></div></div>
      ${stepper()}
      ${body}
      <div class="wizard-actions">
        <button type="button" class="btn btn-secondary" data-step-back ${state.step === 1 || !showBack ? 'disabled' : ''}>Back</button>
        ${submit ? `<button type="button" class="btn btn-primary" data-step-submit ${nextDisabled ? 'disabled' : ''}>Submit appointment request</button>` : `<button type="button" class="btn btn-primary" data-step-next ${nextDisabled ? 'disabled' : ''}>${esc(nextLabel)}</button>`}
      </div>
    </section>`;
  }

  function renderStep1() {
    const completion = renderProfileCompletion(data.patient, data.medical, data.config);
    return wizardShell(`
      ${completion.html}
      <div class="notice notice-info">Personal profile is saved first, then medical profile. Incomplete or outdated information can be updated here before booking.</div>
      <div class="inline-actions">
        <button type="button" class="btn btn-secondary" data-edit-profile="1">Update personal profile</button>
        <button type="button" class="btn btn-secondary" data-edit-profile="2">Update medical profile</button>
      </div>
    `, { nextDisabled: !completion.complete, nextLabel: 'Continue to date selection' });
  }

  function renderStep2() {
    const holder = '<div id="availability-calendar"></div>';
    return wizardShell(`
      <p class="muted">The calendar shows live Supabase capacity. Past dates, Sundays and dates with no available machine capacity are disabled.</p>
      ${holder}
      ${state.selectedDate ? `<div class="notice notice-success">Selected date: <strong>${esc(formatDate(state.selectedDate, true))}</strong></div>` : ''}
    `, { nextDisabled: !state.selectedDate, nextLabel: 'Continue to time selection' });
  }

  function renderStep3() {
    const map = availabilityByDate(state.availability);
    const dateInfo = map.get(state.selectedDate);
    return wizardShell(`
      <p class="muted">Selected date: <strong>${esc(formatDate(state.selectedDate, true))}</strong>. Choose one preferred time window.</p>
      <div id="time-slot-picker"></div>
      ${state.selectedSlot ? `<div class="notice notice-success">Preferred time: <strong>${esc(slotDisplay(data.config, state.selectedSlot))}</strong></div>` : ''}
    `, { nextDisabled: !state.selectedSlot, nextLabel: 'Continue to documents' });
  }

  function renderStep4() {
    const readiness = documentReadiness(data.config, data.documents);
    const ready = readiness.every((r) => r.submitted);
    return wizardShell(`
      <p class="muted">Upload the four required categories. Previously verified documents remain usable unless staff marks them outdated, rejected, or in need of correction.</p>
      <div class="document-list">${readiness.map((r) => documentUploadCard({ type: r.type, readiness: r, context: api.context, config: data.config })).join('')}</div>
      ${ready ? '<div class="notice notice-success">All required categories have a current submitted document.</div>' : '<div class="notice notice-warning">At least one required category still needs a current submitted document.</div>'}
    `, { nextDisabled: !ready, nextLabel: 'Continue to review' });
  }

  function renderStep5() {
    const readiness = documentReadiness(data.config, data.documents);
    return wizardShell(`
      <div class="summary-card">
        <h3>Review and submit</h3>
        ${renderKeyValue([
          ['Patient', data.patient.full_name],
          ['Requested date', formatDate(state.selectedDate, true)],
          ['Preferred time', slotDisplay(data.config, state.selectedSlot)],
          ['Documents', `${readiness.filter((r) => r.submitted).length} of ${readiness.length} categories submitted`],
          ['Machine assignment', 'Staff only after document verification']
        ])}
      </div>
      <div class="form-grid" style="margin-top:1rem">
        ${textareaField({ name: 'notes', label: 'Notes for staff', value: state.notes, required: false, placeholder: 'Optional notes. Do not include urgent medical advice here.', rows: 3, className: 'span-2' })}
      </div>
    `, { submit: true, nextDisabled: !state.selectedDate || !state.selectedSlot });
  }

  function renderSuccess() {
    return `<section class="card wizard-card">
      <div class="state-card state-success"><span class="state-icon" aria-hidden="true">✓</span><h3>Appointment request submitted</h3><p>Appointment ${esc(shortId(state.submitted.appointment_id))} is now Pending. Track it below and wait for staff confirmation.</p><button type="button" class="btn btn-primary" data-view="${esc(state.submitted.appointment_id)}">View appointment</button></div>
    </section>`;
  }

  async function render() {
    const tracker = `
      <section class="card">
        <div class="card-header"><div><h2>Appointment tracker</h2><p>Current status, confirmed details, machine, staff remarks and status history.</p></div><button type="button" class="btn btn-secondary btn-small" data-refresh-book>Refresh</button></div>
        ${appointmentTable(data.appointments)}
      </section>`;
    if (state.submitted) {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'Book Appointment', subtitle: 'Complete the required sequence, then track every request.' })}<div class="panel-stack">${renderSuccess()}${tracker}</div>`;
    } else if (state.step === 1) {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'Book Appointment', subtitle: 'Complete the required sequence, then track every request.' })}<div class="panel-stack">${renderStep1()}${tracker}</div>`;
    } else if (state.step === 2) {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'Book Appointment', subtitle: 'Complete the required sequence, then track every request.' })}<div class="panel-stack">${renderStep2()}${tracker}</div>`;
      const calendar = $('#availability-calendar', container);
      renderAvailabilityCalendar({
        container: calendar,
        monthDate: state.month,
        availability: state.availability,
        selectedDate: state.selectedDate,
        onSelect: (date) => { state.selectedDate = date; state.selectedSlot = ''; render(); },
        onMonthChange: async (nextMonth) => { state.month = nextMonth; await ensureAvailability(); render(); }
      });
    } else if (state.step === 3) {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'Book Appointment', subtitle: 'Complete the required sequence, then track every request.' })}<div class="panel-stack">${renderStep3()}${tracker}</div>`;
      const map = availabilityByDate(state.availability);
      renderTimeSlotPicker({
        container: $('#time-slot-picker', container),
        dateInfo: map.get(state.selectedDate),
        config: data.config,
        selectedTime: state.selectedSlot,
        onSelect: (slot) => { state.selectedSlot = slot; render(); }
      });
    } else if (state.step === 4) {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'Book Appointment', subtitle: 'Complete the required sequence, then track every request.' })}<div class="panel-stack">${renderStep4()}${tracker}</div>`;
      const readiness = documentReadiness(data.config, data.documents);
      bindDocumentUploads(container, {
        context: api.context,
        config: data.config,
        readiness,
        onUploaded: async () => {
          const fresh = await loadPatientData(api.context);
          Object.assign(data, fresh);
          render();
        }
      });
    } else {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'Book Appointment', subtitle: 'Complete the required sequence, then track every request.' })}<div class="panel-stack">${renderStep5()}${tracker}</div>`;
    }

    $$('[data-edit-profile]', container).forEach((button) => button.addEventListener('click', () => api.openProfile({ startStep: Number(button.dataset.editProfile) })));
    $('[data-step-back]', container)?.addEventListener('click', () => { state.step = Math.max(1, state.step - 1); render(); });
    $('[data-step-next]', container)?.addEventListener('click', async () => {
      if (state.step === 1) {
        const completion = renderProfileCompletion(data.patient, data.medical, data.config);
        if (!completion.complete) { toast('Complete personal and medical profiles before booking.', 'error'); return; }
      }
      if (state.step === 4) {
        const readiness = documentReadiness(data.config, data.documents);
        if (!readiness.every((r) => r.submitted)) { toast('Submit all required documents before review.', 'error'); return; }
      }
      state.step = Math.min(5, state.step + 1);
      if (state.step === 2 && !state.availability) await ensureAvailability();
      render();
    });
    $('[data-step-submit]', container)?.addEventListener('click', async (event) => {
      const notes = $('textarea[name="notes"]', container)?.value || '';
      state.notes = notes;
      await withButton(event.currentTarget, async () => {
        const result = await rpc('create_appointment_request', {
          p_requested_date: state.selectedDate,
          p_requested_time: state.selectedSlot,
          p_notes: String(notes).trim() || null
        });
        state.submitted = result;
        const fresh = await loadPatientData(api.context);
        Object.assign(data, fresh);
        toast('Appointment request submitted. Staff will verify documents and assign a machine.', 'success');
        render();
      }, { label: 'Submitting…' });
    });
    $('[data-refresh-book]', container)?.addEventListener('click', async () => {
      const fresh = await loadPatientData(api.context);
      Object.assign(data, fresh);
      render();
    });
    bindAppointmentActions(container, data.appointments, api);
  }

  await ensureAvailability();
  await render();
  const focusId = api.params.get('appointment_id');
  if (focusId) {
    setTimeout(async () => {
      try { await openAppointmentDetail(focusId, api); } catch (error) { toast(error.message, 'error'); }
    }, 150);
  }
}

async function renderMyRecords(container, api) {
  showLoading(container, 'Loading My Records…');
  const data = await loadPatientData(api.context);
  const tab = ['medical', 'documents', 'history'].includes(api.params.get('tab')) ? api.params.get('tab') : 'medical';
  const { patient, medical, config, documents, sessions } = data;
  const readiness = documentReadiness(config, documents);
  const tabs = `<div class="tabs" role="tablist" aria-label="My Records categories">
    <button type="button" class="tab-button ${tab === 'medical' ? 'active' : ''}" data-tab="medical">Medical Information</button>
    <button type="button" class="tab-button ${tab === 'documents' ? 'active' : ''}" data-tab="documents">Submitted Documents</button>
    <button type="button" class="tab-button ${tab === 'history' ? 'active' : ''}" data-tab="history">Dialysis History</button>
  </div>`;

  function medicalTab() {
    return `<div class="detail-layout">
      <section class="card"><div class="card-header"><div><h2>Medical Information</h2><p>Official treatment records cannot be edited by patients.</p></div><button type="button" class="btn btn-secondary btn-small" data-edit-profile>Update permitted profile information</button></div>
        ${renderKeyValue([
          ['Full name', patient.full_name], ['Date of birth', formatDate(patient.date_of_birth)], ['Sex', patient.sex_other || patient.sex],
          ['Contact number', patient.contact_number], ['Address', patient.address],
          ['Emergency contact', patient.emergency_contact_name ? `${patient.emergency_contact_name} · ${patient.emergency_contact_number}` : null],
          ['Height', medical.height ? `${medical.height} cm` : null], ['Baseline weight (general profile)', medical.weight ? `${medical.weight} kg` : null],
          ['Blood type', medical.blood_type], ['Diagnosis', medical.diagnosis], ['Allergies', medical.allergies],
          ['Existing medical conditions', medical.existing_medical_conditions], ['Previous surgeries', medical.previous_surgeries],
          ['Current medications', medical.current_medications], ['Attending nephrologist', medical.attending_nephrologist],
          ['Prescribed dialysis frequency', medical.prescribed_dialysis_frequency], ['Dialysis start date', formatDate(medical.dialysis_start_date)],
          ['Previous dialysis center', medical.previous_dialysis_center], ['Recurring days', Array.isArray(medical.recurring_days) ? medical.recurring_days.join(', ') : null],
          ['Preferred time', medical.preferred_time ? slotDisplay(config, medical.preferred_time) : null]
        ])}
      </section>
      <aside class="card"><div class="card-header"><div><h2>Profile completion</h2><p>Saved information is reused for succeeding bookings.</p></div></div>${renderProfileCompletion(patient, medical, config).html}</aside>
    </div>`;
  }

  function documentsTab() {
    return `<div class="panel-stack">
      <section class="card"><div class="card-header"><div><h2>Required document uploads</h2><p>Private Storage files with staff verification status.</p></div></div>
        <div class="document-list">${readiness.map((r) => documentUploadCard({ type: r.type, readiness: r, context: api.context, config })).join('')}</div>
      </section>
      <section class="card"><div class="card-header"><div><h2>All submitted documents</h2><p>Preview and download use short-lived signed links from private Storage.</p></div></div>
        ${renderTable({
          columns: [
            { label: 'Category', render: (d) => esc(prettyDocumentType(d.document_type)) },
            { label: 'Filename', render: (d) => esc(d.file_name) },
            { label: 'Version', render: (d) => esc(d.version) },
            { label: 'Status', render: (d) => renderDocumentStatus(d) },
            { label: 'Uploaded', render: (d) => esc(formatDateTime(d.uploaded_at)) },
            { label: 'Actions', render: (d) => `<button type="button" class="btn btn-secondary btn-small" data-doc-preview="${esc(d.document_id)}">Preview</button> <button type="button" class="btn btn-ghost btn-small" data-doc-download="${esc(d.document_id)}">Download</button>` }
          ],
          rows: documents,
          emptyTitle: 'No documents submitted',
          emptyMessage: 'Upload required documents from the booking wizard or this section.'
        })}
      </section>
    </div>`;
  }

  function historyTab() {
    if (!sessions.length) return '<div class="state-card state-empty"><span class="state-icon" aria-hidden="true">○</span><h3>No released dialysis history</h3><p>Only official sessions released by authorized staff appear here. Session pre- and post-dialysis weights are separate from your general profile weight.</p></div>';
    return `<div class="panel-grid two">${sessions.map((s) => `<article class="session-card">
      <div class="card-header"><div><h3>${esc(formatDate(s.treatment_date, true))}</h3><p class="session-meta">${esc(data.machinesById.get(s.machine_id)?.machine_code || 'Machine record')} · ${esc(formatTime(s.actual_start_time))} – ${esc(formatTime(s.actual_end_time))}</p></div>${badge(s.session_status)}</div>
      <div class="weight-grid"><div><small>Pre-dialysis weight</small><strong>${esc(s.pre_dialysis_weight ?? '—')} kg</strong></div><div><small>Post-dialysis weight</small><strong>${esc(s.post_dialysis_weight ?? '—')} kg</strong></div></div>
      ${renderKeyValue([
        ['Blood pressure (pre)', s.blood_pressure_pre], ['Blood pressure (post)', s.blood_pressure_post],
        ['Ultrafiltration volume', s.ultrafiltration_volume ? `${s.ultrafiltration_volume} L` : null],
        ['Patient-visible notes', s.patient_visible_notes], ['Released', formatDateTime(s.released_at)]
      ])}
    </article>`).join('')}</div>`;
  }

  container.innerHTML = `${renderSectionHeader({ eyebrow: 'Patient Panel', title: 'My Records', subtitle: 'Medical information, submitted documents and released dialysis history.' })}<div class="panel-stack">${tabs}${tab === 'medical' ? medicalTab() : tab === 'documents' ? documentsTab() : historyTab()}</div>`;
  $$('[data-tab]', container).forEach((button) => button.addEventListener('click', () => api.navigate('my-records', { tab: button.dataset.tab })));
  $('[data-edit-profile]', container)?.addEventListener('click', () => api.openProfile());
  if (tab === 'documents') {
    bindDocumentUploads(container, {
      context: api.context,
      config,
      readiness,
      onUploaded: async () => { await renderMyRecords(container, api); }
    });
    $$('[data-doc-preview]', container).forEach((button) => button.addEventListener('click', async () => {
      const doc = documents.find((d) => d.document_id === button.dataset.docPreview);
      if (doc) await openDocument(doc, 'preview');
    }));
    $$('[data-doc-download]', container).forEach((button) => button.addEventListener('click', async () => {
      const doc = documents.find((d) => d.document_id === button.dataset.docDownload);
      if (doc) await openDocument(doc, 'download');
    }));
  }
}

async function init() {
  const context = await guardRole('patient');
  if (!context.patientId) throw new Error('No active patient record was found for this account.');
  await setupPanel({
    role: 'patient',
    context,
    sidebar: SIDEBAR,
    defaultSection: 'dashboard',
    chatbot: true,
    sections: {
      dashboard: { render: renderDashboard },
      'book-appointment': { render: renderBookAppointment },
      'my-records': { render: renderMyRecords }
    }
  });
  // First visit after sign-up: continue with the personal (if it could not be saved) or medical profile step.
  const onboarding = sessionStorage.getItem(ONBOARDING_KEY);
  sessionStorage.removeItem(ONBOARDING_KEY);
  if (onboarding) openProfileModal(context, { startStep: onboarding === 'personal' ? 1 : 2 });
}

init().catch((error) => {
  const app = $('#app');
  if (app) app.innerHTML = `<div class="state-card state-error" style="margin:2rem"><span class="state-icon">!</span><h3>Unable to open Patient Panel</h3><p>${esc(error.message)}</p><a class="btn btn-primary" href="/public/auth.html?mode=login">Go to Log In</a></div>`;
  console.error(error);
});
