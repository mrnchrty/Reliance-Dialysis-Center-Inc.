// Public landing interactions: responsive nav, active section and static FAQ assistant.
import { $, $$ } from '../core/dom.js';
import { renderChatbot } from '../core/chatbot.js';

const toggle = $('.mobile-nav-toggle');
const links = $('#landing-links');
toggle?.addEventListener('click', () => {
  const open = links.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
links?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  links.classList.remove('open');
  toggle.setAttribute('aria-expanded', 'false');
}));

const sections = ['home', 'about', 'services'];
const observer = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    if (!entry.isIntersecting) continue;
    $$('[data-nav]').forEach((link) => link.classList.toggle('active', link.dataset.nav === entry.target.id));
  }
}, { rootMargin: '-35% 0px -55% 0px' });
for (const id of sections) {
  const section = document.getElementById(id);
  if (section) observer.observe(section);
}

$('#year').textContent = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Manila', year: 'numeric' }).format(new Date());
renderChatbot($('#landing-chatbot'), { compact: false });
