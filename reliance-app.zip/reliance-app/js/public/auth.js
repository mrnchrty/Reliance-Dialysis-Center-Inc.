// Public Supabase Auth: login, patient registration, forgot and reset password.
import { $, $$, esc, inputField, textareaField } from '../core/dom.js';
import { personalSignupFields, readPersonalForm, bindOtherFields, savePersonalProfile } from '../core/forms.js';
import { getSupabase, getSession } from '../core/supabase.js';
import {
  registerPatient, signIn, sendPasswordReset, updatePassword,
  loadRoleContext, redirectByRole, safeRedirectTarget, PANEL_PATHS, completePendingPersonalProfile
} from '../core/auth.js';
import { toast, validateForm, setFormMessage, withButton } from '../core/ui.js';

const root = $('#auth-root');
const params = new URLSearchParams(location.search);
const redirect = params.get('redirect') || '';
const initialMode = params.get('mode') || 'login';
const authError = sessionStorage.getItem('reliance-auth-error');
const ONBOARDING_KEY = 'reliance-onboarding';
let registerPersonal = null;
sessionStorage.removeItem('reliance-auth-error');

function passwordField({ name, label, autocomplete }) {
  return `<div class="form-field">
    <label for="field-${name}">${esc(label)} <span class="required" title="Required">*</span></label>
    <div class="password-wrap">
      <input id="field-${name}" name="${name}" type="password" required autocomplete="${esc(autocomplete)}" minlength="8" placeholder="At least 8 characters" />
      <button type="button" class="password-toggle" data-password-toggle="${name}" aria-label="Show password">Show</button>
    </div>
    <small class="field-error" aria-live="polite"></small>
  </div>`;
}

function bindPasswordToggles(scope = document) {
  $$('[data-password-toggle]', scope).forEach((button) => {
    button.addEventListener('click', () => {
      const input = document.getElementById(`field-${button.dataset.passwordToggle}`);
      if (!input) return;
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      button.textContent = show ? 'Hide' : 'Show';
      button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });
}

function shell({ title, subtitle, body, tabs = '' }) {
  root.innerHTML = `
    <h1>${esc(title)}</h1>
    <p>${esc(subtitle)}</p>
    ${authError ? `<div class="form-message form-message-error">${esc(authError)}</div>` : ''}
    ${params.get('confirmed') === '1' ? '<div class="form-message form-message-success">Email confirmed. You can now log in.</div>' : ''}
    ${tabs}
    ${body}
    <div class="auth-note">Passwords are stored only by Supabase Auth. Application tables never store passwords. Roles are resolved from protected STAFF and PATIENTS records.</div>`;
  bindPasswordToggles(root);
}

function forgotBody() {
  return `<form class="auth-form" id="forgot-form" novalidate>
    ${inputField({ name: 'email', label: 'Email address', type: 'email', required: true, autocomplete: 'email', placeholder: 'name@example.com' })}
    <button class="btn btn-primary" type="submit">Send Reset Link</button>
    <div class="auth-links"><a href="/public/auth.html?mode=login">Back to Log In</a></div>
  </form>`;
}

function resetBody() {
  return `<form class="auth-form" id="reset-form" novalidate>
    ${passwordField({ name: 'password', label: 'New password', autocomplete: 'new-password' })}
    ${passwordField({ name: 'confirm_password', label: 'Confirm new password', autocomplete: 'new-password' })}
    <button class="btn btn-primary" type="submit">Update Password</button>
    <div class="auth-links"><a href="/public/auth.html?mode=login">Back to Log In</a></div>
  </form>`;
}

function loginView() {
  const redirectSuffix = redirect ? `&redirect=${encodeURIComponent(redirect)}` : '';
  root.innerHTML = `
    <h1>Welcome back</h1>
    <p class="auth-sub">Log in to book appointments and view your records.</p>
    ${authError ? `<div class="form-message form-message-error">${esc(authError)}</div>` : ''}
    ${params.get('confirmed') === '1' ? '<div class="form-message form-message-success">Email confirmed. You can now log in.</div>' : ''}
    <form class="auth-form" id="login-form" novalidate>
      <div class="form-field">
        <label for="field-email">Email <span class="required" title="Required">*</span></label>
        <input id="field-email" name="email" type="email" required autocomplete="email" placeholder="you@example.com" />
        <small class="field-error" aria-live="polite"></small>
      </div>
      <div class="form-field">
        <label for="field-password">Password <span class="required" title="Required">*</span></label>
        <div class="password-wrap">
          <input id="field-password" name="password" type="password" required autocomplete="current-password" placeholder="Enter your password" />
          <button type="button" class="password-toggle" data-password-toggle="password" aria-label="Show password">Show</button>
        </div>
        <small class="field-error" aria-live="polite"></small>
      </div>
      <div class="auth-row"><a href="/public/auth.html?mode=forgot">Forgot password?</a></div>
      <button class="btn btn-primary auth-submit" type="submit">Log in</button>
      <p class="auth-alt">No account yet? <a href="/public/auth.html?mode=register${redirectSuffix}">Create one</a></p>
    </form>`;
  bindPasswordToggles(root);
}

async function handleLogin(form) {
  if (!validateForm(form)) return;
  const data = new FormData(form);
  const button = form.querySelector('button[type="submit"]');
  await withButton(button, async () => {
    await signIn({ email: String(data.get('email')), password: String(data.get('password')) });
    const context = await loadRoleContext();
    if (!context?.role) {
      const client = await getSupabase();
      await client.auth.signOut();
      throw new Error('No active patient or staff record was found for this account. Contact the center administrator.');
    }
    const onboarding = await completePendingPersonalProfile(context);
    if (onboarding) sessionStorage.setItem(ONBOARDING_KEY, onboarding);
    toast(`Welcome, ${context.displayName}.`, 'success');
    await redirectByRole(context, redirect);
  }, { label: 'Logging in…', errorPrefix: '' });
}

function registerSteps(active) {
  const items = [
    { n: 1, label: '1. Personal information' },
    { n: 2, label: '2. Account' },
    { n: 3, label: '3. Medical information' }
  ];
  return `<div class="reg-steps" aria-label="Sign-up steps">${items.map(({ n, label }) => {
    if (n === 3) return `<span class="reg-step is-later" title="Completed inside your patient account after sign-up">${label}</span>`;
    const cls = n < active ? 'done' : n === active ? 'active' : '';
    return `<span class="reg-step ${cls}">${label}</span>`;
  }).join('')}</div>`;
}

function registerHeading() {
  return `<h1>Create your account</h1>
    <p class="auth-sub">Complete the steps in order: personal information, account creation, then medical information inside your patient account.</p>`;
}

function registerPersonalView() {
  document.body.classList.add('auth-register');
  const loginHref = `/public/auth.html?mode=login${redirect ? `&redirect=${encodeURIComponent(redirect)}` : ''}`;
  root.innerHTML = `
    ${registerHeading()}
    ${registerSteps(1)}
    <form class="auth-form reg-form" id="register-personal-form" novalidate>
      <p class="reg-step-title">Step 1: Personal information</p>
      ${personalSignupFields(registerPersonal || {})}
      <div class="auth-actions"><button class="btn btn-primary" type="submit">Continue</button></div>
    </form>
    <div class="auth-links"><span>Already registered?</span><a href="${loginHref}">Log in</a></div>`;
  bindOtherFields(root);

  const form = $('#register-personal-form', root);
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!validateForm(form)) return;
    registerPersonal = readPersonalForm(form);
    registerAccountView();
  });
}

function registerAccountView() {
  document.body.classList.add('auth-register');
  root.innerHTML = `
    ${registerHeading()}
    ${registerSteps(2)}
    <form class="auth-form" id="register-form" novalidate>
      <p class="reg-step-title">Step 2: Account <span>Email and password for signing in</span></p>
      ${inputField({ name: 'email', label: 'Email', type: 'email', required: true, autocomplete: 'email', placeholder: 'you@example.com' })}
      ${passwordField({ name: 'password', label: 'Password', autocomplete: 'new-password' })}
      ${passwordField({ name: 'confirm_password', label: 'Confirm password', autocomplete: 'new-password' })}
      <div class="auth-actions">
        <button type="button" class="btn btn-secondary" data-back-personal>Back</button>
        <button class="btn btn-primary" type="submit">Create account</button>
      </div>
    </form>
    <div class="auth-note">Passwords are stored only by Supabase Auth. Application tables never store passwords.</div>`;
  bindPasswordToggles(root);
  $('[data-back-personal]', root).addEventListener('click', () => registerPersonalView());
  $('#register-form', root).addEventListener('submit', (event) => {
    event.preventDefault();
    handleRegister(event.currentTarget).catch((e) => setFormMessage(event.currentTarget, e.message, 'error'));
  });
}

async function handleRegister(form) {
  if (!validateForm(form)) return;
  if (!registerPersonal) { registerPersonalView(); return; }
  const data = new FormData(form);
  if (String(data.get('password')) !== String(data.get('confirm_password'))) {
    setFormMessage(form, 'Passwords do not match.', 'error');
    return;
  }
  const personal = registerPersonal;
  const button = form.querySelector('button[type="submit"]');
  await withButton(button, async () => {
    const result = await registerPatient({
      fullName: personal.full_name,
      email: String(data.get('email')),
      password: String(data.get('password')),
      personal
    });
    if (result.session) {
      const context = await loadRoleContext();
      if (context?.role === 'patient') {
        let onboarding = 'medical';
        try {
          await savePersonalProfile(context, personal);
        } catch {
          onboarding = 'personal';
        }
        sessionStorage.setItem(ONBOARDING_KEY, onboarding);
        registerPersonal = null;
        toast('Account created. Next, complete your medical information.', 'success');
        await redirectByRole(context, redirect || PANEL_PATHS.patient);
        return;
      }
    }
    registerPersonal = null;
    shell({
      title: 'Account created',
      subtitle: 'Your patient account was created through Supabase Auth.',
      body: `<div class="auth-success"><span class="state-icon" aria-hidden="true">✓</span><h2>Check your email</h2><p>If email confirmation is enabled, confirm your account and then log in. After login, you will complete your medical information inside your patient account before booking.</p><a class="btn btn-primary" href="/public/auth.html?mode=login">Go to Log In</a></div>`
    });
  }, { label: 'Creating account…' });
}

async function handleForgot(form) {
  if (!validateForm(form)) return;
  const data = new FormData(form);
  const button = form.querySelector('button[type="submit"]');
  await withButton(button, async () => {
    await sendPasswordReset(String(data.get('email')));
    shell({
      title: 'Reset link sent',
      subtitle: 'Supabase Auth will email a secure password-reset link.',
      body: `<div class="auth-success"><span class="state-icon" aria-hidden="true">✓</span><h2>Check your inbox</h2><p>The reset link returns to this page in reset mode. It does not expose your password.</p><a class="btn btn-primary" href="/public/auth.html?mode=login">Back to Log In</a></div>`
    });
  }, { label: 'Sending…' });
}

async function handleReset(form) {
  if (!validateForm(form)) return;
  const data = new FormData(form);
  if (String(data.get('password')) !== String(data.get('confirm_password'))) {
    setFormMessage(form, 'Passwords do not match.', 'error');
    return;
  }
  const button = form.querySelector('button[type="submit"]');
  await withButton(button, async () => {
    await updatePassword(String(data.get('password')));
    shell({
      title: 'Password updated',
      subtitle: 'Your Supabase Auth password has been changed.',
      body: `<div class="auth-success"><span class="state-icon" aria-hidden="true">✓</span><h2>Password updated</h2><p>You can now log in with your new password.</p><a class="btn btn-primary" href="/public/auth.html?mode=login">Log In</a></div>`
    });
  }, { label: 'Updating…' });
}

async function init() {
  try {
    const session = await getSession();
    if (session && initialMode !== 'reset') {
      const context = await loadRoleContext();
      if (context?.role) {
        await redirectByRole(context, redirect);
        return;
      }
    }

    if (initialMode === 'register') {
      registerPersonalView();
    } else if (initialMode === 'forgot') {
      shell({ title: 'Forgot password', subtitle: 'Enter your account email to receive a secure Supabase Auth reset link.', body: forgotBody() });
      $('#forgot-form').addEventListener('submit', (event) => { event.preventDefault(); handleForgot(event.currentTarget).catch((e) => setFormMessage(event.currentTarget, e.message, 'error')); });
    } else if (initialMode === 'reset') {
      if (!session) {
        shell({ title: 'Reset link unavailable', subtitle: 'This reset link is expired or invalid.', body: `<div class="state-card state-error"><h3>Unable to reset password</h3><p>Request a new reset link from Forgot Password.</p><a class="btn btn-primary" href="/public/auth.html?mode=forgot">Request new link</a></div>` });
        return;
      }
      shell({ title: 'Set new password', subtitle: 'Choose a new password for your Supabase Auth account.', body: resetBody() });
      $('#reset-form').addEventListener('submit', (event) => { event.preventDefault(); handleReset(event.currentTarget).catch((e) => setFormMessage(event.currentTarget, e.message, 'error')); });
    } else {
      loginView();
      $('#login-form').addEventListener('submit', (event) => { event.preventDefault(); handleLogin(event.currentTarget).catch((e) => setFormMessage(event.currentTarget, e.message, 'error')); });
    }
  } catch (error) {
    shell({ title: 'Unable to load sign-in', subtitle: 'Check the runtime Supabase configuration and try again.', body: `<div class="state-card state-error"><h3>Authentication unavailable</h3><p>${esc(error.message)}</p><button class="btn btn-secondary" type="button" onclick="location.reload()">Try again</button></div>` });
  }
}

init();
