// Super Administrator Panel — users, staff roles, system/machine configuration, analytics and audit logs.
// Sensitive account operations use the secure admin-accounts Edge Function or protected RPCs.
import {
  $, $$, esc, formatDate, formatDateTime, shortId, badge,
  manilaTodayISO, addDays, parseISODate, selectField, inputField, textareaField,
  checkboxField, formData
} from '../core/dom.js';
import { getSupabase, rpc, invokeAdminAccounts } from '../core/supabase.js';
import { guardRole } from '../core/auth.js';
import { setupPanel } from '../core/layout.js';
import { slotDisplay, prettyDocumentType, configTimeSlots, WEEKDAY_NAMES } from '../core/forms.js';
import { lineChart, barChart, horizontalBars, donutChart, chartCard } from '../core/charts.js';
import {
  toast, openModal, confirmDialog, renderTable, renderKeyValue, rawHtml,
  renderSectionHeader, renderStatCard, validateForm, setFormMessage, withButton, showLoading, downloadCSV
} from '../core/ui.js';
import { printAnalyticsReport, downloadAnalyticsCSV, downloadAuditCSV, printAuditReport } from '../core/reports.js';

const SIDEBAR = [
  { id: 'dashboard', label: 'Dashboard', icon: '▦' },
  { id: 'user-management', label: 'User Management', icon: '◉' },
  { id: 'staff-management-and-roles', label: 'Staff Management and Roles', icon: '♟' },
  { id: 'system-configuration', label: 'System Configuration', icon: '⚙' },
  { id: 'machine-and-schedule-configuration', label: 'Machine and Schedule Configuration', icon: '▤' },
  { id: 'analytics-and-reports', label: 'Analytics and Reports', icon: '▥' },
  { id: 'audit-logs', label: 'Audit Logs', icon: '▧' }
];

const PERMISSION_LABELS = {
  verify_documents: 'Verify documents',
  manage_appointments: 'Manage appointments',
  manage_machines: 'Manage machines',
  record_sessions: 'Record sessions',
  release_records: 'Release records'
};

async function selectOrThrow(builder) {
  const { data, error } = await builder;
  if (error) throw new Error(error.message);
  return data || [];
}

function roleLabel(role) {
  return role === 'super_admin' ? 'Super Administrator' : role === 'staff' ? 'Staff' : 'Patient';
}

async function loadUsers() {
  try {
    const result = await invokeAdminAccounts('list_users', { page: 1, per_page: 500 });
    return { users: result.users || [], source: 'Supabase Auth via admin-accounts Edge Function' };
  } catch (edgeError) {
    const client = await getSupabase();
    const [patients, staff] = await Promise.all([
      selectOrThrow(client.from('patients').select('patient_id,user_id,email,full_name,contact_number,account_status,created_at').order('full_name')),
      selectOrThrow(client.from('staff').select('staff_id,user_id,email,full_name,position,role,contact_number,account_status,permissions,created_at').order('full_name'))
    ]);
    const map = new Map();
    for (const p of patients) map.set(p.user_id, { user_id: p.user_id, email: p.email, full_name: p.full_name, role: 'patient', account_status: p.account_status, contact_number: p.contact_number, patient_id: p.patient_id, staff_id: null, position: null, permissions: null, registration_date: p.created_at });
    for (const s of staff) {
      const existing = map.get(s.user_id) || {};
      map.set(s.user_id, { ...existing, user_id: s.user_id, email: s.email, full_name: s.full_name, role: s.role, account_status: s.account_status, contact_number: s.contact_number, patient_id: existing.patient_id || null, staff_id: s.staff_id, position: s.position, permissions: s.permissions, registration_date: s.created_at });
    }
    return { users: [...map.values()], source: `Fallback from PATIENTS/STAFF tables (Edge Function unavailable: ${edgeError.message})` };
  }
}

async function openCreateStaffModal(api, reload) {
  const modal = openModal({
    title: 'Create staff account',
    subtitle: 'Creates a Supabase Auth user through the secure Edge Function and a protected STAFF record.',
    content: `<form id="create-staff-form" novalidate><div class="form-grid">
      ${inputField({ name: 'email', label: 'Email address', type: 'email', required: true, autocomplete: 'email' })}
      ${inputField({ name: 'password', label: 'Temporary password', type: 'password', required: true, autocomplete: 'new-password', hint: 'At least 8 characters. Share securely and ask the staff member to change it.' })}
      ${inputField({ name: 'full_name', label: 'Full name', required: true })}
      ${inputField({ name: 'position', label: 'Position', required: true, placeholder: 'e.g. Dialysis Nurse' })}
      ${selectField({ name: 'role', label: 'Protected role', options: [{ value: 'staff', label: 'Staff' }, { value: 'super_admin', label: 'Super Administrator' }], value: 'staff', required: true })}
      ${inputField({ name: 'contact_number', label: 'Contact number', required: false })}
      <div class="form-field span-2"><label>Permissions</label><div class="checkbox-grid">${Object.entries(PERMISSION_LABELS).map(([key, label]) => `<label><input type="checkbox" name="permissions" value="${key}" checked /> <span>${label}</span></label>`).join('')}</div></div>
    </div></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Create staff account', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#create-staff-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          const permissions = Object.fromEntries(Object.keys(PERMISSION_LABELS).map((key) => [key, Array.isArray(data.permissions) ? data.permissions.includes(key) : data.permissions === key]));
          try {
            await invokeAdminAccounts('create_staff', {
              email: String(data.email || '').trim(),
              password: String(data.password || ''),
              full_name: String(data.full_name || '').trim(),
              position: String(data.position || '').trim(),
              role: data.role,
              contact_number: String(data.contact_number || '').trim() || null,
              permissions
            });
            toast('Staff account created. Share the temporary password securely.', 'success');
            apiModal.close();
            await reload();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function openAssignRoleModal(user, api, reload) {
  const modal = openModal({
    title: 'Assign authorized role',
    subtitle: `${user.full_name || user.email} · ${user.email}`,
    content: `<form id="assign-role-form" novalidate><div class="form-grid">
      ${selectField({ name: 'role', label: 'New role', options: [{ value: 'patient', label: 'Patient' }, { value: 'staff', label: 'Staff' }, { value: 'super_admin', label: 'Super Administrator' }], value: user.role, required: true })}
      ${inputField({ name: 'position', label: 'Position (staff roles)', value: user.position || 'Dialysis Nurse', required: false })}
    </div><p class="field-hint">Roles are stored in protected STAFF/PATIENTS records, never in frontend metadata. Self-demotion is prevented.</p></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Assign role', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#assign-role-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          try {
            await invokeAdminAccounts('set_role', { user_id: user.user_id, role: data.role, position: String(data.position || '').trim() || 'Dialysis Nurse' });
            toast('Authorized role updated.', 'success');
            apiModal.close();
            await reload();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function renderDashboard(container, api) {
  showLoading(container, 'Loading administrator dashboard…');
  const stats = await rpc('get_admin_dashboard_stats');
  const analytics = stats.analytics || {};
  const statusCounts = analytics.appointment_status_counts || {};
  const trend = analytics.appointments?.trend || [];
  const byMachine = analytics.machine_utilization?.by_machine || [];
  container.innerHTML = `
    <div class="welcome-banner">
      <div>
        <p class="eyebrow">Super Administrator</p>
        <h1>Welcome, ${esc(api.context.displayName)}</h1>
        <p>System-wide operational overview, machine utilization, and audit logs from live Supabase records.</p>
      </div>
      <div class="section-actions"><button type="button" class="btn btn-primary" data-nav="analytics-and-reports">Analytics and Reports</button><button type="button" class="btn btn-secondary" data-nav="audit-logs">Audit Logs</button></div>
    </div>
    <div class="panel-stack">
      <div class="panel-grid four">
        ${renderStatCard({ label: 'Total patients', value: stats.total_patients ?? 0, note: 'PATIENTS records' })}
        ${renderStatCard({ label: 'Active staff', value: stats.active_staff ?? 0, note: 'STAFF records' })}
        ${renderStatCard({ label: 'Total appointments', value: stats.total_appointments ?? 0, note: 'All appointment records' })}
        ${renderStatCard({ label: 'Completed sessions', value: stats.completed_sessions ?? 0, note: 'DIALYSIS_SESSIONS', tone: 'green' })}
      </div>
      <div class="panel-grid four">
        ${renderStatCard({ label: 'Pending', value: stats.pending ?? 0, note: 'Appointment requests', tone: 'amber' })}
        ${renderStatCard({ label: 'Under Review', value: stats.under_review ?? 0, note: 'Appointment requests', tone: 'red' })}
        ${renderStatCard({ label: 'Confirmed', value: stats.confirmed ?? 0, note: 'Machine assigned', tone: 'green' })}
        ${renderStatCard({ label: 'Rejected', value: stats.rejected ?? 0, note: 'Appointment requests', tone: 'red' })}
      </div>
      <div class="chart-grid">
        ${chartCard({ title: 'Appointment status distribution', subtitle: 'Last 30 days from get_admin_dashboard_stats', body: donutChart({ items: Object.entries(statusCounts).map(([label, value], index) => ({ label, value, color: ['#0a4fa0', '#d62828', '#16875a', '#b7791f'][index % 4] })) }), className: 'span-2' })}
        ${chartCard({ title: 'Appointment trend', subtitle: 'Daily operational requests', body: lineChart({ labels: trend.map((r) => r.period), series: [{ name: 'Total', values: trend.map((r) => r.total), color: '#0a4fa0' }, { name: 'Confirmed', values: trend.map((r) => r.confirmed), color: '#16875a' }] }) })}
        ${chartCard({ title: 'Machine utilization by machine', subtitle: 'Occupied slots in the last 30 days', body: barChart({ labels: byMachine.map((r) => r.machine_code), values: byMachine.map((r) => r.occupied_slots), color: '#0a4fa0' }) })}
      </div>
      <section class="card">
        <div class="card-header"><div><h2>Recent system activity</h2><p>Latest audit-backed events.</p></div></div>
        ${renderTable({
          columns: [
            { label: 'Activity', render: (r) => esc(r.activity) },
            { label: 'Module', render: (r) => esc(r.module) },
            { label: 'Actor', render: (r) => esc(r.actor || 'System') },
            { label: 'Severity', render: (r) => badge(r.severity) },
            { label: 'Time', render: (r) => esc(formatDateTime(r.created_at)) }
          ],
          rows: stats.recent_activities || [],
          emptyTitle: 'No recent activity',
          emptyMessage: 'System actions will appear here.'
        })}
      </section>
    </div>`;
  $$('[data-nav]', container).forEach((button) => button.addEventListener('click', () => api.navigate(button.dataset.nav)));
}

async function renderUserManagement(container, api) {
  showLoading(container, 'Loading users…');
  let loaded = await loadUsers();
  const state = { search: '', role: '', status: '' };
  function filtered() {
    const needle = state.search.trim().toLowerCase();
    return loaded.users.filter((u) => {
      if (state.role && u.role !== state.role) return false;
      if (state.status && u.account_status !== state.status) return false;
      if (!needle) return true;
      return `${u.full_name || ''} ${u.email || ''} ${u.user_id} ${roleLabel(u.role)} ${u.position || ''}`.toLowerCase().includes(needle);
    });
  }
  function render() {
    const rows = filtered();
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'User Management', subtitle: loaded.source, actions: `<button type="button" class="btn btn-primary" data-create-staff>Create staff account</button>` })}
      <div class="panel-stack">
        <section class="card">
          <div class="toolbar">
            <div class="form-field"><label for="user-search">Search</label><input id="user-search" type="search" value="${esc(state.search)}" placeholder="Name, email, user ID or position" /></div>
            <div class="form-field"><label for="user-role">Role</label><select id="user-role"><option value="">All roles</option><option value="patient" ${state.role === 'patient' ? 'selected' : ''}>Patient</option><option value="staff" ${state.role === 'staff' ? 'selected' : ''}>Staff</option><option value="super_admin" ${state.role === 'super_admin' ? 'selected' : ''}>Super Administrator</option></select></div>
            <div class="form-field"><label for="user-status">Status</label><select id="user-status"><option value="">All statuses</option><option value="Active" ${state.status === 'Active' ? 'selected' : ''}>Active</option><option value="Inactive" ${state.status === 'Inactive' ? 'selected' : ''}>Inactive</option></select></div>
          </div>
          ${renderTable({
            columns: [
              { label: 'User', render: (u) => `<strong>${esc(u.full_name || '—')}</strong><small class="field-hint">${esc(u.email || '')}</small>` },
              { label: 'User ID', render: (u) => esc(shortId(u.user_id)) },
              { label: 'Role', render: (u) => badge(roleLabel(u.role)) },
              { label: 'Status', render: (u) => badge(u.account_status) },
              { label: 'Position', render: (u) => esc(u.position || '—') },
              { label: 'Registered', render: (u) => esc(formatDateTime(u.registration_date || u.created_at)) },
              { label: 'Actions', className: 'actions', render: (u) => `<button type="button" class="btn btn-secondary btn-small" data-assign-role="${esc(u.user_id)}">Assign role</button><button type="button" class="btn btn-ghost btn-small" data-set-status="${esc(u.user_id)}">${u.account_status === 'Active' ? 'Deactivate' : 'Activate'}</button>` }
            ],
            rows,
            emptyTitle: 'No users match',
            emptyMessage: 'Adjust role, status or search filters.'
          })}
        </section>
      </div>`;
    $('#user-search', container)?.addEventListener('input', (event) => { state.search = event.target.value; render(); });
    $('#user-role', container)?.addEventListener('change', (event) => { state.role = event.target.value; render(); });
    $('#user-status', container)?.addEventListener('change', (event) => { state.status = event.target.value; render(); });
    $('[data-create-staff]', container)?.addEventListener('click', async () => {
      await openCreateStaffModal(api, async () => { loaded = await loadUsers(); render(); });
    });
    $$('[data-assign-role]', container).forEach((button) => button.addEventListener('click', async () => {
      const user = loaded.users.find((u) => u.user_id === button.dataset.assignRole);
      if (user) await openAssignRoleModal(user, api, async () => { loaded = await loadUsers(); render(); });
    }));
    $$('[data-set-status]', container).forEach((button) => button.addEventListener('click', async () => {
      const user = loaded.users.find((u) => u.user_id === button.dataset.setStatus);
      if (!user) return;
      const next = user.account_status === 'Active' ? 'Inactive' : 'Active';
      const result = await confirmDialog({ title: `${next === 'Active' ? 'Activate' : 'Deactivate'} account?`, message: `${next === 'Active' ? 'Activate' : 'Deactivate'} ${user.full_name || user.email}? This updates protected role records and Supabase Auth ban status.`, confirmLabel: next, danger: next === 'Inactive' });
      if (!result) return;
      try {
        await invokeAdminAccounts('set_status', { user_id: user.user_id, status: next });
        toast(`Account ${next === 'Active' ? 'activated' : 'deactivated'}.`, 'success');
        loaded = await loadUsers();
        render();
      } catch (error) { toast(error.message, 'error'); }
    }));
  }
  render();
}

async function renderStaffManagement(container, api) {
  showLoading(container, 'Loading staff records…');
  const client = await getSupabase();
  let staff = await selectOrThrow(client.from('staff').select('*').order('full_name'));
  const state = { search: '', role: '', status: '' };
  function filtered() {
    const needle = state.search.trim().toLowerCase();
    return staff.filter((s) => {
      if (state.role && s.role !== state.role) return false;
      if (state.status && s.account_status !== state.status) return false;
      if (!needle) return true;
      return `${s.full_name} ${s.email || ''} ${s.position} ${roleLabel(s.role)}`.toLowerCase().includes(needle);
    });
  }
  function permissionSummary(permissions = {}) {
    const enabled = Object.entries(PERMISSION_LABELS).filter(([key]) => permissions?.[key]).map(([, label]) => label);
    return enabled.length ? enabled.join(', ') : 'No permissions enabled';
  }
  function render() {
    const rows = filtered();
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'Staff Management and Roles', subtitle: 'Protected roles and permissions are stored in STAFF, not frontend metadata.' })}
      <div class="panel-stack">
        <section class="card">
          <div class="toolbar">
            <div class="form-field"><label for="staff-search">Search</label><input id="staff-search" type="search" value="${esc(state.search)}" placeholder="Name, email or position" /></div>
            <div class="form-field"><label for="staff-role">Role</label><select id="staff-role"><option value="">All roles</option><option value="staff" ${state.role === 'staff' ? 'selected' : ''}>Staff</option><option value="super_admin" ${state.role === 'super_admin' ? 'selected' : ''}>Super Administrator</option></select></div>
            <div class="form-field"><label for="staff-status">Status</label><select id="staff-status"><option value="">All statuses</option><option value="Active" ${state.status === 'Active' ? 'selected' : ''}>Active</option><option value="Inactive" ${state.status === 'Inactive' ? 'selected' : ''}>Inactive</option></select></div>
          </div>
          ${renderTable({
            columns: [
              { label: 'Staff', render: (s) => `<strong>${esc(s.full_name)}</strong><small class="field-hint">${esc(s.email || '')}</small>` },
              { label: 'Position', render: (s) => esc(s.position) },
              { label: 'Role', render: (s) => badge(roleLabel(s.role)) },
              { label: 'Status', render: (s) => badge(s.account_status) },
              { label: 'Contact', render: (s) => esc(s.contact_number || '—') },
              { label: 'Permissions', render: (s) => esc(permissionSummary(s.permissions)) },
              { label: 'Actions', className: 'actions', render: (s) => `<button type="button" class="btn btn-secondary btn-small" data-edit-staff="${esc(s.staff_id)}">Edit</button>` }
            ],
            rows,
            emptyTitle: 'No staff records match',
            emptyMessage: 'Adjust filters or create a staff account from User Management.'
          })}
        </section>
      </div>`;
    $('#staff-search', container)?.addEventListener('input', (event) => { state.search = event.target.value; render(); });
    $('#staff-role', container)?.addEventListener('change', (event) => { state.role = event.target.value; render(); });
    $('#staff-status', container)?.addEventListener('change', (event) => { state.status = event.target.value; render(); });
    $$('[data-edit-staff]', container).forEach((button) => button.addEventListener('click', async () => {
      const member = staff.find((s) => s.staff_id === button.dataset.editStaff);
      if (!member) return;
      const modal = openModal({
        title: 'Edit staff record',
        subtitle: `${member.full_name} · ${member.email || ''}`,
        content: `<form id="edit-staff-form" novalidate><div class="form-grid">
          ${inputField({ name: 'full_name', label: 'Full name', value: member.full_name, required: true })}
          ${inputField({ name: 'position', label: 'Position', value: member.position, required: true })}
          ${inputField({ name: 'contact_number', label: 'Contact number', value: member.contact_number || '', required: false })}
          ${selectField({ name: 'role', label: 'Protected role', options: [{ value: 'staff', label: 'Staff' }, { value: 'super_admin', label: 'Super Administrator' }], value: member.role, required: true })}
          ${selectField({ name: 'account_status', label: 'Account status', options: ['Active', 'Inactive'], value: member.account_status, required: true })}
          <div class="form-field span-2"><label>Permissions</label><div class="checkbox-grid">${Object.entries(PERMISSION_LABELS).map(([key, label]) => `<label><input type="checkbox" name="permissions" value="${key}" ${member.permissions?.[key] ? 'checked' : ''} /> <span>${label}</span></label>`).join('')}</div></div>
        </div><p class="field-hint">You cannot change your own role, status or privileges.</p></form>`,
        actions: [
          { label: 'Cancel', class: 'btn-secondary' },
          {
            label: 'Save staff record', class: 'btn-primary', close: false,
            onClick: async (apiModal) => {
              const form = $('#edit-staff-form', apiModal.body);
              if (!validateForm(form)) return false;
              const data = formData(form);
              const permissions = Object.fromEntries(Object.keys(PERMISSION_LABELS).map((key) => [key, Array.isArray(data.permissions) ? data.permissions.includes(key) : data.permissions === key]));
              try {
                await invokeAdminAccounts('update_staff', {
                  staff_id: member.staff_id,
                  full_name: String(data.full_name || '').trim(),
                  position: String(data.position || '').trim(),
                  contact_number: String(data.contact_number || '').trim() || null,
                  role: data.role,
                  account_status: data.account_status,
                  permissions
                });
                toast('Staff record updated.', 'success');
                apiModal.close();
                staff = await selectOrThrow(client.from('staff').select('*').order('full_name'));
                render();
              } catch (error) { setFormMessage(form, error.message, 'error'); }
              return false;
            }
          }
        ]
      });
      return modal;
    }));
  }
  render();
}

function slotRow(slot, index) {
  return `<div class="slot-editor" data-slot-index="${index}">
    <h3>Time slot ${index + 1}</h3>
    <div class="form-grid">
      ${inputField({ name: `slot_id_${index}`, label: 'Slot ID', value: slot.id || '', required: true })}
      ${inputField({ name: `slot_label_${index}`, label: 'Label', value: slot.label || slot.id || '', required: true })}
      ${inputField({ name: `slot_display_${index}`, label: 'Display', value: slot.display || '', required: true })}
      ${inputField({ name: `slot_start_${index}`, label: 'Start time', type: 'time', value: slot.start_time || '', required: true })}
      ${inputField({ name: `slot_end_${index}`, label: 'End time', type: 'time', value: slot.end_time || '', required: true })}
    </div>
    <div class="form-actions"><button type="button" class="btn btn-ghost btn-small" data-remove-slot>Remove slot</button></div>
  </div>`;
}

async function renderSystemConfiguration(container, api) {
  showLoading(container, 'Loading system configuration…');
  let config = await rpc('get_system_config');
  let slots = configTimeSlots(config);
  const state = { slotCount: slots.length };

  function render() {
    const days = Array.isArray(config.operating_days) ? config.operating_days.map(Number) : [1, 2, 3, 4, 5, 6];
    const hours = config.operating_hours || { open: '08:00', close: '17:00' };
    const docs = Array.isArray(config.required_document_types) ? config.required_document_types : [];
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'System Configuration', subtitle: 'Operating days, hours, time slots and booking/capacity defaults. Sunday remains closed.' })}
      <form id="system-config-form" novalidate>
        <div class="panel-stack">
          <section class="card">
            <div class="card-header"><div><h2>Operating schedule</h2><p>Configuration is saved as an append-only AUDIT_LOGS snapshot; no extra config table is used.</p></div>${badge(`Version ${config.version || 1}`, 'info')}</div>
            <div class="form-grid">
              <div class="form-field span-2"><label>Operating days <span class="required" title="Required">*</span></label><div class="checkbox-grid">${[1, 2, 3, 4, 5, 6].map((d) => `<label><input type="checkbox" name="operating_days" value="${d}" ${days.includes(d) ? 'checked' : ''} /> <span>${WEEKDAY_NAMES[d]}</span></label>`).join('')}<label><input type="checkbox" disabled /> <span>Sunday (closed)</span></label></div><small class="field-error" aria-live="polite"></small></div>
              ${inputField({ name: 'open_time', label: 'Opening time', type: 'time', value: hours.open || '08:00', required: true })}
              ${inputField({ name: 'close_time', label: 'Closing time', type: 'time', value: hours.close || '17:00', required: true })}
            </div>
          </section>
          <section class="card">
            <div class="card-header"><div><h2>Time slots</h2><p>One patient per machine per time window. Slots must be within operating hours and non-overlapping.</p></div><button type="button" class="btn btn-secondary btn-small" data-add-slot>Add slot</button></div>
            <div class="panel-stack" id="slot-editors">${slots.map((slot, index) => slotRow(slot, index)).join('')}</div>
          </section>
          <section class="card">
            <div class="card-header"><div><h2>Booking and capacity defaults</h2><p>Patients per machine per day must equal the number of configured time slots.</p></div></div>
            <div class="form-grid">
              ${inputField({ name: 'patients_per_machine_per_day', label: 'Patients per machine per day', type: 'number', min: '1', value: config.patients_per_machine_per_day ?? slots.length, required: true })}
              ${inputField({ name: 'min_lead_days', label: 'Minimum lead days', type: 'number', min: '0', value: config.min_lead_days ?? 1, required: true })}
              ${inputField({ name: 'max_advance_days', label: 'Maximum advance days', type: 'number', min: '1', max: '120', value: config.max_advance_days ?? 90, required: true })}
              ${inputField({ name: 'max_open_requests', label: 'Maximum open requests', type: 'number', min: '1', value: config.max_open_requests ?? 6, required: true })}
              ${checkboxField({ name: 'allow_same_day', label: 'Allow same-day booking', checked: Boolean(config.allow_same_day) })}
              ${checkboxField({ name: 'allow_multiple_open_requests', label: 'Allow multiple open requests', checked: config.allow_multiple_open_requests !== false })}
              ${checkboxField({ name: 'require_staff_machine_assignment', label: 'Require staff machine assignment', checked: config.require_staff_machine_assignment !== false })}
              ${checkboxField({ name: 'require_verified_documents_for_confirmation', label: 'Require verified documents for confirmation', checked: config.require_verified_documents_for_confirmation !== false })}
            </div>
          </section>
          <section class="card">
            <div class="card-header"><div><h2>Required document categories</h2><p>These four categories are used by patient uploads and staff verification.</p></div></div>
            <div class="form-grid">${docs.map((doc, index) => inputField({ name: `required_doc_${index}`, label: `Category ${index + 1}`, value: doc, required: true })).join('')}</div>
          </section>
          <div class="form-actions"><button type="button" class="btn btn-secondary" data-reset-config>Reload current config</button><button type="submit" class="btn btn-primary">Save system configuration</button></div>
        </div>
      </form>`;
    $$('[data-remove-slot]', container).forEach((button) => button.addEventListener('click', () => {
      const editor = button.closest('[data-slot-index]');
      if (editor) editor.remove();
      renumberSlots();
    }));
    $('[data-add-slot]', container)?.addEventListener('click', () => {
      const holder = $('#slot-editors', container);
      const index = holder.children.length;
      holder.insertAdjacentHTML('beforeend', slotRow({ id: `Slot${index + 1}`, label: `Slot ${index + 1}`, display: '', start_time: '08:00', end_time: '11:00' }, index));
      renumberSlots();
      $$('[data-remove-slot]', holder).forEach((button) => {
        if (!button.dataset.bound) {
          button.dataset.bound = 'true';
          button.addEventListener('click', () => { button.closest('[data-slot-index]')?.remove(); renumberSlots(); });
        }
      });
    });
    $('[data-reset-config]', container)?.addEventListener('click', async () => { config = await rpc('get_system_config'); slots = configTimeSlots(config); render(); });
    $('#system-config-form', container)?.addEventListener('submit', async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!validateForm(form)) return;
      const data = formData(form);
      const operatingDays = (data.operating_days === undefined ? [] : Array.isArray(data.operating_days) ? data.operating_days : [data.operating_days]).map(Number).sort((a, b) => a - b);
      const nextSlots = $$('[data-slot-index]', container).map((editor, index) => ({
        id: String(data[`slot_id_${index}`] || '').trim(),
        label: String(data[`slot_label_${index}`] || '').trim(),
        display: String(data[`slot_display_${index}`] || '').trim(),
        start_time: data[`slot_start_${index}`],
        end_time: data[`slot_end_${index}`],
        capacity_per_machine: 1
      }));
      const requiredDocs = [0, 1, 2, 3].map((i) => String(data[`required_doc_${i}`] || '').trim()).filter(Boolean);
      const nextConfig = {
        ...config,
        operating_days: operatingDays,
        operating_hours: { open: data.open_time, close: data.close_time },
        time_slots: nextSlots,
        patients_per_machine_per_day: Number(data.patients_per_machine_per_day),
        min_lead_days: Number(data.min_lead_days),
        max_advance_days: Number(data.max_advance_days),
        max_open_requests: Number(data.max_open_requests),
        allow_same_day: Boolean(data.allow_same_day),
        allow_multiple_open_requests: Boolean(data.allow_multiple_open_requests),
        require_staff_machine_assignment: Boolean(data.require_staff_machine_assignment),
        require_verified_documents_for_confirmation: Boolean(data.require_verified_documents_for_confirmation),
        required_document_types: requiredDocs
      };
      const button = form.querySelector('button[type="submit"]');
      await withButton(button, async () => {
        config = await rpc('update_system_config', { p_config: nextConfig });
        slots = configTimeSlots(config);
        toast('System configuration saved and audited.', 'success');
        render();
      }, { label: 'Saving…' });
    });
  }

  function renumberSlots() {
    $$('[data-slot-index]', container).forEach((editor, index) => {
      editor.dataset.slotIndex = String(index);
      editor.querySelector('h3').textContent = `Time slot ${index + 1}`;
      for (const field of editor.querySelectorAll('input')) {
        const name = field.name;
        const suffix = name.replace(/_\d+$/, '');
        field.name = `${suffix}_${index}`;
        field.id = `field-${field.name}`;
        const label = editor.querySelector(`label[for="${CSS.escape(field.id)}"]`) || field.closest('.form-field')?.querySelector('label');
        if (label) label.setAttribute('for', field.id);
      }
    });
  }

  render();
}

async function openAdminMachineModal(machine, api, reload) {
  const modal = openModal({
    title: machine ? 'Edit dialysis machine' : 'Register dialysis machine',
    subtitle: 'Machine records drive generated capacity and staff assignment.',
    content: `<form id="admin-machine-form" novalidate><div class="form-grid">
      ${inputField({ name: 'machine_code', label: 'Machine code', value: machine?.machine_code || '', required: true })}
      ${inputField({ name: 'machine_name', label: 'Machine name', value: machine?.machine_name || '', required: true })}
      ${selectField({ name: 'machine_status', label: 'Machine status', options: ['Available', 'Occupied', 'Maintenance', 'Offline', 'Unavailable'], value: machine?.machine_status || 'Available', required: true })}
      ${inputField({ name: 'daily_capacity', label: 'Daily capacity', type: 'number', min: '1', value: machine?.daily_capacity ?? 3, required: false })}
      ${textareaField({ name: 'description', label: 'Description', value: machine?.description || '', required: false, rows: 3, className: 'span-2' })}
      ${textareaField({ name: 'maintenance_remarks', label: 'Maintenance remarks', value: machine?.maintenance_remarks || '', required: false, rows: 3, className: 'span-2' })}
      ${checkboxField({ name: 'is_active', label: 'Active machine', checked: machine ? Boolean(machine.is_active) : true })}
    </div></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Save machine', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#admin-machine-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          try {
            await rpc('upsert_machine', {
              p_machine_id: machine?.machine_id || null,
              p_machine_code: String(data.machine_code || '').trim(),
              p_machine_name: String(data.machine_name || '').trim(),
              p_machine_status: data.machine_status,
              p_description: String(data.description || '').trim() || null,
              p_maintenance_remarks: String(data.maintenance_remarks || '').trim() || null,
              p_daily_capacity: data.daily_capacity === '' ? null : Number(data.daily_capacity),
              p_is_active: Boolean(data.is_active)
            });
            toast('Machine saved.', 'success');
            apiModal.close();
            await reload();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function renderMachineScheduleConfiguration(container, api) {
  showLoading(container, 'Loading machine and schedule configuration…');
  const client = await getSupabase();
  let config = await rpc('get_system_config');
  let machines = await selectOrThrow(client.from('dialysis_machines').select('*').order('machine_code'));
  const state = { availability: null, start: manilaTodayISO(), end: addDays(manilaTodayISO(), 6) };

  function render() {
    const slots = configTimeSlots(config);
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'Machine and Schedule Configuration', subtitle: 'Machines, generated slots and schedule availability from live Supabase records.', actions: `<button type="button" class="btn btn-primary" data-add-machine>Register machine</button>` })}
      <div class="panel-stack">
        <section class="card"><div class="card-header"><div><h2>Current schedule configuration</h2><p>Operating days, hours and time slots are managed in System Configuration.</p></div><button type="button" class="btn btn-secondary btn-small" data-nav="system-configuration">Open System Configuration</button></div>
          ${renderKeyValue([
            ['Operating days', (config.operating_days || []).map((d) => WEEKDAY_NAMES[d]).join(', ')],
            ['Operating hours', `${config.operating_hours?.open || '08:00'} – ${config.operating_hours?.close || '17:00'}`],
            ['Time slots', slots.map((s) => `${s.id}: ${s.display || s.label}`).join(' · ')],
            ['Patients per machine per day', config.patients_per_machine_per_day],
            ['Version', config.version || 1]
          ])}
        </section>
        <section class="card"><div class="card-header"><div><h2>Generate capacity</h2><p>Creates MACHINE_SLOTS rows for active machines on configured operating days.</p></div></div>
          <form id="capacity-form" novalidate><div class="form-grid">
            ${inputField({ name: 'start_date', label: 'Start date', type: 'date', value: state.start, required: true })}
            ${inputField({ name: 'end_date', label: 'End date', type: 'date', value: state.end, required: true })}
          </div><div class="form-actions"><button type="button" class="btn btn-primary" data-generate-capacity>Generate capacity</button></div></form>
        </section>
        <section class="card"><div class="card-header"><div><h2>Machines</h2><p>Actual machine records drive capacity; no machine count is hardcoded.</p></div></div>
          ${renderTable({
            columns: [
              { label: 'Machine', render: (m) => `<strong>${esc(m.machine_code)}</strong><small class="field-hint">${esc(m.machine_name)}</small>` },
              { label: 'Status', render: (m) => `${badge(m.machine_status)} ${m.is_active ? badge('Active', 'success') : badge('Inactive', 'neutral')}` },
              { label: 'Daily capacity', render: (m) => esc(m.daily_capacity) },
              { label: 'Maintenance remarks', render: (m) => esc(m.maintenance_remarks || '—') },
              { label: 'Actions', className: 'actions', render: (m) => `<button type="button" class="btn btn-secondary btn-small" data-edit-machine="${esc(m.machine_id)}">Edit</button>` }
            ],
            rows: machines,
            emptyTitle: 'No machines registered',
            emptyMessage: 'Register the first dialysis machine.'
          })}
        </section>
        <section class="card"><div class="card-header"><div><h2>Machine availability</h2><p>Live availability from get_machine_availability for the selected range.</p></div></div>
          <form id="availability-form" novalidate><div class="form-grid">
            ${inputField({ name: 'start_date', label: 'Start date', type: 'date', value: state.start, required: true })}
            ${inputField({ name: 'end_date', label: 'End date', type: 'date', value: state.end, required: true })}
          </div><div class="form-actions"><button type="button" class="btn btn-secondary" data-load-availability>Load availability</button></div></form>
          <div id="availability-result" style="margin-top:1rem">${state.availability ? renderTable({
            columns: [
              { label: 'Machine', render: (r) => esc(r.machine_code || r.machine_name || '—') },
              { label: 'Date', render: (r) => esc(formatDate(r.date || r.schedule_date, true)) },
              { label: 'Slot', render: (r) => esc(r.slot_id || r.slot_key || '—') },
              { label: 'Available', render: (r) => esc(r.available ?? r.available_slots ?? '—') },
              { label: 'Total', render: (r) => esc(r.total ?? r.total_slots ?? '—') }
            ],
            rows: state.availability.machines || state.availability.rows || [],
            emptyTitle: 'No availability rows returned',
            emptyMessage: 'Generate capacity for the selected range first.'
          }) : '<div class="empty-inline">Load availability after generating capacity.</div>'}</div>
        </section>
      </div>`;
    $('[data-nav="system-configuration"]', container)?.addEventListener('click', () => api.navigate('system-configuration'));
    $('[data-add-machine]', container)?.addEventListener('click', async () => {
      await openAdminMachineModal(null, api, async () => { machines = await selectOrThrow(client.from('dialysis_machines').select('*').order('machine_code')); render(); });
    });
    $$('[data-edit-machine]', container).forEach((button) => button.addEventListener('click', async () => {
      const machine = machines.find((m) => m.machine_id === button.dataset.editMachine);
      if (machine) await openAdminMachineModal(machine, api, async () => { machines = await selectOrThrow(client.from('dialysis_machines').select('*').order('machine_code')); render(); });
    }));
    $('[data-generate-capacity]', container)?.addEventListener('click', async (event) => {
      const form = $('#capacity-form', container);
      if (!validateForm(form)) return;
      const data = formData(form);
      state.start = data.start_date; state.end = data.end_date;
      await withButton(event.currentTarget, async () => {
        const created = await rpc('ensure_capacity_slots', { p_start_date: data.start_date, p_end_date: data.end_date });
        toast(`Capacity generation complete (${created} new slot rows).`, 'success');
      }, { label: 'Generating…' });
    });
    $('[data-load-availability]', container)?.addEventListener('click', async (event) => {
      const form = $('#availability-form', container);
      if (!validateForm(form)) return;
      const data = formData(form);
      state.start = data.start_date; state.end = data.end_date;
      await withButton(event.currentTarget, async () => {
        state.availability = await rpc('get_machine_availability', { p_start_date: data.start_date, p_end_date: data.end_date });
        render();
      }, { label: 'Loading…' });
    });
  }
  render();
}

async function renderAnalytics(container, api) {
  showLoading(container, 'Loading analytics workspace…');
  const state = { start: addDays(manilaTodayISO(), -29), end: manilaTodayISO(), granularity: 'daily', bundle: null };
  async function load() {
    state.bundle = await rpc('get_analytics_bundle', { p_start_date: state.start, p_end_date: state.end, p_granularity: state.granularity });
  }
  function render() {
    const b = state.bundle;
    if (!b) {
      container.innerHTML = `${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'Analytics and Reports', subtitle: 'Operational analytics only; no clinical conclusions.' })}<div class="state-card state-loading"><span class="spinner"></span><h3>Loading analytics…</h3></div>`;
      return;
    }
    const appointments = b.appointments || {};
    const sessions = b.sessions || {};
    const utilization = b.machine_utilization || {};
    const noShow = b.no_show || {};
    const trend = appointments.trend || [];
    const byMachine = utilization.by_machine || [];
    const statusCounts = b.appointment_status_counts || {};
    const demandSlots = b.demand?.by_slot || [];
    const demandDays = b.demand?.by_day || [];
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'Analytics and Reports', subtitle: 'Operational scheduling and recorded outcomes only.' })}
      <div class="panel-stack">
        <section class="card"><div class="card-header"><div><h2>Measurement period and definitions</h2><p>Asia/Manila. Available slots exclude unavailable/maintenance machines; No-Show uses explicit outcomes only.</p></div></div>
          <form id="analytics-form" novalidate><div class="form-grid">
            ${inputField({ name: 'start_date', label: 'Start date', type: 'date', value: state.start, required: true })}
            ${inputField({ name: 'end_date', label: 'End date', type: 'date', value: state.end, required: true })}
            ${selectField({ name: 'granularity', label: 'Granularity', options: ['daily', 'weekly', 'monthly'], value: state.granularity, required: true })}
          </div><div class="form-actions"><button type="button" class="btn btn-primary" data-load-analytics>Load analytics</button><button type="button" class="btn btn-secondary" data-print-analytics>Print / PDF</button><button type="button" class="btn btn-secondary" data-csv-analytics>Download CSV</button></div></form>
          ${renderKeyValue([
            ['Measurement period', `${formatDate(b.period.start, true)} – ${formatDate(b.period.end, true)}`],
            ['Available slot', b.definition.available_slot], ['Occupied slot', b.definition.occupied_slot],
            ['Utilization formula', b.definition.utilization_formula], ['No-Show formula', b.definition.no_show_formula]
          ])}
        </section>
        <div class="panel-grid four">
          ${renderStatCard({ label: 'Appointments in range', value: appointments.total_in_range ?? 0, note: 'Operational requests' })}
          ${renderStatCard({ label: 'Completed sessions', value: sessions.completed_in_range ?? 0, note: 'Dialysis sessions', tone: 'green' })}
          ${renderStatCard({ label: 'Machine utilization', value: `${utilization.rate ?? 0}%`, note: `${utilization.occupied_slots ?? 0} / ${utilization.total_available_slots ?? 0} slots` })}
          ${renderStatCard({ label: 'No-Show rate', value: `${noShow.rate ?? 0}%`, note: `${noShow.no_show_recorded ?? 0} explicit No-Show`, tone: 'amber' })}
        </div>
        <div class="chart-grid">
          ${chartCard({ title: 'Appointment trend', subtitle: `${b.period.granularity} operational trend`, body: lineChart({ labels: trend.map((r) => r.period), series: [{ name: 'Total', values: trend.map((r) => r.total), color: '#0a4fa0' }, { name: 'Confirmed', values: trend.map((r) => r.confirmed), color: '#16875a' }, { name: 'Pending', values: trend.map((r) => r.pending), color: '#b7791f' }] }) })}
          ${chartCard({ title: 'Machine utilization by machine', subtitle: 'Occupied machine slots', body: barChart({ labels: byMachine.map((r) => r.machine_code), values: byMachine.map((r) => r.occupied_slots), color: '#0a4fa0' }) })}
          ${chartCard({ title: 'Appointment status distribution', subtitle: 'Statuses in selected range', body: donutChart({ items: Object.entries(statusCounts).map(([label, value], index) => ({ label, value, color: ['#0a4fa0', '#d62828', '#16875a', '#b7791f'][index % 4] })) }) })}
          ${chartCard({ title: 'Demand by time slot', subtitle: 'Requested time windows', body: horizontalBars({ items: demandSlots.map((r) => ({ label: slotDisplay({}, r.label), value: r.requests })) }) })}
          ${chartCard({ title: 'Demand by weekday', subtitle: 'Requested dates', body: horizontalBars({ items: demandDays.map((r) => ({ label: r.label, value: r.requests })) }), className: 'span-2' })}
        </div>
      </div>`;
    $('#analytics-form', container)?.addEventListener('submit', (event) => event.preventDefault());
    $('[data-load-analytics]', container)?.addEventListener('click', async (event) => {
      const form = $('#analytics-form', container);
      if (!validateForm(form)) return;
      const data = formData(form);
      state.start = data.start_date; state.end = data.end_date; state.granularity = data.granularity;
      await withButton(event.currentTarget, async () => { await load(); render(); }, { label: 'Loading…' });
    });
    $('[data-print-analytics]', container)?.addEventListener('click', () => printAnalyticsReport(b, { preparedBy: api.context.displayName }));
    $('[data-csv-analytics]', container)?.addEventListener('click', () => downloadAnalyticsCSV(b));
  }
  await load();
  render();
}

async function renderAuditLogs(container, api) {
  showLoading(container, 'Loading audit logs…');
  const client = await getSupabase();
  let rows = await selectOrThrow(client.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(500));
  const state = { search: '', module: '', severity: '', start: '', end: '' };
  function modules() { return [...new Set(rows.map((r) => r.affected_module).filter(Boolean))].sort(); }
  function filtered() {
    const needle = state.search.trim().toLowerCase();
    return rows.filter((r) => {
      if (state.module && r.affected_module !== state.module) return false;
      if (state.severity && r.severity !== state.severity) return false;
      if (state.start && String(r.created_at).slice(0, 10) < state.start) return false;
      if (state.end && String(r.created_at).slice(0, 10) > state.end) return false;
      if (!needle) return true;
      return `${r.activity} ${r.affected_module} ${r.affected_record_id || ''} ${r.actor_name || ''} ${r.actor_email || ''} ${r.actor_role || ''} ${JSON.stringify(r.details || {})}`.toLowerCase().includes(needle);
    });
  }
  function render() {
    const visible = filtered();
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Super Administrator', title: 'Audit Logs', subtitle: 'Comprehensive, filterable and protected. Ordinary users cannot modify audit logs.', actions: `<button type="button" class="btn btn-secondary" data-print-audit>Print / PDF</button><button type="button" class="btn btn-secondary" data-csv-audit>Download CSV</button>` })}
      <div class="panel-stack">
        <section class="card">
          <div class="toolbar">
            <div class="form-field"><label for="audit-search">Search</label><input id="audit-search" type="search" value="${esc(state.search)}" placeholder="Activity, actor, record or details" /></div>
            <div class="form-field"><label for="audit-module">Module</label><select id="audit-module"><option value="">All modules</option>${modules().map((m) => `<option value="${esc(m)}" ${state.module === m ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select></div>
            <div class="form-field"><label for="audit-severity">Severity</label><select id="audit-severity"><option value="">All severities</option>${['Info', 'Warning', 'Error'].map((s) => `<option value="${s}" ${state.severity === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
            <div class="form-field"><label for="audit-start">Start date</label><input id="audit-start" type="date" value="${esc(state.start)}" /></div>
            <div class="form-field"><label for="audit-end">End date</label><input id="audit-end" type="date" value="${esc(state.end)}" /></div>
          </div>
          <p class="muted">${visible.length} of ${rows.length} loaded audit records.</p>
          ${renderTable({
            columns: [
              { label: 'Timestamp', render: (r) => esc(formatDateTime(r.created_at)) },
              { label: 'Activity', render: (r) => esc(r.activity) },
              { label: 'Module', render: (r) => esc(r.affected_module) },
              { label: 'Record', render: (r) => esc(r.affected_record_id || '—') },
              { label: 'Actor', render: (r) => `${esc(r.actor_name || '—')}<small class="field-hint">${esc(r.actor_email || '')} · ${esc(r.actor_role || '')}</small>` },
              { label: 'Severity', render: (r) => badge(r.severity) },
              { label: 'Details', render: (r) => `<div class="audit-detail">${esc(JSON.stringify(r.details || {}))}</div>` }
            ],
            rows: visible,
            emptyTitle: 'No audit logs match',
            emptyMessage: 'Adjust filters or reload the latest audit records.'
          })}
        </section>
      </div>`;
    $('#audit-search', container)?.addEventListener('input', (event) => { state.search = event.target.value; render(); });
    $('#audit-module', container)?.addEventListener('change', (event) => { state.module = event.target.value; render(); });
    $('#audit-severity', container)?.addEventListener('change', (event) => { state.severity = event.target.value; render(); });
    $('#audit-start', container)?.addEventListener('change', (event) => { state.start = event.target.value; render(); });
    $('#audit-end', container)?.addEventListener('change', (event) => { state.end = event.target.value; render(); });
    $('[data-print-audit]', container)?.addEventListener('click', () => printAuditReport(visible, { filters: state, preparedBy: api.context.displayName }));
    $('[data-csv-audit]', container)?.addEventListener('click', () => downloadAuditCSV(visible));
  }
  render();
}

async function init() {
  const context = await guardRole('super_admin');
  if (!context.staffId) throw new Error('No active Super Administrator record was found for this account.');
  await setupPanel({
    role: 'super_admin',
    context,
    sidebar: SIDEBAR,
    defaultSection: 'dashboard',
    chatbot: false,
    sections: {
      dashboard: { render: renderDashboard },
      'user-management': { render: renderUserManagement },
      'staff-management-and-roles': { render: renderStaffManagement },
      'system-configuration': { render: renderSystemConfiguration },
      'machine-and-schedule-configuration': { render: renderMachineScheduleConfiguration },
      'analytics-and-reports': { render: renderAnalytics },
      'audit-logs': { render: renderAuditLogs }
    }
  });
}

init().catch((error) => {
  const app = $('#app');
  if (app) app.innerHTML = `<div class="state-card state-error" style="margin:2rem"><span class="state-icon">!</span><h3>Unable to open Super Administrator Panel</h3><p>${esc(error.message)}</p><a class="btn btn-primary" href="/public/auth.html?mode=login">Go to Log In</a></div>`;
  console.error(error);
});
