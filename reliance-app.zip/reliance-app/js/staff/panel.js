// Staff Panel — Dashboard, Appointment Management, Machine Management and Patient Record.
// Document verification, recurring suggestions, sessions and notifications are integrated here.
import {
  $, $$, esc, formatDate, formatDateTime, formatTime, shortId, badge,
  manilaTodayISO, addDays, parseISODate, selectField, inputField, textareaField,
  checkboxField, formData, createSearchSelect, SELECT_PLACEHOLDER
} from '../core/dom.js';
import { getSupabase, rpc } from '../core/supabase.js';
import { guardRole } from '../core/auth.js';
import { setupPanel } from '../core/layout.js';
import { slotDisplay, prettyDocumentType, configTimeSlots, configOperatingDays, WEEKDAY_NAMES } from '../core/forms.js';
import { renderMonthCalendar, monthDate } from '../core/calendar.js';
import { openDocument, renderDocumentStatus, documentMeta, uploadAuthorizedMedicalFile } from '../core/documents.js';
import {
  toast, openModal, confirmDialog, renderTable, renderKeyValue, renderTimeline,
  rawHtml, renderSectionHeader, renderStatCard, validateForm, setFormMessage, withButton, showLoading
} from '../core/ui.js';
import { printAppointmentReport } from '../core/reports.js';

const SIDEBAR = [
  { id: 'dashboard', label: 'Dashboard', icon: '▦' },
  { id: 'appointment-management', label: 'Appointment Management', icon: '▤' },
  { id: 'machine-management', label: 'Machine Management', icon: '⚙' },
  { id: 'patient-record', label: 'Patient Record', icon: '▧' }
];

async function selectOrThrow(builder) {
  const { data, error } = await builder;
  if (error) throw new Error(error.message);
  return data || [];
}

async function loadOpsData() {
  const client = await getSupabase();
  const [config, patients, appointments, machines] = await Promise.all([
    rpc('get_system_config'),
    selectOrThrow(client.from('patients').select('patient_id,user_id,email,full_name,contact_number,account_status').order('full_name')),
    selectOrThrow(client.from('appointments').select('*').order('created_at', { ascending: false })),
    selectOrThrow(client.from('dialysis_machines').select('*').order('machine_code'))
  ]);
  return {
    config,
    patients,
    patientsById: new Map(patients.map((p) => [p.patient_id, p])),
    appointments,
    machines,
    machinesById: new Map(machines.map((m) => [m.machine_id, m]))
  };
}

function appointmentBadges(appt) {
  const parts = [badge(appt.appointment_status)];
  if (appt.is_cancelled) parts.push(badge('Cancellation processed', 'danger'));
  if (appt.reschedule_requested) parts.push(badge('Reschedule pending', 'warning'));
  if (appt.cancellation_request?.status === 'Pending') parts.push(badge('Cancellation pending', 'warning'));
  if (appt.correction_request?.document_type) parts.push(badge('Correction requested', 'warning'));
  return parts.join(' ');
}

function machineLabel(machine) {
  return `${machine.machine_code} — ${machine.machine_name}`;
}

function eligibleMachines(machines) {
  return machines.filter((m) => m.is_active && ['Available', 'Occupied'].includes(m.machine_status));
}

async function openVerifyDocumentModal(doc, api, reload) {
  const modal = openModal({
    title: 'Verify document',
    subtitle: `${prettyDocumentType(doc.document_type)} · ${doc.file_name}`,
    content: `<form id="verify-doc-form" novalidate><div class="form-grid">
      ${selectField({ name: 'status', label: 'Verification status', options: ['Verified', 'Needs Correction', 'Rejected'], value: 'Verified', required: true })}
      ${textareaField({ name: 'remarks', label: 'Staff remarks', required: false, placeholder: 'Required for Needs Correction or Rejected', rows: 4, className: 'span-2' })}
    </div></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Save verification', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#verify-doc-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          if (data.status !== 'Verified' && !String(data.remarks || '').trim()) {
            setFormMessage(form, 'Remarks are required when requesting correction or rejecting a document.', 'error');
            return false;
          }
          try {
            await rpc('verify_document', { p_document_id: doc.document_id, p_status: data.status, p_remarks: String(data.remarks || '').trim() || null });
            toast('Document verification saved.', 'success');
            apiModal.close();
            await reload();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function openRecordSessionModal(appointment, api, reload) {
  const config = await rpc('get_system_config');
  const today = manilaTodayISO();
  const modal = openModal({
    title: 'Record dialysis session',
    subtitle: `Appointment ${shortId(appointment.appointment_id)} · Session weights are separate from general profile weight.`,
    size: 'large',
    content: `<form id="session-form" novalidate><div class="form-grid">
      ${inputField({ name: 'treatment_date', label: 'Treatment date', type: 'date', value: appointment.confirmed_date || appointment.requested_date || today, required: true })}
      ${inputField({ name: 'start_time', label: 'Actual start time', type: 'time', value: appointment.confirmed_start_time || appointment.requested_start_time || '08:00', required: true })}
      ${inputField({ name: 'end_time', label: 'Actual end time', type: 'time', value: appointment.confirmed_end_time || appointment.requested_end_time || '11:00', required: true })}
      ${inputField({ name: 'pre_weight', label: 'Pre-dialysis weight (kg)', type: 'number', step: '0.01', min: '0', required: false })}
      ${inputField({ name: 'post_weight', label: 'Post-dialysis weight (kg)', type: 'number', step: '0.01', min: '0', required: false })}
      ${inputField({ name: 'bp_pre', label: 'Blood pressure (pre)', required: false, placeholder: 'e.g. 120/80' })}
      ${inputField({ name: 'bp_post', label: 'Blood pressure (post)', required: false, placeholder: 'e.g. 118/78' })}
      ${inputField({ name: 'ultrafiltration', label: 'Ultrafiltration volume (L)', type: 'number', step: '0.01', min: '0', required: false })}
      ${selectField({ name: 'session_status', label: 'Session status', options: ['Completed', 'In Progress', 'Terminated Early'], value: 'Completed', required: true })}
      ${selectField({ name: 'attendance_flag', label: 'Attendance outcome', options: ['Attended', 'No-Show', 'Scheduled'], value: 'Attended', required: true })}
      ${textareaField({ name: 'treatment_notes', label: 'Treatment notes', required: false, rows: 3, className: 'span-2' })}
      ${textareaField({ name: 'patient_visible_notes', label: 'Patient-visible notes', required: false, rows: 3, className: 'span-2' })}
      ${checkboxField({ name: 'is_released', label: 'Release to patient now', checked: false, hint: 'Patients see released sessions only.' })}
      ${textareaField({ name: 'released_remarks', label: 'Release remarks', required: false, rows: 2, className: 'span-2' })}
    </div></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Save session', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#session-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          try {
            await rpc('record_dialysis_session', {
              p_appointment_id: appointment.appointment_id,
              p_treatment_date: data.treatment_date,
              p_start_time: data.start_time,
              p_end_time: data.end_time,
              p_pre_weight: data.pre_weight === '' ? null : Number(data.pre_weight),
              p_post_weight: data.post_weight === '' ? null : Number(data.post_weight),
              p_bp_pre: String(data.bp_pre || '').trim() || null,
              p_bp_post: String(data.bp_post || '').trim() || null,
              p_ultrafiltration: data.ultrafiltration === '' ? null : Number(data.ultrafiltration),
              p_session_status: data.session_status,
              p_treatment_notes: String(data.treatment_notes || '').trim() || null,
              p_patient_visible_notes: String(data.patient_visible_notes || '').trim() || null,
              p_is_released: Boolean(data.is_released),
              p_released_remarks: String(data.released_remarks || '').trim() || null,
              p_attendance_flag: data.attendance_flag
            });
            toast('Dialysis session recorded.', 'success');
            apiModal.close();
            await reload();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function openStaffAppointmentDetail(appointmentId, api, reload) {
  const detail = await rpc('get_appointment_detail', { p_appointment_id: appointmentId });
  const ops = await loadOpsData();
  const a = detail.appointment || {};
  const p = detail.patient || {};
  const m = detail.medical_profile || {};
  const machine = detail.machine || {};
  const config = detail.config || ops.config;
  const slots = configTimeSlots(config);
  const machines = eligibleMachines(ops.machines);
  const correction = a.correction_request || {};
  const reschedule = a.reschedule_request || {};
  const cancellation = a.cancellation_request || {};
  const slotOptions = slots.map((s) => ({ value: s.id, label: s.display || s.label || s.id }));
  const machineOptions = machines.map((mm) => ({ value: mm.machine_id, label: machineLabel(mm) }));

  const content = `
    ${a.is_cancelled ? '<div class="notice notice-danger">Processed cancellation is recorded. Original details and history are preserved.</div>' : ''}
    ${a.reschedule_requested ? `<div class="notice notice-warning">Pending reschedule: ${esc(reschedule.new_date || '')} · ${esc(slotDisplay(config, reschedule.new_time || ''))}${reschedule.reason ? ` · ${esc(reschedule.reason)}` : ''}</div>` : ''}
    ${cancellation?.status === 'Pending' ? `<div class="notice notice-warning">Pending cancellation request: ${esc(cancellation.reason || 'No reason specified')}</div>` : ''}
    <div class="detail-layout">
      <div class="panel-stack">
        <section class="card">
          <div class="card-header"><div><h2>Appointment ${esc(shortId(a.appointment_id))}</h2><p>Complete operational record from Supabase.</p></div>${appointmentBadges(a)}</div>
          ${renderKeyValue([
            ['Patient', p.full_name], ['Email', p.email], ['Contact', p.contact_number],
            ['Requested date', formatDate(a.requested_date, true)], ['Preferred time', slotDisplay(config, a.requested_time)],
            ['Submitted', formatDateTime(a.created_at)], ['Confirmed date', a.confirmed_date ? formatDate(a.confirmed_date, true) : 'Not yet confirmed'],
            ['Confirmed time', a.confirmed_start_time ? `${formatTime(a.confirmed_start_time)} – ${formatTime(a.confirmed_end_time)}` : 'Not yet confirmed'],
            ['Assigned machine', machine.machine_code || a.machine_snapshot?.machine_code || 'Staff assignment pending'],
            ['Staff remarks', a.staff_remarks || 'None recorded'], ['Attendance outcome', a.attendance_flag || 'Scheduled'],
            ['Recurrence group', a.recurrence_group_id ? shortId(a.recurrence_group_id) : '—']
          ])}
        </section>

        <section class="card">
          <div class="card-header"><div><h2>Confirm and assign machine</h2><p>Staff exclusively assigns machines. All current required documents must be verified.</p></div></div>
          <form id="confirm-form" novalidate><div class="form-grid">
            ${selectField({ name: 'machine_id', label: 'Dialysis machine', options: machineOptions, required: true })}
            ${inputField({ name: 'confirmed_date', label: 'Confirmed date', type: 'date', value: a.confirmed_date || a.requested_date, required: true })}
            ${selectField({ name: 'slot_id', label: 'Confirmed time slot', options: slotOptions, value: a.requested_time, required: true })}
            ${textareaField({ name: 'remarks', label: 'Staff remarks', required: false, rows: 2, className: 'span-2' })}
          </div><div class="form-actions"><button type="button" class="btn btn-primary" data-confirm-assign>Confirm & assign machine</button></div></form>
        </section>

        <section class="card">
          <div class="card-header"><div><h2>Status, correction, reschedule and cancellation</h2><p>Main appointment statuses are Pending, Under Review, Confirmed and Rejected only.</p></div></div>
          <form id="status-form" novalidate><div class="form-grid">
            ${selectField({ name: 'status', label: 'Set status', options: ['Pending', 'Under Review', 'Rejected'], required: true })}
            ${textareaField({ name: 'remarks', label: 'Remarks', required: false, placeholder: 'Required when rejecting', rows: 2 })}
          </div><div class="form-actions"><button type="button" class="btn btn-secondary" data-set-status>Apply status</button></div></form>
          <form id="correction-form" novalidate style="margin-top:1rem"><div class="form-grid">
            ${selectField({ name: 'document_type', label: 'Document category', options: slots ? (config.required_document_types || []).map((t) => ({ value: t, label: prettyDocumentType(t) })) : [], required: true })}
            ${textareaField({ name: 'notes', label: 'Correction notes', required: true, rows: 2 })}
          </div><div class="form-actions"><button type="button" class="btn btn-secondary" data-request-correction>Request document correction</button></div></form>
          ${a.reschedule_requested ? `<form id="reschedule-process-form" novalidate style="margin-top:1rem"><div class="form-grid">
            ${selectField({ name: 'action', label: 'Reschedule action', options: [{ value: 'approve', label: 'Approve' }, { value: 'deny', label: 'Deny' }], required: true })}
            ${selectField({ name: 'machine_id', label: 'Machine (required if confirmed)', options: machineOptions, required: false })}
            ${textareaField({ name: 'remarks', label: 'Staff remarks', required: false, rows: 2, className: 'span-2' })}
          </div><div class="form-actions"><button type="button" class="btn btn-secondary" data-process-reschedule>Process reschedule</button></div></form>` : ''}
          ${cancellation?.status === 'Pending' ? `<form id="cancellation-process-form" novalidate style="margin-top:1rem"><div class="form-grid">
            ${selectField({ name: 'action', label: 'Cancellation action', options: [{ value: 'approve', label: 'Approve and release capacity' }, { value: 'deny', label: 'Deny' }], required: true })}
            ${textareaField({ name: 'remarks', label: 'Staff remarks', required: false, rows: 2 })}
          </div><div class="form-actions"><button type="button" class="btn btn-secondary" data-process-cancellation>Process cancellation</button></div></form>` : ''}
        </section>

        <section class="card">
          <div class="card-header"><div><h2>Attendance and dialysis session</h2><p>Attendance outcomes are explicit staff records; no assumption is made from stale status.</p></div></div>
          <form id="attendance-form" novalidate><div class="form-grid">
            ${selectField({ name: 'attendance_flag', label: 'Attendance outcome', options: ['Scheduled', 'Attended', 'No-Show'], value: a.attendance_flag || 'Scheduled', required: true })}
            ${textareaField({ name: 'remarks', label: 'Remarks', required: false, rows: 2 })}
          </div><div class="form-actions"><button type="button" class="btn btn-secondary" data-record-attendance>Record attendance</button><button type="button" class="btn btn-primary" data-record-session>Record dialysis session</button></div></form>
        </section>

        <section class="card">
          <div class="card-header"><div><h2>Integrated document verification</h2><p>Verification status is separate from appointment status and never auto-determines clinical validity.</p></div></div>
          ${renderTable({
            columns: [
              { label: 'Category', render: (d) => esc(prettyDocumentType(d.document_type)) },
              { label: 'File', render: (d) => esc(d.file_name) },
              { label: 'Status', render: (d) => renderDocumentStatus(d) },
              { label: 'Reviewer', render: (d) => esc(d.reviewer_name || '—') },
              { label: 'Actions', render: (d) => `<button type="button" class="btn btn-secondary btn-small" data-doc-preview="${esc(d.document_id)}">Preview</button> <button type="button" class="btn btn-ghost btn-small" data-doc-download="${esc(d.document_id)}">Download</button> <button type="button" class="btn btn-ghost btn-small" data-doc-verify="${esc(d.document_id)}">Verify</button>` }
            ],
            rows: detail.documents || [],
            emptyTitle: 'No documents returned',
            emptyMessage: 'No current documents were returned for this authorized appointment record.'
          })}
        </section>
        <section class="card"><div class="card-header"><div><h2>Status history</h2><p>Preserved appointment history.</p></div></div>${renderTimeline(a.status_history || [])}</section>
      </div>
      <aside class="panel-stack">
        <section class="card"><div class="card-header"><div><h2>Patient information</h2><p>Authorized staff record.</p></div></div>${renderKeyValue([
          ['Patient ID', shortId(p.patient_id)], ['Full name', p.full_name], ['Email', p.email], ['Date of birth', formatDate(p.date_of_birth)],
          ['Sex', p.sex_other || p.sex], ['Contact', p.contact_number], ['Address', p.address]
        ])}</section>
        <section class="card"><div class="card-header"><div><h2>Medical profile</h2><p>Baseline weight is separate from session weights.</p></div></div>${renderKeyValue([
          ['Diagnosis', m.diagnosis], ['Blood type', m.blood_type], ['Allergies', m.allergies], ['Existing conditions', m.existing_medical_conditions],
          ['Current medications', m.current_medications], ['Attending nephrologist', m.attending_nephrologist], ['Prescribed frequency', m.prescribed_dialysis_frequency],
          ['Baseline weight', m.weight ? `${m.weight} kg` : null], ['Recurring days', Array.isArray(m.recurring_days) ? m.recurring_days.join(', ') : null], ['Preferred time', m.preferred_time ? slotDisplay(config, m.preferred_time) : null]
        ])}</section>
      </aside>
    </div>`;

  const modal = openModal({
    title: `Appointment ${shortId(a.appointment_id)}`,
    subtitle: 'Staff operational record',
    size: 'large',
    content,
    actions: [
      { label: 'Close', class: 'btn-secondary' },
      { label: 'Print / PDF', class: 'btn-secondary', close: false, onClick: async () => { printAppointmentReport(detail, { preparedBy: api.context.displayName }); return false; } }
    ]
  });

  const reloadAndClose = async () => { modal.close(); await reload(); };
  $('[data-confirm-assign]', modal.body)?.addEventListener('click', async (event) => {
    const form = $('#confirm-form', modal.body);
    if (!validateForm(form)) return;
    const data = formData(form);
    const slot = slots.find((s) => s.id === data.slot_id);
    if (!slot) { setFormMessage(form, 'Select a configured time slot.', 'error'); return; }
    await withButton(event.currentTarget, async () => {
      await rpc('assign_machine_and_confirm_appointment', {
        p_appointment_id: a.appointment_id,
        p_machine_id: data.machine_id,
        p_confirmed_date: data.confirmed_date,
        p_start_time: slot.start_time,
        p_end_time: slot.end_time,
        p_remarks: String(data.remarks || '').trim() || null,
        p_slot_id: slot.id
      });
      toast('Appointment confirmed and machine assigned.', 'success');
      await reloadAndClose();
    }, { label: 'Confirming…' });
  });
  $('[data-set-status]', modal.body)?.addEventListener('click', async (event) => {
    const form = $('#status-form', modal.body);
    if (!validateForm(form)) return;
    const data = formData(form);
    if (data.status === 'Rejected' && !String(data.remarks || '').trim()) { setFormMessage(form, 'A reason is required when rejecting an appointment.', 'error'); return; }
    await withButton(event.currentTarget, async () => {
      await rpc('set_appointment_status', { p_appointment_id: a.appointment_id, p_status: data.status, p_remarks: String(data.remarks || '').trim() || null });
      toast('Appointment status updated.', 'success');
      await reloadAndClose();
    }, { label: 'Saving…' });
  });
  $('[data-request-correction]', modal.body)?.addEventListener('click', async (event) => {
    const form = $('#correction-form', modal.body);
    if (!validateForm(form)) return;
    const data = formData(form);
    await withButton(event.currentTarget, async () => {
      await rpc('request_document_correction', { p_appointment_id: a.appointment_id, p_document_type: data.document_type, p_notes: String(data.notes || '').trim() });
      toast('Document correction requested. Appointment remains Under Review.', 'success');
      await reloadAndClose();
    }, { label: 'Requesting…' });
  });
  $('[data-process-reschedule]', modal.body)?.addEventListener('click', async (event) => {
    const form = $('#reschedule-process-form', modal.body);
    if (!validateForm(form)) return;
    const data = formData(form);
    if (data.action === 'approve' && a.appointment_status === 'Confirmed' && !data.machine_id) { setFormMessage(form, 'Select an available machine before approving a reschedule for a confirmed appointment.', 'error'); return; }
    await withButton(event.currentTarget, async () => {
      await rpc('process_reschedule_request', {
        p_appointment_id: a.appointment_id,
        p_action: data.action,
        p_machine_id: data.machine_id || null,
        p_remarks: String(data.remarks || '').trim() || null
      });
      toast('Reschedule request processed.', 'success');
      await reloadAndClose();
    }, { label: 'Processing…' });
  });
  $('[data-process-cancellation]', modal.body)?.addEventListener('click', async (event) => {
    const form = $('#cancellation-process-form', modal.body);
    if (!validateForm(form)) return;
    const data = formData(form);
    await withButton(event.currentTarget, async () => {
      await rpc('process_cancellation_request', { p_appointment_id: a.appointment_id, p_action: data.action, p_remarks: String(data.remarks || '').trim() || null });
      toast('Cancellation request processed.', 'success');
      await reloadAndClose();
    }, { label: 'Processing…' });
  });
  $('[data-record-attendance]', modal.body)?.addEventListener('click', async (event) => {
    const form = $('#attendance-form', modal.body);
    if (!validateForm(form)) return;
    const data = formData(form);
    await withButton(event.currentTarget, async () => {
      await rpc('record_appointment_attendance', { p_appointment_id: a.appointment_id, p_attendance_flag: data.attendance_flag, p_remarks: String(data.remarks || '').trim() || null });
      toast('Attendance outcome recorded.', 'success');
      await reloadAndClose();
    }, { label: 'Recording…' });
  });
  $('[data-record-session]', modal.body)?.addEventListener('click', async () => { await openRecordSessionModal(a, api, reload); });
  $$('[data-doc-preview]', modal.body).forEach((button) => button.addEventListener('click', async () => {
    const doc = (detail.documents || []).find((d) => d.document_id === button.dataset.docPreview);
    if (doc) await openDocument(doc, 'preview');
  }));
  $$('[data-doc-download]', modal.body).forEach((button) => button.addEventListener('click', async () => {
    const doc = (detail.documents || []).find((d) => d.document_id === button.dataset.docDownload);
    if (doc) await openDocument(doc, 'download');
  }));
  $$('[data-doc-verify]', modal.body).forEach((button) => button.addEventListener('click', async () => {
    const doc = (detail.documents || []).find((d) => d.document_id === button.dataset.docVerify);
    if (doc) await openVerifyDocumentModal(doc, api, reload);
  }));
  return modal;
}

async function renderDashboard(container, api) {
  showLoading(container, 'Loading staff dashboard…');
  const stats = await rpc('get_staff_dashboard_stats');
  const recent = Array.isArray(stats.recent_activities) ? stats.recent_activities : [];
  container.innerHTML = `
    <div class="welcome-banner">
      <div>
        <p class="eyebrow">Staff Panel</p>
        <h1>Good day, ${esc(api.context.displayName)}</h1>
        <p>Operational queues, document verification, and machine capacity from live Supabase records.</p>
      </div>
      <div class="section-actions"><button type="button" class="btn btn-primary" data-nav="appointment-management">Appointment Management</button><button type="button" class="btn btn-secondary" data-nav="machine-management">Machine Management</button></div>
    </div>
    <div class="panel-stack">
      <div class="panel-grid four">
        ${renderStatCard({ label: 'Today appointments', value: stats.todays_appointments ?? 0, note: `Manila date ${stats.today || ''}` })}
        ${renderStatCard({ label: 'New requests', value: stats.new_requests ?? 0, note: 'Pending appointments', tone: 'amber' })}
        ${renderStatCard({ label: 'Under Review', value: stats.under_review ?? 0, note: 'Document or schedule review', tone: 'red' })}
        ${renderStatCard({ label: 'Confirmed', value: stats.confirmed ?? 0, note: 'Machine assigned', tone: 'green' })}
      </div>
      <div class="panel-grid four">
        ${renderStatCard({ label: 'Available machines', value: stats.available_machines ?? 0, note: 'Active and eligible' })}
        ${renderStatCard({ label: 'Occupied machines', value: stats.occupied_machines ?? 0, note: 'Current machine status' })}
        ${renderStatCard({ label: 'Documents awaiting verification', value: stats.documents_awaiting_verification ?? 0, note: 'Pending or Needs Correction', tone: 'amber' })}
        ${renderStatCard({ label: 'Completed sessions today', value: stats.completed_sessions_today ?? 0, note: 'Dialysis sessions', tone: 'green' })}
      </div>
      <section class="card">
        <div class="card-header"><div><h2>Recent operational activity</h2><p>Audit-backed activity from Supabase.</p></div></div>
        ${renderTable({
          columns: [
            { label: 'Activity', render: (r) => esc(r.activity) },
            { label: 'Module', render: (r) => esc(r.module) },
            { label: 'Record', render: (r) => esc(r.record_id || '—') },
            { label: 'Actor', render: (r) => esc(r.actor || 'System') },
            { label: 'Time', render: (r) => esc(formatDateTime(r.created_at)) }
          ],
          rows: recent,
          emptyTitle: 'No recent activity',
          emptyMessage: 'Operational actions will appear here after staff processes records.'
        })}
      </section>
    </div>`;
  $$('[data-nav]', container).forEach((button) => button.addEventListener('click', () => api.navigate(button.dataset.nav)));
}

async function renderAppointmentManagement(container, api) {
  showLoading(container, 'Loading appointment management…');
  let ops = await loadOpsData();
  const state = {
    month: monthDate(parseISODate(manilaTodayISO()).getUTCFullYear(), parseISODate(manilaTodayISO()).getUTCMonth()),
    selectedDate: '',
    search: '',
    status: '',
    rescheduleOnly: false,
    cancellationOnly: false
  };

  function filteredAppointments() {
    const needle = state.search.trim().toLowerCase();
    return ops.appointments.filter((a) => {
      const patient = ops.patientsById.get(a.patient_id) || {};
      if (state.selectedDate && String(a.requested_date).slice(0, 10) !== state.selectedDate) return false;
      if (state.status && a.appointment_status !== state.status) return false;
      if (state.rescheduleOnly && !a.reschedule_requested) return false;
      if (state.cancellationOnly && a.cancellation_request?.status !== 'Pending') return false;
      if (!needle) return true;
      const haystack = `${a.appointment_id} ${patient.full_name || ''} ${patient.email || ''} ${a.appointment_status} ${a.requested_date} ${a.requested_time}`.toLowerCase();
      return haystack.includes(needle);
    });
  }

  function eventsByDate() {
    const map = {};
    for (const a of ops.appointments) {
      const date = String(a.requested_date || '').slice(0, 10);
      if (date) map[date] = (map[date] || 0) + 1;
    }
    return map;
  }

  function recurringForm() {
    const days = configOperatingDays(ops.config);
    const slots = configTimeSlots(ops.config);
    return `<section class="card">
      <div class="card-header"><div><h2>Recurring appointment suggestions</h2><p>Uses PATIENT_MEDICAL_PROFILES recurring_days and preferred_time. Staff review only; generated records are Pending appointments.</p></div></div>
      <form id="recurring-form" novalidate><div class="form-grid">
        <div class="form-field span-2"><label>Patient <span class="required" title="Required">*</span></label><div id="recurring-patient-select"></div><small class="field-error" aria-live="polite"></small></div>
        <div class="form-field span-2"><label>Recurring days <span class="required" title="Required">*</span></label><div class="checkbox-grid">${days.map((d) => `<label><input type="checkbox" name="recurring_days" value="${esc(WEEKDAY_NAMES[d])}" /> <span>${esc(WEEKDAY_NAMES[d])}</span></label>`).join('')}</div><small class="field-error" aria-live="polite"></small></div>
        ${selectField({ name: 'preferred_time', label: 'Preferred time', options: slots.map((s) => ({ value: s.id, label: s.display || s.label || s.id })), required: true })}
        ${inputField({ name: 'start_date', label: 'Start date', type: 'date', value: manilaTodayISO(), required: true, min: manilaTodayISO() })}
        ${inputField({ name: 'end_date', label: 'End date', type: 'date', value: addDays(manilaTodayISO(), 30), required: true })}
      </div><div class="form-actions"><button type="button" class="btn btn-primary" data-generate-recurring>Generate suggestions</button></div></form>
    </section>`;
  }

  function render() {
    const rows = filteredAppointments();
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Staff Panel', title: 'Appointment Management', subtitle: 'Monthly calendar, request list, document verification, rescheduling, cancellation, recurring suggestions and printable records.' })}
      <div class="panel-stack">
        <section class="card"><div class="card-header"><div><h2>Monthly appointment calendar</h2><p>Counts are live APPOINTMENTS records by requested date.</p></div></div><div id="staff-calendar"></div></section>
        <section class="card">
          <div class="card-header"><div><h2>Appointment requests</h2><p>${rows.length} record${rows.length === 1 ? '' : 's'} after filters.</p></div><button type="button" class="btn btn-secondary btn-small" data-clear-filters>Clear filters</button></div>
          <div class="toolbar">
            <div class="form-field"><label for="appt-search">Search</label><input id="appt-search" type="search" value="${esc(state.search)}" placeholder="Patient, email, ID, date or status" /></div>
            <div class="form-field"><label for="appt-status">Status</label><select id="appt-status"><option value="">All statuses</option>${['Pending', 'Under Review', 'Confirmed', 'Rejected'].map((s) => `<option value="${s}" ${state.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
            <div class="form-field"><label for="appt-date">Requested date</label><input id="appt-date" type="date" value="${esc(state.selectedDate)}" /></div>
            <label class="checkbox-field"><input type="checkbox" id="appt-reschedule" ${state.rescheduleOnly ? 'checked' : ''} /><span>Reschedule pending</span></label>
            <label class="checkbox-field"><input type="checkbox" id="appt-cancellation" ${state.cancellationOnly ? 'checked' : ''} /><span>Cancellation pending</span></label>
          </div>
          ${renderTable({
            columns: [
              { label: 'Appointment', render: (a) => `<strong>${esc(shortId(a.appointment_id))}</strong><small class="field-hint">${esc(formatDateTime(a.created_at))}</small>` },
              { label: 'Patient', render: (a) => { const p = ops.patientsById.get(a.patient_id) || {}; return `${esc(p.full_name || '—')}<small class="field-hint">${esc(p.email || '')}</small>`; } },
              { label: 'Requested', render: (a) => `${esc(formatDate(a.requested_date, true))}<small class="field-hint">${esc(slotDisplay(ops.config, a.requested_time))}</small>` },
              { label: 'Confirmed', render: (a) => a.confirmed_date ? `${esc(formatDate(a.confirmed_date, true))}<small class="field-hint">${esc(formatTime(a.confirmed_start_time))} – ${esc(formatTime(a.confirmed_end_time))}</small>` : 'Not confirmed' },
              { label: 'Status', render: (a) => appointmentBadges(a) },
              { label: 'Actions', className: 'actions', render: (a) => `<button type="button" class="btn btn-secondary btn-small" data-view="${esc(a.appointment_id)}">View</button><button type="button" class="btn btn-ghost btn-small" data-print="${esc(a.appointment_id)}">Print</button>` }
            ],
            rows,
            emptyTitle: 'No appointment requests match',
            emptyMessage: 'Adjust the calendar date, status, search or pending-request filters.'
          })}
        </section>
        ${recurringForm()}
      </div>`;

    renderMonthCalendar({
      container: $('#staff-calendar', container),
      monthDate: state.month,
      eventsByDate: eventsByDate(),
      selectedDate: state.selectedDate,
      onSelect: (date) => { state.selectedDate = state.selectedDate === date ? '' : date; render(); },
      onMonthChange: (nextMonth) => { state.month = nextMonth; render(); }
    });

    $('#appt-search', container)?.addEventListener('input', (event) => { state.search = event.target.value; render(); });
    $('#appt-status', container)?.addEventListener('change', (event) => { state.status = event.target.value; render(); });
    $('#appt-date', container)?.addEventListener('change', (event) => { state.selectedDate = event.target.value; render(); });
    $('#appt-reschedule', container)?.addEventListener('change', (event) => { state.rescheduleOnly = event.target.checked; render(); });
    $('#appt-cancellation', container)?.addEventListener('change', (event) => { state.cancellationOnly = event.target.checked; render(); });
    $('[data-clear-filters]', container)?.addEventListener('click', () => {
      Object.assign(state, { selectedDate: '', search: '', status: '', rescheduleOnly: false, cancellationOnly: false });
      render();
    });
    $$('[data-view]', container).forEach((button) => button.addEventListener('click', async () => {
      try { await openStaffAppointmentDetail(button.dataset.view, api, async () => { ops = await loadOpsData(); render(); }); } catch (error) { toast(error.message, 'error'); }
    }));
    $$('[data-print]', container).forEach((button) => button.addEventListener('click', async () => {
      try {
        const detail = await rpc('get_appointment_detail', { p_appointment_id: button.dataset.print });
        printAppointmentReport(detail, { preparedBy: api.context.displayName });
      } catch (error) { toast(error.message, 'error'); }
    }));

    const patientSelect = createSearchSelect({
      items: ops.patients.map((p) => ({ value: p.patient_id, label: p.full_name, meta: `${p.email || ''} · ${shortId(p.patient_id)}` })),
      name: 'patient_id', label: '', placeholder: 'Search patient name or email…', required: true
    });
    $('#recurring-patient-select', container)?.append(patientSelect);
    $('[data-generate-recurring]', container)?.addEventListener('click', async (event) => {
      const form = $('#recurring-form', container);
      const patientId = patientSelect.getValue();
      if (!patientId || !patientSelect.validate()) { toast('Select a patient for recurring suggestions.', 'error'); return; }
      const data = formData(form);
      const days = data.recurring_days === undefined ? [] : Array.isArray(data.recurring_days) ? data.recurring_days : [data.recurring_days];
      if (!days.length) { toast('Select at least one recurring day.', 'error'); return; }
      await withButton(event.currentTarget, async () => {
        const result = await rpc('generate_recurring_appointments', {
          p_patient_id: patientId,
          p_recurring_days: days,
          p_preferred_time: data.preferred_time,
          p_start_date: data.start_date,
          p_end_date: data.end_date
        });
        const generated = Array.isArray(result.generated) ? result.generated.length : 0;
        const skipped = Array.isArray(result.skipped) ? result.skipped.length : 0;
        toast(`Generated ${generated} Pending recurring request(s); skipped ${skipped}.`, 'success');
        ops = await loadOpsData();
        render();
      }, { label: 'Generating…' });
    });
  }

  render();
  const focusId = api.params.get('appointment_id');
  if (focusId) {
    setTimeout(async () => {
      try { await openStaffAppointmentDetail(focusId, api, async () => { ops = await loadOpsData(); render(); }); } catch (error) { toast(error.message, 'error'); }
    }, 150);
  }
}

async function openMachineModal(machine, api, reload) {
  const isEdit = Boolean(machine?.machine_id);
  const modal = openModal({
    title: isEdit ? 'Edit dialysis machine' : 'Register dialysis machine',
    subtitle: 'Machine records drive capacity. Duplicate codes and unavailable assignments are prevented by database safeguards.',
    content: `<form id="machine-form" novalidate><div class="form-grid">
      ${inputField({ name: 'machine_code', label: 'Machine code', value: machine?.machine_code || '', required: true, placeholder: 'e.g. HD-01' })}
      ${inputField({ name: 'machine_name', label: 'Machine name', value: machine?.machine_name || '', required: true, placeholder: 'e.g. Dialysis Machine 1' })}
      ${selectField({ name: 'machine_status', label: 'Machine status', options: ['Available', 'Occupied', 'Maintenance', 'Offline', 'Unavailable'], value: machine?.machine_status || 'Available', required: true })}
      ${inputField({ name: 'daily_capacity', label: 'Daily capacity', type: 'number', min: '1', value: machine?.daily_capacity ?? 3, required: false })}
      ${textareaField({ name: 'description', label: 'Description', value: machine?.description || '', required: false, rows: 3, className: 'span-2' })}
      ${textareaField({ name: 'maintenance_remarks', label: 'Maintenance remarks', value: machine?.maintenance_remarks || '', required: false, rows: 3, className: 'span-2' })}
      ${checkboxField({ name: 'is_active', label: 'Active machine', checked: machine ? Boolean(machine.is_active) : true })}
    </div></form>`,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: isEdit ? 'Save machine' : 'Register machine', class: 'btn-primary', close: false,
        onClick: async (apiModal) => {
          const form = $('#machine-form', apiModal.body);
          if (!validateForm(form)) return false;
          const data = formData(form);
          try {
            await rpc('upsert_machine', {
              p_machine_id: machine?.machine_id || null,
              p_machine_code: String(data.machine_code || '').trim(),
              p_machine_name: String(data.machine_name || '').trim(),
              p_machine_status: data.machine_status,
              p_description: String(data.description || '').trim() || null,
              p_maintenance_remarks: String(data.maintenance_remarks || '').trim() || null,
              p_daily_capacity: data.daily_capacity === '' ? null : Number(data.daily_capacity),
              p_is_active: Boolean(data.is_active)
            });
            toast('Machine saved.', 'success');
            apiModal.close();
            await reload();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
          return false;
        }
      }
    ]
  });
  return modal;
}

async function openMachineSlotsModal(machine, api) {
  const client = await getSupabase();
  const today = manilaTodayISO();
  const modal = openModal({
    title: `${machine.machine_code} slots`,
    subtitle: 'Live MACHINE_SLOTS rows for the selected date.',
    content: `<div class="form-grid"><div class="form-field"><label for="slot-date">Schedule date</label><input id="slot-date" type="date" value="${today}" /></div></div><div id="slot-list" style="margin-top:1rem"></div>`,
    actions: [{ label: 'Close', class: 'btn-secondary' }]
  });
  async function loadSlots() {
    const date = $('#slot-date', modal.body).value || today;
    const holder = $('#slot-list', modal.body);
    holder.innerHTML = '<div class="state-card state-loading"><span class="spinner"></span><h3>Loading slots…</h3></div>';
    try {
      await rpc('ensure_capacity_slots', { p_start_date: date, p_end_date: date });
      const { data, error } = await client.from('machine_slots').select('*').eq('machine_id', machine.machine_id).eq('schedule_date', date).order('start_time');
      if (error) throw new Error(error.message);
      holder.innerHTML = renderTable({
        columns: [
          { label: 'Time', render: (s) => `${esc(formatTime(s.start_time))} – ${esc(formatTime(s.end_time))}` },
          { label: 'Slot', render: (s) => esc(s.slot_key) },
          { label: 'Status', render: (s) => badge(s.slot_status) },
          { label: 'Appointment', render: (s) => s.appointment_id ? shortId(s.appointment_id) : '—' },
          { label: 'Source', render: (s) => esc(s.capacity_source || 'Generated') }
        ],
        rows: data || [],
        emptyTitle: 'No slots for this date',
        emptyMessage: 'Capacity is generated for configured operating days and active machines.'
      });
    } catch (error) {
      holder.innerHTML = `<div class="state-card state-error"><h3>Unable to load slots</h3><p>${esc(error.message)}</p></div>`;
    }
  }
  $('#slot-date', modal.body).addEventListener('change', loadSlots);
  await loadSlots();
  return modal;
}

async function renderMachineManagement(container, api) {
  showLoading(container, 'Loading machines…');
  let machines = await selectOrThrow((await getSupabase()).from('dialysis_machines').select('*').order('machine_code'));
  const state = { search: '', status: '', active: '' };
  function filtered() {
    const needle = state.search.trim().toLowerCase();
    return machines.filter((m) => {
      if (state.status && m.machine_status !== state.status) return false;
      if (state.active && String(m.is_active) !== state.active) return false;
      if (!needle) return true;
      return `${m.machine_code} ${m.machine_name} ${m.machine_status} ${m.description || ''}`.toLowerCase().includes(needle);
    });
  }
  function render() {
    const rows = filtered();
    const tileTone = (m) => !m.is_active || ['Offline', 'Unavailable'].includes(m.machine_status) ? 'is-unavailable' : m.machine_status === 'Maintenance' ? 'is-maintenance' : m.machine_status === 'Occupied' ? 'is-occupied' : '';
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Staff Panel', title: 'Machine Management', subtitle: 'DIALYSIS_MACHINES and MACHINE_SLOTS drive real capacity. Staff assigns machines; patients never do.', actions: `<button type="button" class="btn btn-primary" data-add-machine>Register machine</button>` })}
      <div class="panel-stack">
        ${rows.length ? `<div class="machine-grid">${rows.map((m) => `<article class="machine-tile ${tileTone(m)}"><div><strong>${esc(m.machine_code)}</strong><small>${esc(m.machine_name)}</small></div><div class="machine-meta">${badge(m.machine_status)} ${m.is_active ? badge('Active', 'success') : badge('Inactive', 'neutral')}</div><small>${esc(m.daily_capacity)} slots/day</small><div class="inline-actions"><button type="button" class="btn btn-secondary btn-small" data-view-slots="${esc(m.machine_id)}">Slots</button><button type="button" class="btn btn-ghost btn-small" data-edit-machine="${esc(m.machine_id)}">Edit</button></div></article>`).join('')}</div>` : ''}
        <section class="card">
          <div class="toolbar">
            <div class="form-field"><label for="machine-search">Search</label><input id="machine-search" type="search" value="${esc(state.search)}" placeholder="Code, name, status or description" /></div>
            <div class="form-field"><label for="machine-status">Status</label><select id="machine-status"><option value="">All statuses</option>${['Available', 'Occupied', 'Maintenance', 'Offline', 'Unavailable'].map((s) => `<option value="${s}" ${state.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
            <div class="form-field"><label for="machine-active">Active</label><select id="machine-active"><option value="">All</option><option value="true" ${state.active === 'true' ? 'selected' : ''}>Active</option><option value="false" ${state.active === 'false' ? 'selected' : ''}>Inactive</option></select></div>
          </div>
          ${renderTable({
            columns: [
              { label: 'Machine', render: (m) => `<strong>${esc(m.machine_code)}</strong><small class="field-hint">${esc(m.machine_name)}</small>` },
              { label: 'Status', render: (m) => `${badge(m.machine_status)} ${m.is_active ? badge('Active', 'success') : badge('Inactive', 'neutral')}` },
              { label: 'Daily capacity', render: (m) => esc(m.daily_capacity) },
              { label: 'Description', render: (m) => esc(m.description || '—') },
              { label: 'Maintenance remarks', render: (m) => esc(m.maintenance_remarks || '—') },
              { label: 'Last service', render: (m) => esc(formatDate(m.last_service_date)) },
              { label: 'Actions', className: 'actions', render: (m) => `<button type="button" class="btn btn-secondary btn-small" data-view-slots="${esc(m.machine_id)}">View slots</button><button type="button" class="btn btn-ghost btn-small" data-edit-machine="${esc(m.machine_id)}">Edit</button>` }
            ],
            rows,
            emptyTitle: 'No machines match',
            emptyMessage: 'Register a machine or adjust filters.'
          })}
        </section>
      </div>`;
    $('#machine-search', container)?.addEventListener('input', (event) => { state.search = event.target.value; render(); });
    $('#machine-status', container)?.addEventListener('change', (event) => { state.status = event.target.value; render(); });
    $('#machine-active', container)?.addEventListener('change', (event) => { state.active = event.target.value; render(); });
    $('[data-add-machine]', container)?.addEventListener('click', async () => {
      await openMachineModal(null, api, async () => { machines = await selectOrThrow((await getSupabase()).from('dialysis_machines').select('*').order('machine_code')); render(); });
    });
    $$('[data-edit-machine]', container).forEach((button) => button.addEventListener('click', async () => {
      const machine = machines.find((m) => m.machine_id === button.dataset.editMachine);
      if (machine) await openMachineModal(machine, api, async () => { machines = await selectOrThrow((await getSupabase()).from('dialysis_machines').select('*').order('machine_code')); render(); });
    }));
    $$('[data-view-slots]', container).forEach((button) => button.addEventListener('click', async () => {
      const machine = machines.find((m) => m.machine_id === button.dataset.viewSlots);
      if (machine) await openMachineSlotsModal(machine, api);
    }));
  }
  render();
}

async function renderPatientRecord(container, api) {
  showLoading(container, 'Loading patient record workspace…');
  const client = await getSupabase();
  const patients = await selectOrThrow(client.from('patients').select('patient_id,user_id,email,full_name,contact_number,account_status').order('full_name'));
  const state = { patientId: api.params.get('patient_id') || '', tab: ['overview', 'documents', 'appointments', 'sessions'].includes(api.params.get('tab')) ? api.params.get('tab') : 'overview', record: null };

  async function loadRecord() {
    if (!state.patientId) { state.record = null; return; }
    state.record = await rpc('get_patient_record', { p_patient_id: state.patientId });
  }

  function tabs() {
    return `<div class="tabs" role="tablist" aria-label="Patient record categories">
      ${['overview', 'documents', 'appointments', 'sessions'].map((tab) => `<button type="button" class="tab-button ${state.tab === tab ? 'active' : ''}" data-tab="${tab}">${tab === 'overview' ? 'Overview' : tab === 'documents' ? 'Documents' : tab === 'appointments' ? 'Appointments' : 'Sessions'}</button>`).join('')}
    </div>`;
  }

  function overview() {
    const p = state.record.patient || {};
    const m = state.record.medical_profile || {};
    return `<div class="detail-layout">
      <section class="card"><div class="card-header"><div><h2>Patient overview</h2><p>Authorized staff view of PATIENTS and PATIENT_MEDICAL_PROFILES.</p></div></div>
        ${renderKeyValue([
          ['Patient ID', shortId(p.patient_id)], ['Full name', p.full_name], ['Email', p.email], ['Account status', p.account_status],
          ['Date of birth', formatDate(p.date_of_birth)], ['Sex', p.sex_other || p.sex], ['Contact', p.contact_number], ['Address', p.address],
          ['Emergency contact', p.emergency_contact_name ? `${p.emergency_contact_name} · ${p.emergency_contact_number}` : null]
        ])}
      </section>
      <aside class="card"><div class="card-header"><div><h2>Medical profile</h2><p>Baseline weight is separate from session weights.</p></div></div>
        ${renderKeyValue([
          ['Height', m.height ? `${m.height} cm` : null], ['Baseline weight', m.weight ? `${m.weight} kg` : null], ['Blood type', m.blood_type],
          ['Diagnosis', m.diagnosis], ['Allergies', m.allergies], ['Existing conditions', m.existing_medical_conditions],
          ['Previous surgeries', m.previous_surgeries], ['Current medications', m.current_medications], ['Attending nephrologist', m.attending_nephrologist],
          ['Prescribed frequency', m.prescribed_dialysis_frequency], ['Recurring days', Array.isArray(m.recurring_days) ? m.recurring_days.join(', ') : null], ['Preferred time', m.preferred_time || null]
        ])}
      </aside>
    </div>`;
  }

  function documents() {
    const docs = state.record.documents || [];
    return `<div class="panel-stack">
      <section class="card"><div class="card-header"><div><h2>Upload authorized medical file</h2><p>Private authorized-medical-files bucket. Release controls patient visibility.</p></div></div>
        <form id="authorized-file-form" novalidate><div class="form-grid">
          <div class="form-field span-2"><label for="authorized-file">Medical file <span class="required" title="Required">*</span></label><input id="authorized-file" type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" required /><small class="field-hint">PDF, JPEG, PNG or WebP; maximum 10 MB.</small><small class="field-error" aria-live="polite"></small></div>
          ${checkboxField({ name: 'is_released', label: 'Release to patient now', checked: false })}
          ${textareaField({ name: 'remarks', label: 'Remarks', required: false, rows: 2 })}
        </div><div class="form-actions"><button type="button" class="btn btn-primary" data-upload-authorized>Upload authorized file</button></div></form>
      </section>
      <section class="card"><div class="card-header"><div><h2>Documents</h2><p>Verification, release and signed private access.</p></div></div>
        ${renderTable({
          columns: [
            { label: 'Category', render: (d) => esc(prettyDocumentType(d.document_type)) },
            { label: 'File', render: (d) => esc(d.file_name) },
            { label: 'Status', render: (d) => renderDocumentStatus(d) },
            { label: 'Released', render: (d) => badge(d.is_released_to_patient ? 'Released' : 'Not released') },
            { label: 'Reviewer', render: (d) => esc(d.reviewer_name || '—') },
            { label: 'Actions', className: 'actions', render: (d) => `<button type="button" class="btn btn-secondary btn-small" data-doc-preview="${esc(d.document_id)}">Preview</button><button type="button" class="btn btn-ghost btn-small" data-doc-download="${esc(d.document_id)}">Download</button><button type="button" class="btn btn-ghost btn-small" data-doc-verify="${esc(d.document_id)}">Verify</button><button type="button" class="btn btn-ghost btn-small" data-doc-release="${esc(d.document_id)}">${d.is_released_to_patient ? 'Hide' : 'Release'}</button>` }
          ],
          rows: docs,
          emptyTitle: 'No documents for this patient',
          emptyMessage: 'Patient-submitted and authorized medical files will appear here.'
        })}
      </section>
    </div>`;
  }

  function appointments() {
    const rows = state.record.appointments || [];
    return `<section class="card"><div class="card-header"><div><h2>Appointments</h2><p>Complete appointment records for this patient.</p></div></div>
      ${renderTable({
        columns: [
          { label: 'Appointment', render: (a) => `<strong>${esc(shortId(a.appointment_id))}</strong><small class="field-hint">${esc(formatDateTime(a.created_at))}</small>` },
          { label: 'Requested', render: (a) => `${esc(formatDate(a.requested_date, true))}<small class="field-hint">${esc(a.requested_time)}</small>` },
          { label: 'Confirmed', render: (a) => a.confirmed_date ? `${esc(formatDate(a.confirmed_date, true))}<small class="field-hint">${esc(formatTime(a.confirmed_start_time))} – ${esc(formatTime(a.confirmed_end_time))}</small>` : 'Not confirmed' },
          { label: 'Machine', render: (a) => esc(a.machine_code || '—') },
          { label: 'Status', render: (a) => appointmentBadges(a) },
          { label: 'Actions', className: 'actions', render: (a) => `<button type="button" class="btn btn-secondary btn-small" data-view="${esc(a.appointment_id)}">View</button><button type="button" class="btn btn-ghost btn-small" data-print="${esc(a.appointment_id)}">Print</button><button type="button" class="btn btn-ghost btn-small" data-record-session="${esc(a.appointment_id)}">Record session</button>` }
        ],
        rows,
        emptyTitle: 'No appointments for this patient',
        emptyMessage: 'Appointment requests will appear here.'
      })}
    </section>`;
  }

  function sessions() {
    const rows = state.record.sessions || [];
    return `<section class="card"><div class="card-header"><div><h2>Dialysis sessions</h2><p>Official treatment records. Release controls patient visibility.</p></div></div>
      ${renderTable({
        columns: [
          { label: 'Treatment date', render: (s) => esc(formatDate(s.treatment_date, true)) },
          { label: 'Machine', render: (s) => esc(s.machine_code || '—') },
          { label: 'Time', render: (s) => `${esc(formatTime(s.actual_start_time))} – ${esc(formatTime(s.actual_end_time))}` },
          { label: 'Pre / Post weight', render: (s) => `${esc(s.pre_dialysis_weight ?? '—')} kg / ${esc(s.post_dialysis_weight ?? '—')} kg` },
          { label: 'Status', render: (s) => badge(s.session_status) },
          { label: 'Released', render: (s) => badge(s.is_released_to_patient ? 'Released' : 'Not released') },
          { label: 'Recorded by', render: (s) => esc(s.recorded_by_name || '—') },
          { label: 'Actions', className: 'actions', render: (s) => `<button type="button" class="btn btn-secondary btn-small" data-session-release="${esc(s.session_id)}">${s.is_released_to_patient ? 'Hide' : 'Release'}</button>` }
        ],
        rows,
        emptyTitle: 'No dialysis sessions recorded',
        emptyMessage: 'Record a session from a confirmed appointment.'
      })}
    </section>`;
  }

  async function render() {
    await loadRecord();
    const patient = patients.find((p) => p.patient_id === state.patientId);
    container.innerHTML = `
      ${renderSectionHeader({ eyebrow: 'Staff Panel', title: 'Patient Record', subtitle: 'Search a patient, then review medical information, documents, appointments and sessions.' })}
      <div class="panel-stack">
        <section class="card"><div class="card-header"><div><h2>Select patient</h2><p>Searchable list from PATIENTS.</p></div></div><div id="patient-record-select"></div></section>
        ${state.record ? `<div class="panel-stack">${tabs()}${state.tab === 'overview' ? overview() : state.tab === 'documents' ? documents() : state.tab === 'appointments' ? appointments() : sessions()}</div>` : '<div class="state-card state-empty"><span class="state-icon" aria-hidden="true">○</span><h3>No patient selected</h3><p>Select a patient to load the authorized record bundle.</p></div>'}
      </div>`;
    const selector = createSearchSelect({
      items: patients.map((p) => ({ value: p.patient_id, label: p.full_name, meta: `${p.email || ''} · ${shortId(p.patient_id)} · ${p.account_status}` })),
      value: state.patientId,
      name: 'patient_id', label: '', placeholder: 'Search patient name or email…',
      onChange: async (value) => { state.patientId = value; api.setParams({ patient_id: value || null, tab: state.tab }); await render(); }
    });
    $('#patient-record-select', container)?.append(selector);
    $$('[data-tab]', container).forEach((button) => button.addEventListener('click', async () => { state.tab = button.dataset.tab; api.setParams({ patient_id: state.patientId || null, tab: state.tab }); await render(); }));

    if (state.record) {
      $$('[data-doc-preview]', container).forEach((button) => button.addEventListener('click', async () => {
        const doc = (state.record.documents || []).find((d) => d.document_id === button.dataset.docPreview);
        if (doc) await openDocument(doc, 'preview');
      }));
      $$('[data-doc-download]', container).forEach((button) => button.addEventListener('click', async () => {
        const doc = (state.record.documents || []).find((d) => d.document_id === button.dataset.docDownload);
        if (doc) await openDocument(doc, 'download');
      }));
      $$('[data-doc-verify]', container).forEach((button) => button.addEventListener('click', async () => {
        const doc = (state.record.documents || []).find((d) => d.document_id === button.dataset.docVerify);
        if (doc) await openVerifyDocumentModal(doc, api, render);
      }));
      $$('[data-doc-release]', container).forEach((button) => button.addEventListener('click', async () => {
        const doc = (state.record.documents || []).find((d) => d.document_id === button.dataset.docRelease);
        if (!doc) return;
        const next = !doc.is_released_to_patient;
        const result = await confirmDialog({ title: next ? 'Release document?' : 'Hide document?', message: next ? 'Release this document to the patient in My Records?' : 'Hide this document from the patient? The record remains in Supabase.', confirmLabel: next ? 'Release' : 'Hide', danger: !next });
        if (!result) return;
        try {
          await rpc('set_document_release', { p_document_id: doc.document_id, p_release: next });
          toast('Document release updated.', 'success');
          await render();
        } catch (error) { toast(error.message, 'error'); }
      }));
      $('[data-upload-authorized]', container)?.addEventListener('click', async (event) => {
        const form = $('#authorized-file-form', container);
        const file = $('#authorized-file', container)?.files?.[0];
        if (!file) { toast('Choose a medical file first.', 'error'); return; }
        const data = formData(form);
        await withButton(event.currentTarget, async () => {
          await uploadAuthorizedMedicalFile({ patient, file, isReleased: Boolean(data.is_released), remarks: String(data.remarks || '').trim() || null });
          toast('Authorized medical file uploaded.', 'success');
          await render();
        }, { label: 'Uploading…' });
      });
      $$('[data-view]', container).forEach((button) => button.addEventListener('click', async () => {
        try { await openStaffAppointmentDetail(button.dataset.view, api, render); } catch (error) { toast(error.message, 'error'); }
      }));
      $$('[data-print]', container).forEach((button) => button.addEventListener('click', async () => {
        try {
          const detail = await rpc('get_appointment_detail', { p_appointment_id: button.dataset.print });
          printAppointmentReport(detail, { preparedBy: api.context.displayName });
        } catch (error) { toast(error.message, 'error'); }
      }));
      $$('[data-record-session]', container).forEach((button) => button.addEventListener('click', async () => {
        const appointment = (state.record.appointments || []).find((a) => a.appointment_id === button.dataset.recordSession);
        if (appointment) await openRecordSessionModal(appointment, api, render);
      }));
      $$('[data-session-release]', container).forEach((button) => button.addEventListener('click', async () => {
        const session = (state.record.sessions || []).find((s) => s.session_id === button.dataset.sessionRelease);
        if (!session) return;
        const next = !session.is_released_to_patient;
        const result = await confirmDialog({ title: next ? 'Release session?' : 'Hide session?', message: next ? 'Release this official dialysis session to the patient?' : 'Hide this session from the patient? The official record remains unchanged.', confirmLabel: next ? 'Release' : 'Hide', danger: !next });
        if (!result) return;
        try {
          await rpc('set_session_release', { p_session_id: session.session_id, p_release: next });
          toast('Session release updated.', 'success');
          await render();
        } catch (error) { toast(error.message, 'error'); }
      }));
    }
  }

  await render();
}

async function init() {
  const context = await guardRole('staff');
  if (!context.staffId) throw new Error('No active staff record was found for this account.');
  await setupPanel({
    role: 'staff',
    context,
    sidebar: SIDEBAR,
    defaultSection: 'dashboard',
    chatbot: false,
    sections: {
      dashboard: { render: renderDashboard },
      'appointment-management': { render: renderAppointmentManagement },
      'machine-management': { render: renderMachineManagement },
      'patient-record': { render: renderPatientRecord }
    }
  });
}

init().catch((error) => {
  const app = $('#app');
  if (app) app.innerHTML = `<div class="state-card state-error" style="margin:2rem"><span class="state-icon">!</span><h3>Unable to open Staff Panel</h3><p>${esc(error.message)}</p><a class="btn btn-primary" href="/public/auth.html?mode=login">Go to Log In</a></div>`;
  console.error(error);
});
