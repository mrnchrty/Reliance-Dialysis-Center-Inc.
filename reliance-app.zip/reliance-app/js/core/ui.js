// Reusable UI states, dialogs, validation, tables, CSV and print helpers.
import { $, $$, escapeHtml, esc, el, loadingState, errorState, emptyState, csvEscape } from './dom.js';

function ensureRoots() {
  let toastRoot = $('#toast-root');
  if (!toastRoot) {
    toastRoot = el('div', { id: 'toast-root', class: 'toast-root', 'aria-live': 'polite', 'aria-atomic': 'true' });
    document.body.append(toastRoot);
  }
  let modalRoot = $('#modal-root');
  if (!modalRoot) {
    modalRoot = el('div', { id: 'modal-root' });
    document.body.append(modalRoot);
  }
  return { toastRoot, modalRoot };
}

export function toast(message, type = 'info', timeout = 5200) {
  const { toastRoot } = ensureRoots();
  const node = el('div', { class: `toast toast-${type}`, role: type === 'error' ? 'alert' : 'status' },
    el('span', { class: 'toast-icon', 'aria-hidden': 'true', text: type === 'error' ? '!' : type === 'success' ? '✓' : 'i' }),
    el('span', { text: message }),
    el('button', { type: 'button', class: 'icon-btn toast-close', 'aria-label': 'Dismiss message', onClick: () => node.remove(), text: '×' })
  );
  toastRoot.append(node);
  setTimeout(() => node.remove(), timeout);
  return node;
}

export function showLoading(container, label) {
  if (container) container.innerHTML = loadingState(label);
}

export function showError(container, error, onRetry = null) {
  const message = error instanceof Error ? error.message : String(error || 'Unexpected error.');
  if (!container) { toast(message, 'error'); return; }
  container.innerHTML = errorState(message);
  const retry = $('[data-retry]', container);
  if (retry && onRetry) retry.addEventListener('click', onRetry);
  else if (retry) retry.addEventListener('click', () => location.reload());
}

export function showEmpty(container, title, message, actionHtml = '') {
  if (container) container.innerHTML = emptyState(title, message, actionHtml);
}

export function showSuccess(container, title, message, actionHtml = '') {
  if (container) container.innerHTML = `<div class="state-card state-success"><span class="state-icon" aria-hidden="true">✓</span><h3>${esc(title)}</h3><p>${esc(message)}</p>${actionHtml}</div>`;
}

export function validateForm(form, { focus = true } = {}) {
  let valid = true;
  let firstInvalid = null;
  $$('.field-error', form).forEach((node) => { node.textContent = ''; });
  $$('input, select, textarea', form).forEach((field) => {
    field.classList.remove('invalid');
    if (field.disabled || field.type === 'hidden') return;
    let message = '';
    if (field.required && !String(field.value || '').trim()) message = 'This field is required.';
    else if (field.type === 'email' && field.value && !field.checkValidity()) message = 'Enter a valid email address.';
    else if (field.type === 'date' && field.value && !field.checkValidity()) message = 'Enter a valid date.';
    else if (field.minLength > 0 && field.value.length < field.minLength) message = `Use at least ${field.minLength} characters.`;
    else if (!field.checkValidity()) message = field.validationMessage || 'Check this value.';
    if (message) {
      valid = false;
      field.classList.add('invalid');
      const errorNode = field.closest('.form-field')?.querySelector('.field-error')
        || field.closest('.search-select')?.querySelector('.field-error');
      if (errorNode) errorNode.textContent = message;
      if (!firstInvalid) firstInvalid = field;
    }
  });
  if (!valid && focus) firstInvalid?.focus();
  return valid;
}

export function setFormMessage(form, message, type = 'error') {
  let node = $('.form-message', form);
  if (!node) {
    node = el('div', { class: 'form-message', 'aria-live': 'polite' });
    form.prepend(node);
  }
  node.className = `form-message form-message-${type}`;
  node.textContent = message;
}

export async function withButton(button, task, { label = 'Working…', success = null, errorPrefix = '' } = {}) {
  if (!button) return task();
  const original = button.innerHTML;
  button.disabled = true;
  button.innerHTML = `<span class="spinner spinner-small" aria-hidden="true"></span> ${esc(label)}`;
  try {
    const result = await task();
    if (success) toast(success, 'success');
    return result;
  } catch (error) {
    toast(`${errorPrefix}${error instanceof Error ? error.message : String(error)}`, 'error');
    throw error;
  } finally {
    button.disabled = false;
    button.innerHTML = original;
  }
}

export function openModal({ title, content, subtitle = '', size = 'medium', actions = [], onClose = null }) {
  const { modalRoot } = ensureRoots();
  const dialog = el('dialog', { class: `modal modal-${size}`, 'aria-labelledby': 'modal-title' });
  const body = el('div', { class: 'modal-body' });
  if (typeof content === 'string') body.innerHTML = content;
  else if (content instanceof Node) body.append(content);
  const footer = el('div', { class: 'modal-footer' });
  const api = {
    dialog, body, footer,
    close() { if (dialog.open) dialog.close(); },
    setContent(next) { if (typeof next === 'string') body.innerHTML = next; else if (next instanceof Node) body.replaceChildren(next); },
    setActions(next) {
      footer.replaceChildren();
      for (const action of next) {
        const btn = el('button', {
          type: 'button', class: `btn ${action.class || 'btn-secondary'}`, text: action.label,
          onClick: async () => {
            try {
              const result = action.onClick ? await action.onClick(api) : undefined;
              if (result !== false && action.close !== false) api.close();
            } catch (error) { toast(error instanceof Error ? error.message : String(error), 'error'); }
          }
        });
        footer.append(btn);
      }
    }
  };
  dialog.append(
    el('div', { class: 'modal-header' },
      el('div', {}, el('h2', { id: 'modal-title', text: title }), subtitle ? el('p', { text: subtitle }) : null),
      el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Close dialog', text: '×', onClick: () => api.close() })
    ),
    el('div', { class: 'modal-scroll' }, body),
    footer
  );
  dialog.addEventListener('close', () => { dialog.remove(); onClose?.(); });
  dialog.addEventListener('cancel', (event) => { event.preventDefault(); api.close(); });
  modalRoot.append(dialog);
  api.setActions(actions);
  dialog.showModal();
  return api;
}

export function confirmDialog({ title = 'Please confirm', message = '', confirmLabel = 'Confirm', cancelLabel = 'Cancel', danger = false, requireText = false }) {
  return new Promise((resolve) => {
    const modal = openModal({
      title,
      size: 'small',
      content: `<p class="modal-message">${esc(message)}</p>${requireText ? `<div class="form-field"><label for="confirm-text">Optional note <span class="optional">Optional</span></label><textarea id="confirm-text" rows="3" placeholder="Add a note for the audit trail"></textarea></div>` : ''}`,
      actions: [
        { label: cancelLabel, class: 'btn-secondary', onClick: () => { resolve(false); } },
        {
          label: confirmLabel, class: danger ? 'btn-danger' : 'btn-primary', close: false,
          onClick: (api) => {
            const text = $('#confirm-text', api.body)?.value?.trim() || null;
            api.close();
            resolve(requireText ? { confirmed: true, note: text } : true);
          }
        }
      ],
      onClose: () => resolve(requireText ? { confirmed: false, note: null } : false)
    });
  });
}

export function renderTable({ columns = [], rows = [], emptyTitle = 'No records found', emptyMessage = 'There are no records to display for the current selection.', rowAttrs = null, className = '' }) {
  if (!rows.length) return emptyState(emptyTitle, emptyMessage);
  return `<div class="table-wrap"><table class="data-table ${esc(className)}">
    <thead><tr>${columns.map((c) => `<th scope="col" class="${esc(c.className || '')}">${esc(c.label)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map((row, index) => `<tr ${rowAttrs ? rowAttrs(row, index) : ''}>${columns.map((c) => `<td class="${esc(c.className || '')}">${c.render ? c.render(row, index) : esc(row[c.key] ?? '—')}</td>`).join('')}</tr>`).join('')}</tbody>
  </table></div>`;
}

export function rawHtml(html) { return { __html: String(html ?? '') }; }

export function renderKeyValue(pairs, className = '') {
  return `<dl class="key-value ${esc(className)}">${pairs.map(([key, value, hint]) => {
    let rendered = '—';
    if (value && typeof value === 'object' && typeof value.__html === 'string') rendered = value.__html;
    else if (value !== null && value !== undefined && value !== '') rendered = esc(value);
    return `<div><dt>${esc(key)}</dt><dd>${rendered}${hint ? `<small>${esc(hint)}</small>` : ''}</dd></div>`;
  }).join('')}</dl>`;
}

export function renderTimeline(entries = []) {
  if (!entries.length) return emptyState('No status history', 'Status changes will appear here as staff processes this appointment.');
  const ordered = [...entries].sort((a, b) => new Date(a.timestamp || 0) - new Date(b.timestamp || 0));
  return `<ol class="timeline">${ordered.map((entry) => `<li>
    <span class="timeline-dot" aria-hidden="true"></span>
    <div class="timeline-content"><strong>${esc(entry.event_type || entry.status || 'Update')}</strong>
      <span class="timeline-meta">${esc(entry.status || '')} · ${esc(entry.timestamp ? new Date(entry.timestamp).toLocaleString('en-US', { timeZone: 'Asia/Manila' }) : 'Timestamp not recorded')}</span>
      ${entry.remarks ? `<p>${esc(entry.remarks)}</p>` : ''}
    </div>
  </li>`).join('')}</ol>`;
}

export function downloadCSV(filename, rows, headers = null) {
  const matrix = [];
  if (headers) matrix.push(headers);
  for (const row of rows) matrix.push(Array.isArray(row) ? row : headers ? headers.map((h) => row[h]) : Object.values(row));
  const csv = matrix.map((row) => row.map(csvEscape).join(',')).join('\r\n');
  const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = el('a', { href: url, download: filename });
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function printReport({ title, subtitle = '', content, preparedBy = '' }) {
  const win = window.open('', '_blank', 'noopener,noreferrer,width=980,height=760');
  if (!win) { toast('Allow pop-ups to open the printable report.', 'error'); return; }
  const styles = `
    :root{color-scheme:light}*{box-sizing:border-box}body{font-family:'Poppins','Segoe UI',Arial,sans-serif;color:#16243b;margin:32px;line-height:1.5}
    header{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #d62828;padding-bottom:16px;margin-bottom:24px}
    h1{font-size:22px;margin:0;color:#0a4fa0}h2{font-size:16px;color:#0a4fa0;margin:22px 0 8px;border-bottom:1px solid #e2e9f4;padding-bottom:5px}
    p,small,td,th,dd,dt{font-size:12px}table{width:100%;border-collapse:collapse;margin:10px 0}th,td{border:1px solid #e2e9f4;padding:7px;text-align:left;vertical-align:top}
    th{background:#f5f8fd;color:#16243b}.kv{display:grid;grid-template-columns:1fr 1fr;gap:4px 24px}.kv div{display:flex;gap:6px;border-bottom:1px solid #EDF2F7;padding:5px 0}.kv dt{font-weight:700;min-width:160px}.kv dd{margin:0}
    .muted{color:#64748b}.accent{color:#d62828}.footer{margin-top:30px;border-top:1px solid #e2e9f4;padding-top:10px;color:#64748b}
    @page{size:A4;margin:14mm}@media print{body{margin:0}.no-print{display:none}}`;
  win.document.open();
  win.document.write(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${styles}</style></head><body>
    <header><div><h1>Reliance Dialysis Center Inc.</h1><p>${esc(subtitle || 'Authorized record report')}</p></div><div class="muted"><strong>${esc(title)}</strong><br>${new Date().toLocaleString('en-US', { timeZone: 'Asia/Manila' })}<br>Asia/Manila</div></header>
    ${content}
    <p class="footer">Generated from live authorized Supabase records. ${preparedBy ? `Prepared by ${esc(preparedBy)}. ` : ''}This report is not a clinical certificate.</p>
    <script>window.addEventListener('load',()=>setTimeout(()=>window.print(),250));<\/script>
  </body></html>`);
  win.document.close();
}

export function renderSectionHeader({ eyebrow = '', title, subtitle = '', actions = '' }) {
  return `<div class="section-header"><div>${eyebrow ? `<p class="eyebrow">${esc(eyebrow)}</p>` : ''}<h1>${esc(title)}</h1>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div><div class="section-actions">${actions}</div></div>`;
}

export function renderStatCard({ label, value, note = '', tone = 'blue', icon = '' }) {
  return `<article class="stat-card stat-${esc(tone)}"><div class="stat-top"><span>${esc(label)}</span>${icon ? `<span aria-hidden="true">${esc(icon)}</span>` : ''}</div><strong>${esc(value ?? 0)}</strong>${note ? `<small>${esc(note)}</small>` : ''}</article>`;
}

export function bindRetry(container, callback) {
  const button = $('[data-retry]', container);
  if (button) button.addEventListener('click', callback);
}
