// Report builders. Callers must pass data returned from authorized Supabase reads.
import { esc, formatDate, formatDateTime, formatTime, shortId, badge } from './dom.js';
import { renderKeyValue, renderTable, renderTimeline, rawHtml, printReport, downloadCSV } from './ui.js';
import { prettyDocumentType, slotDisplay } from './forms.js';

export function appointmentReportHtml(detail, { preparedBy = '', purpose = 'Appointment record' } = {}) {
  const a = detail?.appointment || {};
  const p = detail?.patient || {};
  const m = detail?.medical_profile || {};
  const machine = detail?.machine || {};
  const docs = detail?.documents || [];
  const config = detail?.config || {};
  const statusHistory = Array.isArray(a.status_history) ? a.status_history : [];
  return `<h2>${esc(purpose)}</h2>
    ${renderKeyValue([
      ['Appointment ID', shortId(a.appointment_id)],
      ['Current status', rawHtml(badge(a.appointment_status))],
      ['Request type', a.request_type || 'New'],
      ['Submitted', formatDateTime(a.created_at)],
      ['Requested date', formatDate(a.requested_date, true)],
      ['Preferred time', slotDisplay(config, a.requested_time)],
      ['Confirmed date', a.confirmed_date ? formatDate(a.confirmed_date, true) : 'Not yet confirmed'],
      ['Confirmed time', a.confirmed_start_time ? `${formatTime(a.confirmed_start_time)} – ${formatTime(a.confirmed_end_time)}` : 'Not yet confirmed'],
      ['Assigned machine', machine.machine_code || a.machine_snapshot?.machine_code || 'Staff assignment pending'],
      ['Staff remarks', a.staff_remarks || 'None recorded'],
      ['Cancellation processed', rawHtml(a.is_cancelled ? badge('Yes', 'danger') : badge('No', 'success'))],
      ['Reschedule requested', rawHtml(a.reschedule_requested ? badge('Pending staff review', 'warning') : badge('No', 'neutral'))]
    ])}
    <h2>Patient information</h2>
    ${renderKeyValue([
      ['Patient ID', shortId(p.patient_id)], ['Full name', p.full_name], ['Email', p.email],
      ['Date of birth', formatDate(p.date_of_birth)], ['Sex', p.sex_other || p.sex],
      ['Contact number', p.contact_number], ['Address', p.address],
      ['Emergency contact', p.emergency_contact_name ? `${p.emergency_contact_name} · ${p.emergency_contact_number}` : null]
    ])}
    <h2>Medical profile</h2>
    ${renderKeyValue([
      ['Diagnosis', m.diagnosis], ['Blood type', m.blood_type], ['Allergies', m.allergies],
      ['Existing conditions', m.existing_medical_conditions], ['Current medications', m.current_medications],
      ['Attending nephrologist', m.attending_nephrologist], ['Prescribed frequency', m.prescribed_dialysis_frequency],
      ['Baseline weight (kg)', m.weight], ['Preferred time', m.preferred_time ? slotDisplay(config, m.preferred_time) : null]
    ])}
    <h2>Submitted documents</h2>
    ${docs.length ? renderTable({
      columns: [
        { label: 'Category', render: (d) => esc(prettyDocumentType(d.document_type)) },
        { label: 'Filename', render: (d) => esc(d.file_name) },
        { label: 'Version', render: (d) => esc(d.version) },
        { label: 'Verification', render: (d) => badge(d.verification_status) },
        { label: 'Uploaded', render: (d) => esc(formatDateTime(d.uploaded_at)) }
      ], rows: docs
    }) : '<p class="muted">No current documents were returned for this authorized record.</p>'}
    <h2>Status history</h2>${renderTimeline(statusHistory)}
    <p class="muted">Document verification records staff review only and is separate from the appointment status. This report does not determine clinical validity.</p>`;
}

export function printAppointmentReport(detail, options = {}) {
  const a = detail?.appointment || {};
  printReport({
    title: `Appointment ${shortId(a.appointment_id)}`,
    subtitle: 'Authorized appointment record — Reliance Dialysis Center Inc., Mabini, Batangas',
    preparedBy: options.preparedBy,
    content: appointmentReportHtml(detail, options)
  });
}

export function printAnalyticsReport(bundle, { preparedBy = '' } = {}) {
  const period = bundle?.period || {};
  const def = bundle?.definition || {};
  const appointments = bundle?.appointments || {};
  const sessions = bundle?.sessions || {};
  const utilization = bundle?.machine_utilization || {};
  const noShow = bundle?.no_show || {};
  const rows = [
    ['Total appointments', appointments.total_in_range], ['Pending', appointments.pending],
    ['Under Review', appointments.under_review], ['Confirmed', appointments.confirmed], ['Rejected', appointments.rejected],
    ['Completed sessions', sessions.completed_in_range], ['Total available machine slots', utilization.total_available_slots],
    ['Occupied machine slots', utilization.occupied_slots], ['Utilization rate', `${utilization.rate ?? 0}%`],
    ['Explicit attended outcomes', noShow.attended_recorded], ['Explicit No-Show outcomes', noShow.no_show_recorded],
    ['No-Show rate', `${noShow.rate ?? 0}%`]
  ];
  printReport({
    title: 'Operational Analytics Report',
    subtitle: `${formatDate(period.start, true)} – ${formatDate(period.end, true)} · ${esc(period.granularity || 'daily')} · Asia/Manila`,
    preparedBy,
    content: `<h2>Measurement and definitions</h2>${renderKeyValue([
      ['Measurement period', `${formatDate(period.start, true)} – ${formatDate(period.end, true)}`],
      ['Available slot', def.available_slot], ['Occupied slot', def.occupied_slot],
      ['Utilization formula', def.utilization_formula], ['No-Show formula', def.no_show_formula],
      ['Operational scope', 'Operational scheduling and recorded outcomes only; no clinical conclusions.']
    ])}<h2>Operational totals</h2>${renderKeyValue(rows)}<h2>Status distribution</h2>${renderTable({
      columns: [{ label: 'Status', key: 'status' }, { label: 'Count', key: 'count' }],
      rows: Object.entries(bundle?.appointment_status_counts || {}).map(([status, count]) => ({ status, count }))
    })}<p class="muted">${esc(noShow.note || '')}</p>`
  });
}

export function downloadAnalyticsCSV(bundle, filename = 'reliance-operational-analytics.csv') {
  const rows = [];
  const add = (section, metric, value, note = '') => rows.push({ section, metric, value, note });
  const period = bundle?.period || {};
  const def = bundle?.definition || {};
  add('Period', 'Start', period.start, 'Asia/Manila');
  add('Period', 'End', period.end, 'Asia/Manila');
  add('Period', 'Granularity', period.granularity);
  add('Definition', 'Available slot', def.available_slot);
  add('Definition', 'Occupied slot', def.occupied_slot);
  add('Definition', 'Utilization formula', def.utilization_formula);
  for (const [key, value] of Object.entries(bundle?.appointments || {})) if (!Array.isArray(value)) add('Appointments', key, value);
  for (const [key, value] of Object.entries(bundle?.patients || {})) if (!Array.isArray(value)) add('Patients', key, value);
  for (const [key, value] of Object.entries(bundle?.sessions || {})) if (!Array.isArray(value)) add('Sessions', key, value);
  for (const [key, value] of Object.entries(bundle?.machine_utilization || {})) if (!Array.isArray(value)) add('Machine utilization', key, value);
  for (const [key, value] of Object.entries(bundle?.no_show || {})) add('No-show', key, value);
  for (const row of bundle?.appointments?.trend || []) add('Appointment trend', row.period, JSON.stringify(row));
  for (const row of bundle?.machine_utilization?.by_machine || []) add('Machine utilization by machine', row.machine_code, JSON.stringify(row));
  downloadCSV(filename, rows, ['section', 'metric', 'value', 'note']);
}

export function downloadAuditCSV(rows, filename = 'reliance-audit-logs.csv') {
  downloadCSV(filename, rows.map((row) => ({
    created_at: row.created_at, activity: row.activity, module: row.affected_module,
    record_id: row.affected_record_id, actor_name: row.actor_name, actor_email: row.actor_email,
    actor_role: row.actor_role, severity: row.severity, details: JSON.stringify(row.details || {})
  })), ['created_at', 'activity', 'module', 'record_id', 'actor_name', 'actor_email', 'actor_role', 'severity', 'details']);
}

export function printAuditReport(rows, { filters = {}, preparedBy = '' } = {}) {
  printReport({
    title: 'Audit Log Report',
    subtitle: 'Protected, filterable audit records — Reliance Dialysis Center Inc.',
    preparedBy,
    content: `<h2>Applied filters</h2>${renderKeyValue(Object.entries(filters).map(([k, v]) => [k.replaceAll('_', ' '), v || 'All']))}<h2>Records</h2>${renderTable({
      columns: [
        { label: 'Timestamp', render: (r) => esc(formatDateTime(r.created_at)) },
        { label: 'Activity', render: (r) => esc(r.activity) },
        { label: 'Module', render: (r) => esc(r.affected_module) },
        { label: 'Record', render: (r) => esc(r.affected_record_id || '—') },
        { label: 'Actor', render: (r) => esc(r.actor_name || r.actor_email || 'System') },
        { label: 'Severity', render: (r) => badge(r.severity) }
      ], rows
    })}<p class="muted">Audit logs are append-only under database policies and cannot be modified by ordinary users.</p>`
  });
}
