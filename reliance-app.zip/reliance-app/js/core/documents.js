// Private Storage upload verification, signed access and document readiness.
import { esc, formatBytes, formatDateTime, badge } from './dom.js';
import { getSupabase, rpc } from './supabase.js';
import { openModal, toast } from './ui.js';
import { requiredDocumentTypes, prettyDocumentType } from './forms.js';

export const ALLOWED_MIME_TYPES = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const PATIENT_BUCKET = 'patient-documents';
export const AUTHORIZED_BUCKET = 'authorized-medical-files';

export function validateUpload(file) {
  if (!file) throw new Error('Choose a file first.');
  if (!ALLOWED_MIME_TYPES.includes(file.type)) throw new Error('Allowed file types are PDF, JPEG, PNG, and WebP.');
  if (file.size <= 0 || file.size > MAX_FILE_SIZE) throw new Error('File size must be greater than zero and no larger than 10 MB.');
  if (/[\\/]/.test(file.name) || file.name.includes('..')) throw new Error('The filename contains unsupported characters.');
  return true;
}

export function safeFileName(name) {
  return String(name || 'document').normalize('NFKD').replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(-120) || 'document';
}

export function slug(value) {
  return String(value || 'document').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
}

async function verifyPrivateObject(bucket, path) {
  const client = await getSupabase();
  const { data, error } = await client.storage.from(bucket).createSignedUrl(path, 30);
  if (error || !data?.signedUrl) throw new Error('The upload could not be verified in private Storage. Please try again.');
}

export async function uploadPatientDocument({ context, file, documentType, replacesDocumentId = null, config }) {
  validateUpload(file);
  const types = requiredDocumentTypes(config);
  if (!types.includes(documentType)) throw new Error('Select one of the configured required document categories.');
  const client = await getSupabase();
  const path = `${context.user.id}/${slug(documentType)}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeFileName(file.name)}`;
  const { error: uploadError } = await client.storage.from(PATIENT_BUCKET).upload(path, file, {
    contentType: file.type, upsert: false
  });
  if (uploadError) throw new Error(uploadError.message);
  await verifyPrivateObject(PATIENT_BUCKET, path);
  try {
    return await rpc('register_patient_document', {
      p_document_type: documentType,
      p_file_path: path,
      p_file_name: file.name,
      p_file_size: file.size,
      p_mime_type: file.type,
      p_replaces_document_id: replacesDocumentId
    });
  } catch (error) {
    // Patient delete is intentionally denied by Storage RLS; staff can clean up an orphan if needed.
    await client.storage.from(PATIENT_BUCKET).remove([path]).catch(() => null);
    throw error;
  }
}

export async function uploadAuthorizedMedicalFile({ patient, file, isReleased = false, remarks = null }) {
  validateUpload(file);
  if (!patient?.user_id || !patient?.patient_id) throw new Error('Select a patient record first.');
  const client = await getSupabase();
  const path = `${patient.user_id}/medical-records/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeFileName(file.name)}`;
  const { error: uploadError } = await client.storage.from(AUTHORIZED_BUCKET).upload(path, file, {
    contentType: file.type, upsert: false
  });
  if (uploadError) throw new Error(uploadError.message);
  await verifyPrivateObject(AUTHORIZED_BUCKET, path);
  return rpc('register_authorized_medical_file', {
    p_patient_id: patient.patient_id,
    p_file_path: path,
    p_file_name: file.name,
    p_file_size: file.size,
    p_mime_type: file.type,
    p_is_released: Boolean(isReleased),
    p_remarks: remarks || null
  });
}

export async function signedDocumentUrl(doc, { download = false } = {}) {
  const client = await getSupabase();
  const bucket = doc.storage_bucket || PATIENT_BUCKET;
  const options = download ? { download: doc.file_name || 'reliance-document' } : {};
  const { data, error } = await client.storage.from(bucket).createSignedUrl(doc.file_path, 60, options);
  if (error || !data?.signedUrl) throw new Error(error?.message || 'A signed document link could not be created.');
  return data.signedUrl;
}

export async function openDocument(doc, mode = 'preview') {
  try {
    const url = await signedDocumentUrl(doc, { download: mode === 'download' });
    if (mode === 'download') {
      const link = document.createElement('a');
      link.href = url;
      link.download = doc.file_name || 'reliance-document';
      link.rel = 'noopener';
      document.body.append(link);
      link.click();
      link.remove();
      toast('Secure download started.', 'success');
      return;
    }
    const isImage = String(doc.mime_type || '').startsWith('image/');
    const body = isImage
      ? `<img class="document-preview-image" src="${esc(url)}" alt="Preview of ${esc(doc.file_name)}" />`
      : `<iframe class="document-preview-frame" src="${esc(url)}#view=FitH" title="Preview of ${esc(doc.file_name)}"></iframe>`;
    openModal({
      title: doc.file_name || 'Document preview',
      subtitle: `${prettyDocumentType(doc.document_type)} · ${formatBytes(doc.file_size)} · Verification: ${doc.verification_status || 'Pending'}`,
      size: 'large',
      content: `${body}<p class="field-hint">This is a short-lived signed link from private Storage. It expires in 60 seconds and is not a public URL.</p>`,
      actions: [
        { label: 'Download', class: 'btn-secondary', onClick: async () => { await openDocument(doc, 'download'); } },
        { label: 'Close', class: 'btn-primary' }
      ]
    });
  } catch (error) {
    toast(error.message || 'Unable to open this private document.', 'error');
  }
}

export function documentReadiness(config, docs = []) {
  return requiredDocumentTypes(config).map((type) => {
    const candidates = docs
      .filter((d) => d.document_type === type && d.is_current !== false)
      .sort((a, b) => new Date(b.uploaded_at || 0) - new Date(a.uploaded_at || 0));
    const current = candidates[0] || null;
    const verified = Boolean(current && current.verification_status === 'Verified' && !current.correction_requested && !current.is_outdated);
    const submitted = Boolean(current && ['Pending', 'Verified'].includes(current.verification_status) && !current.is_outdated);
    const needsUpload = !current || !submitted || Boolean(current.correction_requested) || Boolean(current.is_outdated) || ['Rejected', 'Needs Correction'].includes(current.verification_status);
    return { type, current, verified, submitted, needsUpload, reusable: verified };
  });
}

export function renderDocumentStatus(doc) {
  if (!doc) return badge('Not submitted');
  const parts = [badge(doc.verification_status)];
  if (doc.correction_requested) parts.push(badge('Update requested', 'warning'));
  if (doc.is_outdated) parts.push(badge('Outdated', 'neutral'));
  if (doc.is_released_to_patient === false) parts.push(badge('Not released', 'neutral'));
  return parts.join(' ');
}

export function documentMeta(doc) {
  if (!doc) return 'No file has been submitted for this category.';
  return `${esc(doc.file_name || 'Unnamed file')} · v${esc(doc.version || 1)} · ${esc(formatBytes(doc.file_size))} · ${esc(formatDateTime(doc.uploaded_at))}`;
}
