// Shared authenticated panel shell: exact sidebars, protected header, notifications and deep links.
import { $, $$, esc, escapeHtml, formatDateTime, shortId, emptyState, loadingState } from './dom.js';
import { getSupabase } from './supabase.js';
import { PANEL_PATHS, signOut, loadRoleContext } from './auth.js';
import { toast, showError } from './ui.js';
import { openProfileModal } from './profile.js';
import { renderChatbot } from './chatbot.js';

const PANEL_ALIASES = {
  patient: 'patient', staff: 'staff', admin: 'super_admin', super_admin: 'super_admin', 'super-admin': 'super_admin'
};

const SECTION_ALIASES = {
  booking: 'book-appointment', book: 'book-appointment', 'book_appointment': 'book-appointment', appointment: 'book-appointment',
  records: 'my-records', 'my_records': 'my-records', documents: 'my-records', history: 'my-records',
  appointments: 'appointment-management', 'appointment_management': 'appointment-management',
  machines: 'machine-management', 'machine_management': 'machine-management',
  'patient_records': 'patient-record', 'patient_records_management': 'patient-record',
  users: 'user-management', 'user_management': 'user-management',
  'staff_management': 'staff-management-and-roles', 'staff_roles': 'staff-management-and-roles', 'staff_management_and_roles': 'staff-management-and-roles',
  config: 'system-configuration', 'system_config': 'system-configuration', 'system_configuration': 'system-configuration',
  schedule: 'machine-and-schedule-configuration', 'machine_schedule': 'machine-and-schedule-configuration', 'machine_and_schedule_configuration': 'machine-and-schedule-configuration',
  analytics: 'analytics-and-reports', 'analytics_reports': 'analytics-and-reports', reports: 'analytics-and-reports',
  audit: 'audit-logs', 'audit_logs': 'audit-logs'
};

const RECORD_PARAMS = ['appointment_id', 'document_id', 'session_id', 'patient_id', 'tab', 'action', 'record_id', 'recurrence_group_id', 'machine_id', 'user_id'];

const ALL_SECTION_IDS = [
  'dashboard', 'book-appointment', 'my-records', 'appointment-management', 'machine-management', 'patient-record',
  'user-management', 'staff-management-and-roles', 'system-configuration', 'machine-and-schedule-configuration',
  'analytics-and-reports', 'audit-logs'
];
const ALL_SECTIONS = Object.fromEntries(ALL_SECTION_IDS.map((id) => [id, true]));

function normalizeSection(value, sections, fallback) {
  const raw = String(value || '').replace(/^#/, '');
  const normalized = SECTION_ALIASES[raw] || raw;
  return Object.prototype.hasOwnProperty.call(sections, normalized) ? normalized : fallback;
}

function defaultSectionForRole(role, sections, fallback) {
  const preferred = {
    patient: 'dashboard', staff: 'dashboard', super_admin: 'dashboard'
  }[role];
  return Object.prototype.hasOwnProperty.call(sections, preferred) ? preferred : fallback;
}

function destinationSection(dest, targetRole, sections, fallback) {
  const allowed = { ...ALL_SECTIONS, ...sections };
  const raw = dest.section || dest.page || '';
  if (raw) {
    const normalized = normalizeSection(raw, allowed, null);
    if (normalized) return normalized;
  }
  if (targetRole === 'patient') {
    if (dest.session_id || dest.document_id || dest.tab === 'history' || dest.tab === 'documents') return 'my-records';
    if (dest.appointment_id || dest.recurrence_group_id) return 'book-appointment';
    return 'dashboard';
  }
  if (targetRole === 'staff') {
    if (dest.patient_id || dest.document_id || dest.session_id || dest.tab === 'documents' || dest.tab === 'history') return 'patient-record';
    if (dest.appointment_id || dest.action === 'reschedule' || dest.action === 'cancellation') return 'appointment-management';
    if (dest.machine_id) return 'machine-management';
    return 'appointment-management';
  }
  if (dest.user_id || dest.role) return 'user-management';
  if (dest.patient_id) return 'analytics-and-reports';
  return 'audit-logs';
}

function normalizeDestination(notification, role) {
  let dest = notification?.destination || {};
  if (typeof dest === 'string') { try { dest = JSON.parse(dest); } catch { dest = {}; } }
  dest = { ...dest };
  for (const key of RECORD_PARAMS) {
    if (!dest[key] && notification?.[`related_${key}`]) dest[key] = notification[`related_${key}`];
  }
  if (!dest.appointment_id && notification?.related_appointment_id) dest.appointment_id = notification.related_appointment_id;
  if (!dest.document_id && notification?.related_document_id) dest.document_id = notification.related_document_id;
  if (!dest.session_id && notification?.related_session_id) dest.session_id = notification.related_session_id;
  if (!dest.patient_id && notification?.related_patient_id) dest.patient_id = notification.related_patient_id;
  let target = PANEL_ALIASES[dest.panel] || role;
  if (role === 'super_admin' && target !== 'super_admin') target = 'super_admin';
  if (role === 'staff' && target === 'patient') target = 'staff';
  if (role === 'patient' && target !== 'patient') target = 'patient';
  dest.panel = target;
  return dest;
}

function paramsFromDestination(dest) {
  const params = {};
  for (const key of RECORD_PARAMS) {
    if (dest[key] !== undefined && dest[key] !== null && dest[key] !== '') params[key] = String(dest[key]);
  }
  return params;
}

export function panelPath(role) {
  return PANEL_PATHS[role] || '/';
}

export function buildDestinationUrl(notification, role, sections, fallback = 'dashboard') {
  const dest = normalizeDestination(notification, role);
  const targetRole = dest.panel;
  const section = destinationSection(dest, targetRole, sections, fallback);
  const url = new URL(panelPath(targetRole), location.origin);
  for (const [key, value] of Object.entries(paramsFromDestination(dest))) url.searchParams.set(key, value);
  url.hash = section;
  return { url, targetRole, section, params: paramsFromDestination(dest), destination: dest };
}

function initials(name) {
  return String(name || 'RD').split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0].toUpperCase()).join('') || 'RD';
}

const SECTION_ICONS = {
  dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z"/></svg>',
  'book-appointment': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>',
  'my-records': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>',
  'appointment-management': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M9 15l2 2 4-4"/></svg>',
  'machine-management': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h4"/></svg>',
  'patient-record': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/></svg>',
  'user-management': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>',
  'staff-management-and-roles': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
  'system-configuration': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9c.26.6.77 1.02 1.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>',
  'machine-and-schedule-configuration': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  'analytics-and-reports': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>',
  'audit-logs': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>'
};
const BELL_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8a6 6 0 0112 0c0 7 3 8 3 8H3s3-1 3-8M10 21h4"/></svg>';
const OUT_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>';

export async function setupPanel({ role, context: initialContext, sidebar = [], sections = {}, defaultSection = 'dashboard', chatbot = false }) {
  const root = $('#app');
  if (!root) throw new Error('Panel mount point #app was not found.');
  let context = initialContext;
  const roleTitle = role === 'super_admin' ? 'Super Administrator' : role === 'staff' ? 'Staff' : 'Patient';
  const sidebarLinks = sidebar.map((item) => `<a class="sidebar-link" href="#${esc(item.id)}" data-section="${esc(item.id)}"><span class="sidebar-icon" aria-hidden="true">${SECTION_ICONS[item.id] || esc(item.icon || '•')}</span><span>${esc(item.label)}</span></a>`).join('');
  root.innerHTML = `<div class="app-shell">
    <aside class="sidebar" id="sidebar" aria-label="Primary navigation">
      <div class="sidebar-brand"><a href="/public/index.html" aria-label="Reliance Dialysis Center home"><img src="/assets/images/reliance-logo.png" alt="Reliance Dialysis Center Inc." /></a><button type="button" class="icon-btn sidebar-close" aria-label="Close navigation">×</button></div>
      <div class="sidebar-who"><span class="sidebar-avatar" id="sidebar-avatar">${esc(initials(context.displayName))}</span><div class="sidebar-who-copy"><strong data-user-name>${esc(context.displayName)}</strong><small>${esc(roleTitle)}</small></div></div>
      <nav class="sidebar-nav">${sidebarLinks}</nav>
      <button type="button" class="sidebar-logout" id="sidebar-logout">${OUT_SVG}<span>Log out</span></button>
      <div class="sidebar-footer"><strong>Reliance Dialysis Center Inc.</strong><small>Mabini, Batangas</small></div>
    </aside>
    <div class="app-main">
      <header class="app-header">
        <button type="button" class="icon-btn mobile-menu" id="mobile-menu" aria-label="Open navigation" aria-expanded="false">☰</button>
        <a class="header-logo" href="/public/index.html" aria-label="Reliance Dialysis Center home"><img src="/assets/images/reliance-logo.png" alt="Reliance Dialysis Center Inc." /></a>
        <div class="header-title"><span>${esc(role === 'super_admin' ? 'Super Administrator' : role === 'staff' ? 'Staff Panel' : 'Patient Panel')}</span></div>
        <div class="header-actions">
          <div class="notification-wrap">
            <button type="button" class="icon-btn notification-button" id="notification-button" aria-label="Notifications" aria-expanded="false">${BELL_SVG}<span class="notification-badge" id="notification-badge" hidden>0</span></button>
            <div class="notification-dropdown" id="notification-dropdown" hidden></div>
          </div>
          <div class="profile-wrap">
            <button type="button" class="profile-button" id="profile-button" aria-expanded="false"><span class="avatar" id="header-avatar">${esc(initials(context.displayName))}</span><span class="header-user-name" data-user-name>${esc(context.displayName)}</span><span aria-hidden="true">⌄</span></button>
            <div class="profile-menu" id="profile-menu" hidden>
              <button type="button" data-profile-action="my-profile">My Profile</button>
              <button type="button" data-profile-action="logout">Logout</button>
            </div>
          </div>
        </div>
      </header>
      <main id="section-root" tabindex="-1"></main>
    </div>
  </div><div id="panel-chatbot"></div>`;
  const sectionRoot = $('#section-root', root);

  let currentSection = defaultSection;
  const api = {
    role,
    get context() { return context; },
    setContext(next) { context = next; updateHeader(); },
    get params() { return new URLSearchParams(location.search); },
    setParams(updates = {}, { replace = true, rerender = true } = {}) {
      const url = new URL(location.href);
      for (const [key, value] of Object.entries(updates)) {
        if (value === null || value === undefined || value === '') url.searchParams.delete(key);
        else url.searchParams.set(key, String(value));
      }
      history[replace ? 'replaceState' : 'pushState']({}, '', `${url.pathname}${url.search}${url.hash}`);
      if (rerender) renderCurrent();
    },
    navigate(sectionId, params = {}, { replace = false } = {}) {
      const section = normalizeSection(sectionId, sections, defaultSection);
      const url = new URL(location.href);
      for (const key of RECORD_PARAMS) if (!Object.prototype.hasOwnProperty.call(params, key)) url.searchParams.delete(key);
      for (const [key, value] of Object.entries(params)) {
        if (value === null || value === undefined || value === '') url.searchParams.delete(key);
        else url.searchParams.set(key, String(value));
      }
      url.hash = section;
      history[replace ? 'replaceState' : 'pushState']({}, '', `${url.pathname}${url.search}${url.hash}`);
      closeSidebar();
      renderCurrent();
    },
    refresh() { renderCurrent(); },
    async openNotification(notification) { await openNotification(notification); },
    openProfile(options = {}) {
      return openProfileModal(context, {
        ...options,
        onSaved: async () => {
          try {
            context = await loadRoleContext();
            updateHeader();
            toast('Profile refreshed from Supabase.', 'success');
            renderCurrent();
            options.onSaved?.();
          } catch (error) { toast(error.message, 'error'); }
        }
      });
    }
  };

  function updateHeader() {
    $$('[data-user-name]', root).forEach((el) => { el.textContent = context.displayName; });
    const avatar = $('#header-avatar', root);
    const sideAvatar = $('#sidebar-avatar', root);
    if (avatar) avatar.textContent = initials(context.displayName);
    if (sideAvatar) sideAvatar.textContent = initials(context.displayName);
  }

  function getInitialSection() {
    const fromHash = location.hash.slice(1);
    const fromQuery = new URLSearchParams(location.search).get('section');
    return normalizeSection(fromHash || fromQuery, sections, defaultSectionForRole(role, sections, defaultSection));
  }

  function closeSidebar() {
    root.classList.remove('sidebar-open');
    $('#mobile-menu', root)?.setAttribute('aria-expanded', 'false');
  }

  async function renderCurrent() {
    currentSection = getInitialSection();
    $$('.sidebar-link', root).forEach((link) => {
      const active = link.dataset.section === currentSection;
      link.classList.toggle('active', active);
      if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
    });
    document.title = `${sidebar.find((s) => s.id === currentSection)?.label || 'Panel'} | Reliance Dialysis Center Inc.`;
    sectionRoot.innerHTML = loadingState(`Loading ${sidebar.find((s) => s.id === currentSection)?.label || 'section'}…`);
    try {
      await sections[currentSection].render(sectionRoot, api);
    } catch (error) {
      showError(sectionRoot, error, () => renderCurrent());
    }
  }

  async function loadNotifications() {
    const client = await getSupabase();
    const [listResult, countResult] = await Promise.all([
      client.from('notifications').select('notification_id,title,message,notification_type,related_appointment_id,related_document_id,related_session_id,related_patient_id,destination,action_label,is_read,created_at')
        .eq('recipient_user_id', context.user.id).order('created_at', { ascending: false }).limit(20),
      client.from('notifications').select('notification_id', { count: 'exact', head: true })
        .eq('recipient_user_id', context.user.id).eq('is_read', false)
    ]);
    if (listResult.error) throw new Error(listResult.error.message);
    if (countResult.error) throw new Error(countResult.error.message);
    updateBadge(countResult.count ?? 0);
    return listResult.data || [];
  }

  function updateBadge(count) {
    const badge = $('#notification-badge', root);
    const button = $('#notification-button', root);
    if (button) button.classList.toggle('has-unread', Boolean(count));
    if (!badge) return;
    badge.textContent = String(count);
    badge.hidden = !count;
  }

  function renderNotificationDropdown(items) {
    const dropdown = $('#notification-dropdown', root);
    if (!items.length) {
      dropdown.innerHTML = `<div class="notification-head"><strong>Notifications</strong></div><div class="notification-empty">No notifications yet.</div>`;
      return;
    }
    dropdown.innerHTML = `<div class="notification-head"><strong>Notifications</strong><button type="button" class="text-btn" id="refresh-notifications">Refresh</button></div>
      <div class="notification-list">${items.map((item) => `<button type="button" class="notification-item${item.is_read ? '' : ' unread'}" data-notification-id="${esc(item.notification_id)}">
        <span class="notification-icon" aria-hidden="true">${BELL_SVG}</span><span class="notification-copy"><strong>${esc(item.title)}</strong><span>${esc(item.message)}</span><small>${esc(formatDateTime(item.created_at))} · ${esc(item.action_label || 'Open record')}</small></span><span class="notification-dot" aria-hidden="true"></span>
      </button>`).join('')}</div>`;
    $('#refresh-notifications', dropdown)?.addEventListener('click', async (event) => {
      event.stopPropagation();
      await showNotifications();
    });
    $$('[data-notification-id]', dropdown).forEach((button) => button.addEventListener('click', async () => {
      const item = items.find((x) => x.notification_id === button.dataset.notificationId);
      if (item) await openNotification(item);
    }));
  }

  async function showNotifications() {
    const dropdown = $('#notification-dropdown', root);
    dropdown.hidden = false;
    dropdown.innerHTML = loadingState('Loading notifications…');
    $('#notification-button', root)?.setAttribute('aria-expanded', 'true');
    try { renderNotificationDropdown(await loadNotifications()); }
    catch (error) { dropdown.innerHTML = `<div class="notification-error">${esc(error.message)}</div>`; }
  }

  async function openNotification(notification) {
    try {
      const client = await getSupabase();
      const { error } = await client.from('notifications').update({ is_read: true }).eq('notification_id', notification.notification_id);
      if (error) throw new Error(error.message);
      const target = buildDestinationUrl(notification, role, sections, defaultSection);
      $('#notification-dropdown', root).hidden = true;
      $('#notification-button', root)?.setAttribute('aria-expanded', 'false');
      if (target.targetRole === role) {
        api.navigate(target.section, target.params);
      } else {
        location.assign(`${target.url.pathname}${target.url.search}${target.url.hash}`);
      }
      updateBadge(Math.max(0, Number($('#notification-badge', root)?.textContent || 0) - (notification.is_read ? 0 : 1)));
    } catch (error) {
      toast(error.message || 'Unable to open this notification.', 'error');
    }
  }

  $('#mobile-menu', root)?.addEventListener('click', () => {
    const open = root.classList.toggle('sidebar-open');
    $('#mobile-menu', root)?.setAttribute('aria-expanded', String(open));
  });
  $('.sidebar-close', root)?.addEventListener('click', closeSidebar);
  $$('.sidebar-link', root).forEach((link) => link.addEventListener('click', (event) => {
    event.preventDefault();
    api.navigate(link.dataset.section, {}, { replace: false });
  }));

  $('#notification-button', root)?.addEventListener('click', async (event) => {
    event.stopPropagation();
    const dropdown = $('#notification-dropdown', root);
    if (!dropdown.hidden) { dropdown.hidden = true; $('#notification-button', root).setAttribute('aria-expanded', 'false'); return; }
    await showNotifications();
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.notification-wrap')) {
      const dropdown = $('#notification-dropdown', root);
      if (dropdown) dropdown.hidden = true;
      $('#notification-button', root)?.setAttribute('aria-expanded', 'false');
    }
    if (!event.target.closest('.profile-wrap')) {
      const menu = $('#profile-menu', root);
      if (menu) menu.hidden = true;
      $('#profile-button', root)?.setAttribute('aria-expanded', 'false');
    }
  });

  $('#profile-button', root)?.addEventListener('click', (event) => {
    event.stopPropagation();
    const menu = $('#profile-menu', root);
    menu.hidden = !menu.hidden;
    $('#profile-button', root).setAttribute('aria-expanded', String(!menu.hidden));
  });
  $('[data-profile-action="my-profile"]', root)?.addEventListener('click', () => {
    $('#profile-menu', root).hidden = true;
    api.openProfile();
  });
  $('[data-profile-action="logout"]', root)?.addEventListener('click', async () => {
    try { await signOut(); } catch (error) { toast(error.message, 'error'); }
  });
  $('#sidebar-logout', root)?.addEventListener('click', async () => {
    try { await signOut(); } catch (error) { toast(error.message, 'error'); }
  });

  if (chatbot) {
    renderChatbot($('#panel-chatbot', root), {
      compact: true,
      onNavigate: (section) => api.navigate(section)
    });
  }

  window.addEventListener('hashchange', renderCurrent);
  window.addEventListener('popstate', renderCurrent);
  try { await loadNotifications(); } catch (error) { console.warn('Notification badge unavailable:', error.message); }
  await renderCurrent();
  return api;
}
