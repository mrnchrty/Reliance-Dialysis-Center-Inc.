// Profile editors used from the header profile dropdown and booking gates.
import { $, esc, inputField, textareaField } from './dom.js';
import { getSupabase, rpc, mutate, ApiError } from './supabase.js';
import { openModal, toast, validateForm, setFormMessage, showLoading } from './ui.js';
import {
  personalProfileFields, medicalProfileFields, bindOtherFields,
  readPersonalForm, readMedicalForm, savePersonalProfile, saveMedicalProfile
} from './forms.js';

async function loadPatientProfileData(context) {
  const client = await getSupabase();
  const [patientResult, medicalResult, config] = await Promise.all([
    client.from('patients').select('*').eq('patient_id', context.patientId).single(),
    client.from('patient_medical_profiles').select('*').eq('patient_id', context.patientId).maybeSingle(),
    rpc('get_system_config')
  ]);
  if (patientResult.error) throw new ApiError(patientResult.error.message, patientResult.error);
  if (medicalResult.error) throw new ApiError(medicalResult.error.message, medicalResult.error);
  return { patient: patientResult.data, medical: medicalResult.data || {}, config };
}

export function openPatientProfileModal(context, { onSaved = null, startStep = 1 } = {}) {
  const modal = openModal({
    title: 'My Profile',
    subtitle: 'Saved information is reused for succeeding appointment requests.',
    size: 'large',
    content: '<div class="state-card state-loading"><span class="spinner"></span><h3>Loading your saved profile…</h3></div>',
    actions: [{ label: 'Close', class: 'btn-secondary' }]
  });
  let state = { step: startStep === 2 ? 2 : 1, patient: null, medical: null, config: null };

  async function init() {
    try {
      const data = await loadPatientProfileData(context);
      state = { ...state, ...data };
      render();
    } catch (error) {
      modal.setContent(`<div class="state-card state-error"><h3>Unable to load profile</h3><p>${esc(error.message)}</p></div>`);
    }
  }

  function render() {
    const { step, patient, medical, config } = state;
    const progress = `<div class="mini-stepper"><span class="${step === 1 ? 'active' : 'done'}">1. Personal</span><span class="${step === 2 ? 'active' : ''}">2. Medical</span></div>`;
    if (step === 1) {
      modal.setContent(`${progress}<form id="personal-profile-form" novalidate>${personalProfileFields(patient)}</form>`);
      bindOtherFields(modal.body);
      modal.setActions([
        { label: 'Cancel', class: 'btn-secondary' },
        {
          label: 'Save personal & continue', class: 'btn-primary', close: false,
          onClick: async () => {
            const form = $('#personal-profile-form', modal.body);
            if (!validateForm(form)) return;
            const values = readPersonalForm(form);
            try {
              await savePersonalProfile(context, values);
              state.patient = { ...state.patient, ...values };
              state.step = 2;
              toast('Personal profile saved.', 'success');
              onSaved?.();
              render();
            } catch (error) { setFormMessage(form, error.message, 'error'); }
          }
        }
      ]);
    } else {
      modal.setContent(`${progress}<form id="medical-profile-form" novalidate>${medicalProfileFields(medical, config)}</form>`);
      bindOtherFields(modal.body);
      modal.setActions([
        { label: 'Back', class: 'btn-secondary', close: false, onClick: () => { state.step = 1; render(); } },
        {
          label: 'Save medical profile', class: 'btn-primary', close: false,
          onClick: async () => {
            const form = $('#medical-profile-form', modal.body);
            if (!validateForm(form)) return;
            const values = readMedicalForm(form);
            try {
              await saveMedicalProfile(context, values);
              state.medical = { ...state.medical, ...values };
              toast('Medical profile saved. Important changes were recorded in the audit trail.', 'success');
              onSaved?.();
              modal.close();
            } catch (error) { setFormMessage(form, error.message, 'error'); }
          }
        }
      ]);
    }
  }
  init();
  return modal;
}

export async function openStaffProfileModal(context, { onSaved = null } = {}) {
  const client = await getSupabase();
  const { data: staff, error } = await client.from('staff').select('staff_id,user_id,email,full_name,position,role,contact_number,account_status,permissions')
    .eq('staff_id', context.staffId).single();
  if (error) { toast(error.message, 'error'); return null; }
  const content = `<form id="staff-profile-form" novalidate><div class="form-grid">
    ${inputField({ name: 'email', label: 'Account email', value: staff.email || context.email || '', required: false, attrs: 'readonly' })}
    ${inputField({ name: 'full_name', label: 'Full name', value: staff.full_name || '', required: true })}
    ${inputField({ name: 'position', label: 'Position', value: staff.position || '', required: true, placeholder: 'Free text; use Other wording if needed' })}
    ${inputField({ name: 'contact_number', label: 'Contact number', value: staff.contact_number || '', required: false })}
    ${inputField({ name: 'role', label: 'Protected role', value: staff.role === 'super_admin' ? 'Super Administrator' : 'Staff', required: false, attrs: 'readonly' })}
    ${inputField({ name: 'account_status', label: 'Account status', value: staff.account_status || '', required: false, attrs: 'readonly' })}
  </div><p class="field-hint">Role, status and permissions are protected records managed only through Super Administrator tools.</p></form>`;
  const modal = openModal({
    title: 'My Profile', subtitle: 'Only permitted personal details can be changed here.', content,
    actions: [
      { label: 'Cancel', class: 'btn-secondary' },
      {
        label: 'Save profile', class: 'btn-primary', close: false,
        onClick: async (api) => {
          const form = $('#staff-profile-form', api.body);
          if (!validateForm(form)) return;
          const values = new FormData(form);
          try {
            await mutate(client.from('staff').update({
              full_name: String(values.get('full_name') || '').trim(),
              position: String(values.get('position') || '').trim(),
              contact_number: String(values.get('contact_number') || '').trim() || null
            }).eq('staff_id', staff.staff_id));
            toast('Profile updated.', 'success');
            onSaved?.();
            api.close();
          } catch (error) { setFormMessage(form, error.message, 'error'); }
        }
      }
    ]
  });
  return modal;
}

export function openProfileModal(context, options = {}) {
  if (context.role === 'patient') return openPatientProfileModal(context, options);
  return openStaffProfileModal(context, options);
}
