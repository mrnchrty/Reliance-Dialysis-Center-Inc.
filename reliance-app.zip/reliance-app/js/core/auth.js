// Supabase Auth + protected role resolution. Roles come only from STAFF.
import { getSupabase, getSession, getUser, ApiError } from './supabase.js';
import { savePersonalProfile } from './forms.js';

export const PANEL_PATHS = {
  patient: '/patient/',
  staff: '/staff/',
  super_admin: '/super-admin/'
};

export function authPath(mode = 'login', redirect = '') {
  const params = new URLSearchParams();
  if (mode && mode !== 'login') params.set('mode', mode);
  if (redirect) params.set('redirect', redirect);
  const query = params.toString();
  return `/public/auth.html${query ? `?${query}` : ''}`;
}

export function safeRedirectTarget(candidate, allowedRole) {
  if (!candidate || !allowedRole) return PANEL_PATHS[allowedRole] || '/';
  try {
    const url = new URL(candidate, location.origin);
    if (url.origin !== location.origin) return PANEL_PATHS[allowedRole] || '/';
    const allowedPath = PANEL_PATHS[allowedRole]?.replace(/\/$/, '') || '';
    if (allowedPath && !url.pathname.startsWith(allowedPath)) return PANEL_PATHS[allowedRole] || '/';
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return PANEL_PATHS[allowedRole] || '/';
  }
}

export async function loadRoleContext() {
  const client = await getSupabase();
  const user = await getUser();
  if (!user) return null;

  const [staffResult, patientResult] = await Promise.all([
    client.from('staff').select('staff_id,user_id,email,full_name,position,role,contact_number,account_status,permissions,last_login_at')
      .eq('user_id', user.id).maybeSingle(),
    client.from('patients').select('patient_id,user_id,email,full_name,date_of_birth,sex,sex_other,address,contact_number,emergency_contact_name,emergency_contact_number,account_status,profile_completed_at,created_at')
      .eq('user_id', user.id).maybeSingle()
  ]);
  if (staffResult.error) throw new ApiError(staffResult.error.message, staffResult.error);
  if (patientResult.error) throw new ApiError(patientResult.error.message, patientResult.error);

  const staff = staffResult.data || null;
  const patient = patientResult.data || null;
  let role = null;
  if (staff && staff.account_status === 'Active' && ['staff', 'super_admin'].includes(staff.role)) role = staff.role;
  else if (patient && patient.account_status === 'Active') role = 'patient';

  const displayName = role === 'patient' ? (patient?.full_name || user.user_metadata?.full_name || user.email?.split('@')[0] || 'Patient')
    : (staff?.full_name || user.user_metadata?.full_name || user.email?.split('@')[0] || 'Staff');

  return {
    user,
    role,
    staff,
    patient,
    displayName,
    email: user.email || staff?.email || patient?.email || '',
    patientId: patient?.patient_id || null,
    staffId: staff?.staff_id || null,
    permissions: staff?.permissions || {},
    isSuperAdmin: role === 'super_admin',
    isActive: Boolean(role)
  };
}

export async function guardRole(requiredRole, { redirectToAuth = true } = true) {
  let context;
  try {
    context = await loadRoleContext();
  } catch (error) {
    if (redirectToAuth) {
      sessionStorage.setItem('reliance-auth-error', error.message || 'Unable to verify your session.');
      location.replace(authPath('login', location.pathname + location.search + location.hash));
    }
    throw error;
  }
  if (!context || context.role !== requiredRole) {
    if (redirectToAuth) {
      if (context?.role) location.replace(PANEL_PATHS[context.role]);
      else location.replace(authPath('login', location.pathname + location.search + location.hash));
    }
    throw new ApiError(context?.role ? `This area is restricted to ${requiredRole.replaceAll('_', ' ')} accounts.` : 'Please log in to continue.');
  }
  return context;
}

export async function redirectByRole(context, fallbackRedirect = '') {
  if (!context?.role) {
    location.replace(authPath());
    return;
  }
  location.replace(safeRedirectTarget(fallbackRedirect, context.role));
}

export async function registerPatient({ fullName, email, password, personal = null }) {
  const client = await getSupabase();
  const { data, error } = await client.auth.signUp({
    email: email.trim().toLowerCase(),
    password,
    options: {
      data: { full_name: fullName.trim(), intended_role: 'patient', ...(personal ? { personal_profile: personal } : {}) },
      emailRedirectTo: `${location.origin}/public/auth.html?mode=login&confirmed=1`
    }
  });
  if (error) throw new ApiError(error.message, error);
  return data;
}

export async function signIn({ email, password }) {
  const client = await getSupabase();
  const { data, error } = await client.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
  if (error) throw new ApiError(error.message, error);
  return data;
}

export async function sendPasswordReset(email) {
  const client = await getSupabase();
  const { error } = await client.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
    redirectTo: `${location.origin}/public/auth.html?mode=reset`
  });
  if (error) throw new ApiError(error.message, error);
}

export async function updatePassword(password) {
  const client = await getSupabase();
  const { error } = await client.auth.updateUser({ password });
  if (error) throw new ApiError(error.message, error);
}

export async function signOut() {
  const client = await getSupabase();
  const { error } = await client.auth.signOut();
  if (error) throw new ApiError(error.message, error);
  sessionStorage.removeItem('reliance-auth-error');
  location.replace(authPath('login', ''));
}

export async function getActiveSession() {
  return getSession();
}

// Personal details entered during sign-up are kept in the account data until the
// first login after email confirmation. Returns the onboarding step to open next
// ('medical' when saved, 'personal' when saving failed) or null when nothing is pending.
export async function completePendingPersonalProfile(context) {
  const pending = context?.user?.user_metadata?.personal_profile;
  if (context?.role !== 'patient' || !pending || context.patient?.date_of_birth) return null;
  try {
    await savePersonalProfile(context, pending);
    return 'medical';
  } catch {
    return 'personal';
  }
}
