// Live Supabase capacity calendar and a simple month grid for operational lists.
import { esc, dateISO, monthBounds, parseISODate, addDays, manilaTodayISO, formatDate } from './dom.js';
import { rpc } from './supabase.js';

export function monthDate(year, monthIndex) {
  return new Date(Date.UTC(year, monthIndex, 1, 12));
}

export async function ensureCapacityForRange(start, end) {
  if (!start || !end || end < start) return 0;
  const config = await rpc('get_system_config');
  const maxAdvance = Number(config?.max_advance_days ?? 90);
  const today = manilaTodayISO();
  const clampedStart = start < today ? today : start;
  const clampedEnd = end > addDays(today, maxAdvance) ? addDays(today, maxAdvance) : end;
  if (clampedEnd < clampedStart) return 0;
  return rpc('ensure_capacity_slots', { p_start_date: clampedStart, p_end_date: clampedEnd });
}

export async function loadAvailabilityForMonth(year, monthIndex) {
  const { start, end } = monthBounds(year, monthIndex);
  await ensureCapacityForRange(start, end);
  const availability = await rpc('get_schedule_availability', { p_start_date: start, p_end_date: end });
  return { availability, config: availability?.config || await rpc('get_system_config') };
}

export function availabilityByDate(availability) {
  const map = new Map();
  for (const entry of availability?.dates || []) map.set(String(entry.date).slice(0, 10), entry);
  return map;
}

export function enabledSlots(dateInfo) {
  return (dateInfo?.slots || []).filter((slot) => slot.enabled && Number(slot.available) > 0);
}

function monthLabel(date) {
  return new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', month: 'long', year: 'numeric' }).format(date);
}

function calendarFrame({ container, date, prevLabel = 'Previous month', nextLabel = 'Next month', onMonthChange, legend = '' }) {
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth();
  const header = `<div class="calendar-header"><button type="button" class="icon-btn" data-calendar-prev aria-label="${esc(prevLabel)}">‹</button><strong>${esc(monthLabel(date))}</strong><button type="button" class="icon-btn" data-calendar-next aria-label="${esc(nextLabel)}">›</button></div>`;
  const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => `<span>${d}</span>`).join('');
  container.innerHTML = `${header}<div class="calendar-weekdays">${weekdays}</div><div class="calendar-grid" role="grid"></div>${legend ? `<div class="calendar-legend">${legend}</div>` : ''}`;
  const grid = container.querySelector('.calendar-grid');
  container.querySelector('[data-calendar-prev]').addEventListener('click', () => onMonthChange(monthDate(year, month - 1)));
  container.querySelector('[data-calendar-next]').addEventListener('click', () => onMonthChange(monthDate(year, month + 1)));
  return { grid, year, month };
}

export function renderAvailabilityCalendar({ container, monthDate: month, availability, selectedDate = '', onSelect, onMonthChange }) {
  const map = availabilityByDate(availability);
  const today = manilaTodayISO();
  const { grid } = calendarFrame({
    container, date: month, onMonthChange,
    legend: '<span><i class="legend-dot available"></i> Available capacity</span><span><i class="legend-dot closed"></i> Closed / unavailable</span><span><i class="legend-dot selected"></i> Selected</span><small>Live derived capacity from MACHINE_SLOTS; Sundays are closed.</small>'
  });
  const { start, end } = monthBounds(month.getUTCFullYear(), month.getUTCMonth());
  const first = parseISODate(start);
  const offset = (first.getUTCDay() + 6) % 7;
  const totalDays = Number(end.slice(8, 10));
  for (let i = 0; i < offset; i += 1) grid.append(document.createElement('div'));
  for (let day = 1; day <= totalDays; day += 1) {
    const iso = `${start.slice(0, 8)}${String(day).padStart(2, '0')}`;
    const date = parseISODate(iso);
    const isSunday = date.getUTCDay() === 0;
    const info = map.get(iso);
    const availableSlots = enabledSlots(info);
    const capacity = Number(info?.available ?? 0);
    const disabled = isSunday || !info || !info.operating_day || capacity <= 0 || availableSlots.length === 0 || iso < today;
    const state = isSunday ? 'Closed' : iso < today ? 'Past' : capacity <= 0 ? 'Full' : `${capacity} slot${capacity === 1 ? '' : 's'}`;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `calendar-day${disabled ? ' is-disabled' : ''}${iso === selectedDate ? ' is-selected' : ''}${capacity > 0 && !disabled ? ' has-capacity' : ''}`;
    button.disabled = disabled;
    button.dataset.date = iso;
    button.setAttribute('aria-label', `${formatDate(iso, true)}, ${state}`);
    button.innerHTML = `<span class="day-number">${day}</span><span class="day-capacity">${esc(state)}</span>`;
    if (!disabled) button.addEventListener('click', () => onSelect(iso, info));
    grid.append(button);
  }
}

export function renderTimeSlotPicker({ container, dateInfo, config, selectedTime = '', onSelect }) {
  const slots = dateInfo?.slots || [];
  if (!dateInfo || !slots.length) {
    container.innerHTML = '<div class="inline-note">No configured time windows are available for this date.</div>';
    return;
  }
  container.innerHTML = `<div class="time-slot-grid">${slots.map((slot) => {
    const enabled = Boolean(slot.enabled) && Number(slot.available) > 0;
    return `<button type="button" class="time-slot-card${selectedTime === slot.slot_id ? ' is-selected' : ''}${enabled ? '' : ' is-disabled'}" data-slot="${esc(slot.slot_id)}" ${enabled ? '' : 'disabled'}>
      <span class="time-slot-label">${esc(slot.label || slot.slot_id)}</span>
      <strong>${esc(slot.display || `${slot.start_time}–${slot.end_time}`)}</strong>
      <small>${enabled ? `${esc(slot.available)} of ${esc(slot.total)} machine slots available` : 'Not available'}</small>
    </button>`;
  }).join('')}</div>
  <p class="field-hint">Proposed windows are configurable: Morning 8:00 AM–11:00 AM, Midday 11:00 AM–2:00 PM, Afternoon 2:00 PM–5:00 PM. Duration and turnaround are subject to final center confirmation. Patients select a preferred time only; staff assigns machines.</p>`;
  container.querySelectorAll('[data-slot]').forEach((button) => {
    button.addEventListener('click', () => onSelect(button.dataset.slot, slots.find((s) => s.slot_id === button.dataset.slot)));
  });
}

export function renderMonthCalendar({ container, monthDate: month, eventsByDate = {}, selectedDate = '', onSelect, onMonthChange }) {
  const { grid } = calendarFrame({
    container, date: month, onMonthChange,
    legend: '<small>Counts are appointment records stored in Supabase. Select a date to filter the request list.</small>'
  });
  const { start, end } = monthBounds(month.getUTCFullYear(), month.getUTCMonth());
  const first = parseISODate(start);
  const offset = (first.getUTCDay() + 6) % 7;
  const totalDays = Number(end.slice(8, 10));
  for (let i = 0; i < offset; i += 1) grid.append(document.createElement('div'));
  for (let day = 1; day <= totalDays; day += 1) {
    const iso = `${start.slice(0, 8)}${String(day).padStart(2, '0')}`;
    const count = Number(eventsByDate[iso] || 0);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `calendar-day compact${iso === selectedDate ? ' is-selected' : ''}${count ? ' has-events' : ''}`;
    button.dataset.date = iso;
    button.innerHTML = `<span class="day-number">${day}</span><span class="day-capacity">${count ? `${count} request${count === 1 ? '' : 's'}` : '—'}</span>`;
    button.addEventListener('click', () => onSelect(iso));
    grid.append(button);
  }
}
