// Runtime configuration loader. Browser code never contains a hard-coded key.
// The same-origin /api/config endpoint is implemented by api/config.js on Vercel
// and by server.mjs for the local preview.

let configPromise = null;

export async function loadConfig() {
  if (!configPromise) {
    configPromise = fetch('/api/config', { cache: 'no-store', credentials: 'same-origin' })
      .then(async (response) => {
        const payload = await response.json().catch(() => ({}));
        if (!response.ok || payload.error) {
          throw new Error(payload.error || `Runtime configuration request failed (${response.status}).`);
        }
        if (!payload.supabaseUrl || !payload.publishableKey) {
          throw new Error('Supabase URL and publishable key must be set in the server environment.');
        }
        return Object.freeze(payload);
      })
      .catch((error) => {
        configPromise = null;
        throw error;
      });
  }
  return configPromise;
}

export function clearConfigCache() {
  configPromise = null;
}
