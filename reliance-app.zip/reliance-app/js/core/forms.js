// Profile field definitions, "Other" handling and DB-backed profile saves.
import { $, $$, esc, selectField, inputField, textareaField, formData, SELECT_PLACEHOLDER, manilaTodayISO } from './dom.js';
import { getSupabase, mutate } from './supabase.js';

export const WEEKDAY_NAMES = {
  1: 'Monday', 2: 'Tuesday', 3: 'Wednesday', 4: 'Thursday', 5: 'Friday', 6: 'Saturday', 7: 'Sunday'
};

export const CIVIL_STATUS_OPTIONS = ['Single', 'Married', 'Widowed', 'Separated', 'Divorced'];

export const PERSONAL_LABELS = {
  full_name: 'Full name', sex: 'Gender', date_of_birth: 'Birthdate', civil_status: 'Civil status',
  contact_number: 'Contact number', address: 'Home address',
  emergency_contact_name: 'Emergency contact name', emergency_contact_number: 'Emergency contact number'
};

export const MEDICAL_LABELS = {
  height: 'Height', weight: 'Baseline weight (general profile)', blood_type: 'Blood type',
  diagnosis: 'Medical diagnosis', allergies: 'Allergies', existing_medical_conditions: 'Existing medical conditions',
  previous_surgeries: 'Previous surgeries', current_medications: 'Current medications',
  attending_nephrologist: 'Attending nephrologist', prescribed_dialysis_frequency: 'Prescribed dialysis frequency'
};

export function configTimeSlots(config) {
  return Array.isArray(config?.time_slots) ? config.time_slots : [];
}

export function configOperatingDays(config) {
  const days = Array.isArray(config?.operating_days) ? config.operating_days.map(Number) : [1, 2, 3, 4, 5, 6];
  return days.filter((d) => d >= 1 && d <= 6); // Sunday remains closed.
}

export function requiredDocumentTypes(config) {
  return Array.isArray(config?.required_document_types) ? config.required_document_types : [];
}

export function prettyDocumentType(value) {
  return String(value || '').replace("'s", '’s');
}

export function slotDisplay(config, slotId) {
  const slot = configTimeSlots(config).find((s) => s.id === slotId);
  return slot?.display || slot?.label || slotId || '—';
}

function otherTextField({ name, label, value = '', hint = '' }) {
  return `<div class="form-field other-field" data-other-wrapper="${esc(name)}" hidden>
    <label for="field-${esc(name)}">${esc(label)} <span class="required" title="Required">*</span></label>
    <input id="field-${esc(name)}" name="${esc(name)}" type="text" value="${esc(value)}" placeholder="Please specify" />
    ${hint ? `<small class="field-hint">${esc(hint)}</small>` : ''}
    <small class="field-error" aria-live="polite"></small>
  </div>`;
}

export function bindOtherFields(root) {
  const triggers = $$('[data-other-trigger]', root);
  for (const trigger of triggers) {
    const target = trigger.dataset.otherTrigger;
    const expected = trigger.dataset.otherValue || 'Other';
    const wrapper = $(`[data-other-wrapper="${CSS.escape(target)}"]`, root);
    const field = wrapper?.querySelector('input, textarea, select');
    const sync = () => {
      const visible = trigger.value === expected;
      if (wrapper) wrapper.hidden = !visible;
      if (field) {
        field.required = visible;
        if (!visible) field.classList.remove('invalid');
      }
    };
    trigger.addEventListener('change', sync);
    sync();
  }
  bindAgeField(root);
}

// Whole years between a birthdate (YYYY-MM-DD) and today in Manila. Returns '' when unknown or in the future.
export function ageFromBirthdate(iso, today = manilaTodayISO()) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ''));
  if (!match) return '';
  const [birthYear, birthMonth, birthDay] = match.slice(1).map(Number);
  const [nowYear, nowMonth, nowDay] = String(today).split('-').map(Number);
  if (!nowYear) return '';
  let years = nowYear - birthYear;
  if (nowMonth < birthMonth || (nowMonth === birthMonth && nowDay < birthDay)) years -= 1;
  return years < 0 ? '' : String(years);
}

// The personal details shared by sign-up and the profile form, in the order: name, gender, age, birthdate,
// civil status, contact number, home address. Age is calculated from the birthdate and is never saved on its own.
function personalDetailFields(patient = {}) {
  const sex = patient.sex || '';
  const civil = patient.civil_status || '';
  return `${inputField({ name: 'full_name', label: 'Full name', value: patient.full_name || '', required: true, placeholder: 'As written on your identification', autocomplete: 'name', className: 'span-2' })}
    <div class="form-field">
      <label for="field-sex">Gender <span class="required" title="Required">*</span></label>
      <select id="field-sex" name="sex" required data-other-trigger="sex_other" data-other-value="Other">
        <option value="" disabled${!sex ? ' selected' : ''}>${SELECT_PLACEHOLDER}</option>
        ${['Female', 'Male', 'Prefer not to say', 'Other'].map((v) => `<option value="${esc(v)}"${sex === v ? ' selected' : ''}>${esc(v)}</option>`).join('')}
      </select><small class="field-error" aria-live="polite"></small>
    </div>
    ${otherTextField({ name: 'sex_other', label: 'Specify gender', value: patient.sex_other || '' })}
    ${inputField({ name: 'age', label: 'Age', value: ageFromBirthdate(patient.date_of_birth), attrs: 'readonly', hint: 'Calculated from your birthdate.' })}
    ${inputField({ name: 'date_of_birth', label: 'Birthdate', type: 'date', value: patient.date_of_birth || '', required: true, max: manilaTodayISO() })}
    <div class="form-field">
      <label for="field-civil_status">Civil status <span class="required" title="Required">*</span></label>
      <select id="field-civil_status" name="civil_status" required>
        <option value="" disabled${!civil ? ' selected' : ''}>${SELECT_PLACEHOLDER}</option>
        ${CIVIL_STATUS_OPTIONS.map((v) => `<option value="${esc(v)}"${civil === v ? ' selected' : ''}>${esc(v)}</option>`).join('')}
      </select><small class="field-error" aria-live="polite"></small>
    </div>
    ${inputField({ name: 'contact_number', label: 'Contact number', value: patient.contact_number || '', required: true, placeholder: 'Phone or mobile number', autocomplete: 'tel' })}
    ${textareaField({ name: 'address', label: 'Home address', value: patient.address || '', required: true, placeholder: 'House / street, barangay, city, province', rows: 2, className: 'span-2' })}`;
}

// Sign-up step 1: personal details only. Emergency contact is collected later in the profile.
export function personalSignupFields(patient = {}) {
  return `<div class="form-grid">${personalDetailFields(patient)}</div>`;
}

export function personalProfileFields(patient = {}, { includeEmail = true } = {}) {
  return `<div class="form-grid">
    ${includeEmail ? inputField({ name: 'email', label: 'Account email', value: patient.email || '', required: false, attrs: 'readonly', hint: 'Account email is managed through Supabase Auth.' }) : ''}
    ${personalDetailFields(patient)}
    ${inputField({ name: 'emergency_contact_name', label: 'Emergency contact name', value: patient.emergency_contact_name || '', required: true })}
    ${inputField({ name: 'emergency_contact_number', label: 'Emergency contact number', value: patient.emergency_contact_number || '', required: true, autocomplete: 'tel' })}
  </div>`;
}

// Keeps the Age box in step with the birthdate.
export function bindAgeField(root) {
  const dob = root.querySelector('[name="date_of_birth"]');
  const age = root.querySelector('[name="age"]');
  if (!dob || !age) return;
  const update = () => { age.value = ageFromBirthdate(dob.value); };
  dob.addEventListener('input', update);
  dob.addEventListener('change', update);
}

export function medicalProfileFields(profile = {}, config = {}) {
  const slots = configTimeSlots(config);
  const days = configOperatingDays(config);
  const selectedDays = Array.isArray(profile.recurring_days) ? profile.recurring_days : [];
  const blood = profile.blood_type || '';
  const knownBlood = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'];
  const bloodIsOther = blood && !knownBlood.includes(blood) && blood !== 'Other';
  const frequency = profile.prescribed_dialysis_frequency || '';
  const frequencyOptions = ['Once weekly', 'Twice weekly', 'Three times weekly', 'Four times weekly', 'As prescribed by nephrologist', 'Other'];
  const frequencyIsOther = frequency && !frequencyOptions.includes(frequency);
  const preferred = profile.preferred_time || '';
  const preferredIsOther = preferred && !slots.some((s) => s.id === preferred);
  return `<div class="form-grid">
    ${inputField({ name: 'height', label: 'Height (cm)', type: 'number', min: '1', max: '300', step: '0.01', value: profile.height ?? '', required: true, placeholder: 'e.g. 160' })}
    ${inputField({ name: 'weight', label: 'Baseline weight (kg)', type: 'number', min: '1', max: '500', step: '0.01', value: profile.weight ?? '', required: true, placeholder: 'General profile weight only', hint: 'This is separate from pre- and post-dialysis session weights.' })}
    <div class="form-field">
      <label for="field-blood_type">Blood type <span class="required" title="Required">*</span></label>
      <select id="field-blood_type" name="blood_type" required data-other-trigger="blood_type_custom" data-other-value="Other">
        <option value="" disabled${!blood ? ' selected' : ''}>${SELECT_PLACEHOLDER}</option>
        ${knownBlood.map((v) => `<option value="${esc(v)}"${blood === v ? ' selected' : ''}>${esc(v)}</option>`).join('')}
        <option value="Other"${bloodIsOther || blood === 'Other' ? ' selected' : ''}>Other</option>
      </select><small class="field-error" aria-live="polite"></small>
    </div>
    ${otherTextField({ name: 'blood_type_custom', label: 'Specify blood type', value: bloodIsOther ? blood : '' })}
    ${textareaField({ name: 'diagnosis', label: 'Medical diagnosis', value: profile.diagnosis || '', required: true, placeholder: 'Free text; enter the diagnosis as provided by your physician', rows: 3 })}
    ${textareaField({ name: 'allergies', label: 'Allergies', value: profile.allergies || '', required: true, placeholder: 'Write “None”, “Unknown”, or the known allergies', rows: 2 })}
    ${inputField({ name: 'allergy_other', label: 'Other allergy details', value: profile.allergy_other || '', required: false, placeholder: 'Add details if the list of known allergies is insufficient' })}
    ${textareaField({ name: 'existing_medical_conditions', label: 'Existing medical conditions', value: profile.existing_medical_conditions || '', required: true, placeholder: 'Write “None”, “Unknown”, or list the conditions', rows: 2 })}
    ${inputField({ name: 'condition_other', label: 'Other condition details', value: profile.condition_other || '', required: false, placeholder: 'Add details not covered above' })}
    ${textareaField({ name: 'previous_surgeries', label: 'Previous surgeries', value: profile.previous_surgeries || '', required: true, placeholder: 'Write “None”, “Unknown”, or list previous surgeries', rows: 2 })}
    ${inputField({ name: 'surgery_other', label: 'Other surgery details', value: profile.surgery_other || '', required: false, placeholder: 'Add details not covered above' })}
    ${textareaField({ name: 'current_medications', label: 'Current medications', value: profile.current_medications || '', required: true, placeholder: 'Write “None”, “Unknown”, or list current medications', rows: 2 })}
    ${inputField({ name: 'attending_nephrologist', label: 'Attending nephrologist', value: profile.attending_nephrologist || '', required: true, placeholder: 'Name of attending nephrologist' })}
    <div class="form-field">
      <label for="field-prescribed_dialysis_frequency">Prescribed dialysis frequency <span class="required" title="Required">*</span></label>
      <select id="field-prescribed_dialysis_frequency" name="prescribed_dialysis_frequency" required data-other-trigger="frequency_other" data-other-value="Other">
        <option value="" disabled${!frequency ? ' selected' : ''}>${SELECT_PLACEHOLDER}</option>
        ${frequencyOptions.map((v) => `<option value="${esc(v)}"${frequency === v || (frequencyIsOther && v === 'Other') ? ' selected' : ''}>${esc(v)}</option>`).join('')}
      </select><small class="field-error" aria-live="polite"></small>
    </div>
    ${otherTextField({ name: 'frequency_other', label: 'Specify prescribed frequency', value: frequencyIsOther ? frequency : (profile.frequency_other || ''), hint: 'Subject to center and nephrologist confirmation.' })}
    ${inputField({ name: 'dialysis_start_date', label: 'Dialysis start date', type: 'date', value: profile.dialysis_start_date || '', required: false, max: manilaTodayISO() })}
    ${inputField({ name: 'previous_dialysis_center', label: 'Previous dialysis center', value: profile.previous_dialysis_center || '', required: false, placeholder: 'Optional' })}
  </div>
  <div class="form-divider"><h3>Recurring appointment preferences</h3><p>Used by authorized staff only when preparing recurring appointment suggestions. Sunday remains closed.</p></div>
  <div class="form-grid">
    <div class="form-field span-2">
      <label>Recurring days <span class="optional">Optional</span></label>
      <div class="checkbox-grid">${[1, 2, 3, 4, 5, 6].map((d) => `<label><input type="checkbox" name="recurring_days" value="${esc(WEEKDAY_NAMES[d])}" ${selectedDays.includes(WEEKDAY_NAMES[d]) ? 'checked' : ''} ${days.includes(d) ? '' : 'disabled'} /> <span>${esc(WEEKDAY_NAMES[d])}${days.includes(d) ? '' : ' (closed)'}</span></label>`).join('')}</div>
      <small class="field-hint">Only configured operating days can be selected.</small>
    </div>
    <div class="form-field">
      <label for="field-preferred_time">Preferred time <span class="optional">Optional</span></label>
      <select id="field-preferred_time" name="preferred_time" data-other-trigger="preferred_time_other" data-other-value="Other">
        <option value=""${!preferred ? ' selected' : ''}>${SELECT_PLACEHOLDER}</option>
        ${slots.map((s) => `<option value="${esc(s.id)}"${preferred === s.id ? ' selected' : ''}>${esc(s.display || s.label || s.id)}</option>`).join('')}
        <option value="Other"${preferredIsOther ? ' selected' : ''}>Other</option>
      </select><small class="field-error" aria-live="polite"></small>
    </div>
    ${otherTextField({ name: 'preferred_time_other', label: 'Specify preferred time', value: preferredIsOther ? preferred : (profile.preferred_time_other || ''), hint: 'Other preferences require staff review and a configured schedule.' })}
  </div>`;
}

export function missingPersonalFields(patient = {}) {
  const missing = [];
  for (const [key, label] of Object.entries(PERSONAL_LABELS)) {
    if (!String(patient[key] ?? '').trim()) missing.push(label);
  }
  if (patient.sex === 'Other' && !String(patient.sex_other || '').trim()) missing.push('Specify gender');
  return missing;
}

export function missingMedicalFields(profile = {}) {
  const missing = [];
  for (const [key, label] of Object.entries(MEDICAL_LABELS)) {
    const value = profile[key];
    if (value === null || value === undefined || String(value).trim() === '') missing.push(label);
  }
  if (profile.prescribed_dialysis_frequency === 'Other' && !String(profile.frequency_other || '').trim()) missing.push('Specify prescribed frequency');
  if (profile.preferred_time === 'Other' && !String(profile.preferred_time_other || '').trim()) missing.push('Specify preferred time');
  return missing;
}

export function readPersonalForm(form) {
  const data = formData(form);
  const sexOther = String(data.sex_other || '').trim();
  const values = {
    full_name: String(data.full_name || '').trim(),
    date_of_birth: data.date_of_birth || null,
    sex: String(data.sex || '').trim(),
    sex_other: data.sex === 'Other' ? sexOther : null,
    civil_status: String(data.civil_status || '').trim() || null,
    address: String(data.address || '').trim(),
    contact_number: String(data.contact_number || '').trim()
  };
  // Sign-up does not show emergency contact fields, so do not write blanks over saved values.
  if (form.querySelector('[name="emergency_contact_name"]')) {
    values.emergency_contact_name = String(data.emergency_contact_name || '').trim();
    values.emergency_contact_number = String(data.emergency_contact_number || '').trim();
  }
  return values;
}

export function readMedicalForm(form) {
  const data = formData(form);
  let bloodType = String(data.blood_type || '').trim();
  if (bloodType === 'Other') bloodType = String(data.blood_type_custom || '').trim();
  let frequency = String(data.prescribed_dialysis_frequency || '').trim();
  if (frequency === 'Other') frequency = String(data.frequency_other || '').trim();
  let preferredTime = String(data.preferred_time || '').trim();
  if (preferredTime === 'Other') preferredTime = String(data.preferred_time_other || '').trim();
  const recurring = data.recurring_days === undefined ? [] : (Array.isArray(data.recurring_days) ? data.recurring_days : [data.recurring_days]);
  return {
    height: data.height === '' ? null : Number(data.height),
    weight: data.weight === '' ? null : Number(data.weight),
    blood_type: bloodType || null,
    allergies: String(data.allergies || '').trim() || null,
    allergy_other: String(data.allergy_other || '').trim() || null,
    diagnosis: String(data.diagnosis || '').trim() || null,
    existing_medical_conditions: String(data.existing_medical_conditions || '').trim() || null,
    condition_other: String(data.condition_other || '').trim() || null,
    previous_surgeries: String(data.previous_surgeries || '').trim() || null,
    surgery_other: String(data.surgery_other || '').trim() || null,
    current_medications: String(data.current_medications || '').trim() || null,
    attending_nephrologist: String(data.attending_nephrologist || '').trim() || null,
    prescribed_dialysis_frequency: frequency || null,
    frequency_other: frequency === 'Other' ? String(data.frequency_other || '').trim() || null : null,
    dialysis_start_date: data.dialysis_start_date || null,
    previous_dialysis_center: String(data.previous_dialysis_center || '').trim() || null,
    recurring_days: recurring.map(String),
    preferred_time: preferredTime || null,
    preferred_time_other: preferredTime === 'Other' ? String(data.preferred_time_other || '').trim() || null : null
  };
}

export async function savePersonalProfile(context, values) {
  const client = await getSupabase();
  const complete = missingPersonalFields(values).length === 0;
  const payload = { ...values, profile_completed_at: complete ? new Date().toISOString() : null };
  await mutate(client.from('patients').update(payload).eq('patient_id', context.patientId));
  return complete;
}

export async function saveMedicalProfile(context, values) {
  const client = await getSupabase();
  const complete = missingMedicalFields(values).length === 0;
  const payload = {
    patient_id: context.patientId,
    ...values,
    profile_updated_by: context.user.id,
    profile_completed_at: complete ? new Date().toISOString() : null
  };
  await mutate(client.from('patient_medical_profiles').upsert(payload, { onConflict: 'patient_id' }));
  return complete;
}

export function renderProfileCompletion(patient, medical, config) {
  const personalMissing = missingPersonalFields(patient || {});
  const medicalMissing = missingMedicalFields(medical || {});
  const all = [...personalMissing.map((x) => `Personal: ${x}`), ...medicalMissing.map((x) => `Medical: ${x}`)];
  const complete = all.length === 0;
  return {
    complete,
    personalMissing,
    medicalMissing,
    html: `<div class="profile-status ${complete ? 'is-complete' : 'is-incomplete'}">
      <strong>${complete ? 'Profile complete' : 'Information still needed'}</strong>
      <p>${complete ? 'Saved personal and medical information can be reused for succeeding appointment requests.' : 'Complete the following before submitting an appointment request:'}</p>
      ${complete ? '' : `<ul>${all.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>`}
    </div>`
  };
}
