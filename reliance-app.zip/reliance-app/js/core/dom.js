// Small DOM, formatting and form helpers shared by every ES module.
// All dynamic values are escaped before insertion into innerHTML.

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

export function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}
export const esc = escapeHtml;

export function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class' || key === 'className') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'html') node.innerHTML = value;
    else if (key === 'dataset') Object.assign(node.dataset, value);
    else if (key === 'style' && typeof value === 'object') Object.assign(node.style, value);
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
    else if (key === 'disabled' || key === 'checked' || key === 'selected' || key === 'required' || key === 'multiple') {
      if (value) node.setAttribute(key, '');
    } else node.setAttribute(key, value);
  }
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

export function setHTML(container, html) {
  if (container instanceof Element) container.innerHTML = html;
  return container;
}

export function clear(container) {
  if (container instanceof Element) container.replaceChildren();
  return container;
}

export function debounce(fn, wait = 220) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

const dateFormatter = new Intl.DateTimeFormat('en-US', {
  timeZone: 'Asia/Manila', year: 'numeric', month: 'short', day: '2-digit'
});
const longDateFormatter = new Intl.DateTimeFormat('en-US', {
  timeZone: 'Asia/Manila', weekday: 'short', year: 'numeric', month: 'long', day: 'numeric'
});
const dateTimeFormatter = new Intl.DateTimeFormat('en-US', {
  timeZone: 'Asia/Manila', year: 'numeric', month: 'short', day: '2-digit',
  hour: 'numeric', minute: '2-digit', hour12: true
});
const timeFormatter = new Intl.DateTimeFormat('en-US', {
  timeZone: 'Asia/Manila', hour: 'numeric', minute: '2-digit', hour12: true
});

export function manilaTodayISO() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(new Date());
  const get = (type) => parts.find((p) => p.type === type)?.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

export function parseISODate(value) {
  if (!value) return null;
  const [y, m, d] = String(value).slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return null;
  return new Date(Date.UTC(y, m - 1, d, 12));
}

export function dateISO(date) {
  if (date instanceof Date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  return String(date || '').slice(0, 10);
}

export function addDays(iso, days) {
  const date = parseISODate(iso) ?? new Date();
  date.setUTCDate(date.getUTCDate() + Number(days || 0));
  return date.toISOString().slice(0, 10);
}

export function monthBounds(year, monthIndex) {
  const start = new Date(Date.UTC(year, monthIndex, 1, 12));
  const end = new Date(Date.UTC(year, monthIndex + 1, 0, 12));
  return { start: dateISO(start), end: dateISO(end) };
}

export function formatDate(value, long = false) {
  if (!value) return '—';
  const date = typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)
    ? parseISODate(value) : new Date(value);
  if (!date || Number.isNaN(date.getTime())) return '—';
  return (long ? longDateFormatter : dateFormatter).format(date);
}

export function formatDateTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return dateTimeFormatter.format(date);
}

export function formatTime(value) {
  if (!value) return '—';
  if (/^\d{2}:\d{2}(:\d{2})?$/.test(String(value))) {
    const [h, m] = String(value).split(':').map(Number);
    const d = new Date(Date.UTC(2026, 0, 1, h, m));
    return timeFormatter.format(d).replace('UTC', '').trim();
  }
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : timeFormatter.format(date);
}

export function formatBytes(value) {
  const n = Number(value || 0);
  if (!n) return '—';
  if (n < 1024) return `${n} B`;
  if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1048576).toFixed(1)} MB`;
}

export function shortId(value) {
  const text = String(value || '').replaceAll('-', '').toUpperCase();
  return text ? text.slice(0, 8) : '—';
}

export function titleCase(value) {
  return String(value || '').replace(/[_-]+/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

export function statusClass(status) {
  const value = String(status || '').toLowerCase();
  if (['verified', 'confirmed', 'active', 'available', 'attended', 'completed', 'released'].some((x) => value.includes(x))) return 'success';
  if (['pending', 'under review', 'scheduled', 'info', 'reserved'].some((x) => value.includes(x))) return 'warning';
  if (['rejected', 'needs correction', 'inactive', 'offline', 'unavailable', 'no-show', 'cancelled', 'error'].some((x) => value.includes(x))) return 'danger';
  if (value.includes('maintenance')) return 'neutral';
  return 'info';
}

export function badge(text, kind = '') {
  return `<span class="badge badge-${kind || statusClass(text)}">${esc(text || '—')}</span>`;
}

export function emptyState(title, message, action = '') {
  return `<div class="state-card state-empty"><span class="state-icon" aria-hidden="true">○</span><h3>${esc(title)}</h3><p>${esc(message)}</p>${action}</div>`;
}

export function loadingState(label = 'Loading live records…') {
  return `<div class="state-card state-loading"><span class="spinner" aria-hidden="true"></span><h3>${esc(label)}</h3><p>Reading authorized Supabase data.</p></div>`;
}

export function errorState(message, retryLabel = 'Try again') {
  return `<div class="state-card state-error"><span class="state-icon" aria-hidden="true">!</span><h3>Unable to load this section</h3><p>${esc(message)}</p><button class="btn btn-secondary" data-retry>${esc(retryLabel)}</button></div>`;
}

export function successState(title, message, action = '') {
  return `<div class="state-card state-success"><span class="state-icon" aria-hidden="true">✓</span><h3>${esc(title)}</h3><p>${esc(message)}</p>${action}</div>`;
}

export function requiredMark(required = true) {
  return required ? '<span class="required" title="Required">*</span>' : '<span class="optional">Optional</span>';
}

export function option(value, label, selected = false, disabled = false) {
  return `<option value="${esc(value)}"${selected ? ' selected' : ''}${disabled ? ' disabled' : ''}>${esc(label)}</option>`;
}

export const SELECT_PLACEHOLDER = 'Select an option';

export function selectField({
  name, label, options = [], value = '', required = false, placeholder = SELECT_PLACEHOLDER,
  hint = '', id = '', multiple = false, className = '', disabled = false, attrs = ''
}) {
  const fieldId = id || `field-${name}`;
  const renderedOptions = [
    `<option value=""${!value ? ' selected' : ''}${required ? ' disabled' : ''}>${esc(placeholder)}</option>`,
    ...options.map((item) => {
      const v = typeof item === 'object' ? item.value : item;
      const l = typeof item === 'object' ? item.label : item;
      const d = typeof item === 'object' && item.disabled;
      return option(v, l, String(value) === String(v), d);
    })
  ].join('');
  return `<div class="form-field ${esc(className)}">
    <label for="${esc(fieldId)}">${esc(label)} ${requiredMark(required)}</label>
    <select id="${esc(fieldId)}" name="${esc(name)}" ${required ? 'required' : ''} ${multiple ? 'multiple' : ''} ${disabled ? 'disabled' : ''} ${attrs}>${renderedOptions}</select>
    ${hint ? `<small class="field-hint">${esc(hint)}</small>` : ''}
    <small class="field-error" aria-live="polite"></small>
  </div>`;
}

export function inputField({
  name, label, type = 'text', value = '', required = false, placeholder = '', hint = '',
  id = '', min = '', max = '', step = '', attrs = '', className = '', autocomplete = ''
}) {
  const fieldId = id || `field-${name}`;
  const attrsText = [
    min !== '' ? `min="${esc(min)}"` : '', max !== '' ? `max="${esc(max)}"` : '',
    step !== '' ? `step="${esc(step)}"` : '', autocomplete ? `autocomplete="${esc(autocomplete)}"` : '',
    attrs
  ].filter(Boolean).join(' ');
  return `<div class="form-field ${esc(className)}">
    <label for="${esc(fieldId)}">${esc(label)} ${requiredMark(required)}</label>
    <input id="${esc(fieldId)}" name="${esc(name)}" type="${esc(type)}" value="${esc(value ?? '')}" ${required ? 'required' : ''} placeholder="${esc(placeholder)}" ${attrsText} />
    ${hint ? `<small class="field-hint">${esc(hint)}</small>` : ''}
    <small class="field-error" aria-live="polite"></small>
  </div>`;
}

export function textareaField({
  name, label, value = '', required = false, placeholder = '', hint = '', rows = 4, id = '', className = '', attrs = ''
}) {
  const fieldId = id || `field-${name}`;
  return `<div class="form-field ${esc(className)}">
    <label for="${esc(fieldId)}">${esc(label)} ${requiredMark(required)}</label>
    <textarea id="${esc(fieldId)}" name="${esc(name)}" rows="${rows}" ${required ? 'required' : ''} placeholder="${esc(placeholder)}" ${attrs}>${esc(value ?? '')}</textarea>
    ${hint ? `<small class="field-hint">${esc(hint)}</small>` : ''}
    <small class="field-error" aria-live="polite"></small>
  </div>`;
}

export function checkboxField({ name, label, checked = false, value = 'true', hint = '', id = '', className = '' }) {
  const fieldId = id || `field-${name}`;
  return `<label class="checkbox-field ${esc(className)}" for="${esc(fieldId)}">
    <input id="${esc(fieldId)}" type="checkbox" name="${esc(name)}" value="${esc(value)}" ${checked ? 'checked' : ''} />
    <span>${esc(label)}</span>${hint ? `<small>${esc(hint)}</small>` : ''}
  </label>`;
}

export function radioGroup({ name, label, options = [], value = '', required = false, className = '' }) {
  return `<fieldset class="radio-group ${esc(className)}"><legend>${esc(label)} ${requiredMark(required)}</legend>
    <div class="radio-options">${options.map((item, i) => {
      const v = typeof item === 'object' ? item.value : item;
      const l = typeof item === 'object' ? item.label : item;
      return `<label><input type="radio" name="${esc(name)}" value="${esc(v)}" ${String(value) === String(v) ? 'checked' : ''} ${required && i === 0 ? 'required' : ''} /> <span>${esc(l)}</span></label>`;
    }).join('')}</div>
  </fieldset>`;
}

export function createSearchSelect({ items = [], value = '', name = '', label = '', placeholder = 'Search records…', required = false, onChange = null, disabled = false }) {
  const normalized = items.map((item) => ({
    value: String(item.value ?? ''),
    label: String(item.label ?? ''),
    meta: String(item.meta ?? ''),
    disabled: Boolean(item.disabled)
  }));
  const wrapper = el('div', { class: 'search-select', dataset: { name } });
  const hidden = el('input', { type: 'hidden', name, value, required, disabled });
  const input = el('input', { type: 'text', class: 'search-select-input', placeholder, autocomplete: 'off', role: 'combobox', 'aria-expanded': 'false', disabled });
  const list = el('div', { class: 'search-select-list', role: 'listbox', hidden: true });
  const help = el('small', { class: 'field-error', 'aria-live': 'polite' });
  const labelNode = label ? el('label', { class: 'search-select-label', text: label }) : null;
  if (labelNode) wrapper.append(labelNode);
  wrapper.append(hidden, input, list, help);

  function selectedItem() { return normalized.find((item) => item.value === hidden.value) || null; }
  function setText() {
    const item = selectedItem();
    input.value = item ? `${item.label}${item.meta ? ` — ${item.meta}` : ''}` : '';
  }
  function renderList(filter = '') {
    const needle = filter.trim().toLowerCase();
    const found = normalized.filter((item) => !needle || `${item.label} ${item.meta}`.toLowerCase().includes(needle));
    list.replaceChildren();
    if (!found.length) {
      list.append(el('div', { class: 'search-select-empty', text: 'No matching records.' }));
    } else {
      for (const item of found.slice(0, 80)) {
        const button = el('button', {
          type: 'button', class: `search-select-option${item.value === hidden.value ? ' is-selected' : ''}`,
          role: 'option', 'aria-selected': item.value === hidden.value ? 'true' : 'false',
          disabled: item.disabled,
          onClick: () => {
            if (item.disabled) return;
            hidden.value = item.value;
            setText();
            close();
            help.textContent = '';
            if (onChange) onChange(item.value, item);
          }
        }, el('span', { text: item.label }), item.meta ? el('small', { text: item.meta }) : null);
        list.append(button);
      }
    }
  }
  function open() { renderList(''); list.hidden = false; input.setAttribute('aria-expanded', 'true'); }
  function close() { list.hidden = true; input.setAttribute('aria-expanded', 'false'); }
  input.addEventListener('focus', open);
  input.addEventListener('input', () => { hidden.value = ''; renderList(input.value); list.hidden = false; });
  input.addEventListener('blur', () => setTimeout(close, 120));
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') close();
    if (event.key === 'Enter') { event.preventDefault(); open(); }
  });
  wrapper.setValue = (next) => { hidden.value = String(next ?? ''); setText(); };
  wrapper.getValue = () => hidden.value;
  wrapper.setItems = (next) => {
    normalized.splice(0, normalized.length, ...next.map((item) => ({
      value: String(item.value ?? ''), label: String(item.label ?? ''), meta: String(item.meta ?? ''), disabled: Boolean(item.disabled)
    })));
    setText();
  };
  wrapper.validate = () => {
    const ok = !required || Boolean(hidden.value);
    help.textContent = ok ? '' : 'Select an option';
    input.classList.toggle('invalid', !ok);
    return ok;
  };
  setText();
  return wrapper;
}

export function formData(form) {
  const data = {};
  for (const [key, value] of new FormData(form).entries()) {
    if (Object.prototype.hasOwnProperty.call(data, key)) {
      data[key] = Array.isArray(data[key]) ? [...data[key], value] : [data[key], value];
    } else data[key] = value;
  }
  return data;
}

export function csvEscape(value) {
  const text = value === null || value === undefined ? '' : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
