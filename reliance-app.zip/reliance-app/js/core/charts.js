// Dependency-free inline SVG charts. All values come from live Supabase RPCs.
import { esc, emptyState } from './dom.js';

export const PALETTE = ['#0a4fa0', '#d62828', '#2477d6', '#b7791f', '#16875a', '#6366f1', '#64748b'];

function niceMax(value) {
  if (!Number.isFinite(value) || value <= 0) return 1;
  const magnitude = 10 ** Math.floor(Math.log10(value));
  const normalized = value / magnitude;
  const step = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10;
  return step * magnitude;
}

export function lineChart({ labels = [], series = [], height = 230, emptyMessage = 'No values were recorded for this period.' }) {
  if (!labels.length || !series.length || series.every((s) => !s.values?.length)) return emptyState('No chart data', emptyMessage);
  const width = 720;
  const pad = { left: 46, right: 18, top: 18, bottom: 38 };
  const chartW = width - pad.left - pad.right;
  const chartH = height - pad.top - pad.bottom;
  const allValues = series.flatMap((s) => s.values.map(Number)).filter(Number.isFinite);
  const max = niceMax(Math.max(...allValues, 0));
  const pointsFor = (values) => values.map((v, i) => {
    const x = pad.left + (labels.length === 1 ? chartW / 2 : (i / (labels.length - 1)) * chartW);
    const y = pad.top + chartH - (Number(v || 0) / max) * chartH;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const grid = [0, 0.25, 0.5, 0.75, 1].map((ratio) => {
    const y = pad.top + chartH - ratio * chartH;
    return `<line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}" stroke="#E3EAF3" stroke-width="1"/><text x="${pad.left - 8}" y="${y + 4}" text-anchor="end" class="chart-label">${Math.round(ratio * max)}</text>`;
  }).join('');
  const xLabels = labels.map((label, i) => {
    const x = pad.left + (labels.length === 1 ? chartW / 2 : (i / (labels.length - 1)) * chartW);
    return `<text x="${x}" y="${height - 10}" text-anchor="middle" class="chart-label">${esc(String(label).slice(0, 10))}</text>`;
  }).join('');
  const lines = series.map((s, index) => `<polyline points="${pointsFor(s.values)}" fill="none" stroke="${s.color || PALETTE[index % PALETTE.length]}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>`).join('');
  const legend = `<div class="chart-legend">${series.map((s, i) => `<span><i style="background:${s.color || PALETTE[i % PALETTE.length]}"></i>${esc(s.name)}</span>`).join('')}</div>`;
  return `<div class="chart"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Line chart">${grid}${lines}${xLabels}</svg>${legend}</div>`;
}

export function barChart({ labels = [], values = [], color = PALETTE[0], height = 230, emptyMessage = 'No values were recorded for this period.' }) {
  if (!labels.length || !values.length) return emptyState('No chart data', emptyMessage);
  const width = 720;
  const pad = { left: 46, right: 18, top: 18, bottom: 44 };
  const chartW = width - pad.left - pad.right;
  const chartH = height - pad.top - pad.bottom;
  const max = niceMax(Math.max(...values.map(Number), 0));
  const barWidth = Math.min(42, (chartW / values.length) * 0.6);
  const grid = [0, 0.5, 1].map((ratio) => {
    const y = pad.top + chartH - ratio * chartH;
    return `<line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}" stroke="#E3EAF3"/><text x="${pad.left - 8}" y="${y + 4}" text-anchor="end" class="chart-label">${Math.round(ratio * max)}</text>`;
  }).join('');
  const bars = values.map((value, i) => {
    const x = pad.left + (i + 0.5) * (chartW / values.length) - barWidth / 2;
    const h = (Number(value || 0) / max) * chartH;
    const y = pad.top + chartH - h;
    return `<rect x="${x}" y="${y}" width="${barWidth}" height="${Math.max(h, 0)}" rx="3" fill="${color}"><title>${esc(labels[i])}: ${esc(value)}</title></rect><text x="${x + barWidth / 2}" y="${height - 14}" text-anchor="middle" class="chart-label">${esc(String(labels[i]).slice(0, 10))}</text>`;
  }).join('');
  return `<div class="chart"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Bar chart">${grid}${bars}</svg></div>`;
}

export function horizontalBars({ items = [], emptyMessage = 'No values were recorded for this period.' }) {
  if (!items.length) return emptyState('No chart data', emptyMessage);
  const max = niceMax(Math.max(...items.map((i) => Number(i.value || 0)), 0));
  return `<div class="hbar-chart">${items.map((item, index) => {
    const pct = Math.round((Number(item.value || 0) / max) * 100);
    return `<div class="hbar-row"><span class="hbar-label" title="${esc(item.label)}">${esc(item.label)}</span><div class="hbar-track"><div class="hbar-fill" style="width:${pct}%;background:${item.color || PALETTE[index % PALETTE.length]}"></div></div><strong>${esc(item.value ?? 0)}</strong></div>`;
  }).join('')}</div>`;
}

export function donutChart({ items = [], emptyMessage = 'No values were recorded for this period.' }) {
  const filtered = items.filter((i) => Number(i.value || 0) > 0);
  if (!filtered.length) return emptyState('No chart data', emptyMessage);
  const total = filtered.reduce((sum, i) => sum + Number(i.value || 0), 0);
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;
  const circles = filtered.map((item, index) => {
    const fraction = Number(item.value || 0) / total;
    const length = fraction * circumference;
    const circle = `<circle cx="80" cy="80" r="${radius}" fill="none" stroke="${item.color || PALETTE[index % PALETTE.length]}" stroke-width="24" stroke-dasharray="${length.toFixed(2)} ${(circumference - length).toFixed(2)}" stroke-dashoffset="${(-offset).toFixed(2)}" transform="rotate(-90 80 80)"><title>${esc(item.label)}: ${esc(item.value)}</title></circle>`;
    offset += length;
    return circle;
  }).join('');
  return `<div class="donut-wrap"><svg viewBox="0 0 160 160" class="donut" role="img" aria-label="Status distribution"><circle cx="80" cy="80" r="${radius}" fill="none" stroke="#EDF2F7" stroke-width="24"/>${circles}<text x="80" y="77" text-anchor="middle" class="donut-total">${esc(total)}</text><text x="80" y="96" text-anchor="middle" class="chart-label">records</text></svg>
    <ul class="donut-legend">${filtered.map((item, index) => `<li><i style="background:${item.color || PALETTE[index % PALETTE.length]}"></i><span>${esc(item.label)}</span><strong>${esc(item.value)}</strong></li>`).join('')}</ul></div>`;
}

export function chartCard({ title, subtitle = '', body, footnote = '', className = '' }) {
  return `<section class="card chart-card ${esc(className)}"><div class="card-header"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div></div>${body}${footnote ? `<p class="chart-footnote">${esc(footnote)}</p>` : ''}</section>`;
}
