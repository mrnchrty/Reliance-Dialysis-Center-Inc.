// Single Supabase client for all ES-module pages. Only the publishable key from
// /api/config reaches the browser; the service-role key is never used here.
import { createClient } from '../vendor/supabase.esm.js';
import { loadConfig } from './config.js';

let clientPromise = null;

export class ApiError extends Error {
  constructor(message, details = null) {
    super(message);
    this.name = 'ApiError';
    this.details = details;
  }
}

export async function getSupabase() {
  if (!clientPromise) {
    clientPromise = loadConfig().then((config) => createClient(config.supabaseUrl, config.publishableKey, {
      auth: {
        storageKey: 'reliance-auth-session',
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: 'pkce'
      },
      global: {
        headers: { 'X-Client-Info': 'reliance-web/1.0' }
      }
    })).catch((error) => {
      clientPromise = null;
      throw error;
    });
  }
  return clientPromise;
}

export async function rpc(name, args = {}) {
  const client = await getSupabase();
  const { data, error } = await client.rpc(name, args);
  if (error) throw new ApiError(error.message || 'Database request failed.', error);
  return data;
}

export async function select(builder) {
  const { data, error, count } = await builder;
  if (error) throw new ApiError(error.message || 'Unable to load records.', error);
  return count === null || count === undefined ? (data ?? []) : { data: data ?? [], count };
}

export async function mutate(builder) {
  const { data, error } = await builder;
  if (error) throw new ApiError(error.message || 'Unable to save changes.', error);
  return data;
}

export async function invokeAdminAccounts(action, payload = {}) {
  const client = await getSupabase();
  const { data, error } = await client.functions.invoke('admin-accounts', {
    body: { action, ...payload },
    headers: { 'Content-Type': 'application/json' }
  });
  if (error) throw new ApiError(error.message || 'Account administration request failed.', error);
  if (data?.error) throw new ApiError(data.error, data);
  return data;
}

export async function getSession() {
  const client = await getSupabase();
  const { data, error } = await client.auth.getSession();
  if (error) throw new ApiError(error.message || 'Unable to read the current session.', error);
  return data?.session ?? null;
}

export async function getUser() {
  const client = await getSupabase();
  const { data, error } = await client.auth.getUser();
  if (error) throw new ApiError(error.message || 'Unable to verify the current user.', error);
  return data?.user ?? null;
}

export async function onAuthStateChange(callback) {
  const client = await getSupabase();
  const { data } = client.auth.onAuthStateChange((event, session) => callback(event, session));
  return () => data?.subscription?.unsubscribe?.();
}
