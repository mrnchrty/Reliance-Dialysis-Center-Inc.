// Static FAQ assistant. It never diagnoses, prescribes, or recommends treatment changes.
import { $, $$, esc, el } from './dom.js';

const DISCLAIMER = 'I can help with accounts, booking, required documents, appointment tracking, and records. For medical advice or treatment changes, contact your provider or authorized Reliance center personnel.';

function answerFor(text) {
  const q = String(text || '').toLowerCase();
  if (/(diagnos|symptom|pain|medic|dose|treatment|prescrib|diet|fluid|blood pressure|kidney problem|what should i)/.test(q)) {
    return {
      text: 'I cannot diagnose, prescribe, or recommend treatment changes. Please contact your provider or authorized Reliance Dialysis Center personnel for any medical question.',
      action: null
    };
  }
  if (/(book|appointment|schedule|step|register|create account)/.test(q)) {
    return {
      text: 'The approved public sequence is: 1) create an account with your profile, 2) complete personal and medical profiles, 3) upload required documents, 4) request a schedule, and 5) wait for staff confirmation. Log in or register before booking.',
      action: { label: 'Open booking', section: 'book-appointment', href: '/public/auth.html?mode=register&redirect=%2Fpatient%2F' }
    };
  }
  if (/(document|upload|endorsement|abstract|laboratory|identification|id)/.test(q)) {
    return {
      text: 'Required categories are Nephrologist’s Endorsement, Medical Abstract, Latest Laboratory Results, and Valid Identification. Files must be PDF, JPEG, PNG, or WebP and no larger than 10 MB. Staff records verification; this assistant does not determine clinical validity.',
      action: { label: 'Open documents', section: 'my-records', href: null }
    };
  }
  if (/(status|track|confirm|pending|reschedul|cancel)/.test(q)) {
    return {
      text: 'Use Book Appointment to open your tracker. It shows the current appointment status, staff remarks, confirmed details, and status history from live records.',
      action: { label: 'Open tracker', section: 'book-appointment', href: null }
    };
  }
  if (/(record|history|session|weight|lab result)/.test(q)) {
    return {
      text: 'My Records has Medical Information, Submitted Documents, and Dialysis History. Only official session records released by authorized staff are visible to patients.',
      action: { label: 'Open records', section: 'my-records', href: null }
    };
  }
  if (/(password|forgot|reset|log in|login)/.test(q)) {
    return {
      text: 'Use Forgot Password on the Log In page. Supabase Auth sends a secure reset link; passwords are not stored in application tables.',
      action: { label: 'Reset password', section: null, href: '/public/auth.html?mode=forgot' }
    };
  }
  if (/(hour|open|sunday|monday|operating|contact|email|phone|address|location)/.test(q)) {
    return {
      text: 'Reference hours are Monday–Saturday, 8:00 AM–5:00 PM; Sunday is closed. Contact: redci.mabini@thebestrenalcare.com · 0969 161 3662 · Mabini Community Hospital, Sitio Mailayin, Barangay Pulong Niogan, Mabini, Batangas. Hours are subject to final center confirmation.',
      action: null
    };
  }
  return { text: DISCLAIMER, action: null };
}

export function renderChatbot(container, { onNavigate = null, compact = false } = {}) {
  if (!(container instanceof Element)) return null;
  container.className = `chatbot ${compact ? 'chatbot-compact' : ''}`;
  container.innerHTML = `
    <button type="button" class="chatbot-toggle" aria-expanded="false" aria-label="Open Reliance Assistant"><span aria-hidden="true">?</span><span class="chatbot-toggle-label">Reliance Assistant</span></button>
    <section class="chatbot-panel" hidden aria-label="Reliance Assistant FAQ">
      <header><div><strong>Reliance Assistant</strong><small>FAQ support · no medical advice</small></div><button type="button" class="icon-btn chatbot-close" aria-label="Close assistant">×</button></header>
      <div class="chatbot-messages" aria-live="polite"><p class="chatbot-bot">${esc(DISCLAIMER)}</p></div>
      <div class="chatbot-quick">
        <button type="button" data-question="How do I book an appointment?">How to book</button>
        <button type="button" data-question="What documents do I need?">Documents</button>
        <button type="button" data-question="Where is my appointment status?">Status</button>
        <button type="button" data-question="I have a medical question">Medical question</button>
      </div>
      <form class="chatbot-input"><label class="sr-only" for="chatbot-question">Ask a non-medical FAQ question</label><input id="chatbot-question" type="text" placeholder="Ask about booking, documents, or records" autocomplete="off" /><button type="submit" class="btn btn-primary" aria-label="Send question">Send</button></form>
    </section>`;
  const toggle = $('.chatbot-toggle', container);
  const panel = $('.chatbot-panel', container);
  const messages = $('.chatbot-messages', container);
  const form = $('.chatbot-input', container);
  const input = $('#chatbot-question', container);
  const close = () => { panel.hidden = true; toggle.setAttribute('aria-expanded', 'false'); };
  const open = () => { panel.hidden = false; toggle.setAttribute('aria-expanded', 'true'); input.focus(); };

  function addQuestion(question) {
    const answer = answerFor(question);
    messages.append(el('p', { class: 'chatbot-user', text: question }));
    const bot = el('p', { class: 'chatbot-bot', text: answer.text });
    messages.append(bot);
    if (answer.action) {
      const button = el('button', {
        type: 'button', class: 'chatbot-action', text: answer.action.label,
        onClick: () => {
          if (answer.action.href) location.href = answer.action.href;
          else if (answer.action.section && onNavigate) onNavigate(answer.action.section);
          else close();
        }
      });
      messages.append(button);
    }
    messages.scrollTop = messages.scrollHeight;
  }

  toggle.addEventListener('click', () => panel.hidden ? open() : close());
  $('.chatbot-close', container).addEventListener('click', close);
  $$('[data-question]', container).forEach((button) => button.addEventListener('click', () => addQuestion(button.dataset.question)));
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const question = input.value.trim();
    if (!question) return;
    addQuestion(question);
    input.value = '';
  });
  return { open, close, ask: addQuestion };
}
