// Local preview/development server for Reliance Dialysis Center Inc.
// Serves the static ES-module frontend and the same-origin /api/config endpoint.
// Production on Vercel uses api/config.js instead; this file is for local preview only.
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = __dirname;

// Minimal .env loader for local development. Real environment variables win.
const envPath = path.join(root, '.env');
if (existsSync(envPath)) {
  for (const line of readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const match = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/);
    if (!match) continue;
    const [, key, rawValue] = match;
    if (process.env[key] !== undefined) continue;
    let value = rawValue.trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    process.env[key] = value;
  }
}

const port = Number(process.env.PORT || 5500);
const host = process.env.HOST || '0.0.0.0';

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.pdf': 'application/pdf'
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(body);
}

function sendFile(res, filePath, req) {
  const ext = path.extname(filePath).toLowerCase();
  const type = mimeTypes[ext] || 'application/octet-stream';
  const isHtml = ext === '.html';
  const isCode = ['.js', '.mjs', '.css'].includes(ext);
  res.writeHead(200, {
    'Content-Type': type,
    // Scripts and styles are revalidated on every load so edits show up without a stale cache.
    'Cache-Control': isHtml ? 'no-store' : isCode ? 'no-cache' : 'public, max-age=3600',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin'
  });
  if (req.method === 'HEAD') return res.end();
  readFile(filePath).then((data) => res.end(data)).catch(() => {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Unable to read file.');
  });
}

async function resolveFile(urlPath) {
  const decoded = decodeURIComponent(urlPath);
  const normalized = path.posix.normalize(decoded);
  const candidate = path.join(root, normalized);
  if (!candidate.startsWith(root)) return null;

  try {
    const info = await stat(candidate);
    if (info.isFile()) return candidate;
    if (info.isDirectory()) {
      const index = path.join(candidate, 'index.html');
      try { await stat(index); return index; } catch { return null; }
    }
  } catch {
    // Try clean URL fallbacks below.
  }

  const withHtml = `${candidate}.html`;
  try { await stat(withHtml); return withHtml; } catch { /* ignore */ }
  const nestedIndex = path.join(candidate, 'index.html');
  try { await stat(nestedIndex); return nestedIndex; } catch { return null; }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (pathname === '/api/config') {
      const supabaseUrl = process.env.SUPABASE_URL || '';
      const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '';
      if (!supabaseUrl || !publishableKey) {
        return sendJson(res, 500, { error: 'Supabase URL and publishable key must be set in the server environment.' });
      }
      return sendJson(res, 200, { supabaseUrl, publishableKey });
    }

    if (pathname === '/api/health') return sendJson(res, 200, { ok: true, service: 'reliance-dialysis-center' });

    if (pathname === '/') {
      res.writeHead(302, { Location: '/public/index.html' });
      return res.end();
    }

    const cleanRedirects = new Map([
      ['/public', '/public/index.html'],
      ['/patient', '/patient/index.html'],
      ['/staff', '/staff/index.html'],
      ['/super-admin', '/super-admin/index.html']
    ]);
    if (cleanRedirects.has(pathname)) {
      res.writeHead(302, { Location: cleanRedirects.get(pathname) });
      return res.end();
    }

    const filePath = await resolveFile(pathname);
    if (!filePath) {
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('<!doctype html><title>Not found</title><h1>Not found</h1><p><a href="/public/index.html">Back to Reliance Dialysis Center</a></p>');
    }
    return sendFile(res, filePath, req);
  } catch (error) {
    return sendJson(res, 500, { error: 'Internal server error.' });
  }
});

server.listen(port, host, () => {
  console.log(`Reliance Dialysis Center local preview: http://${host}:${port}/public/index.html`);
});
